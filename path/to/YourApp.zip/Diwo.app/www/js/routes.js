angular.module('app.routes', ['ionicUIRouter'])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      /* 
    The IonicUIRouter.js UI-Router Modification is being used for this route.
    To navigate to this route, do NOT use a URL. Instead use one of the following:
      1) Using the ui-sref HTML attribute:
        ui-sref='tabsController.home'
      2) Using $state.go programatically:
        $state.go('tabsController.home');
    This allows your app to figure out which Tab to open this page in on the fly.
    If you're setting a Tabs default page or modifying the .otherwise for your app and
    must use a URL, use one of the following:
      /page1/tab1/page2
      /page1/tab4/page2
  */
  .state('tabsController.home', {
    url: '/page2',
    views: {
      'tab1': {
        templateUrl: 'templates/home.html',
        controller: 'homeCtrl'
      }
    }
  })
  .state('chathome', {
    url: '/chathome',

    templateUrl: 'templates/chathome.html',
    controller: 'chathomeCtrl'
      
  })
   .state('filtro', {
    url: '/page8',

    templateUrl: 'templates/filtro.html',
    controller: 'filtroCtrl'
      
    
  })

   .state('tabsController.eventofiltroEncerrado', {
    url: '/EFE',
    views: {
      'tab1': {
    templateUrl: 'templates/eventofiltroEncerrado.html',
    controller: 'eventofiltroEncerradoCtrl'
      }
    }
  })
   .state('tabsController.comentariosEFE', {
    url: '/comentariosEFE',
    views: {
          'tab1': {
    templateUrl: 'templates/comentariosEFE.html',
    controller: 'comentariosEFECtrl'
          }
        }
  })



    .state('tabsController.criandoEventoPart1', {
    url: '/page20',
     views: {
      'tab4': {
    templateUrl: 'templates/criandoEventoPart1.html',
    controller: 'criandoEventoPart1Ctrl'
        }
      }
  })
  
  .state('tabsController.criandoEventoPart2', {
    url: '/page21',
     views: {
      'tab4': {
    templateUrl: 'templates/criandoEventoPart2.html',
    controller: 'criandoEventoPart2Ctrl'
  }}
  })

  .state('tabsController.criandoEventoPart3', {
    url: '/page22',
     views: {
      'tab4': {
    templateUrl: 'templates/criandoEventoPart3.html',
    controller: 'criandoEventoPart3Ctrl'
  }}
  })

  .state('tabsController.criandoEventoPart4', {
    url: '/page23',
     views: {
      'tab4': {
    templateUrl: 'templates/criandoEventoPart4.html',
    controller: 'criandoEventoPart4Ctrl'
  }}
  })

    .state('tabsController.repeteEventoPart1', {
    url: '/page39',
     views: {
      'tab3': {
    templateUrl: 'templates/repeteEventoPart1.html',
    controller: 'repeteEventoPart1Ctrl'
        }
      }
  })
  
  .state('tabsController.repeteEventoPart2', {
    url: '/page221',
     views: {
      'tab3': {
    templateUrl: 'templates/repeteEventoPart2.html',
    controller: 'repeteEventoPart2Ctrl'
  }}
  })

  .state('tabsController.repeteEventoPart3', {
    url: '/page222',
     views: {
      'tab3': {
    templateUrl: 'templates/repeteEventoPart3.html',
    controller: 'repeteEventoPart3Ctrl'
  }}
  })

  .state('tabsController.repeteEventoPart4', {
    url: '/page223',
     views: {
      'tab3': {
    templateUrl: 'templates/repeteEventoPart4.html',
    controller: 'repeteEventoPart4Ctrl'
  }}
  })





  .state('tabsController.eventosAbertos', {
    url: '/page7',
    views: {
      'tab2': {
        templateUrl: 'templates/eventosAbertos.html',
        controller: 'eventosAbertosCtrl'
      }
    }
  })

   .state('tabsController.EditaEventoPart1', {
    url: '/page339',
     views: {
      'tab1': {
    templateUrl: 'templates/EditaEventoPart1.html',
    controller: 'EditaEventoPart1Ctrl'
        }
      }
  })
  
  .state('tabsController.EditaEventoPart2', {
    url: '/page3221',
     views: {
      'tab2': {
    templateUrl: 'templates/EditaEventoPart2.html',
    controller: 'EditaEventoPart2Ctrl'
  }}
  })

  .state('tabsController.EditaEventoPart3', {
    url: '/page3222',
     views: {
      'tab2': {
    templateUrl: 'templates/EditaEventoPart3.html',
    controller: 'EditaEventoPart3Ctrl'
  }}
  })

  .state('tabsController.EditaEventoPart4', {
    url: '/page3223',
     views: {
      'tab1': {
    templateUrl: 'templates/EditaEventoPart4.html',
    controller: 'EditaEventoPart4Ctrl'
  }}
  })



  .state('tabsController.perfil', {
    url: '/page4',
    views: {
      'tab3': {
        templateUrl: 'templates/perfil.html',
        controller: 'perfilCtrl'
      }
    }
  })


  .state('tabsController.convitescriar', {
    url: '/convitescriar',
    views: {
      'tab3': {
        templateUrl: 'templates/convitescriar.html',
        controller: 'convitescriarCtrl'
      }
    }
  })

  .state('tabsController.perfilFollow', {
    url: '/perfilFollow',
    views: {
      'tab3': {
        templateUrl: 'templates/perfilFollow.html',
        controller: 'perfilFollowCtrl'
      }
    }
  })

  .state('tabsController.comentarios', {
    url: '/page30',
    views: {
      'tab3': {
        templateUrl: 'templates/comentarios.html',
        controller: 'comentariosCtrl'
      }
    }
  })

  .state('tabsController.indice', {
    url: '/indice',
    views: {
      'tab3': {
        templateUrl: 'templates/indice.html',
        controller: 'indiceCtrl'
      }
    }
  })

   .state('tabsController.comentariosdosoutros', {
    url: '/comentariosdosoutros',
    views: {
      'tab2': {
        templateUrl: 'templates/comentariosdosoutros.html',
        controller: 'comentariosdosoutrosCtrl'
      }
    }
  })

  .state('tabsController.ranking', {
    url: '/ranking',
    views: {
      'tab3': {
    templateUrl: 'templates/ranking.html',
    controller: 'rankingCtrl'
      }
    }
  })

  .state('tabsController.nivelestrela', {
    url: '/nivelestrela',
    views: {
      'tab3': {
    templateUrl: 'templates/nivelestrela.html',
    controller: 'nivelestrelaCtrl'
      }
    }
  })

  .state('tabsController.infoestrela', {
    url: '/infoestrela',
    views: {
      'tab3': {
        templateUrl: 'templates/infoestrela.html',
        controller: 'infoestrelaCtrl'
      }
    }
  })

   .state('tabsController.sigo', {
    url: '/page26',
     views: {
      'tab3': {
    templateUrl: 'templates/sigo.html',
    controller: 'sigoCtrl'
    }}
  })

  .state('tabsController.eventoFechado', {
    url: '/page13',
          views: {
          'tab3': {
        templateUrl: 'templates/eventoFechado.html',
        controller: 'eventoFechadoCtrl'
      }
    }
  })

  .state('tabsController.chatfechado', {
    url: '/chatfechado',
    views: {
      'tab3': {
    templateUrl: 'templates/chatfechado.html',
    controller: 'chatfechadoCtrl'
      }
    }
  })

   .state('tabsController.comentRiosEvento', {
    url: '/page29',
    views: {
          'tab3': {
    templateUrl: 'templates/comentRiosEvento.html',
    controller: 'comentRiosEventoCtrl'
          }
        }
  })

  .state('tabsController.avaliaODoUsuario', {
    url: '/Avaliausuario',
    views: {
          'tab3': {
    templateUrl: 'templates/avaliaODoUsuario.html',
    controller: 'avaliaODoUsuarioCtrl'
   }}
  })

  .state('tabsController.avaliaODoEvento', {
    url: '/page25',
    views: {
          'tab3': {
    templateUrl: 'templates/avaliaODoEvento.html',
    controller: 'avaliaODoEventoCtrl'
    }}
  })
  

   .state('tabsController.eventoCriado', {
    url: '/page12',
     views: {
          'tab3': {
        templateUrl: 'templates/eventoCriado.html',
        controller: 'eventoCriadoCtrl'
      }
    }
  })

   .state('tabsController.perfil_outro_evento_criados', {
    url: '/page40',
    views: {
      'tab3': {
        templateUrl: 'templates/perfil_outro_evento_criados.html',
        controller: 'perfil_outro_evento_criadosCtrl'
      }
    }
  })

    .state('tabsController.comentariosdosoutrosnoperfil', {
    url: '/comentariosdosoutrosnoperfil',
    views: {
      'tab3': {
        templateUrl: 'templates/comentariosdosoutrosnoperfil.html',
        controller: 'comentariosdosoutrosnoperfilCtrl'
      }
    }
  })

   .state('tabsController.evento_do_eventoCriados_do_outro', {
    url: '/page41',
    views: {
      'tab3': {
        templateUrl: 'templates/evento_do_eventoCriados_do_outro.html',
        controller: 'evento_do_eventoCriados_do_outroCtrl'
      }
    }
  })

  .state('tabsController.evento_do_eventoAbertos', {
    url: '/evento_do_eventoAbertos',
    views: {
      'tab2': {
        templateUrl: 'templates/evento_do_eventoAbertos.html',
        controller: 'evento_do_eventoAbertosCtrl'
      }
    }
  })

  .state('tabsController.EditEv', {
    url: '/EditEv',
     views: {
      'tab2': {
    templateUrl: 'templates/EditEv.html',
    controller: 'EditEvCtrl'
  }}
  })

  .state('tabsController.EditaEEAPart1', {
    url: '/editaeeap1',
     views: {
      'tab1': {
    templateUrl: 'templates/EditaEEAPart1.html',
    controller: 'EditaEEAPart1Ctrl'
        }
      }
  })
  
  .state('tabsController.EditaEEAPart2', {
    url: '/editaeeap2',
     views: {
      'tab1': {
    templateUrl: 'templates/EditaEEAPart2.html',
    controller: 'EditaEEAPart2Ctrl'
  }}
  })

  .state('tabsController.EditaEEAPart3', {
    url: '/editaeeap3',
     views: {
      'tab1': {
    templateUrl: 'templates/EditaEEAPart3.html',
    controller: 'EditaEEAPart3Ctrl'
  }}
  })

  .state('tabsController.EditaEEAPart4', {
    url: '/editaeeap4',
     views: {
      'tab2': {
    templateUrl: 'templates/EditaEEAPart4.html',
    controller: 'EditaEEAPart4Ctrl'
  }}
  })


  .state('tabsController.chat', {
    url: '/chat',
    views: {
      'tab2': {
    templateUrl: 'templates/chat.html',
    controller: 'chatCtrl'
      }
    }
  })


  .state('tabsController.ver_onde_mapa_Eventoabertos', {
    url: '/ver_onde_mapa_Eventoabertos',
     views: {
      'tab2': {
    templateUrl: 'templates/ver_onde_mapa_Eventoabertos.html',
    controller: 'ver_onde_mapa_EventoabertosCtrl'
  }}
  })

    .state('tabsController.evento_do_eventoAbertos_do_outro', {
    url: '/evento_do_eventoAbertos_do_outro',
    views: {
      'tab2': {
        templateUrl: 'templates/evento_do_eventoAbertos_do_outro.html',
        controller: 'evento_do_eventoAbertos_do_outroCtrl'
      }
    }
  })

   .state('tabsController.perfil_outro_eventoabertos', {
    url: '/page19',
    views: {
      'tab2': {
        templateUrl: 'templates/perfil_outro_eventoabertos.html',
        controller: 'perfil_outro_eventoabertosCtrl'
      }
    }
  })

   

   .state('tabsController.eventoAberto', {
    url: '/page10',
    views: {
      'tab1': {
        templateUrl: 'templates/eventoAberto.html',
        controller: 'eventoAbertoCtrl'
      }
    }
  })

   .state('tabsController.eventoPinzado', {
    url: '/eventoPinzado',
    views: {
      'tab2': {
        templateUrl: 'templates/eventoPinzado.html',
        controller: 'eventoPinzadoCtrl'
      }
    }
  })

   .state('tabsController.ver_onde_mapa', {
    url: '/ver_onde_mapa',
     views: {
      'tab1': {
    templateUrl: 'templates/ver_onde_mapa.html',
    controller: 'ver_onde_mapaCtrl'
  }}
  })

   .state('tabsController.perfilOutro', {
    url: '/page14',
    views: {
      'tab1': {
        templateUrl: 'templates/perfilOutro.html',
        controller: 'perfilOutroCtrl'
      }
    }
  })

   .state('tabsController.comentariosperfiloutros', {
    url: '/comentariosperfiloutros',
    views: {
      'tab1': {
        templateUrl: 'templates/comentariosperfiloutros.html',
        controller: 'comentariosperfiloutrosCtrl'
      }
    }
  })

   

      .state('tabsController.editarPerfil', {
    url: '/editarperfil',
    views: {
      'tab3': {
        templateUrl: 'templates/editarPerfil.html',
        controller: 'editarPerfilCtrl'
      }
    }
  })

           .state('tabsController.notificaEs', {
    url: '/page11',
    views: {
      'tab1': {
        templateUrl: 'templates/notificaEs.html',
        controller: 'notificaEsCtrl'
      }
    }
  })

  .state('geral', {


    url: '/geral',

        templateUrl: 'templates/geral.html',
        controller: 'geralCtrl'
    
    
  })

  .state('tabsController.sobre', {
    url: '/sobre',
    views: {
      'tab1': {
        templateUrl: 'templates/sobre.html',
        controller: 'sobreCtrl'
      }
    }
  })

  .state('qmFoiMesmo', {
    url: '/page27',
    templateUrl: 'templates/qmFoiMesmo.html',
    controller: 'qmFoiMesmoCtrl'
  })
  

        .state('perfilAceitar', {
    url: '/page17',
    templateUrl: 'templates/perfilAceitar.html',
    controller: 'perfilAceitarCtrl'
  })

             .state('perfilAceitarGeral', {
    url: '/perfilAceitarGeral',
    templateUrl: 'templates/perfilAceitarGeral.html',
    controller: 'perfilAceitarGeralCtrl'
  })
             
.state('comentariosperfilaceitargeral', {
    url: '/comentariosperfilaceitargeral',
    templateUrl: 'templates/comentariosperfilaceitargeral.html',
    controller: 'comentariosperfilaceitargeralCtrl'
   
  })
  .state('logando', {
    url: '/logando',
    templateUrl: 'templates/login.html',
    controller: 'loginCtrl'
  })

  .state('nomeuser', {
    url: '/nomeuser',
    templateUrl: 'templates/username.html',
    controller: 'nomeuserCtrl'
  })
  

  .state('comentariosperfilaceitar', {
    url: '/comentariosperfilaceitar',

        templateUrl: 'templates/comentariosperfilaceitar.html',
        controller: 'comentariosperfilaceitarCtrl'
   
  })

  .state('tabsControllersemlogin.homesemlogin', {
    url: '/homesemlogin',
    views: {
      'tab1semlogin': {
        templateUrl: 'templates/homesemlogin.html',
        controller: 'homesemloginCtrl'
      }
    }
  })

  .state('tabsControllersemlogin', {
    url: '/tabsControllersemlogin',
    templateUrl: 'templates/tabsControllersemlogin.html',
    abstract:true
  })

  .state('tabsController', {
    url: '/page1',
    templateUrl: 'templates/tabsController.html',
    abstract:true
  })
  .state('new', {
    url: '/new',

    templateUrl: 'templates/new.html',
    controller: 'newCtrl'
      
    
  })




//$urlRouterProvider.otherwise('/new')
$urlRouterProvider.otherwise('/tabsControllersemlogin/homesemlogin')


});