angular.module('app.controllers', ['ngCordova','ion-datetime-picker','chart.js','ionic-ratings'])
  
.controller('newCtrl', ['$scope', '$stateParams', '$state', 'EventoService', '$cordovaCamera', '$cordovaFile', '$cordovaFileTransfer', '$cordovaDevice', '$ionicPopup', '$cordovaActionSheet','$ionicLoading','$http','formCodigo', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $state, EventoService, $cordovaCamera, $cordovaFile, $cordovaFileTransfer, $cordovaDevice, $ionicPopup, $cordovaActionSheet,$ionicLoading,$http,formCodigo) {
  $scope.user = {
    email: '',
    username: '',
    password: '',
    apelido: '',
    idade: '',
    genero: 'masc',
    profilepic: '',
    devicetoken: '123'
  };
  $scope.codigo = formCodigo.getForm();
  $scope.imgURI = "img/pessoasn/perfil.png";
  $scope.codd = false;

    var username;
    var password;
    var personalname;
    var poolData;
    var nickname;

    
    var header = document.getElementById("barsexo");
    var btns = header.getElementsByClassName("btnsex");
    for (var i = 0; i < btns.length; i++) {
      btns[i].addEventListener("click", function() {
        var current = document.getElementsByClassName("act");
        current[0].className = current[0].className.replace(" act", "");
        this.className += " act";
      });
    }
    $scope.macho = function() {$scope.user.genero = 'masc'};
    $scope.femea = function() {$scope.user.genero = 'fem'};
    $scope.takePicture = function() {
      var optionsCamera = {
          quality : 100,
          destinationType : Camera.DestinationType.FILE_URL,
          sourceType : Camera.PictureSourceType.CAMERA,
          allowEdit : true,
          encodingType: Camera.EncodingType.JPEG,
          targetWidth: 640,
          targetHeight: 640,
          popoverOptions: CameraPopoverOptions,
          saveToPhotoAlbum: true
      };

      $cordovaCamera.getPicture(optionsCamera).then(function(imageData) {
          $scope.imgURI = imageData;
          
      }, function(err) {
      });
    }
    $scope.getPicture = function (optionsCamera) {
      var optionsCamera = {
            quality : 100,
            sourceType : 0,
            allowEdit : true,
            targetWidth: 640,
            targetHeight: 640
      };
      $cordovaCamera.getPicture(optionsCamera).then(function(imageData) {
        $scope.imgURI = imageData;
      }, function(err) {
        console.log(err);
      });
    };
    
  $scope.signup = function() {
      var palavrasnaousar = ["ALIAMBA", "ANUS", "BAGULIO"
      , "BANZA", "BARRUFO", "BECK", "BEQUE", "BOCETA"
      , "BOLAGATO", "BOQUETE", "BOLCAT", "BOSSETA", "BOSTANA", "BREXA", "BRIOCO", "BRONHA", "BUCA", "BUCETA"
      , "BUSSETA", "CANABIS", "CANNABIS", "CARALHO"
      , "CASSETA", "CASSETE", "CHECHECA", "CHERECA", "CHIBUMBA", "CHIBUMBO", "CHOTA", "CHOCHOTA", "CHUPADA", "CHUPADO", "CLITORIS"
      , "COCAINA", "C+"
      , "C*", "CURALHO", "CUZAO", "CUZUDA", "CUZUDO", "CUZÃO", "ESPORRADA", "ESPORRADO", "ESPORRO", "estupro"
      , "FELACAO", "FELACÃO", "FODA", "FODAO", "FODÃO", "FODAUM", "FODE", "FODIDA", "FODIDO", "FORNICA", "FUDENDO", "FUDECÃO", "FUDECAO"
      , "FUDIDA", "FUDIDO", "GRELINHO", "GRELO", "ISCROTA", "ISCROTO", "MACONHA", "MASTURBA", "MASTURBAÇÃO", "MASTURBACÃO", "MASTURBACAO"
      , "PENIS", "PEN1S", "PENES", "PENIZ", "PICA", "PIROCA", "PIRU", "PORRA", "POURRA", "PROSTIBULO", "PUTA", "PUNHETA", "PUTO"
      , "RABAO", "TESTUDA", "TESTUDO", "VAGABUNDA", "VAGINA", "VIADO", "VIADAO", "VIADÃO", "XAVASCA", "XERERECA", "XEXECA", "XOTA"
      , "XOCHOTA", "XOXOTA", "XANA", "XANINHA", "MDMA", "VSF", "TNC", "FDP", "CRACK"];
      var error = 0; 
      for (var i = 0; i < palavrasnaousar.length; i++) {
        var res2 = $scope.user.username.split("_") ;
        if(res2.length>1){
          for(var w = 0; w < res2.length; w++){
            var val = palavrasnaousar[i].toLowerCase();
            if ((res2[w].toLowerCase()).indexOf(val.toString()) > -1) {  
              error = error + 1;  
            }
          }
        }else{
          var val = palavrasnaousar[i].toLowerCase();  
          if (($scope.user.username.toLowerCase()).indexOf(val.toString()) > -1) {  
            error = error + 1;  
          }
        }   
      } 
      if (error > 0) {  
          var alertPopup = $ionicPopup.alert({
                title: '（・о・；）',
                template: 'Que boquinha suja eim, usaste uma palavra inapropriada né'
              }); 
      }else{  
        if($scope.user.password.length<8){
           var alertPopup = $ionicPopup.alert({
            title: '=//',
            template: 'Senha muito curta'
          });
        }else{
          if($scope.user.idade.valueOf() < 18 ){
         var alertPopup = $ionicPopup.alert({
            title: '=//',
            template: 'Você é muito novo para usar o app'
          });
        }else{
          if ($scope.user.email == '' || $scope.user.username == '' || $scope.user.password == '' || $scope.user.idade == '' ) {
            var alertPopup = $ionicPopup.alert({
              title: 'Campos incompletos',
              template: 'Favor preencher todos os campos de acordo!!'
            });
          }else{
            var res = $scope.user.username.split(" ") ;
            if(res.length>1){
              var alertPopup = $ionicPopup.alert({
                title: 'Username inválido',
                template: 'Não pode haver "espaço" no seu username'
              });
            }else{
              if ($scope.user.password != $scope.user.password2) {
                var alertPopup = $ionicPopup.alert({
                  title: 'ʕノ•ᴥ•ʔノ ︵ ┻━┻',
                  template: 'Senha não bate com a outra'
                });
              }else{
                if($scope.imgURI == "img/pessoasn/perfil.png"){
                  var alertPopup = $ionicPopup.alert({
                    title: '(*ﾟｰﾟ)ゞ',
                    template: 'Tire uma foto para as pessoas saberem quem tu é quando for conhecer elas'
                  });
                }else{

                EventoService.verificausername($scope.user).then(function(result) {
                   if(result.success==false){
                    var alertPopup = $ionicPopup.alert({
                            title: 'ಠ_ಠ',
                            template: 'Ja tem alguem com esse username'
                          });
                   }else{
                $scope.user.apelido = $scope.user.username;
                poolData = {
                    UserPoolId : 'us-east-1_nOWA67ADf', // Your user pool id here
                    ClientId : '8k5rbqhifi5r1hb2j4n1u07li'// Your client id here
                  };    
                var userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);

                var attributeList = [];
                
                var dataEmail = {
                  Name : 'email', 
                  Value : $scope.user.email, //get from form field
                };
                
                var dataPersonalName = {
                  Name : 'gender', 
                  Value : $scope.user.genero, //get from form field
                };

                var dataPersonalNickname = {
                  Name : 'nickname', 
                  Value : $scope.user.username, //get from form field
                };

                var attributeEmail = new AmazonCognitoIdentity.CognitoUserAttribute(dataEmail);
                var attributePersonalName = new AmazonCognitoIdentity.CognitoUserAttribute(dataPersonalName);
                var attributePersonalNickname = new AmazonCognitoIdentity.CognitoUserAttribute(dataPersonalNickname);
                
                attributeList.push(attributeEmail);
                attributeList.push(attributePersonalName);
                attributeList.push(attributePersonalNickname);
                console.log($scope.user)
               
                userPool.signUp($scope.user.email, $scope.user.password, attributeList, null, function(err, result){
                  if (err) {
                    console.log("ja existe", err.message)
                    if(err.message == "Password did not conform with policy: Password must have uppercase characters"){
                      var alertPopup = $ionicPopup.alert({
                      title: '(҂⌣̀_⌣́)',
                      template: 'Senha precisa ter caracter em maiúsculo'
                    });
                    }
                    if(err.message == "Password did not conform with policy: Password must have lowercase characters"){
                      var alertPopup = $ionicPopup.alert({
                      title: '(ꐦ ಠ皿ಠ )',
                      template: 'Senha precisa ter caracter em minúsculo'
                    });
                    }
                    if(err.message == "Password did not conform with policy: Password not long enough"){
                      var alertPopup = $ionicPopup.alert({
                      title: '(ﾒﾟ皿ﾟ)',
                      template: 'Senha precisa ter 8 caracteres no mínimo'
                    });
                    }
                    if(err.message == "Password did not conform with policy: Password must have numeric characters"){
                      var alertPopup = $ionicPopup.alert({
                        title: '(¬_¬)',
                        template: 'Senha precisa ter número'
                      });
                    }
                    if(err.message == "User already exists"){
                      var alertPopup = $ionicPopup.alert({
                        title: 'ಠ_ಠ',
                        template: 'Ja existe uma conta vinculada a esse email'
                      });
                    }
                    // var alertPopup = $ionicPopup.alert({
                    //   title: 'ಠ_ಠ',
                    //   template: 'Ja existe uma conta vinculada a esse email ou username'
                    // });
                    return;
                  }
                  cognitoUser = result.user;
                  $scope.cognito = result.user;
                  console.log('user name is ' + cognitoUser.getUsername());
                  //change elements of page
                    $ionicPopup.prompt({
                              title: 'Confirmação de email',
                              template: 'Verifique em seu email e escreva aqui o número para validação da sua conta',
                             inputType: 'text',
                             inputPlaceholder: 'XXXXXX'
                           }).then(function(confi) {
                            cognitoUser.confirmRegistration(confi, true, function(err, result) {
                              if (err) {
                                $scope.codd = true;
                                  return;
                                }
                                if(result == "SUCCESS"){
                                  EventoService.confereconvite($scope.codigo).then(function(resp) {
                                    var currentdate = new Date();
                                    currentdate.setDate(currentdate.getDate() - 7);
                                    var curr_date = (currentdate.getDate()<10?'0':'') + currentdate.getDate();
                                    var curr_month = (currentdate.getMonth()<10?'0':'') + (currentdate.getMonth() + 1); 
                                    var curr_year = currentdate.getFullYear();
                                    var h2 = (currentdate.getHours()<10?'0':'') + currentdate.getHours();
                                    var m2 = (currentdate.getMinutes()<10?'0':'') + currentdate.getMinutes();
                                    var j = curr_year + "-" + curr_month + "-" + curr_date+ ' '+h2 + ':' + m2 + ':00';
                                    console.log(j, resp[0].codigodatacriacao)
                                    if(resp[0].codigodatacriacao > j){
                                      resp[0].numcodigo = parseInt(resp[0].numcodigo) + 1
                                      console.log(resp[0].numcodigo)
                                      $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/somanumcodigo.php', {iduser : resp[0].iduser,
                                                                                                            numcodigo : resp[0].numcodigo});
                                    }
                                });
                                  var mystring = String($scope.user.email);
                                  mystring = mystring.replace(/[^a-zA-Z0-9]/g, '');
                                      $scope.user.profilepic = 'https://s3.amazonaws.com/diwoappprofilepics/profilepicsdiwo/' + mystring + '.jpg';
                                         
                                        //EventoService.CriaConta($scope.user);
                                        EventoService.CriaConta($scope.user).then(function(result) {
                                          if(result.success){
                                            var url = "http://ec2-3-84-65-68.compute-1.amazonaws.com/upload.php";
                                            // File for Upload
                                            var targetPath = $scope.imgURI;
                                           
                                            // File name only
                                            //var name = $scope.imgURI.substr(imageData.lastIndexOf('/') + 1);
                                            var filename = mystring + '.jpg';

                                            // NO CASO SERIA O NOME DO USUARIO.jpg O fileName
                                            var options = {
                                              fileKey: "file",
                                              fileName: filename,
                                              chunkedMode: false,
                                              mimeType: "multipart/form-data"
                                            };
                                            $cordovaFileTransfer.upload(url, targetPath, options).then(function(result) {
                                              
                                              var alertPopup = $ionicPopup.alert({
                                                title: 'Parabéns',
                                                template: 'Sua conta esta habilitada'
                                              });
                                              alertPopup.then(function(){
                                                $state.go('logando');
                                              });
                                              
                                              $ionicLoading.hide();
                                            }, function(err) {
                                              $ionicPopup.alert({
                                                title: 'Sorry!',
                                                template: 'Aconteceu um probleminha, tente de novo'
                                              });
                                              $ionicLoading.hide();
                                            }, function (progress) {
                                              $ionicLoading.show({
                                                title: '┗(＾0＾)┓',
                                                template: 'DANCE, DANCE, DANCE!!'
                                              });
                                            });
                                          }
                                        });
                                      
                                }else{
                                  var alertPopup = $ionicPopup.alert({
                                      title: 'Código de confirmação incorreto',
                                      template: 'Verifique no seu email novamente o código de confirmação'
                                    });
                                  $scope.codd = true;
                                }
                            });
                    });
                  });       
                  }
                });
                }
              }
            }
          }
        }  
        }
        
      }  
  };
  $scope.ativa = function() {$scope.codd = true;};

  $scope.codigoconfirm = function(codigo) {
    if($scope.user.password.length<8){
      var alertPopup = $ionicPopup.alert({
        title: '=//',
        template: 'Senha muito curta'
      });
    }else{
      if($scope.user.idade.valueOf() < 18 ){
       var alertPopup = $ionicPopup.alert({
          title: '=//',
          template: 'Você é muito novo para usar o app'
        });
      }else{
        if ($scope.user.email == '' || $scope.user.username == '' || $scope.user.password == '' || $scope.user.idade == '' ) {
          var alertPopup = $ionicPopup.alert({
            title: 'Campos incompletos',
            template: 'Favor preencher todos os campos de acordo!!'
          });
        }else{
          var res = $scope.user.username.split(" ") ;
          if(res.length>1){
            var alertPopup = $ionicPopup.alert({
              title: 'Username inválido',
              template: 'Não pode haver "espaço" no seu username'
            });
          }else{
            if ($scope.user.password != $scope.user.password2) {
              var alertPopup = $ionicPopup.alert({
                title: 'ʕノ•ᴥ•ʔノ ︵ ┻━┻',
                template: 'Senha não bate com a outra'
              });
            }else{
              if($scope.imgURI == "img/pessoasn/perfil.png"){
                var alertPopup = $ionicPopup.alert({
                  title: '(*ﾟｰﾟ)ゞ',
                  template: 'Tire uma foto para as pessoas saberem quem tu é quando for conhecer elas'
                });
              }else{
                EventoService.verificausername($scope.user).then(function(result) {
                  if(result.success==false){
                    var alertPopup = $ionicPopup.alert({
                          title: 'ಠ_ಠ',
                          template: 'Ja tem alguem com esse username'
                    });
                  }else{
                  $scope.user.apelido = $scope.user.username;
                  if($scope.cognito){
                    cognitoUser.confirmRegistration(codigo, true, function(err, result) {
                      if (err) {
                          return;
                        }
                        console.log('call result: ' + result);
                        if(result == "SUCCESS"){
                          EventoService.confereconvite($scope.codigo).then(function(resp) {
                                    var currentdate = new Date();
                                    currentdate.setDate(currentdate.getDate() - 7);
                                    var curr_date = (currentdate.getDate()<10?'0':'') + currentdate.getDate();
                                    var curr_month = (currentdate.getMonth()<10?'0':'') + (currentdate.getMonth() + 1); 
                                    var curr_year = currentdate.getFullYear();
                                    var h2 = (currentdate.getHours()<10?'0':'') + currentdate.getHours();
                                    var m2 = (currentdate.getMinutes()<10?'0':'') + currentdate.getMinutes();
                                    var j = curr_year + "-" + curr_month + "-" + curr_date+ ' '+h2 + ':' + m2 + ':00';
                                    console.log(j, resp[0].codigodatacriacao)
                                    if(resp[0].codigodatacriacao > j){
                                      resp[0].numcodigo = parseInt(resp[0].numcodigo) + 1
                                      console.log(resp[0].numcodigo)
                                      $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/somanumcodigo.php', {iduser : resp[0].iduser,
                                                                                                            numcodigo : resp[0].numcodigo});
                                    }
                                });
                          var mystring = String($scope.user.email);
                                  mystring = mystring.replace(/[^a-zA-Z0-9]/g, '');
                          $scope.user.profilepic = 'https://s3.amazonaws.com/diwoappprofilepics/profilepicsdiwo/' + mystring + '.jpg';                         
                                                      //EventoService.CriaConta($scope.user);
                          EventoService.CriaConta($scope.user).then(function(result) {
                            if(result.success){

                              var url = "http://ec2-3-84-65-68.compute-1.amazonaws.com/upload.php";
                              // File for Upload
                              var targetPath = $scope.imgURI;
                             
                              // File name only
                              //var name = $scope.imgURI.substr(imageData.lastIndexOf('/') + 1);
                              var filename = mystring + '.jpg';

                              // NO CASO SERIA O NOME DO USUARIO.jpg O fileName
                              var options = {
                                fileKey: "file",
                                fileName: filename,
                                chunkedMode: false,
                                mimeType: "multipart/form-data"
                              };
                              $cordovaFileTransfer.upload(url, targetPath, options).then(function(result) {
                                
                                var alertPopup = $ionicPopup.alert({
                                  title: 'Parabéns',
                                  template: 'Sua conta esta habilitada'
                                });
                                alertPopup.then(function(){
                                  $state.go('logando');
                                });
                                
                                $ionicLoading.hide();
                              }, function(err) {
                                $ionicPopup.alert({
                                  title: 'Sorry!',
                                  template: 'Aconteceu um probleminha, tente de novo'
                                });
                                $ionicLoading.hide();
                              }, function (progress) {
                                $ionicLoading.show({
                                  title: '┗(＾0＾)┓',
                                  template: 'DANCE, DANCE, DANCE!!'
                                });
                              });
                            }
                          });
                        }else{
                          var alertPopup = $ionicPopup.alert({
                              title: 'Código de confirmação incorreto',
                              template: 'Verifique no seu email novamente o código de confirmação'
                            });
                        }
                    });
                  }else{
                    var alertPopup = $ionicPopup.alert({
                                                  title: 'Falta de dados',
                                                  template: 'Não foi possivel confirmar sua conta devido a algum problema com ela. Por favor tente recriar uma nova conta'
                                                });
                  }
                }
              });
              }
            }
          }
        }
      }
    }
  };

  $scope.Reenviar = function() {
    if($scope.cognito){
      cognitoUser.resendConfirmationCode(function(err, result) {
                if (err) {
                    //alert(err);
                    return;
                   }
                   var alertPopup = $ionicPopup.alert({
                    title: 'Deve ter chego',
                    template: 'Foi reenviado no seu email de cadastro outro código de validação, se nao chegou ainda, chegará'
                  });
            });
    }else{
      var alertPopup = $ionicPopup.alert({
                                    title: 'Falta de dados',
                                    template: 'Não foi possivel confirmar sua conta devido a algum problema com ela. Por favor tente recriar uma nova conta'
                                  });
    }
  };

}])

.controller('homesemloginCtrl', ['$scope', '$stateParams', 'EventoService', '$timeout',  '$state', '$ionicPopup','formUser', 'formLoc', '$http', 'formCodigo',   // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, EventoService, $timeout, $state,  $ionicPopup, formUser, formLoc, $http, formCodigo) {

  $scope.entra = function(){
    $state.go("logando");
  }

  $scope.entracodigo = function(){
    $scope.codigoconvite = {};
    $scope.codigoconvite.convite = '';
    // var currentdate = new Date();
    // currentdate.setDate(currentdate.getDate() - 7);
    // var curr_date = (currentdate.getDate()<10?'0':'') + currentdate.getDate();
    // var curr_month = (currentdate.getMonth()<10?'0':'') + (currentdate.getMonth() + 1); 
    // var curr_year = currentdate.getFullYear();
    // var h2 = (currentdate.getHours()<10?'0':'') + currentdate.getHours();
    // var m2 = (currentdate.getMinutes()<10?'0':'') + currentdate.getMinutes();
    // var j = curr_year + "-" + curr_month + "-" + curr_date+ ' '+h2 + ':' + m2 + ':00';
    // //var j =j.toLocaleString();
    // $scope.codigoconvite.hj = j;
    $ionicPopup.prompt({
        title: 'Insira código de acesso',
        template: 'Insira código de acesso',
       inputType: 'text',
       inputPlaceholder: 'código'
     }).then(function(codigoconvite) {
      $scope.codigoconvite.convite = codigoconvite
      console.log($scope.codigoconvite);
      EventoService.confereconvite(codigoconvite).then(function(resp) {
        console.log(resp.success, "fewe")
        if(resp.success == false){
          var alertPopup = $ionicPopup.alert({
            title: 'Código não bate',
            template: 'Ocorreu uma falha!!'
          });
        }else{
          if(resp[0].numcodigo > 4){
            $ionicPopup.prompt({
              title: 'Limite excedido',
              template: 'Opss! Parece que esse código atingiu seu limite de uso! Mas você pode colocar um email de contato abaixo que enviaremos um novo código para você assim que possível :) ',
              inputType: 'text',
              inputPlaceholder: 'email@email.com'
            }).then(function(emaildocara) {
              if(emaildocara){
                $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/pedeconvite.php', {namereportado : codigoconvite,
                                                                                    usernamereportando : emaildocara,
                                                                                    tiporeport : 'Limite excedido',
                                                                                    motivo : 'Limite excedido do convite'}).then(function (tes){
                  if(tes.data.success == true){
                    var alertPopup = $ionicPopup.alert({
                      title: 'Obrigado',
                      template: 'Fique de olho no seu email!!'
                    });
                  }else{
                    var alertPopup = $ionicPopup.alert({
                      title: 'Vish',
                      template: 'Ocorreu uma falha!!'
                    });
                  }
                });
              }
            });
          }else{
            formCodigo.updateForm(codigoconvite);
            $state.go("logando");
            // console.log(j, resp.codigodatacriacao)
            // if(resp.codigodatacriacao < j){
            //   $state.go("logando");
            // }else{
            //   resp.numcodigo = parseInt(resp.numcodigo) + 1
            //   console.log(resp.numcodigo)
            //   $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/somanumcodigo.php', {iduser : resp.iduser,
            //                                                                         numcodigo : resp.numcodigo}).then(function (tes){
            //     $state.go("logando");
            //   });
            // }
          }
        }
      })

    });
  }
  $scope.naotemcodigo = function(){
    $scope.ncodigoemail = '';
    $ionicPopup.prompt({
        title: 'Quer que te enviemos o código',
        template: 'Insira seu email a baixo que entraremos em contato com você para te enviar um código de acesso',
       inputType: 'text',
       inputPlaceholder: 'meuemail@email.com'
     }).then(function(ncodigoemail) {
      $scope.ncodigoemail = ncodigoemail
      console.log($scope.ncodigoemail)
      if(ncodigoemail){
        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/pedeconvite.php', {namereportado : $scope.ncodigoemail,
                                                                                    usernamereportando : $scope.ncodigoemail,
                                                                                    tiporeport : 'Sem convite',
                                                                                    motivo : 'Nao tenho convite e quero'}).then(function (tes){
          if(tes.data.success == true){
            var alertPopup = $ionicPopup.alert({
              title: 'Obrigado',
              template: 'Fique de olho no seu email!!'
            });
          }else{
            var alertPopup = $ionicPopup.alert({
              title: 'Vish',
              template: 'Ocorreu uma falha!!'
            });
          }
        });  
      }
    });
  }

  var user = JSON.parse( window.localStorage.getItem( 'user' ));
  if(user){
    formUser.updateForm(user);
    $state.go('tabsController.home');
  }
  

  var currentdate = new Date(); 
  var curr_date = (currentdate.getDate()<10?'0':'') + currentdate.getDate();
  var curr_h = (currentdate.getHours()<10?'0':'') + currentdate.getHours();
  

  var ft = 0;
  var ft2 = 0;
  var auxtes =0;
  $scope.amigo = {};
  $scope.lastidevento = 0;

  var pmin;
  var iddoevento;
  var lat;
  var long;
  var myLatlng;
  var spherical; 
  var north; 
  var west; 
  var south; 
  var east;
  var raio;

  $scope.items = [];
  $scope.items.eventopic = '';
  $scope.vezes = 0;
  $scope.faltatempo = [];
  $scope.newItems = [];
  $scope.noMoreItemsAvailable = false;
  $scope.semfeed = false;
  $scope.semloc = false;

  $scope.lastidevento = 0;
  $scope.aux = 0;
  $scope.participantes =[];
  $scope.participantesid = [];
  $scope.auxitems ={};

 
 
  $scope.user = {};
    // if (!$scope.user.northlat) {
    //       $scope.user.northlat = -27;
    //       $scope.user.southlat = -28;
    //       $scope.user.westlng = -49;
    //       $scope.user.eastlng = -48;
    //       console.log("peaga")
    // }
    navigator.geolocation.getCurrentPosition(function(position){
      console.log("to aqui")
      raio = 50000*0.71;
      lat  = position.coords.latitude;
      long = position.coords.longitude;
      $scope.user.lat =  position.coords.latitude;
      $scope.user.long =  position.coords.longitude;

      myLatlng = new google.maps.LatLng(lat, long);
      spherical = google.maps.geometry.spherical; 
      north = spherical.computeOffset(myLatlng, raio, 0); 
      west  = spherical.computeOffset(myLatlng, raio, -90); 
      south = spherical.computeOffset(myLatlng, raio, 180); 
      east  = spherical.computeOffset(myLatlng, raio, 90);
      $scope.user.northlat = north.lat();
      $scope.user.westlng = west.lng();
      $scope.user.southlat = south.lat();
      $scope.user.eastlng = east.lng();
      formLoc.updateForm($scope.user);
    },function (error) { 
      if (error.code == error.PERMISSION_DENIED)
          console.log("you denied me :-(");
          $scope.semloc = true;
      });

    //EventoService.FinalizarEventos();
     var currentdate = new Date(); 
    var curr_date = (currentdate.getDate()<10?'0':'') + currentdate.getDate();
    var curr_month = (currentdate.getMonth()<10?'0':'') + (currentdate.getMonth() + 1); 
    var curr_year = currentdate.getFullYear();
    var h2 = (currentdate.getHours()<10?'0':'') + currentdate.getHours();
    var m2 = (currentdate.getMinutes()<10?'0':'') + currentdate.getMinutes();
    var j = curr_year + "-" + curr_month + "-" + curr_date+ ' '+h2 + ':' + m2 + ':00';
    j = j.toLocaleString();
    EventoService.paraenviarnoti(j).then(function(items) {
      if (items[0] != "E"){
        for(var i = 0 ; i<items.length ; i++){
          EventoService.paraenviarnoti2(items[i]);
        }
      }
    });

    EventoService.finalizarevts(j).then(function(items) {
      if (items[0] != "E"){
        for(var i = 0 ; i<items.length ; i++){
          EventoService.finalizarevts2(items[i]);
        }
      }
    });
    EventoService.finalizarsemppl1(j).then(function(items) {
      if (items[0] != "E"){
        for(var i = 0 ; i<items.length ; i++){
          EventoService.finalizarsemppl2(items[i]);
        }
      }
    });

    $scope.$on("$ionicView.enter", function(event, data){
      $scope.noMoreItemsAvailable = false;
      $scope.semfeed = false;
      $scope.semloc = false;
      $scope.items = [];
      $scope.items.eventopic = '';
      $scope.eventocomconhecido =[];
      $scope.eventocomconhecidoidevento =[];
      $scope.participantes =[];
      $scope.participantesid = [];
      var user = JSON.parse( window.localStorage.getItem( 'user' ));
      if(user){
        formUser.updateForm(user);
        $state.go('tabsController.home');
      }
      if (lat){
        console.log("tem lat", $scope.user, lat, $scope.user.northlat)
        EventoService.GetFeedSemLogin($scope.user).then(function(items) {
          if (items != 'E'){
            $scope.semfeed = false;
            ft2 = 0;
            for(var i = 0 ; i<items.length ; i++){
              if(items[i].zone ==  'red' && parseInt(items[i].pmin)> parseInt(items[i].patual) && items[i].estado == '0'){
                 EventoService.Cancelarevento(items[i]);
                console.log('Falta gente para o evento, mas como estamos na redzone vou cancelar', items[i].idevento ,items[i].pmin , items[i].patual);
              }
              // $scope.auxfoto = items[i].nomeevento + items[i].diainicio;
              // var mystring = String($scope.auxfoto);
              // mystring = mystring.replace(/[^a-zA-Z0-9]/g, '');
              // items[i].eventopic = 'https://s3.amazonaws.com/diwoappprofilepics/eventopicsdiwo/' + mystring + '.jpg';;   
            }
            $scope.items = items.concat($scope.items);
          }else{
            console.log("sem feed");
            $scope.semfeed = true;
          }
        }); 
      }else{
        navigator.geolocation.getCurrentPosition(function(position){
          raio = 50000*0.71;
          lat  = position.coords.latitude;
          long = position.coords.longitude;
          $scope.user.lat =  position.coords.latitude;
          $scope.user.long =  position.coords.longitude;

          myLatlng = new google.maps.LatLng(lat, long);
          spherical = google.maps.geometry.spherical; 
          north = spherical.computeOffset(myLatlng, raio, 0); 
          west  = spherical.computeOffset(myLatlng, raio, -90); 
          south = spherical.computeOffset(myLatlng, raio, 180); 
          east  = spherical.computeOffset(myLatlng, raio, 90); 
          $scope.user.northlat = north.lat();
          $scope.user.westlng = west.lng();
          $scope.user.southlat = south.lat();
          $scope.user.eastlng = east.lng();

          EventoService.GetFeedSemLogin($scope.user).then(function(items) {
            if (items != 'E'){
              $scope.semfeed = false;
              for(var i = 0 ; i<items.length ; i++){
                if(items[i].zone ==  'red' && parseInt(items[i].pmin) > parseInt(items[i].patual) && items[i].estado == '0'){
                  console.log('Falta gente para o evento, mas como estamos na redzone vou cancelar', items[i].idevento ,items[i].pmin , items[i].patual);
                  EventoService.Cancelarevento(items[i]);
                }
                // $scope.auxfoto = items[i].nomeevento + items[i].diainicio;
                // var mystring = String($scope.auxfoto);
                // mystring = mystring.replace(/[^a-zA-Z0-9]/g, '');
                // items[i].eventopic = 'https://s3.amazonaws.com/diwoappprofilepics/eventopicsdiwo/' + mystring + '.jpg';
              }
              $scope.items = items.concat($scope.items);
            }else{
              console.log("sem feed");
              $scope.semfeed = true;
            }
          });
        },function (error) { 
          if (error.code == error.PERMISSION_DENIED)
              $scope.semloc = true;
          });
        }  
      })

  $scope.enterItem =  function(item){
      var alertPopup = $ionicPopup.alert({
                        title: 'Baaahhh',
                        template: 'Para poder ver mais detalhes desse evento sem estar dentro da plataforma'
                      });
        // alertPopup.then(function(){
        //   $state.go('logando');
        // });
  }


}])

.controller('homeCtrl', ['$scope', '$stateParams','$http', 'EventoService', '$timeout', 'formItem', '$state', 'formUser', 'formtela', 'formtelaCriar', '$ionicLoading', 'formvimdofiltro', 'formvimdofiltroperfil', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $http, EventoService, $timeout, formItem,  $state, formUser, formtela, formtelaCriar, $ionicLoading, formvimdofiltro, formvimdofiltroperfil) {
 
  $scope.user = formUser.getForm();
  console.log($scope.user)
  var currentdate = new Date(); 
  var curr_date = (currentdate.getDate()<10?'0':'') + currentdate.getDate();
  var curr_h = (currentdate.getHours()<10?'0':'') + currentdate.getHours();
  $scope.devicetoken = window.localStorage.getItem( 'token' );
  $scope.mudatoken ={};
  if($scope.devicetoken != $scope.user.devicetoken){
    $scope.mudatoken.iduser = $scope.user.iduser;
    $scope.mudatoken.devicetoken = $scope.devicetoken;
    EventoService.Mudadevice($scope.mudatoken);
  }
  formtela.updateForm(0);
  $scope.auxtelacriar = formtelaCriar.getForm();

  var ft = 0;
  var ft2 = 0;
  var auxtes =0;
  var  deletou = 0;
  var followers = 0;
  $scope.amigo = {};
  $scope.lastidevento = 0;

  var pmin;
  var iddoevento;
  var lat;
  var long;
  var myLatlng;
  var spherical; 
  var north; 
  var west; 
  var south; 
  var east;
  var raio;
  // $ionicLoading.show({
  //   template: 'Carregando'
  // });
  $scope.items = [];
  $scope.vezes = 0;
  $scope.faltatempo = [];
  $scope.newItems = [];
  $scope.noMoreItemsAvailable = false;
  $scope.semfeed = false;
  $scope.semloc = false;

  $scope.lastidevento = 0;
  $scope.aux = 0;
  $scope.eventocomconhecido =[];
  $scope.eventocomconhecidoidevento =[];
  $scope.participantes =[];
  $scope.participantesid = [];
  $scope.tagsevento =[];
  $scope.auxitems ={};

 
  $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/getamigos.php", {iduser : $scope.user.iduser}).then(function(response) {
    $scope.amigo = response.data[0];
    followers =  response.data[0].length;
  });

    if(curr_date == 1 && curr_h == 11){
      if( $scope.user.atualizaestrela == 0 && $scope.user.atualizaestrela ){
        EventoService.AtualizaEstrela().then(function(response) {
          if(response){
            EventoService.AtualizaEstrelaPessoaevento();
          }
        });
      }
    }
    if(curr_date == 1 && curr_h==12  ){
       if($scope.user.atualizaestrela ==  1 ){
        EventoService.DesatulizaEstrela();
      }
    }

    // if (!$scope.user.northlat) {
    //       $scope.user.northlat = -27;
    //       $scope.user.southlat = -28;
    //       $scope.user.westlng = -49;
    //       $scope.user.eastlng = -48;
    // }
    navigator.geolocation.getCurrentPosition(function(position){
      raio = 50000*0.71;
      lat  = position.coords.latitude;
      long = position.coords.longitude;
      $scope.user.lat =  position.coords.latitude;
      $scope.user.long =  position.coords.longitude;

      myLatlng = new google.maps.LatLng(lat, long);
      spherical = google.maps.geometry.spherical; 
      north = spherical.computeOffset(myLatlng, raio, 0); 
      west  = spherical.computeOffset(myLatlng, raio, -90); 
      south = spherical.computeOffset(myLatlng, raio, 180); 
      east  = spherical.computeOffset(myLatlng, raio, 90);
      $scope.user.northlat = north.lat();
      $scope.user.westlng = west.lng();
      $scope.user.southlat = south.lat();
      $scope.user.eastlng = east.lng();
      formUser.updateForm($scope.user);
    },function (error) { 
          if (error.code == error.PERMISSION_DENIED)
                console.log("you denied me :-(");
              $scope.semloc = true;
          });

    //EventoService.FinalizarEventos();
    var currentdate = new Date(); 
    var curr_date = (currentdate.getDate()<10?'0':'') + currentdate.getDate();
    var curr_month = (currentdate.getMonth()<10?'0':'') + (currentdate.getMonth() + 1); 
    var curr_year = currentdate.getFullYear();
    var h2 = (currentdate.getHours()<10?'0':'') + currentdate.getHours();
    var m2 = (currentdate.getMinutes()<10?'0':'') + currentdate.getMinutes();
    var j = curr_year + "-" + curr_month + "-" + curr_date+ ' '+h2 + ':' + m2 + ':00';
    j = j.toLocaleString();
   

    EventoService.paraenviarnoti(j).then(function(items) {
      //console.log(items[0].idevento)
      if (items[0] != "E"){
        for(var i = 0 ; i<items.length ; i++){
          EventoService.paraenviarnoti2(items[i]);
        }
      }
    });
    EventoService.finalizarevts(j).then(function(items) {

      if (items[0] != "E"){
        for(var i = 0 ; i<items.length ; i++){
          EventoService.finalizarevts2(items[i]);
        }
      }
    });
    EventoService.finalizarsemppl1(j).then(function(items) {
      if (items[0] != "E"){
        for(var i = 0 ; i<items.length ; i++){
          EventoService.finalizarsemppl2(items[i]);
        }
      }
    });
    $scope.user.hj = j;
    EventoService.lastlogin($scope.user);
    
    $scope.nnoti = 0;
    $scope.temnoti = false;
    EventoService.GetNotificacoes1($scope.user).then(function(aux) {
      if(aux == "error"){
        $scope.temnoti = false;
      }else{
        $scope.nnoti = aux.nrow;
        if($scope.nnoti>0){
          $scope.temnoti = true;
        }else{
          $scope.temnoti = false;
        }
      }
    });

    $scope.$on("$ionicView.enter", function(event, data){
      $scope.user = formUser.getForm();
      $scope.noMoreItemsAvailable = false;
      $scope.semfeed = false;
      $scope.semloc = false;
      // $scope.auxtelacriar = formtelaCriar.getForm();
      // console.log($scope.auxtelacriar);
      $scope.items = [];
      $scope.eventocomconhecido =[];
      $scope.eventocomconhecidoidevento =[];
      $scope.participantes =[];
      $scope.participantesid = [];
      $scope.items.tagsevento = [];
      $scope.tagsevento =[];
      var hptag = 0;
      $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/getamigos.php", {iduser : $scope.user.iduser}).then(function(response) {
        $scope.amigo = response.data[0];
        followers =  response.data[0].length;
      });
      $scope.nnoti = 0;
      $scope.temnoti = false;
      EventoService.GetNotificacoes1($scope.user).then(function(aux) {
        if(aux == "error"){
          $scope.temnoti = false;
        }else{
          $scope.nnoti = aux.nrow;
          if($scope.nnoti>0){
            $scope.temnoti = true;
          }else{
            $scope.temnoti = false;
          }
        }
      });
      //formtelaCriar.updateForm(0); // 0 significa que ja foi atualizado o feed perante a criação de um evento novo
      if ($scope.user.northlat){
        console.log("tem lat", $scope.user, lat, $scope.user.northlat)
        EventoService.GetFeed($scope.user).then(function(items) {
          //$ionicLoading.hide();
          if (items != 'E'){
            $scope.semfeed = false;
            ft2 = 0;
            for(var i = 0 ; i<items.length ; i++){
                // $scope.auxfoto = items[i].nomeevento + items[i].diainicio;
                // var mystring = String($scope.auxfoto);
                // mystring = mystring.replace(/[^a-zA-Z0-9]/g, '');
                // items[i].eventopic = 'https://s3.amazonaws.com/diwoappprofilepics/eventopicsdiwo/' + mystring + '.jpg';

                       //  REDZONE com menos pessoas que o necessario, logo cancelo o evento e avisa todo mundo
              //console.log(items[i].zone , items[i].pmin , items[i].patual)
              if(items[i].zone ==  'red' && parseInt(items[i].pmin)> parseInt(items[i].patual) && items[i].estado == '0'){
                 EventoService.Cancelarevento(items[i]);
                console.log('Falta gente para o evento, mas como estamos na redzone vou cancelar', items[i].idevento ,items[i].pmin , items[i].patual);
              }
              // EventoService.Gettags(items[i].idevento).then(function(tags) {
              //   //console.log("ds")
              //   for(var tg1 =0; tg1<tags.length;tg1++){
              //     if($scope.items.tagsevento[ft2] !=undefined){
              //         $scope.items.tagsevento[ft2] = ($scope.items.tagsevento[ft2] + ' ' + tags[tg1].tag);
              //       }else{
              //         $scope.items.tagsevento[ft2] = (tags[tg1].tag);
              //       }
              //       console.log($scope.items.tagsevento[ft2], ft2)
              //   } 
              // });
              // hptag++;

              EventoService.GetParticipantes(items[i].idevento).then(function(tes) {
                for (var j = 0; j < tes.length; j++) {
                   if(tes[j].estado == '2'){
                    //$scope.participantes[ft2];
                    if($scope.participantesid[ft2] !=undefined){
                      $scope.participantesid[ft2] = tes[j].idevento;
                      $scope.participantes[ft2]++ ;
                    }else{
                      $scope.participantesid[ft2] = tes[j].idevento;
                      $scope.participantes[ft2] = 1;
                    }
                  }
                  for (var l = 0; l< followers;l++){
                    if (tes[j].iduser == $scope.amigo[l].iduserseguindo) {
                      if($scope.eventocomconhecidoidevento[ft2] !=undefined){
                        $scope.eventocomconhecidoidevento[ft2] = tes[j].idevento;
                        $scope.eventocomconhecido[ft2] = tes[j].apelido + ', '+ $scope.eventocomconhecido[ft2] ;
                      }else{
                        $scope.eventocomconhecidoidevento[ft2] = tes[j].idevento;
                        $scope.eventocomconhecido[ft2] = tes[j].apelido;
                      }
                     //console.log($scope.eventocomconhecidoidevento[ft2], $scope.eventocomconhecido[ft2] , ft2)
                    }
                  }
                }
                ft2++;
                console.log(ft2)
                if(ft2==items.length){
                  for(var t = 0; t<ft2;t++){
                    for(var r = 0; r<ft2;r++){
                      if (items[t].idevento == $scope.eventocomconhecidoidevento[r]) {
                         items[t].amigo =  'Q vai e sigo: '+$scope.eventocomconhecido[r];
                         // console.log(items[t].idevento, t ,items[t].amigo );
                      }
                      if (items[t].idevento == $scope.participantesid[r]) {
                       items[t].participantes =  $scope.participantes[r];
                      }
                    }
                  }
                  if(t == items.length){
                    $scope.items = items.concat($scope.items);
                   //console.log($scope.lastidvestido);
                  }
                }
              });
            }
          }else{
            console.log("sem feed");
            $scope.semfeed = true;
          }
        }); 
      }else{
        navigator.geolocation.getCurrentPosition(function(position){
          raio = 50000*0.71;
          lat  = position.coords.latitude;
          long = position.coords.longitude;
          $scope.user.lat =  position.coords.latitude;
          $scope.user.long =  position.coords.longitude;

          myLatlng = new google.maps.LatLng(lat, long);
          spherical = google.maps.geometry.spherical; 
          north = spherical.computeOffset(myLatlng, raio, 0); 
          west  = spherical.computeOffset(myLatlng, raio, -90); 
          south = spherical.computeOffset(myLatlng, raio, 180); 
          east  = spherical.computeOffset(myLatlng, raio, 90); 
          $scope.user.northlat = north.lat();
          $scope.user.westlng = west.lng();
          $scope.user.southlat = south.lat();
          $scope.user.eastlng = east.lng();

          EventoService.GetFeed($scope.user).then(function(items) {
             //$ionicLoading.hide();
            if (items != 'E'){
              $scope.semfeed = false;
              ft2 = 0;
              for(var i = 0 ; i<items.length ; i++){
                // $scope.auxfoto = items[i].nomeevento + items[i].diainicio;
                // var mystring = String($scope.auxfoto);
                // mystring = mystring.replace(/[^a-zA-Z0-9]/g, '');
                // items[i].eventopic = 'https://s3.amazonaws.com/diwoappprofilepics/eventopicsdiwo/' + mystring + '.jpg';
                if(items[i].zone ==  'red' && parseInt(items[i].pmin) > parseInt(items[i].patual) && items[i].estado == '0'){
                  console.log('Falta gente para o evento, mas como estamos na redzone vou cancelar', items[i].idevento ,items[i].pmin , items[i].patual);
                  EventoService.Cancelarevento(items[i]);
                }
                EventoService.GetParticipantes(items[i].idevento).then(function(tes) {            
                  for (var j = 0; j < tes.length; j++) {
                     if(tes[j].estado == '2'){
                        //$scope.participantes[ft2];
                        if($scope.participantesid[ft2] !=undefined){
                          $scope.participantesid[ft2] = tes[j].idevento;
                          $scope.participantes[ft2]++ ;
                        }else{
                          $scope.participantesid[ft2] = tes[j].idevento;
                          $scope.participantes[ft2] = 1;
                        }
                    }
                    for (var l = 0; l< followers;l++){
                      if (tes[j].iduser == $scope.amigo[l].iduserseguindo) {
                        if($scope.eventocomconhecidoidevento[ft2] !=undefined){
                          $scope.eventocomconhecidoidevento[ft2] = tes[j].idevento;
                          $scope.eventocomconhecido[ft2] = tes[j].apelido + ', '+ $scope.eventocomconhecido[ft2] ;
                        }else{
                          $scope.eventocomconhecidoidevento[ft2] = tes[j].idevento;
                          $scope.eventocomconhecido[ft2] = tes[j].apelido;
                        }
                       //console.log($scope.eventocomconhecidoidevento[ft2], $scope.eventocomconhecido[ft2] , ft2)
                      }
                    }
                  }
                  ft2++;
                  console.log(ft2, items.length)
                  if(ft2==items.length){
                    for(var t = 0; t<ft2;t++){
                      for(var r = 0; r<ft2;r++){
                        if (items[t].idevento == $scope.eventocomconhecidoidevento[r]) {
                           items[t].amigo =  'Q vai e sigo: '+$scope.eventocomconhecido[r];
                        }
                        if (items[t].idevento == $scope.participantesid[r]) {
                          items[t].participantes =  $scope.participantes[r];
                        }
                      }
                    }
                    if(t == items.length){
                     $scope.items = items.concat($scope.items);
                    }
                  }
                });
              }
            }else{
            console.log("sem feed");
            $scope.semfeed = true;
          }
          });
        },function (error) { 
          if (error.code == error.PERMISSION_DENIED)
                console.log("you denied me :-(");
              $scope.semloc = true;
          });
        }  
         
              // VER AS 48H APÓS UM EVENTO SER FINALIZADO
              
              $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/getpenalidade.php", {iduser : $scope.user.iduser}).then(function(tes) {
                var ic = {};
                ic.iduser = $scope.user.iduser;
                ic.black = 0;
                ic.red = 0;
                ic.yellow = 0;
                ic.antiblack = 0;
                ic.antired = 0;
                ic.antiyellow = 0;
                ic.lenghtblack = 0;
                ic.lenghtred = 0;
                ic.lenghtyellow = 0;
                ic.idblack = [];
                ic.idred = [];
                ic.idyellow = [];

                ic.lenghtantiblack = 0;
                ic.lenghtantired = 0;
                ic.lenghtantiyellow = 0;
                ic.idantiblack = [];
                ic.idantired = [];
                ic.idantiyellow = [];


                if(tes.data.success != false){
                  //console.log('dasa')
                                  for(var h = 0;h<tes.data[0].length;h++){
                                    if(tes.data[0][h].tipopenalidade == 3){ic.black += 1; ic.blackdate = tes.data[0][h].date; ic.idblack[ic.lenghtblack] =tes.data[0][h].idpenalidade;  ic.lenghtblack++;}
                                    if(tes.data[0][h].tipopenalidade == 2){ic.red += 1;  ic.reddate = tes.data[0][h].date; ic.idred[ic.lenghtred] =tes.data[0][h].idpenalidade; ic.lenghtred++;}
                                    if(tes.data[0][h].tipopenalidade == 1){ic.yellow += 1;  ic.yellowdate = tes.data[0][h].date; ic.idyellow[ic.lenghtyellow] =tes.data[0][h].idpenalidade; ic.lenghtyellow++;}
                                    if(tes.data[0][h].tipopenalidade == 6){ic.antiblack += 1; ic.antiblackdate = tes.data[0][h].date; ic.idantiblack[ic.lenghtantiblack] =tes.data[0][h].idpenalidade; ic.lenghtantiblack++;}
                                    if(tes.data[0][h].tipopenalidade == 5){ic.antired += 1;  ic.antireddate = tes.data[0][h].date; ic.idantired[ic.lenghtantired] =tes.data[0][h].idpenalidade; ic.lenghtantired++;}
                                    if(tes.data[0][h].tipopenalidade == 4){ic.antiyellow += 1;  ic.antiyellowdate = tes.data[0][h].date; ic.idantiyellow[ic.lenghtantiyellow] =tes.data[0][h].idpenalidade; ic.lenghtantiyellow++;}
                                  }
                                  //console.log(ic.black);
                  EventoService.faz48h(ic);       
                }else{
                  EventoService.faz48h(ic);
                }

              });

    })

  $scope.doRefresh = function(uia) {
     if(!$scope.semloc ){
    //console.log(uia[0].diainicio)
      var yes = uia[0].diainicio;
      var no = uia[0].idevento;
        EventoService.GetNewEventos($scope.user).then(function(items) {
         $scope.newItems = [];
         //console.log(items)
         $scope.newItems = items.concat($scope.newItems);
         console.log( $scope.newItems[0].diainicio ,yes);
           if (yes > $scope.newItems[0].diainicio && no != $scope.newItems[0].idevento) {
            for (var g = 0; g<items.length;g++){
              $scope.newItems[g].faltatempo = 'Novo evento próximo';
            }
            if(g == items.length){
              $scope.items = $scope.newItems.concat($scope.items);
            $scope.$broadcast('scroll.refreshComplete');
            $scope.lastidevento  = $scope.newItems[0].diainicio;
            $scope.newItems = [];
            }
          }else {
            //console.log($scope.items.length);
            var hj = new Date();
            var currentdate = new Date(); 
            var curr_date = (currentdate.getDate()<10?'0':'') + currentdate.getDate();
            var curr_month = (currentdate.getMonth()<10?'0':'') + (currentdate.getMonth() + 1); //Months are zero based
            var curr_year = currentdate.getFullYear();
            var h2 = (currentdate.getHours()<10?'0':'') + currentdate.getHours();
            var m2 = (currentdate.getMinutes()<10?'0':'') + currentdate.getMinutes();
            for (var c = 0; c<$scope.items.length;c++){
              hj = $scope.items[c].diainicio;
              var ano = (hj[0]+hj[1]+hj[2]+hj[3]).valueOf()-curr_year;
              var mes = (hj[5]+hj[6]).valueOf()-curr_month;
              var dia = (hj[8]+hj[9]).valueOf()-curr_date;
              var h = (hj[11]+hj[12]).valueOf()-h2;
              var m = (hj[14]+hj[15]).valueOf()-m2;
                
            }

          //     //Stop the ion-refresher from spinning
              $scope.$broadcast('scroll.refreshComplete');
           }
        });
      }
      $scope.$broadcast('scroll.refreshComplete');
    }
  
    $scope.loadMore = function() {
      console.log($scope.semloc, $scope.semfeed)
      if(!$scope.semloc ){
      deletou = 0;
      EventoService.GetOldEventos($scope.user).then(function(items) {
      $scope.$broadcast('scroll.infiniteScrollComplete');
      //console.log(items.length);
      auxtes = 0;
       for(var i = 0 ; i<items.length ; i++){
         // console.log(items[i].faltatempo);
              EventoService.GetParticipantes(items[i].idevento).then(function(tes) {

                for (var j = 0; j < tes.length; j++) {
                  for (var l = 0; l< followers;l++){
                    if (tes[j].iduser == $scope.amigo[l].iduserseguindo) {
                      if($scope.eventocomconhecidoidevento[ft2] !=undefined){
                        $scope.eventocomconhecidoidevento[ft2] = tes[j].idevento;
                        $scope.eventocomconhecido[ft2] = tes[j].apelido + ', '+ $scope.eventocomconhecido[ft2] ;
                      }else{
                        $scope.eventocomconhecidoidevento[ft2] = tes[j].idevento;
                        $scope.eventocomconhecido[ft2] = tes[j].apelido;
                      }
                    
                    // console.log($scope.eventocomconhecidoidevento[ft2], $scope.eventocomconhecido[ft2] , ft2)
                    }
                  }
                }ft2++;auxtes++;
                if(auxtes==items.length){
                  for(var t = 0; t<auxtes;t++){
                    for(var r = 0; r<$scope.eventocomconhecidoidevento.length;r++){
                      if (items[t].idevento == $scope.eventocomconhecidoidevento[r]) {
                         items[t].amigo =  'Q vai e sigo: '+$scope.eventocomconhecido[r];
                          //console.log(items[t].idevento, t ,items[t].amigo );
                      }
                    }
                   
                  }
        
                   if(t == items.length){
                   $scope.items = $scope.items.concat(items);
                   $scope.lastidvestido = $scope.items[0].diainicio; 
                   //console.log($scope.lastidvestido);
                  }
                 
                  
                }
              });
          }

        if (items.length <= 4 &&  deletou != 1) {
        //  console.log('aqui');
          $scope.noMoreItemsAvailable = true;
          $scope.items=$scope.items;
        }
        if (items[0]=='E') {
          $scope.noMoreItemsAvailable = true;
          $scope.items=$scope.items;
        }
      });
    }
    $scope.$broadcast('scroll.infiniteScrollComplete');
  }

 

  $scope.enterItem =  function(item){
    if($scope.user.iduser == 37){
      var alertPopup = $ionicPopup.alert({
                        title: 'Parabéns',
                        template: $scope.response.msg
                      });
        alertPopup.then(function(){
          $state.go('logando');
        });
    }
    formItem.updateForm(item);
    formvimdofiltro.updateForm(false);
    formvimdofiltroperfil.updateForm(false);
   // console.log(item.idevento);
    //console.log(item.adm);
    $state.go('tabsController.eventoAberto');
  }


}])
   
.controller('eventosAbertosCtrl', ['$scope', '$state', '$stateParams', 'formUser', 'formItem', 'EventoService', '$http', 'formtelaStalkear', 'formEventoAbertosTab',  // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $state, $stateParams, formUser, formItem, EventoService, $http, formtelaStalkear, formEventoAbertosTab) {
    $scope.telastalk = formtelaStalkear.getForm();
    $scope.user = formUser.getForm();
    $scope.infoevento ={};
    if ($scope.telastalk == 1) {
      formtelaStalkear.updateForm(0);
      $state.go('tabsController.perfil_outro_eventoabertos');
    }

    var header = document.getElementById("barevento");
    var btns = header.getElementsByClassName("btneva");
    for (var i = 0; i < btns.length; i++) {
      btns[i].addEventListener("click", function() {
        var current = document.getElementsByClassName("actiea");
        current[0].className = current[0].className.replace(" actiea", "");
        this.className += " actiea";
      });
    }



    $scope.$on("$ionicView.enter", function(event, data){

      var das = document.getElementById("qvo");
      var current = document.getElementsByClassName("actiea");
      current[0].className = current[0].className.replace(" actiea", "");
      das.className += " actiea";
    
      $scope.items = [];
      $scope.telastalk = formtelaStalkear.getForm();
      if ($scope.telastalk == 1) {
        formtelaStalkear.updateForm(0);
        $state.go('tabsController.perfil_outro_eventoabertos');
      }
      
      EventoService.GetAbertosQvou($scope.user.iduser).then(function(items){
          console.log(items, "AbertosQvou")
          if(items=='E'){
            $scope.items = [];
          }else{
            for (var i = 0; i < items.length; i++) {
              if (items[i].estado == 0) {
                items[i].confirmacao = 'Sou o organizador';
              }
              if (items[i].estado == 1) {
                items[i].confirmacao = 'Aguardando confirmação';
              }
              if (items[i].estado == 2) {
                items[i].confirmacao = 'Confirmado';
              }
              var curr_date = (items[i].diainicio[8]+items[i].diainicio[9]);
                var h2 = (items[i].diainicio[11]+items[i].diainicio[12]);
                var m2 = (items[i].diainicio[14]+items[i].diainicio[15]);
                var curr_month = (items[i].diainicio[5]+items[i].diainicio[6]);
                var curr_year = (items[i].diainicio[2]+items[i].diainicio[3]);
                var j = curr_date + "/" + curr_month + "/" + curr_year+ '  '+h2 + ':' + m2;
                items[i].datainicio = j;
            }
            $scope.items = items.concat($scope.items);
          }
        });
    });

    $scope.loadqvou = function(){
      $scope.items = [];
      EventoService.GetAbertosQvou($scope.user.iduser).then(function(items){
          console.log(items)
          if(items=='E'){
            $scope.items = [];
          }else{
            for (var i = 0; i < items.length; i++) {
              if (items[i].estado == 0) {
                items[i].confirmacao = 'Sou o organizador';
              }
              if (items[i].estado == 1) {
                items[i].confirmacao = 'Aguardando confirmação';
              }
              if (items[i].estado == 2) {
                items[i].confirmacao = 'Confirmado';
              }
              var curr_date = (items[i].diainicio[8]+items[i].diainicio[9]);
                var h2 = (items[i].diainicio[11]+items[i].diainicio[12]);
                var m2 = (items[i].diainicio[14]+items[i].diainicio[15]);
                var curr_month = (items[i].diainicio[5]+items[i].diainicio[6]);
                var curr_year = (items[i].diainicio[2]+items[i].diainicio[3]);
                var j = curr_date + "/" + curr_month + "/" + curr_year+ '  '+h2 + ':' + m2;
                items[i].datainicio = j;
            }
            $scope.items = items.concat($scope.items);
          }
        });
    }
    $scope.loadCriados = function(){
      $scope.items = [];
      EventoService.GetAbertosCriados($scope.user.iduser).then(function(items) {
          console.log(items)
          if(items=='E'){
            $scope.items = [];
          }else{
            for (var i = 0; i < items.length; i++) {
                var curr_date = (items[i].diainicio[8]+items[i].diainicio[9]);
                var h2 = (items[i].diainicio[11]+items[i].diainicio[12]);
                var m2 = (items[i].diainicio[14]+items[i].diainicio[15]);
                var curr_month = (items[i].diainicio[5]+items[i].diainicio[6]);
                var curr_year = (items[i].diainicio[2]+items[i].diainicio[3]);
                var j = curr_date + "/" + curr_month + "/" + curr_year+'  '+h2 + ':' + m2;
                items[i].datainicio = j;
                items[i].confirmacao = " Participantes confirmados: " + items[i].patual + " de " + items[i].pmin + "/" +items[i].pmax ;
            }
            $scope.items = items.concat($scope.items);
          }
      });
    }
    $scope.loadInteresse = function(){
      $scope.items = [];
      EventoService.GetAbertosInteresse($scope.user.iduser).then(function(items) {
          console.log(items)
          if(items=='E'){
            $scope.items = [];
          }else{
            for (var i = 0; i < items.length; i++) {
                var curr_date = (items[i].diainicio[8]+items[i].diainicio[9]);
                var h2 = (items[i].diainicio[11]+items[i].diainicio[12]);
                var m2 = (items[i].diainicio[14]+items[i].diainicio[15]);
                var curr_month = (items[i].diainicio[5]+items[i].diainicio[6]);
                var curr_year = (items[i].diainicio[2]+items[i].diainicio[3]);
                var j = curr_date + "/" + curr_month + "/" + curr_year+ '  ' +h2 + ':' + m2;
                items[i].datainicio = j;
                items[i].confirmacao = '';
            }
            $scope.items = items.concat($scope.items);
          }
      });
    }

    $scope.enterItem =  function(item){
      
      $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/geteventoporid.php', {idevento : item.idevento}).then(function (result){
                                $scope.infoevento = result.data[0];
                                console.log($scope.infoevento.idevento, $scope.infoevento.diainicio);
                                //formItem.updateForm($scope.infoevento);
                                formEventoAbertosTab.updateForm($scope.infoevento);
                                 if (item.estado == 7) {
                                    $state.go('tabsController.eventoPinzado');
                                    }else{
                                    $state.go('tabsController.evento_do_eventoAbertos');
                                    }
                             });
     
      
    }


}])

.controller('evento_do_eventoAbertosCtrl', ['$scope', '$stateParams', 'formItem', 'formUser', 'formOutro', '$http', '$timeout','$ionicPopup', 'EventoService', '$state', 'formtelaCriar', 'formEventoAbertosTab','formEventoEdita', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, formItem, formUser, formOutro, $http, $timeout, $ionicPopup, EventoService, $state, formtelaCriar, formEventoAbertosTab, formEventoEdita) {
    //$scope.evento = formItem.getForm();
    $scope.evento = formEventoAbertosTab.getForm();
    console.log("ajsdiansd")
    console.log($scope.evento, "era pra estar aqui");
    $scope.aux = formUser.getForm();
    //console.log($scope.aux.iduser);
    $scope.data = {};
    $scope.tag = '';
    $scope.deletarPessoa = false;
    $scope.confirmaPessoa =false;
    $scope.items = [];
    $scope.limiteconfirmacao ={};
    $scope.fim = {};
    $scope.dia = {};
    $scope.pushnoti = {};

    var zone;
    var meuestado;
    var noti = {};
    var confirm = $scope.aux.iduser;

    

    var hj = new Date();
    var currentdate = new Date(); 
    var curr_date = (currentdate.getDate()<10?'0':'') + currentdate.getDate();
    var curr_month = (currentdate.getMonth()<10?'0':'') + (currentdate.getMonth() + 1); //Months are zero based
    var curr_year = currentdate.getFullYear();
    var h2 = (currentdate.getHours()<10?'0':'') + currentdate.getHours();
    var m2 = (currentdate.getMinutes()<10?'0':'') + currentdate.getMinutes();

    hj = $scope.evento.diainicio;

    var ano = (hj[0]+hj[1]+hj[2]+hj[3]).valueOf()-curr_year;
    var mes = (hj[5]+hj[6]).valueOf()-curr_month;
    var dia = (hj[8]+hj[9]).valueOf()-curr_date;
    var h = (hj[11]+hj[12]).valueOf()-h2;
    var m = (hj[14]+hj[15]).valueOf()-m2;

    hjl = $scope.evento.dialimiteconfirmacao;
    $scope.dialimiteconfirmacao =  (hjl[8]+hjl[9]).valueOf()+'/'+(hjl[5]+hjl[6]).valueOf()+'/'+(hjl[0]+hjl[1]+hjl[2]+hjl[3])+' '+(hjl[11]+hjl[12]).valueOf()+':'+(hjl[14]+hjl[15]).valueOf();
    
    var anol = (hjl[0]+hjl[1]+hjl[2]+hjl[3]).valueOf()-curr_year;
    var mesl = (hjl[5]+hjl[6]).valueOf()-curr_month;
    var dial = (hjl[8]+hjl[9]).valueOf()-curr_date;
    var hl = (hjl[11]+hjl[12]).valueOf()-h2;
    var ml = (hjl[14]+hjl[15]).valueOf()-m2;
    
    //$scope.dia = (hj[8]+hj[9]).valueOf()+'/'+(hj[5]+hj[6]).valueOf()+'/'+(hj[0]+hj[1]+hj[2]+hj[3])+' '+(hj[11]+hj[12]).valueOf()+':'+(hj[14]+hj[15]).valueOf();

    var hjf = $scope.evento.diafim;
    $scope.diafim =  (hjf[8]+hjf[9]).valueOf()+'/'+(hjf[5]+hjf[6]).valueOf()+'/'+(hjf[0]+hjf[1]+hjf[2]+hjf[3])+' '+(hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf();
    
    var hjd = $scope.evento.duracao;
    var hd = (hjd[0]+hjd[1]).valueOf();
    var md = (hjd[3]+hjd[4]).valueOf();
    $scope.duracao= hd+':'+md;
    $scope.limiteconfirmacao.dia =  (hjl[8]+hjl[9]).valueOf()+'/'+(hjl[5]+hjl[6]).valueOf();
    $scope.limiteconfirmacao.hora =  (hjl[11]+hjl[12]).valueOf()+':'+(hjl[14]+hjl[15]).valueOf();  
    

    $scope.fim.dia =  (hjf[8]+hjf[9]).valueOf()+'/'+(hjf[5]+hjf[6]).valueOf()+'/'+(hjf[0]+hjf[1]+hjf[2]+hjf[3]);
    $scope.fim.hora = (hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf();
    $scope.dia.dia = (hj[8]+hj[9]).valueOf()+'/'+(hj[5]+hj[6]).valueOf();
    $scope.dia.hora = (hj[11]+hj[12]).valueOf()+':'+(hj[14]+hj[15]).valueOf() +' - '+(hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf() ;

    EventoService.Gettags($scope.evento.idevento).then(function(tags) {
      for(var  i =0; i< tags.length;i++){
        $scope.tag = ($scope.tag + ' ' + tags[i].tag);
      } 
    });

          // YELLOW ZONE qualquer pessoa confirmada por confirmar a pessoa que nao foi confirmada
    console.log(anol, mesl, dial , hl, ml , hjl,);
       ///errradooo
    if(anol == 0 && mesl == 0 && dial == 0 && ((hl == 1 && ml<30 && ml>0)||(hl==0 && ml > 30)|| (hl==1 && ml>-30))){
      console.log('YELLOW-ZONE');
      zone = 'yellow';
      $scope.confirmaPessoa =true;
    }
   if($scope.evento.preco == 0 || $scope.evento.preco =="Gratuito"){
      $scope.evento.preco = "Gratuito";
      $scope.porpessoa = false;
      $scope.porlocal = false;
    }else{
      if($scope.evento.precopor == 1){
        $scope.porpessoa = true;
        $scope.porlocal = false;
      }else{
        $scope.porpessoa = false;
        $scope.porlocal = true;
      }
    }

          // RED ZONE 
        if(anol<0 || mesl < 0 ||(anol == 0 && mesl == 0 && (dial < 0 || (dial==0 && ((hl == 0 && ml<=0)||(hl < 0)))))){
      console.log('RED-ZONE');
      zone = 'red';
      $scope.confirmaPessoa =false;
      $scope.deletarPessoa = false;
      $scope.edita = false;
    }
    if($scope.evento.adm ==  $scope.aux.iduser){
      $scope.deletarPessoa = true;
      $scope.confirmaPessoa =true;
      if(zone == 'red'){
        $scope.edita = false;
        $scope.deletarPessoa = false;
      }else{
        $scope.edita = true;
      }
    }
    if($scope.evento.genero == "masc"){
      $scope.masc = true;
      $scope.fem = false;
    }
    if($scope.evento.genero == "fem"){
        $scope.fem = true;
        $scope.masc = false;
    }
    if($scope.evento.genero == "todos"){
        $scope.fem = false;
        $scope.masc = false;
    }

    if(parseInt($scope.evento.patual) < parseInt($scope.evento.pmin) && zone == 'red'){
            console.log('Evento não acontece por falta de pessoas')
          }
    if(parseInt($scope.evento.patual) < parseInt($scope.evento.pmin) && zone == 'yellow'){
      console.log('Evento esta com poucas pessoas, talvez ele nao aconteça')
    }
    EventoService.GetParticipantes($scope.evento.idevento).then(function(items) {
      //console.log(items[0].idevento);
      $scope.nomeevento = items[0].nomeevento;
      for (var i = 0; i < items.length; i++) {
        if ($scope.aux.iduser == items[i].iduser) {
          meuestado = items[i].estado;
          $scope.nuser++;
        }
        if (items[i].estado == 0) {
          items[i].confirmacao = 'Sou o organizador';
          $scope.criador = items[i].iduser;
        }
        if (items[i].estado == 1) {
          items[i].confirmacao = 'Aguardando confirmação';
        }
        if (items[i].estado == 2) {
          items[i].confirmacao = 'Confirmação aprovada';
        }
        if(items[i].borda == 0){
            items[i].bb = false;
            items[i].bs = false;
            items[i].bg = false;
          }
          if(items[i].borda == 1){
            items[i].bb = true;
            items[i].bs = false;
            items[i].bg = false;
          }
          if(items[i].borda == 2){
            items[i].bb = false;
            items[i].bs = true;
            items[i].bg = false;
          }
          if(items[i].borda == 3){
            items[i].bb = false;
            items[i].bs = false;
            items[i].bg = true;
          } 
          if(items[i].profilepic[8] == 's' && items[i].profilepic[9] == '3'){
            items[i].profilepic=items[i].profilepic+"?{{getTimeStamp()}}";
           }else{
             items[i].profilepic=items[i].profilepic;
           }
          //items[i].profilepic = items[i].profilepic+"?{{getTimeStamp()}}";
      }
      $scope.items = items;
      
    });

    $scope.$on("$ionicView.enter", function(event, data){
      //$scope.evento = formItem.getForm();
      $scope.evento = formEventoAbertosTab.getForm();
      $scope.data = {};
      $scope.tag = '';
      $scope.deletarPessoa = false;
      $scope.confirmaPessoa =false;
      $scope.items = [];
      $scope.pushnoti = {};
      zone;
      meuestado;
      noti = {};
      confirm = $scope.aux.iduser;

      if(!$scope.evento.dialimiteconfirmacao){
        console.log($scope.evento.idevento)
        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/geteventoporid.php', {idevento : $scope.evento.idevento}).then(function (result){
          $scope.evento = result.data[0];
          hj = new Date();
          currentdate = new Date(); 
          curr_date = (currentdate.getDate()<10?'0':'') + currentdate.getDate();
           curr_month = (currentdate.getMonth()<10?'0':'') + (currentdate.getMonth() + 1); //Months are zero based
           curr_year = currentdate.getFullYear();
           h2 = (currentdate.getHours()<10?'0':'') + currentdate.getHours();
           m2 = (currentdate.getMinutes()<10?'0':'') + currentdate.getMinutes();

          hj = $scope.evento.diainicio;

           ano = (hj[0]+hj[1]+hj[2]+hj[3]).valueOf()-curr_year;
           mes = (hj[5]+hj[6]).valueOf()-curr_month;
           dia = (hj[8]+hj[9]).valueOf()-curr_date;
           h = (hj[11]+hj[12]).valueOf()-h2;
           m = (hj[14]+hj[15]).valueOf()-m2;

          hjl = $scope.evento.dialimiteconfirmacao;
          
           anol = (hjl[0]+hjl[1]+hjl[2]+hjl[3]).valueOf()-curr_year;
           mesl = (hjl[5]+hjl[6]).valueOf()-curr_month;
           dial = (hjl[8]+hjl[9]).valueOf()-curr_date;
           hl = (hjl[11]+hjl[12]).valueOf()-h2;
           ml = (hjl[14]+hjl[15]).valueOf()-m2;
          
          
           hjf = $scope.evento.diafim;

          $scope.diafim =  (hjf[8]+hjf[9]).valueOf()+'/'+(hjf[5]+hjf[6]).valueOf()+'/'+(hjf[0]+hjf[1]+hjf[2]+hjf[3])+' '+(hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf();
          $scope.dialimiteconfirmacao =  (hjl[8]+hjl[9]).valueOf()+'/'+(hjl[5]+hjl[6]).valueOf()+'/'+(hjl[0]+hjl[1]+hjl[2]+hjl[3])+' '+(hjl[11]+hjl[12]).valueOf()+':'+(hjl[14]+hjl[15]).valueOf();
          var hjd = $scope.evento.duracao;
          var hd = (hjd[0]+hjd[1]).valueOf();
          var md = (hjd[3]+hjd[4]).valueOf();
          $scope.duracao= hd+':'+md;

          $scope.limiteconfirmacao.dia =  (hjl[8]+hjl[9]).valueOf()+'/'+(hjl[5]+hjl[6]).valueOf();
          $scope.limiteconfirmacao.hora =  (hjl[11]+hjl[12]).valueOf()+':'+(hjl[14]+hjl[15]).valueOf();  
          
          $scope.fim.dia =  (hjf[8]+hjf[9]).valueOf()+'/'+(hjf[5]+hjf[6]).valueOf()+'/'+(hjf[0]+hjf[1]+hjf[2]+hjf[3]);
          $scope.fim.hora = (hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf();
          $scope.dia.dia = (hj[8]+hj[9]).valueOf()+'/'+(hj[5]+hj[6]).valueOf();
           $scope.dia.hora = (hj[11]+hj[12]).valueOf()+':'+(hj[14]+hj[15]).valueOf() +' - '+(hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf() ;
        });
      }else{

      hj = new Date();
      currentdate = new Date(); 
      curr_date = (currentdate.getDate()<10?'0':'') + currentdate.getDate();
       curr_month = (currentdate.getMonth()<10?'0':'') + (currentdate.getMonth() + 1); //Months are zero based
       curr_year = currentdate.getFullYear();
       h2 = (currentdate.getHours()<10?'0':'') + currentdate.getHours();
       m2 = (currentdate.getMinutes()<10?'0':'') + currentdate.getMinutes();

      hj = $scope.evento.diainicio;

       ano = (hj[0]+hj[1]+hj[2]+hj[3]).valueOf()-curr_year;
       mes = (hj[5]+hj[6]).valueOf()-curr_month;
       dia = (hj[8]+hj[9]).valueOf()-curr_date;
       h = (hj[11]+hj[12]).valueOf()-h2;
       m = (hj[14]+hj[15]).valueOf()-m2;

      hjl = $scope.evento.dialimiteconfirmacao;
      
       anol = (hjl[0]+hjl[1]+hjl[2]+hjl[3]).valueOf()-curr_year;
       mesl = (hjl[5]+hjl[6]).valueOf()-curr_month;
       dial = (hjl[8]+hjl[9]).valueOf()-curr_date;
       hl = (hjl[11]+hjl[12]).valueOf()-h2;
       ml = (hjl[14]+hjl[15]).valueOf()-m2;
      
      
       hjf = $scope.evento.diafim;
       var hjd = $scope.evento.duracao;
      var hd = (hjd[0]+hjd[1]).valueOf();
      var md = (hjd[3]+hjd[4]).valueOf();
      $scope.duracao= hd+':'+md;

      $scope.limiteconfirmacao.dia =  (hjl[8]+hjl[9]).valueOf()+'/'+(hjl[5]+hjl[6]).valueOf();
      $scope.limiteconfirmacao.hora =  (hjl[11]+hjl[12]).valueOf()+':'+(hjl[14]+hjl[15]).valueOf();  
      
      

      $scope.fim.dia =  (hjf[8]+hjf[9]).valueOf()+'/'+(hjf[5]+hjf[6]).valueOf()+'/'+(hjf[0]+hjf[1]+hjf[2]+hjf[3]);
      $scope.fim.hora = (hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf();
      $scope.dia.dia = (hj[8]+hj[9]).valueOf()+'/'+(hj[5]+hj[6]).valueOf();
       $scope.dia.hora = (hj[11]+hj[12]).valueOf()+':'+(hj[14]+hj[15]).valueOf() +' - '+(hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf() ;

      $scope.diafim =  (hjf[8]+hjf[9]).valueOf()+'/'+(hjf[5]+hjf[6]).valueOf()+'/'+(hjf[0]+hjf[1]+hjf[2]+hjf[3])+' '+(hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf();
      $scope.dialimiteconfirmacao =  (hjl[8]+hjl[9]).valueOf()+'/'+(hjl[5]+hjl[6]).valueOf()+'/'+(hjl[0]+hjl[1]+hjl[2]+hjl[3])+' '+(hjl[11]+hjl[12]).valueOf()+':'+(hjl[14]+hjl[15]).valueOf();
      //$scope.dia = (hj[8]+hj[9]).valueOf()+'/'+(hj[5]+hj[6]).valueOf()+'/'+(hj[0]+hj[1]+hj[2]+hj[3])+' '+(hj[11]+hj[12]).valueOf()+':'+(hj[14]+hj[15]).valueOf();

      }


      console.log('Voltei para a pagina', $scope.evento ,$scope.evento.idevento, $scope.evento.dialimiteconfirmacao )
      

      EventoService.Gettags($scope.evento.idevento).then(function(tags) {
        for(var  i =0; i< tags.length;i++){
          $scope.tag = ($scope.tag + ' ' + tags[i].tag);
        } 
      });

            // YELLOW ZONE qualquer pessoa confirmada por confirmar a pessoa que nao foi confirmada
      console.log(anol, mesl, dial , hl, ml , hjl,);
         ///errradooo
      if(anol == 0 && mesl == 0 && dial == 0 && ((hl == 1 && ml<30 && ml>0)||(hl==0 && ml > 30)|| (hl==1 && ml>-30))){
        console.log('YELLOW-ZONE');
        zone = 'yellow';
        $scope.confirmaPessoa =true;
      }

            // RED ZONE 
     if(anol<0 || mesl < 0 ||(anol == 0 && mesl == 0 && (dial < 0 || (dial==0 && ((hl == 0 && ml<=0)||(hl < 0)))))){
        console.log('RED-ZONE');
        zone = 'red';
        $scope.confirmaPessoa =false;
        $scope.deletarPessoa = false;
      }
      if($scope.evento.adm ==  $scope.aux.iduser){
        $scope.deletarPessoa = true;
        $scope.confirmaPessoa =true;
        if(zone == 'red'){
          $scope.edita = false;
          $scope.deletarPessoa = false;
        }else{
          $scope.edita = true;
        }
      }

      if(parseInt($scope.evento.patual) < parseInt($scope.evento.pmin) && zone == 'red'){
              console.log('Evento não acontece por falta de pessoas')
            }
            console.log($scope.evento.patual , $scope.evento.pmin)
      if(parseInt($scope.evento.patual) < parseInt($scope.evento.pmin) && zone == 'yellow'){
        console.log('Evento esta com poucas pessoas, talvez ele nao aconteça')
      }
      EventoService.GetParticipantes($scope.evento.idevento).then(function(items) {
        //console.log(items[0].idevento);
        $scope.nomeevento = items[0].nomeevento;
        for (var i = 0; i < items.length; i++) {
          if ($scope.aux.iduser == items[i].iduser) {
            meuestado = items[i].estado;
            $scope.nuser++;
          }
          if (items[i].estado == 0) {
            items[i].confirmacao = 'Sou o organizador';
            $scope.criador = items[i].iduser;
            //console.log($scope.criador);
          }
          if (items[i].estado == 1) {
            items[i].confirmacao = 'Aguardando confirmação';
          }
          if (items[i].estado == 2) {
            items[i].confirmacao = 'Confirmação aprovada';
          }
          if(items[i].borda == 0){
            items[i].bb = false;
            items[i].bs = false;
            items[i].bg = false;
          }
          if(items[i].borda == 1){
            items[i].bb = true;
            items[i].bs = false;
            items[i].bg = false;
          }
          if(items[i].borda == 2){
            items[i].bb = false;
            items[i].bs = true;
            items[i].bg = false;
          }
          if(items[i].borda == 3){
            items[i].bb = false;
            items[i].bs = false;
            items[i].bg = true;
          }
          if(items[i].profilepic[8] == 's' && items[i].profilepic[9] == '3'){
            items[i].profilepic=items[i].profilepic+"?{{getTimeStamp()}}";
           }else{
             items[i].profilepic=items[i].profilepic;
           }
        }
        $scope.items = items;
      });
    });

    $scope.editar = function(){
      formEventoEdita.updateForm($scope.evento)
      $state.go('tabsController.EditEv');
      //$state.go('tabsController.EditaEEAPart1');
    }

    $scope.confirma = function(item){
      console.log(meuestado, confirm)
      if(meuestado == 1 || meuestado == 8 || meuestado == 7 ){
                  var alertPopup = $ionicPopup.alert({
                            title: '(°ロ°)☝',
                            template: 'Ainda não foi confirmado para poder aprovar alguem'
                          });
      }else{
        if(item.estado == 1 ){
          if (item.iduser!=$scope.aux.iduser && confirm!= item.iduser) {
                  confirm = item.iduser;
                  console.log(item.iduser, $scope.aux.iduser);
                  $scope.msgnoti = ('Tu foi aceito no evento: ' + $scope.evento.nomeevento);
                  $scope.evento.patual = parseInt($scope.evento.patual)+1;
                  $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/addpessoaevento.php', {idevento : $scope.evento.idevento,
                                                                                  patual : $scope.evento.patual});
                  $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpessoaevento.php' , {iduser : item.iduser,
                                                                                    idevento : $scope.evento.idevento,
                                                                                    confirmacao : 'Confirmação aceita',
                                                                                    estado :2});
                  noti.recebeusername = item.username;
                  noti.recebe = item.iduser;
                  noti.envia = $scope.aux.iduser;
                  noti.tipo = 2;
                  noti.nomeevento = $scope.evento.nomeevento;
                  $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacaoporids.php", {id_user_recebe : $scope.evento.adm,
                                                                                id_user_envia: item.iduser,
                                                                                nomeevento: noti.nomeevento,
                                                                                tipo : '1'});
                  EventoService.VerificaNotificacao(noti).then(function(res) {
                    console.log(res);
                    if(res){
                      $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : $scope.msgnoti, 
                                            idevento : $scope.evento.idevento,
                                            nomeevento : $scope.evento.nomeevento,
                                            id_user_envia : $scope.aux.iduser,
                                            username_envia : $scope.aux.username,
                                            apelido_envia : $scope.aux.apelido,
                                            tipo : '2',
                                            id_user_recebe : noti.recebe});
                    EventoService.getusuario2(noti.recebeusername).then(function(user) {
                            $scope.pushnoti.titulo = $scope.evento.nomeevento;
                            $scope.pushnoti.msg = 'Tu foi aceito no evento: ' + $scope.evento.nomeevento;
                            $scope.pushnoti.token = user.devicetoken;
                             EventoService.MandaPushNoti($scope.pushnoti);
                          });
                    }
                  });
                   var alertPopup = $ionicPopup.alert({
                            title: '(/^▽^)/',
                            template: 'Vamos avisa-lo que ele foi aprovado, obrigado.'
                          });
                   item.confirmacao = 'Confirmação aprovada';
          }else{
            if(confirm ==  item.iduser){
              var alertPopup = $ionicPopup.alert({
                            title: '༼ つ ◕_◕ ༽つ',
                            template: 'Ja esta confirmado nesse evento!!!'
                          });
            }else{
                var alertPopup = $ionicPopup.alert({
                            title: 'ಠ_ಠ',
                            template: 'Seria muito facil tu se aceitar no evento né?'
                          });
            }
          }
        }
        if(item.estado == 2 ){
          var alertPopup = $ionicPopup.alert({
                        title: '༼ つ ◕_◕ ༽つ',
                        template: 'Ja esta confirmado nesse evento!!!'
                      });
          console.log('Ja estou confirmado')
        }
        console.log($scope.evento.diainicio)
        if(item.estado == 8 ){
          if(parseInt($scope.evento.patual)<parseInt($scope.evento.pmax) && confirm!= item.iduser){
            confirm = item.iduser;
            console.log(item.iduser, $scope.aux.iduser);
                  $scope.msgnoti = ('Tu foi aceito no evento: ' + $scope.evento.nomeevento);
                  $scope.evento.patual = parseInt($scope.evento.patual)+1;
                  $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/addpessoaevento.php', {idevento : $scope.evento.idevento,
                                                                                  patual : $scope.evento.patual});
                  $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpessoaevento.php' , {iduser : item.iduser,
                                                                                    idevento : $scope.evento.idevento,
                                                                                    confirmacao : 'Confirmação aceita',
                                                                                      estado :2});
                  noti.recebeusername = item.username;
                  noti.recebe = item.iduser;
                  noti.envia = $scope.aux.iduser;
                  noti.tipo = 2;
                  noti.nomeevento = $scope.evento.nomeevento;
                  EventoService.VerificaNotificacao(noti).then(function(res) {
                    console.log(res);
                    if(res){
                      $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : $scope.msgnoti, 
                                                                                      idevento : $scope.evento.idevento,
                                                                                      nomeevento : $scope.evento.nomeevento,
                                                                                      id_user_envia : $scope.aux.iduser,
                                                                                      username_envia : $scope.aux.username,
                                                                                      apelido_envia : $scope.aux.apelido,
                                                                                      tipo : '2',
                                                                                      id_user_recebe : noti.recebe});
                    EventoService.getusuario2(noti.recebeusername).then(function(user) {
                            $scope.pushnoti.titulo = $scope.evento.nomeevento;
                            $scope.pushnoti.msg = 'Tu foi aceito no evento: ' + $scope.evento.nomeevento;
                            $scope.pushnoti.token = user.devicetoken;
                             EventoService.MandaPushNoti($scope.pushnoti);
                          });
                    }
                  });
                  var alertPopup = $ionicPopup.alert({
                      title: '(°◡°♡).:｡',
                      template: 'Vamos confirmar a presença dele!!'
                    });
                  item.confirmacao = 'Confirmação aprovada';
           
          console.log('Ja estou confirmado')
          }else{
              var confirmPopup = $ionicPopup.show({
                   title: '(◕⌓◕;)',
                   template: 'Evento esta cheio, deseja confirmar essa pessoa mesmo assim?',
                   buttons: [
                      { text: 'Não',
                        type: 'button-assertive'},
                      {
                        text: 'Sim',
                        type: 'button-positive',
                        onTap: function(e){
                          confirm = item.iduser;
                          console.log(item.iduser, $scope.aux.iduser);
                          $scope.msgnoti = ('Tu foi aceito no evento: ' + $scope.evento.nomeevento);
                          $scope.evento.patual = parseInt($scope.evento.patual)+1;
                          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/addpessoaevento.php', {idevento : $scope.evento.idevento,
                                                                                          patual : $scope.evento.patual});
                          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpessoaevento.php' , {iduser : item.iduser,
                                                                                            idevento : $scope.evento.idevento,
                                                                                            confirmacao : 'Confirmação aceita',
                                                                                            estado :2});
                          noti.recebeusername = item.username;
                          noti.recebe = item.iduser;
                          noti.envia = $scope.aux.iduser;
                          noti.tipo = 2;
                          noti.nomeevento = $scope.evento.nomeevento;
                          EventoService.VerificaNotificacao(noti).then(function(res) {
                            console.log(res);
                            if(res){
                              $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : $scope.msgnoti, 
                                                    idevento : $scope.evento.idevento,
                                                    nomeevento : $scope.evento.nomeevento,
                                                    id_user_envia : $scope.aux.iduser,
                                                    username_envia : $scope.aux.username,
                                                    apelido_envia : $scope.aux.apelido,
                                                    tipo : '2',
                                                    id_user_recebe : noti.recebe});
                              EventoService.getusuario2(noti.recebeusername).then(function(user) {
                                $scope.pushnoti.titulo = $scope.evento.nomeevento;
                                $scope.pushnoti.msg = 'Tu foi aceito no evento: ' + $scope.evento.nomeevento;
                                $scope.pushnoti.token = user.devicetoken;
                                 EventoService.MandaPushNoti($scope.pushnoti);
                              });
                            }
                          });
                            var alertPopup = $ionicPopup.alert({
                                title: '(°◡°♡).:｡',
                                template: 'Vamos confirmar a presença dele!!'
                              });
                           item.confirmacao = 'Confirmação aprovada';
                              }
                             }
                           ]
                   })
          console.log('Esta cheio o evento')
          }
        }
        if (item.estado == 0) {
                  var alertPopup = $ionicPopup.alert({
                            title: 'ლ(́◉◞౪◟◉‵ლ)',
                            template: 'Ja sou o organizador, não preciso me confirmar'
                          });
        }
      }
     }
    $scope.onItemDelete = function(item) {
      if (item.iduser == $scope.aux.iduser) {
        var alertPopup = $ionicPopup.alert({
                        title: 'Oi?',
                        template: 'Tu és o organizador, não podes se deletar do seu evento, podes cancelar ele'
        });
      }else{
        var confirmPopup = $ionicPopup.show({
                     title: 'ATENÇÃO!!!',
                     template: 'Você esta preste excluir pessoa do evento, ela não poderá mais entrar neste evento, tens certeza disso?',
                     buttons: [
                        { text: 'Não',
                          type: 'button-assertive'},
                        {
                          text: 'Sim',
                          type: 'button-positive',
                          onTap: function(e){
                          noti.recebeusername = item.username;
                          noti.recebe = item.iduser;
                          noti.envia = $scope.aux.iduser;
                          noti.tipo = 9;
                          noti.nomeevento = $scope.evento.nomeevento;
                          EventoService.VerificaNotificacao(noti).then(function(res) {
                            console.log(res);
                            if(res){
                              $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : 'Tu foi retirado do evento', 
                                                                                              idevento : $scope.evento.idevento,
                                                                                              nomeevento : $scope.evento.nomeevento,
                                                                                              id_user_envia : $scope.aux.iduser,
                                                                                              username_envia : $scope.aux.username,
                                                                                              apelido_envia : $scope.aux.apelido,
                                                                                              tipo : '9', //pessoa kickada
                                                                                              id_user_recebe : noti.recebe});
                              EventoService.getusuario2(noti.recebeusername).then(function(user) {
                                $scope.pushnoti.titulo = $scope.evento.nomeevento;
                                $scope.pushnoti.msg = 'Tu foi retirado do evento: ' + $scope.evento.nomeevento;
                                $scope.pushnoti.token = user.devicetoken;
                                 EventoService.MandaPushNoti($scope.pushnoti);
                              });
                            }
                          });
                            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser :item.iduser,
                                                                                                idevento : $scope.evento.idevento});
                            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletachat.php', {iduser : item.iduser,
                                                                                        idevento : $scope.aux.idevento}); 
                            if(item.estado == 2){
                             $scope.evento.patual = parseInt($scope.evento.patual)-1;
                            }
                            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/addpessoaevento.php', {idevento : $scope.evento.idevento,
                                                                                            patual : $scope.evento.patual});     
                            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/pessoanaoevento.php', {iduser : item.iduser, 
                                                                                            idevento : $scope.evento.idevento,
                                                                                            nomeevento : $scope.evento.nomeevento,
                                                                                            estado : '1'});//foi kickado
                                                                                               

                            $scope.items.splice($scope.items.indexOf(item), 1);      
                                }
                               }
                             ]
                     })


        
      }
    };  

    $scope.nuser = 0;
    $scope.enterItem =  function(item){
      console.log('dasdasdasdada',item)
      formOutro.updateForm(item);
      $state.go('tabsController.perfil_outro_eventoabertos');
    }
    

    $scope.Vermapa = function(){
      $state.go('tabsController.ver_onde_mapa_Eventoabertos');
    }

    $scope.deletar =  function(){
      if ($scope.criador == $scope.aux.iduser) {
                      if(zone == 'red' || zone == 'yellow'){
                          if(zone == 'red' ){
                             var myPopup = $ionicPopup.show({
                                template: '<input type="text" placeholder="Escreva aqui pq nao vai rolar" ng-model="data.desculpa">',
                                title: 'ATENÇÃO!!!',
                                subTitle: 'Você esta preste a cancelar seu evento faltando muito pouco para seu começo, tens certeza disso?. Se tu realmente cancelar estaremos te dando um cartão vermelho. Para saber mais sobre eles va no seu indice de confirmação',
                                scope: $scope,
                                buttons: [
                                  { text: 'Não' },
                                  {
                                    text: '<b>Sim</b>',
                                    type: 'button-positive',
                                    onTap: function(e) {
                                      // console.log($scope.items.length);
                                       var notifica = ("Desisti de fazer o evento, " + $scope.data.desculpa);
                                      // console.log(notifica);
                                      // console.log($scope.aux.iduser);
                                    
                                      formtelaCriar.updateForm(1);
                                      $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacaoporevento.php' , {idevento : $scope.evento.idevento,
                                                                                                    nomeevento : $scope.evento.nomeevento});
                                      EventoService.GetParticipantes($scope.evento.idevento).then(function(ppl) {
                                   for (var i = 0; i < ppl.length; i++) {
                                    if ($scope.aux.iduser != ppl[i].iduser) {
                                      noti.recebeusername = ppl[i].username;
                                       noti.recebe = ppl[i].iduser;
                                          noti.envia = $scope.aux.iduser;
                                          noti.tipo = 4;
                                          noti.nomeevento = $scope.evento.nomeevento;
                                          EventoService.VerificaNotificacao(noti).then(function(res) {
                                            console.log(res);
                                            if(res){
                                              $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : notifica, 
                                                    idevento : $scope.evento.idevento,
                                                    nomeevento : $scope.evento.nomeevento,
                                                    id_user_envia : $scope.aux.iduser,
                                                    username_envia : $scope.aux.username,
                                                    apelido_envia : $scope.aux.apelido,
                                                    tipo : '5',   
                                                    id_user_recebe : noti.recebe}).then(function (res){
                                                   $scope.response = res.data;
                                                   console.log($scope.response.msg)
                                                 });
                                              EventoService.getusuario2(noti.recebeusername).then(function(user) {
                                                $scope.pushnoti.titulo =  $scope.evento.nomeevento +'Cancelado' ;
                                                $scope.pushnoti.msg = ("Desisti de fazer o evento, " + $scope.data.desculpa);
                                                $scope.pushnoti.token = user.devicetoken;
                                                 EventoService.MandaPushNoti($scope.pushnoti);
                                              });
                                            }
                                          });
                                        }
                                  }
                                 })
                                      for(var i = 0; i< $scope.items.length; i++){
        
                                        
                                        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser : $scope.items[i].iduser,
                                                                                                           idevento : $scope.evento.idevento});
                                      }

                                         $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/penalidade.php', {iduser : $scope.aux.iduser,
                                                                                                     idevento : $scope.evento.idevento,
                                                                                                     username : $scope.aux.username,
                                                                                                     tipopenalidade : '2'});     // tipo2 saiu na redzone         
                                       $scope.evento.estado = "3";                
                                     EventoService.atualizarevento($scope.evento);
                                                          $state.go('tabsController.eventosAbertos');
                                                          }
                                  }]
                                 });

                                      console.log('criador do evento cancelando proprio evento');
                       }else{
                             var myPopup = $ionicPopup.show({
                                template: '<input type="text" placeholder="Escreva aqui pq nao vai rolar" ng-model="data.desculpa">',
                                title: 'ATENÇÃO!!!',
                                subTitle: 'Você esta preste a cancelar seu evento faltando pouco para seu começo, tens certeza disso?. Se tu realmente cancelar estaremos te dando um cartão amarelo. Para saber mais sobre eles va no seu indice de confirmação',
                                scope: $scope,
                                buttons: [
                                  { text: 'Não' },
                                  {
                                    text: '<b>Sim</b>',
                                    type: 'button-positive',
                                    onTap: function(e) {
                                      // console.log($scope.items.length);
                                       var notifica = ("Desisti de fazer o evento, " + $scope.data.desculpa);
                                      // console.log(notifica);
                                      // console.log($scope.aux.iduser);
                                    
                                      formtelaCriar.updateForm(1);
                                      $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacaoporevento.php' , {idevento : $scope.evento.idevento,
                                                                                                    nomeevento : $scope.evento.nomeevento}).then(function(response) {console.log(response, 'deleta')});
                                      EventoService.GetParticipantes($scope.evento.idevento).then(function(ppl) {
                                   for (var i = 0; i < ppl.length; i++) {
                                    if ($scope.aux.iduser != ppl[i].iduser) {
                                      noti.recebeusername = ppl[i].username;
                                       noti.recebe = ppl[i].iduser;
                                          noti.envia = $scope.aux.iduser;
                                          noti.tipo = 4;
                                          noti.nomeevento = $scope.evento.nomeevento;
                                          EventoService.VerificaNotificacao(noti).then(function(res) {
                                            console.log(res);
                                            if(res){
                                              $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : notifica, 
                                                      idevento : $scope.evento.idevento,
                                                      nomeevento : $scope.evento.nomeevento,
                                                      id_user_envia : $scope.aux.iduser,
                                                      username_envia : $scope.aux.username,
                                                      apelido_envia : $scope.aux.apelido,
                                                      tipo : '5',   
                                                      id_user_recebe : noti.recebe}).then(function (res){
                                                     $scope.response = res.data;
                                                     console.log($scope.response.msg)
                                              });
                                              EventoService.getusuario2(noti.recebeusername).then(function(user) {
                                                $scope.pushnoti.titulo =  $scope.evento.nomeevento +'Cancelado' ;
                                                $scope.pushnoti.msg = ("Desisti de fazer o evento, " + $scope.data.desculpa);
                                                $scope.pushnoti.token = user.devicetoken;
                                                 EventoService.MandaPushNoti($scope.pushnoti);
                                              });
                                            }
                                          });
                                        }
                                  }
                                 })
                                      for(var i = 0; i< $scope.items.length; i++){

                                        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser : $scope.items[i].iduser,
                                                                                                           idevento : $scope.evento.idevento});
                                      }
                                       $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/penalidade.php', {iduser : $scope.aux.iduser,
                                                                                                     idevento : $scope.evento.idevento,
                                                                                                     username : $scope.aux.username,
                                                                                                     tipopenalidade : '1'});   // tipo 1 saiu na yellow zone               
                                       $scope.evento.estado = "3";                
                                     EventoService.atualizarevento($scope.evento);
                                                          $state.go('tabsController.eventosAbertos');
                                                          }
                                  }]
                                 });

                                      console.log('criador do evento cancelando proprio evento');
                       }
        }else{
           var myPopup = $ionicPopup.show({
                  template: '<input type="text" placeholder="Escreva aqui pq nao vai rolar" ng-model="data.desculpa">',
                  title: 'ATENÇÃO!!!',
                  subTitle: 'Você esta preste a deletar seu evento, tens certeza disso?',
                  scope: $scope,
                  buttons: [
                    { text: 'Não' },
                    {
                      text: '<b>Sim</b>',
                      type: 'button-positive',
                      onTap: function(e) {
                        // console.log($scope.items.length);
                         var notifica = ("Desisti de fazer o evento, " + $scope.data.desculpa);
                        // console.log(notifica);
                        // console.log($scope.aux.iduser);
                      
                        formtelaCriar.updateForm(1);
                        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacaoporevento.php' , {idevento : $scope.evento.idevento,
                                                                                                    nomeevento : $scope.evento.nomeevento}).then(function(response) {console.log(response, 'deleta')});
                        EventoService.GetParticipantes($scope.evento.idevento).then(function(ppl) {
                                   for (var i = 0; i < ppl.length; i++) {
                                    if ($scope.aux.iduser != ppl[i].iduser) {
                                      noti.recebeusername = ppl[i].username;
                                       noti.recebe = ppl[i].iduser;
                                          noti.envia = $scope.aux.iduser;
                                          noti.tipo = 4;
                                          noti.nomeevento = $scope.evento.nomeevento;
                                          EventoService.VerificaNotificacao(noti).then(function(res) {
                                            console.log(res);
                                            if(res){
                                              $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : notifica, 
                                                    idevento : $scope.evento.idevento,
                                                    nomeevento : $scope.evento.nomeevento,
                                                    id_user_envia : $scope.aux.iduser,
                                                    username_envia : $scope.aux.username,
                                                    apelido_envia : $scope.aux.apelido,
                                                    tipo : '5',   
                                                    id_user_recebe : noti.recebe}).then(function (res){
                                                   $scope.response = res.data;
                                                   console.log($scope.response.msg)
                                              });
                                              EventoService.getusuario2(noti.recebeusername).then(function(user) {
                                                $scope.pushnoti.titulo =  $scope.evento.nomeevento +'Cancelado' ;
                                                $scope.pushnoti.msg = ("Desisti de fazer o evento, " + $scope.data.desculpa);
                                                $scope.pushnoti.token = user.devicetoken;
                                                 EventoService.MandaPushNoti($scope.pushnoti);
                                              });
                                            }
                                          });
                                        }
                                  }
                                 })

                        for(var i = 0; i< $scope.items.length; i++){
                          
                          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser : $scope.items[i].iduser,
                                                                                             idevento : $scope.evento.idevento});
                        }
                                        
                        $scope.evento.estado = "3";                
                        EventoService.atualizarevento($scope.evento);
                        $state.go('tabsController.eventosAbertos');
                      }
                    }]
                   });

                        console.log('criador do evento cancelando proprio evento');
        }
              
      }else{
        if (meuestado!=1) {
         if(zone == 'red' || zone == 'yellow'){
                          if(zone == 'red' ){
                               var confirmPopup = $ionicPopup.show({
                                         title: 'ATENÇÃO!!!',
                                         template: 'Você esta preste a desistir de um evento faltando muito pouco tempo para seu começo, tens certeza disso? Se tu realmente cancelar estaremos te dando um cartão vermelho. Para saber mais sobre eles va no seu indice de confirmação ',
                                         buttons: [
                                            { text: 'Não',
                                              type: 'button-assertive'},
                                            {
                                              text: 'Sim',
                                              type: 'button-positive',
                                              onTap: function(e){
                                                noti.recebeusername = $scope.evento.admusername;
                                                 noti.recebe =  $scope.criador;
                                          noti.envia = $scope.aux.iduser;
                                          noti.tipo = 5;
                                          noti.nomeevento = $scope.evento.nomeevento;
                                          EventoService.VerificaNotificacao(noti).then(function(res) {
                                            console.log(res);
                                            if(res){
                                                  $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : 'Desisti de ir no seu evento, perdão.', 
                                                        idevento : $scope.evento.idevento,
                                                        nomeevento : $scope.evento.nomeevento,
                                                        id_user_envia : $scope.aux.iduser,
                                                        username_envia : $scope.aux.username,
                                                        apelido_envia : $scope.aux.apelido,
                                                        tipo : '5', //pessoa desistiu
                                                        id_user_recebe : $scope.criador});
                                              EventoService.getusuario2(noti.recebeusername).then(function(user) {
                                                $scope.pushnoti.titulo =  $scope.aux.username +' desistiu' ;
                                                $scope.pushnoti.msg = $scope.aux.username + " não vai mais no evento " + $scope.evento.nomeevento;
                                                $scope.pushnoti.token = user.devicetoken;
                                                 EventoService.MandaPushNoti($scope.pushnoti);
                                              });
                                            }
                                          });
                                          $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacaoporids.php", {id_user_recebe : noti.recebe,
                                                                              id_user_envia: noti.envia,
                                                                              nomeevento: noti.nomeevento,
                                                                              tipo : '1'});
                                          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/penalidade.php', {iduser : $scope.aux.iduser,
                                                                                         idevento : $scope.evento.idevento,
                                                                                         username : $scope.aux.username,
                                                                                         tipopenalidade : '2'});     // tipo2 saiu na redzone  
                                          if(meuestado == 2){
                                             $scope.evento.patual = parseInt($scope.evento.patual)-1;
                                          }
                                          if(parseInt($scope.evento.patual)<parseInt($scope.evento.pmin)){
                                            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/mudaestadoevento.php', {idevento : $scope.evento.idevento,
                                                                                                          estado : '2'});
                                            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : 'ATENÇÃO!! Numero de pessoas agora nao bate o mínimo.', 
                                                        idevento : $scope.evento.idevento,
                                                        nomeevento : $scope.evento.nomeevento,
                                                        id_user_envia : $scope.aux.iduser,
                                                        username_envia : $scope.aux.username,
                                                        apelido_envia : $scope.aux.apelido,
                                                        tipo : '12', //pessoa desistiu
                                                        id_user_recebe : $scope.criador});
                                          }
                                          
                                          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/addpessoaevento.php', {idevento : $scope.evento.idevento,
                                                                                                          patual : $scope.evento.patual});    
                                          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser : $scope.aux.iduser,
                                                                                                            idevento : $scope.evento.idevento});
                                          $state.go('tabsController.eventosAbertos');
                                                    }
                                                   }
                                                 ]
                                         })
                             }else{
                                 var confirmPopup = $ionicPopup.show({
                                         title: 'ATENÇÃO!!!',
                                         template: 'Você esta preste a desistir de um evento faltando pouco tempo para seu começo, tens certeza disso? Se tu realmente cancelar estaremos te dando um cartão amarelo. Para saber mais sobre eles va no seu indice de confirmação',
                                         buttons: [
                                            { text: 'Não',
                                              type: 'button-assertive'},
                                            {
                                              text: 'Sim',
                                              type: 'button-positive',
                                              onTap: function(e){
                                                noti.recebeusername = $scope.evento.admusername;
                                                noti.recebe =  $scope.criador;
                                          noti.envia = $scope.aux.iduser;
                                          noti.tipo = 5;
                                          noti.nomeevento = $scope.evento.nomeevento;
                                          EventoService.VerificaNotificacao(noti).then(function(res) {
                                          console.log(res);
                                            if(res){
                                                $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : 'Desisti de ir no seu evento, perdão', 
                                                      idevento : $scope.evento.idevento,
                                                      nomeevento : $scope.evento.nomeevento,
                                                      id_user_envia : $scope.aux.iduser,
                                                      username_envia : $scope.aux.username,

                                                      tipo : '5', //pessoa desistiu
                                                      id_user_recebe : $scope.criador});
                                              EventoService.getusuario2(noti.recebeusername).then(function(user) {
                                                $scope.pushnoti.titulo =  $scope.aux.username +' desistiu' ;
                                                $scope.pushnoti.msg = $scope.aux.username + " não vai mais no evento " + $scope.evento.nomeevento;
                                                $scope.pushnoti.token = user.devicetoken;
                                                 EventoService.MandaPushNoti($scope.pushnoti);
                                              });
                                            }
                                          });
                                          $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacaoporids.php", {id_user_recebe : noti.recebe,
                                                                              id_user_envia: noti.envia,
                                                                              nomeevento: noti.nomeevento,
                                                                              tipo : '1'});
                                                       $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/penalidade.php', {iduser : $scope.aux.iduser,
                                                                                                     idevento : $scope.evento.idevento,
                                                                                                     username : $scope.aux.username,
                                                                                                     tipopenalidade : '1'});   // tipo 1 saiu na yellow zone   
                                                      
                                                         if(meuestado == 2){
                                                         $scope.evento.patual = parseInt($scope.evento.patual)-1;
                                                        }
                                                        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/addpessoaevento.php', {idevento : $scope.evento.idevento,
                                                                                          patual : $scope.evento.patual});    
                                                    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser : $scope.aux.iduser,
                                                                                                                        idevento : $scope.evento.idevento});
                                                      $state.go('tabsController.eventosAbertos');
                                                    }
                                                   }
                                                 ]
                                         })

                             }
                           }else{
                             var confirmPopup = $ionicPopup.show({
                                         title: 'ATENÇÃO!!!',
                                         template: 'Você esta preste a desistir de um evento, tens certeza disso?',
                                         buttons: [
                                            { text: 'Não',
                                              type: 'button-assertive'},
                                            {
                                              text: 'Sim',
                                              type: 'button-positive',
                                              onTap: function(e){
                                                noti.recebeusername = $scope.evento.admusername;
                                                noti.recebe =  $scope.criador;
                                          noti.envia = $scope.aux.iduser;
                                          noti.tipo = 5;
                                          noti.nomeevento = $scope.evento.nomeevento;
                                          EventoService.VerificaNotificacao(noti).then(function(res) {
                                          console.log(res);
                                            if(res){
                                                $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : 'Desisti de ir no seu evento, perdão', 
                                                      idevento : $scope.evento.idevento,
                                                      nomeevento : $scope.evento.nomeevento,
                                                      id_user_envia : $scope.aux.iduser,
                                                      username_envia : $scope.aux.username,
                                                      apelido_envia : $scope.aux.apelido,
                                                      tipo : '5', //pessoa desistiu
                                                      id_user_recebe : $scope.criador}).then(function (res){
                                                     $scope.response = res.data;
                                                     //console.log($scope.response.msg)
                                                   });
                                              EventoService.getusuario2(noti.recebeusername).then(function(user) {
                                                $scope.pushnoti.titulo =  $scope.aux.username +' desistiu' ;
                                                $scope.pushnoti.msg = $scope.aux.username + " não vai mais no evento " + $scope.evento.nomeevento;
                                                $scope.pushnoti.token = user.devicetoken;
                                                 EventoService.MandaPushNoti($scope.pushnoti);
                                              });
                                            }
                                          });
                                          $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacaoporids.php", {id_user_recebe : noti.recebe,
                                                                              id_user_envia: noti.envia,
                                                                              nomeevento: noti.nomeevento,
                                                                              tipo : '1'});
                                                       if(meuestado == 2){
                                                         $scope.evento.patual = parseInt($scope.evento.patual)-1;
                                                        }
                                                    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/addpessoaevento.php', {idevento : $scope.evento.idevento,
                                                                                                                    patual : $scope.evento.patual});    
                                                    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser : $scope.aux.iduser,
                                                                                                                        idevento : $scope.evento.idevento});
                                                      $state.go('tabsController.eventosAbertos');
                                                    }
                                                   }
                                                 ]
                                         })
                           }
              }else{
                             var confirmPopup = $ionicPopup.show({
                                         title: 'ATENÇÃO!!!',
                                         template: 'Você esta preste a desistir de um evento, tens certeza disso?',
                                         buttons: [
                                            { text: 'Não',
                                              type: 'button-assertive'},
                                            {
                                              text: 'Sim',
                                              type: 'button-positive',
                                              onTap: function(e){
                                                noti.recebeusername = $scope.evento.admusername;
                                                noti.recebe =  $scope.criador;
                                          noti.envia = $scope.aux.iduser;
                                          noti.tipo = 5;
                                          noti.nomeevento = $scope.evento.nomeevento;
                                          EventoService.VerificaNotificacao(noti).then(function(res) {
                                          console.log(res);
                                            if(res){
                                                $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : 'Desisti de ir no seu evento, perdão', 
                                                      idevento : $scope.evento.idevento,
                                                      nomeevento : $scope.evento.nomeevento,
                                                      id_user_envia : $scope.aux.iduser,
                                                      username_envia : $scope.aux.username,
                                                      apelido_envia : $scope.aux.apelido,
                                                      tipo : '5', //pessoa desistiu
                                                      id_user_recebe : $scope.criador}).then(function (res){
                                                     $scope.response = res.data;
                                                     //console.log($scope.response.msg)
                                                   });
                                              EventoService.getusuario2(noti.recebeusername).then(function(user) {
                                                $scope.pushnoti.titulo =  $scope.aux.username +' desistiu' ;
                                                $scope.pushnoti.msg = $scope.aux.username + " não vai mais no evento " + $scope.evento.nomeevento;
                                                $scope.pushnoti.token = user.devicetoken;
                                                 EventoService.MandaPushNoti($scope.pushnoti);
                                              });
                                            }
                                          });
                                          $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacaoporids.php", {id_user_recebe : noti.recebe,
                                                                              id_user_envia: noti.envia,
                                                                              nomeevento: noti.nomeevento,
                                                                              tipo : '1'});
                                                      if(meuestado == 2){
                                                         $scope.evento.patual = parseInt($scope.evento.patual)-1;
                                                        }
                                                    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/addpessoaevento.php', {idevento : $scope.evento.idevento,
                                                                                                                    patual : $scope.evento.patual});    
                                                    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser : $scope.aux.iduser,
                                                                                                                        idevento : $scope.evento.idevento});
                                                      $state.go('tabsController.eventosAbertos');
                                                    }
                                                   }
                                                 ]
                                         })
                           }





            }
       
    }
   
}])

.controller('ver_onde_mapa_EventoabertosCtrl', ['$scope', '$stateParams', '$cordovaGeolocation', '$state', '$ionicLoading', 'formItem', 'formEventoAbertosTab',  // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $cordovaGeolocation, $state, $ionicLoading, formItem, formEventoAbertosTab) {
 //$scope.evento = formItem.getForm();
 $scope.evento = formEventoAbertosTab.getForm();
 //$scope.coord = {};
  console.log($scope.evento.lat);
  console.log($scope.evento.lng);
        
        var latlng = {lat: parseFloat($scope.evento.lat), lng: parseFloat($scope.evento.lng)};


        var mapOptions = {
                center: latlng,
                zoom: 16,
                mapTypeId: google.maps.MapTypeId.ROADMAP
            };          
             

        var map = new google.maps.Map(document.getElementById("map_canvas2"), mapOptions); 
        var geocoder = new google.maps.Geocoder;
        var infowindow = new google.maps.InfoWindow({
                                                      maxWidth: 200
                                                    });

        geocoder.geocode({'location': latlng}, function(results, status) {
          if (status === 'OK') {
            if (results[1]) {
              var marker = new google.maps.Marker({
                position: latlng,
                map: map,
                title: "Borai",
                icon: 'http://maps.google.com/mapfiles/ms/icons/green-dot.png',
                animation: google.maps.Animation.DROP 
              });
              infowindow.setContent(results[0].formatted_address);
              infowindow.open(map, marker);
            } else {
              window.alert('No results found');
            }
          } else {
            window.alert('Geocoder failed due to: ' + status);
          }
        });

        $scope.map = map;  
             
}])

.controller('perfil_outro_eventoabertosCtrl', ['$scope', '$stateParams', 'formItem', 'formOutro', '$state', 'EventoService', '$http', '$timeout', 'formUser', '$ionicPopup', 'formStalker','formEventoAbertosTab', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, formItem, formOutro, $state, EventoService, $http, $timeout, formUser, $ionicPopup, formStalker, formEventoAbertosTab) {

    $scope.estadobutton = 0; 
    $scope.stalkeada = {};
    $scope.neventos= 0;
    $scope.neventosnao= 0;
    $scope.p =0;
    $scope.outro = formOutro.getForm();
    $scope.stalkeada = $scope.outro;
    $scope.user = formUser.getForm();
    $scope.pushnoti = {};
    $scope.followbutton = false;
    $scope.desseguirbutton = false;
    $scope.auxusers = {};
    $scope.qvou = true;

    $scope.CoisasCriado = true;
    $scope.CoisasFinalizado = false;


    var auxbloqueado = 0;
    var noti = {};
     
    var header = document.getElementById("barperfiloutroev");
    var btns = header.getElementsByClassName("btnperfilotro");
    for (var i = 0; i < btns.length; i++) {
      btns[i].addEventListener("click", function() {
        var current = document.getElementsByClassName("actoea");
        current[0].className = current[0].className.replace(" actoea", "");
        this.className += " actoea";
      });
    }

    $scope.infosstalkeada={};
    EventoService.GetStalkear($scope.stalkeada.iduser).then(function(stalker) {
        $scope.infosstalkeada = stalker;
        if($scope.infosstalkeada.profilepic[8] == 's' && $scope.infosstalkeada.profilepic[9] == '3'){
            document.getElementById("imageidperfil_outro_eventoabertos").src=$scope.infosstalkeada.profilepic+"?{{getTimeStamp()}}";
           }else{
             document.getElementById("imageidperfil_outro_eventoabertos").src=$scope.infosstalkeada.profilepic;
           }
        $scope.frase = stalker.frase;
        if(stalker.borda == 0){
          $scope.estrelabb = false;
          $scope.estrelabs = false;
          $scope.estrelabg = false;
        }
        if(stalker.borda == 1){
          $scope.estrelabb = true;
          $scope.estrelabs = false;
          $scope.estrelabg = false;
        }
        if(stalker.borda == 2){
          $scope.estrelabb = false;
          $scope.estrelabs = true;
          $scope.estrelabg = false;
        }
        if(stalker.borda == 3){
          $scope.estrelabb = false;
          $scope.estrelabs = false;
          $scope.estrelabg = true;
        }
        if($scope.infosstalkeada.idade){
          $scope.infosstalkeada.idade = ", "+ $scope.infosstalkeada.idade +" anos";
        }else{
           $scope.infosstalkeada.idade ='';
        }
    });

   
     EventoService.GetPontos($scope.stalkeada.iduser).then(function(items) {
        $scope.p = items;
        $scope.labels3 = ["Pontos"];
        $scope.colores3 = ["#ff4d4d"];
        $scope.data3 = [$scope.p];
      });

       
      EventoService.getIC($scope.stalkeada).then(function(items) {
        if(items){
          $scope.ic = items;
          $scope.options2 = {title: {
                      display: true,
                      text: 'Indice de confirmação',
                      position: 'bottom'
                  }
           }
          $scope.labels2 = ["Fui", "Não fui"];
          $scope.colores2 = ["#99FF99","#ff4d4d"];
          var menos = (100-$scope.ic.total).toFixed(1);
          var mais = $scope.ic.total;
          $scope.data2 = [mais, menos ];
        }
      });

      EventoService.GetComments3($scope.stalkeada).then(function(items) {
        
          $scope.options1 = {title: {
                    display: true,
                    text: 'Avaliações',
                    position: 'bottom'
                }
         }
          $scope.labels1 = ["Extrovertido", "Introvertido", "Realista","Curioso", "Solidário", "Racional","Organizado", "Criativo"];
          $scope.colores1 = ["#fff200", "#02fff2", "#ff9d00","#1867ce", "#e50be1", "#0e8c28","#ef370e", "#af0eef"];
          $scope.data1 =items.chart;
        
      });   
      $scope.outro= $scope.outro.iduser;
      
    $scope.$on("$ionicView.enter", function(event, data){
      $scope.pushnoti = {};
      $scope.items = [];
      $scope.vezes = 0;
      $scope.newItems = [];
      $scope.noMoreItemsAvailable = false;
      $scope.lastidevento = 0;
      $scope.aux2 = 0;
      $scope.outro = formOutro.getForm();
      $scope.stalkeada = $scope.outro;
      $scope.followbutton = false;
      $scope.desseguirbutton = false;
      $scope.infosstalkeada={};
        if($scope.outro == $scope.user.iduser){
        $scope.followbutton = false;
        $scope.desseguirbutton = false;
        $scope.reportbutton = false;
        $scope.qvou = true;
      }else{
        $scope.reportbutton = true;
      }
      EventoService.GetStalkear($scope.stalkeada.iduser).then(function(stalker) {
            $scope.infosstalkeada = stalker;
            if($scope.infosstalkeada.profilepic[8] == 's' && $scope.infosstalkeada.profilepic[9] == '3'){
            document.getElementById("imageidperfil_outro_eventoabertos").src=$scope.infosstalkeada.profilepic+"?{{getTimeStamp()}}";
           }else{
             document.getElementById("imageidperfil_outro_eventoabertos").src=$scope.infosstalkeada.profilepic;
           }
            //document.getElementById("imageidperfil_outro_eventoabertos").src=$scope.infosstalkeada.profilepic+"?{{getTimeStamp()}}";
            $scope.frase = stalker.frase;
             if(stalker.borda == 0){
          $scope.estrelabb = false;
          $scope.estrelabs = false;
          $scope.estrelabg = false;
        }
        if(stalker.borda == 1){
          $scope.estrelabb = true;
          $scope.estrelabs = false;
          $scope.estrelabg = false;
        }
        if(stalker.borda == 2){
          $scope.estrelabb = false;
          $scope.estrelabs = true;
          $scope.estrelabg = false;
        }
        if(stalker.borda == 3){
          $scope.estrelabb = false;
          $scope.estrelabs = false;
          $scope.estrelabg = true;
        }
            if($scope.infosstalkeada.idade){
              $scope.infosstalkeada.idade = ", "+ $scope.infosstalkeada.idade +" anos";
            }else{
               $scope.infosstalkeada.idade ='';
            }
        });
         // GET VALORES DE PONTOS E IC DA PESSOA

       EventoService.GetPontos($scope.stalkeada.iduser).then(function(items) {
        $scope.p = items;
        $scope.labels3 = ["Pontos"];
        $scope.colores3 = ["#ff4d4d"];
        $scope.data3 = [$scope.p];
      });


      EventoService.getIC($scope.stalkeada).then(function(items) {
        if(items){
          $scope.ic = items;
          $scope.options2 = {title: {
                      display: true,
                      text: 'Indice de confirmação',
                      position: 'bottom'
                  }
           }
          $scope.labels2 = ["Fui", "Não fui"];
          $scope.colores2 = ["#99FF99","#ff4d4d"];
          var menos = (100-$scope.ic.total).toFixed(1);
          var mais = $scope.ic.total;
          $scope.data2 = [mais, menos ];
        }
      });

      EventoService.GetComments3($scope.stalkeada).then(function(items) {
        
          $scope.options1 = {title: {
                    display: true,
                    text: 'Avaliações',
                    position: 'bottom'
                }
         }
          $scope.labels1 = ["Extrovertido", "Introvertido", "Realista","Curioso", "Solidário", "Racional","Organizado", "Criativo"];
          $scope.colores1 = ["#fff200", "#02fff2", "#ff9d00","#1867ce", "#e50be1", "#0e8c28","#ef370e", "#af0eef"];
          $scope.data1 =items.chart;
        
      });   

      
        EventoService.GetCriados($scope.stalkeada).then(function(items) {
          $scope.CoisasCriado = true;
          $scope.CoisasFinalizado = false;

          if(items == 'E'){
            $scope.items = [];
          }else{
            for (var i = 0; i < items.length; i++) {
                var curr_date = (items[i].diainicio[8]+items[i].diainicio[9]);
                var h2 = (items[i].diainicio[11]+items[i].diainicio[12]);
                var m2 = (items[i].diainicio[14]+items[i].diainicio[15]);
                var curr_month = (items[i].diainicio[5]+items[i].diainicio[6]);
                var curr_year = (items[i].diainicio[0]+items[i].diainicio[1]+items[i].diainicio[2]+items[i].diainicio[3]);
                var j = curr_date + "/" + curr_month + "/" + curr_year+ ' '+h2 + ':' + m2;
                items[i].datainicio = j;
                if(items[i].estado == 0){
                  items[i].confirmacao = "Vai acontecer"
                }
                if(items[i].estado == 1){
                  items[i].confirmacao = "Finalizado"
                }
                if(items[i].estado == 2){
                  items[i].confirmacao = "Standy by, talvez aconteça"
                }
                if(items[i].estado == 3){
                  items[i].confirmacao = "Vai acontecer"
                }
                if(items[i].estado == 4){
                  items[i].confirmacao = "Cancelado"
                }
                if(items[i].estado == 5){
                  items[i].confirmacao = "Acabado"
                }
                if(items[i].estado == 6){
                  items[i].confirmacao = "Escondido"
                }
            }
            $scope.items = items.concat($scope.items);
            $scope.lastidvestido = $scope.items[0].idevento;
          }
        }); 
           

                      //Para ver se eu ja sigo esta pessoa ou não.
      $scope.outro= $scope.outro.iduser;
      $scope.auxusers.outro =  $scope.outro;
      $scope.auxusers.eu =  $scope.user.iduser;


      EventoService.possoseguir($scope.auxusers).then(function(items) {
        console.log(items)
        if(items){
          console.log($scope.outro,$scope.user.iduser)
          //// nao funciona, nao pegar os bloqueados
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/getfollow.php', {iduserseguindo : $scope.outro, 
                                                                    iduserseguidor : $scope.user.iduser}).then(function(res) {
            console.log( 'oi' , res.data[0].bloqueado, res.data[0] );
            if(res.data[0]!='E'){
              if (res.data[0].bloqueado==0){ 
                $scope.desseguirbutton = true;
                $scope.followbutton = false;
                auxbloqueado = 1;
                $scope.qvou = true;
                console.log('ja sigo este cara');
              }
              if(res.data[0].bloqueado==2){
                console.log('nao sigo este cara');
                $scope.desseguirbutton = false;
                $scope.followbutton = true;
                auxbloqueado = 1;
                $scope.qvou = false;
              }
              if(res.data[0].bloqueado==1){
                console.log('tais bloqueado');
                $scope.desseguirbutton = false;
                $scope.followbutton = false;
                auxbloqueado = 3;
                $scope.items = [];
                $scope.qvou = false;
              }
              if($scope.outro == $scope.user.iduser){
                $scope.followbutton = false;
                $scope.desseguirbutton = false;
                $scope.reportbutton = false;
                $scope.qvou = true;
              }
            }else{
                $scope.followbutton = true;
                auxbloqueado = 2;
                $scope.qvou = false;
            }
            if($scope.outro == $scope.user.iduser){
              $scope.followbutton = false;
              $scope.desseguirbutton = false;
              $scope.reportbutton = false;
              $scope.qvou = true;
            }
          });
        }else{
          if($scope.outro == $scope.user.iduser){
            $scope.followbutton = false;
            $scope.desseguirbutton = false;
            $scope.reportbutton = false;
            $scope.qvou = true;
          }else{
            $scope.qvou = false;
          }
        }
      });        
    });

    $scope.seguir = function(){
      noti.recebe = $scope.outro;
      noti.envia = $scope.user.iduser;
      noti.tipo = 11;
      noti.nomeevento = 'follow';
      EventoService.VerificaNotificacao(noti).then(function(res) {
        console.log(res);
        if(res){
          var msgnoti ='Nova pessoa esta t stalkeando';
          var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php';
            $http.post(link, {notificacao :msgnoti, 
                                idevento : $scope.user.iduser,
                                nomeevento : 'follow',
                                id_user_envia : $scope.user.iduser,
                                username_envia : $scope.user.username,
                                apelido_envia : $scope.user.apelido,
                                tipo : '11',
                                id_user_recebe : $scope.outro});
        }
      });
      if(auxbloqueado == 2){
        var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/seguepessoa.php';
            $http.post(link, {iduserseguindo : $scope.outro, 
                          usernameseguindo : $scope.stalkeada.username,
                          apelidoseguindo : $scope.infosstalkeada.apelido,
                          apelidoseguidor : $scope.user.apelido,
                          profilepicseguindo : $scope.infosstalkeada.profilepic,
                          profilepicseguidor : $scope.user.profilepic,
                          iduserseguidor : $scope.user.iduser,
                          devicetokenseguidor : $scope.user.devicetoken,
                          usernameseguidor : $scope.user.username}).then(function(res) {
                          console.log(res.success);
                                var alertPopup = $ionicPopup.alert({
                                                            title: '(*•̀ᴗ•́*)و ̑̑',
                                                            template: 'Pessoa adicionada as pessoas de interesse'
                                                          }); 
                                
                            
                            $scope.desseguirbutton = true;
                            $scope.followbutton = false;
                          });
      }else{
         var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/refollow.php'; // estado "Bloqueado"  = 2;
            $http.post(link, {iduserseguindo : $scope.outro, 
                          iduserseguidor : $scope.user.iduser}).then(function(res) {
                            
                                var alertPopup = $ionicPopup.alert({
                                                            title: '(￣▽￣)ノ',
                                                            template: 'Pessoa adicionada as pessoas de interesse'
                                                          }); 
                                $scope.desseguirbutton = true;
                                $scope.followbutton = false;
                            
                          });
      }
    }

    $scope.desseguir = function(){
      auxbloqueado = 0;
        var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/desfollow.php'; // estado "Bloqueado"  = 2;
            $http.post(link, {iduserseguindo : $scope.outro, 
                          iduserseguidor : $scope.user.iduser}).then(function(res) {
                            
                                var alertPopup = $ionicPopup.alert({
                                                            title: '(*꒦ິ⌓꒦ີ)',
                                                            template: 'Não segues mais esta pessoa'
                                                          }); 
                                $scope.desseguirbutton = false;
                                $scope.followbutton = true;
                            
                          });
    }



    $scope.loadCriados = function() {
      $scope.CoisasCriado = true;
      $scope.CoisasFinalizado = false;

      if(auxbloqueado!=3){
        $scope.estadobutton = 0;
        $scope.items = [];
        EventoService.GetCriados($scope.stalkeada).then(function(items) {
          if(items == 'E'){
            $scope.items = [];
          }else{
            for (var i = 0; i < items.length; i++) {
                 var curr_date = (items[i].diainicio[8]+items[i].diainicio[9]);
                var h2 = (items[i].diainicio[11]+items[i].diainicio[12]);
                var m2 = (items[i].diainicio[14]+items[i].diainicio[15]);
                var curr_month = (items[i].diainicio[5]+items[i].diainicio[6]);
                var curr_year = (items[i].diainicio[0]+items[i].diainicio[1]+items[i].diainicio[2]+items[i].diainicio[3]);
                var j = curr_date + "/" + curr_month + "/" + curr_year+ ' '+h2 + ':' + m2;
                items[i].datainicio = j;
                if(items[i].estado == 0){
                  items[i].confirmacao = "Vai acontecer"
                }
                if(items[i].estado == 1){
                  items[i].confirmacao = "Finalizado"
                }
                if(items[i].estado == 2){
                  items[i].confirmacao = "Standy by, talvez aconteça"
                }
                if(items[i].estado == 3){
                  items[i].confirmacao = "Vai acontecer"
                }
                if(items[i].estado == 4){
                  items[i].confirmacao = "Cancelado"
                }
                if(items[i].estado == 5){
                  items[i].confirmacao = "Acabado"
                }
                if(items[i].estado == 6){
                  items[i].confirmacao = "Escondido"
                }
            }
            $scope.items = items.concat($scope.items);
            $scope.lastidvestido = $scope.items[0].idevento;
          }
        });
      }
        // $scope.enterItem =  function(item){
          //   formItem.updateForm(item);
          //   //console.log(item.idevento);
          //   //console.log(item.adm);
          //   $state.go('tabsController.evento_do_eventoAbertos');
          //   }
      }
      $scope.loadAbertos = function() {
        $scope.CoisasCriado = false;
        $scope.CoisasFinalizado = true;

        if(auxbloqueado!=3){
        $scope.estadobutton = 1;
        $scope.items = [];
        console.log($scope.stalkeada.iduser);
        EventoService.GetAbertos($scope.stalkeada.iduser).then(function(items) {  //mudar
          if(items == 'E'){
            $scope.items = [];
          }else{
            for (var i = 0; i < items.length; i++) {
                var curr_date = (items[i].diainicio[8]+items[i].diainicio[9]);
                var h2 = (items[i].diainicio[11]+items[i].diainicio[12]);
                var m2 = (items[i].diainicio[14]+items[i].diainicio[15]);
                var curr_month = (items[i].diainicio[5]+items[i].diainicio[6]);
                var curr_year = (items[i].diainicio[0]+items[i].diainicio[1]+items[i].diainicio[2]+items[i].diainicio[3]);
                var j = curr_date + "/" + curr_month + "/" + curr_year+ ' '+h2 + ':' + m2;
                items[i].datainicio = j;
            }
            $scope.items = items.concat($scope.items);
            $scope.lastidvestido = $scope.items[0].idevento;
          }
        });
      }
         // $scope.enterItem =  function(item){
          //   formItem.updateForm(item);
          //   //console.log(item.idevento);
          //   //console.log(item.adm);
          //   $state.go('tabsController.evento_do_eventoAbertos');
          //   }
      }
      $scope.loadFechados = function() {
        $scope.CoisasCriado = false;
        $scope.CoisasFinalizado = true;
        if(auxbloqueado!=3){
        $scope.estadobutton = 2;
        $scope.items = [];
        //console.log($scope.user.iduser);
        EventoService.GetFinalizadosPerfil($scope.stalkeada.iduser).then(function(items) {         //mudar
          if(items=='E'){
            $scope.items = [];
          }else{
            for (var i = 0; i < items.length; i++) {
                var curr_date = (items[i].diainicio[8]+items[i].diainicio[9]);
                var h2 = (items[i].diainicio[11]+items[i].diainicio[12]);
                var m2 = (items[i].diainicio[14]+items[i].diainicio[15]);
                var curr_month = (items[i].diainicio[5]+items[i].diainicio[6]);
                var curr_year = (items[i].diainicio[0]+items[i].diainicio[1]+items[i].diainicio[2]+items[i].diainicio[3]);
                var j = curr_date + "/" + curr_month + "/" + curr_year+ ' '+h2 + ':' + m2;
                items[i].datainicio = j;
            }
            $scope.items = items.concat($scope.items);
            $scope.lastidvestido = $scope.items[0].idevento;
          }
        });
      }
          
      }
      $scope.loadMore = function() {
        if ($scope.estadobutton == 0&& auxbloqueado!=3) {
          EventoService.GetOldEventosCriados($scope.stalkeada).then(function(items) {
          $scope.items = $scope.items.concat(items);
          $scope.$broadcast('scroll.infiniteScrollComplete');
            // an empty array indicates that there are no more items
            if (items.length <= 4) {
              $scope.noMoreItemsAvailable = true;
            }

          });
         

        }
        if ($scope.estadobutton == 1&& auxbloqueado!=3) {
          // EventoService.GetOldEventosCriados($scope.stalkeada).then(function(items) {
          // $scope.items = $scope.items.concat(items);
          // $scope.$broadcast('scroll.infiniteScrollComplete');
          //   // an empty array indicates that there are no more items
          //   if (items.length <= 4) {
          //     $scope.noMoreItemsAvailable = true;
          //   }
          // });

          $scope.noMoreItemsAvailable = true;
        }
        if ($scope.estadobutton == 2&& auxbloqueado!=3) {
          // EventoService.GetOldEventosCriados($scope.stalkeada).then(function(items) {
          // $scope.items = $scope.items.concat(items);
          // $scope.$broadcast('scroll.infiniteScrollComplete');
          //   // an empty array indicates that there are no more items
          //   if (items.length <= 4) {
          //     $scope.noMoreItemsAvailable = true;
          //   }
          // });

          $scope.noMoreItemsAvailable = true;
        }
      }

      $scope.reportar = function(){
          $scope.reportmsg = '';
          console.log($scope.stalkeada.username);
            $scope.report = [
          { text: "Nome impróprio", checked: false },
          { text: "Comportamento inadequado", checked: false },
          { text: "Foto inapropriada", checked: false },
          { text: "É um impostor", checked: false }
         ];
            $ionicPopup.confirm({
              title: 'Você quer reportar essa pessoa pq?',
              content: '<ion-checkbox ng-repeat="item in report" style="color: #FCFCFC;" ng-model="item.checked"  ng-checked="item.checked">{{item.text}}</ion-checkbox>',
              scope: $scope
            })
            .then(function(res) {
              if(res) {
                for (var h=0;h<3;h++){
                  //console.log($scope.report[h].checked , h);
                  if($scope.report[h].checked){
                    $scope.reportmsg = $scope.reportmsg + $scope.report[h].text + ' ';
                    //console.log($scope.reportmsg);
                  }
                }

                if(h==3){
                  console.log($scope.reportmsg);
                   $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/reportaevento.php', {namereportado : $scope.stalkeada.username,
                                                                                  reportadoid : $scope.stalkeada.iduser,
                                                                                  iduserreportando : $scope.user.iduser,
                                                                                  usernamereportando : $scope.user.username,
                                                                                  tiporeport : 'usuario',
                                                                                  motivo : $scope.reportmsg}).then(function (tes){
                                     $scope.response = tes.data;
                                      var alertPopup = $ionicPopup.alert({
                                                              title: 'Obrigado',
                                                              template: 'Esta pessoa esta agora sobre investigação, obrigado por manter a plataforma segura'
                                                            });

                                   });
                }
                
              }
            });
         }

         $scope.comentario = function(){
          formStalker.updateForm($scope.stalkeada);
          if(auxbloqueado!=3){
          $state.go('tabsController.comentariosdosoutros');}
         }

      $scope.enterItem =  function(item){
        formEventoAbertosTab.updateForm(item);
        //formItem.updateForm(item);
        console.log(item.idevento);
        //console.log(item.adm);
      $state.go('tabsController.evento_do_eventoAbertos_do_outro');
    }

}])

.controller('perfil_outro_evento_criadosCtrl', ['$scope', '$stateParams', 'formItem', 'formOutro', '$state', 'EventoService','$http', '$timeout', 'formUser', '$ionicPopup', 'formStalker', 'formEventoPerfil',   // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, formItem, formOutro, $state, EventoService, $http, $timeout, formUser, $ionicPopup, formStalker, formEventoPerfil) {

    $scope.estadobutton = 0; 
    $scope.stalkeada = formOutro.getForm();;
    $scope.neventos= 0;
    $scope.neventosnao= 0;
    $scope.p =0;
    $scope.outro = formOutro.getForm();
    $scope.user = formUser.getForm();
    $scope.pushnoti = {};
    $scope.followbutton = false;
    $scope.desseguirbutton = false;
    $scope.qvou = true;

     $scope.CoisasCriado = true;
        $scope.CoisasFinalizado = false;

    $scope.auxusers = {};

    var header = document.getElementById("barperfiloutroev");
    var btns = header.getElementsByClassName("btnperfilotro");
    for (var i = 0; i < btns.length; i++) {
      btns[i].addEventListener("click", function() {
        var current = document.getElementsByClassName("actoec");
        current[0].className = current[0].className.replace(" actoec", "");
        this.className += " actoec";
      });
    }

    $scope.infosstalkeada={};
      EventoService.GetStalkear($scope.stalkeada.iduser).then(function(stalker) {
            $scope.infosstalkeada = stalker;
            if($scope.infosstalkeada.profilepic[8] == 's' && $scope.infosstalkeada.profilepic[9] == '3'){
            document.getElementById("imageidperfil_outro_evento_criados").src=$scope.infosstalkeada.profilepic+"?{{getTimeStamp()}}";
           }else{
             document.getElementById("imageidperfil_outro_evento_criados").src=$scope.infosstalkeada.profilepic;
           }
            //document.getElementById("imageidperfil_outro_evento_criados").src=$scope.infosstalkeada.profilepic+"?{{getTimeStamp()}}";
            $scope.frase = stalker.frase;
            if(stalker.borda == 0){
          $scope.estrelabb = false;
          $scope.estrelabs = false;
          $scope.estrelabg = false;
        }
        if(stalker.borda == 1){
          $scope.estrelabb = true;
          $scope.estrelabs = false;
          $scope.estrelabg = false;
        }
        if(stalker.borda == 2){
          $scope.estrelabb = false;
          $scope.estrelabs = true;
          $scope.estrelabg = false;
        }
        if(stalker.borda == 3){
          $scope.estrelabb = false;
          $scope.estrelabs = false;
          $scope.estrelabg = true;
        }
            if($scope.infosstalkeada.idade){
              $scope.infosstalkeada.idade = ", "+ $scope.infosstalkeada.idade +" anos";
            }else{
               $scope.infosstalkeada.idade ='';
            }
        });
    var auxbloqueado = 0;
    var noti = {};
    
    EventoService.GetPontos($scope.stalkeada.iduser).then(function(items) {
        $scope.p = items;
        $scope.labels3 = ["Pontos"];
        $scope.colores3 = ["#ff4d4d"];
        $scope.data3 = [$scope.p];
      });
      EventoService.getIC($scope.stalkeada).then(function(items) {
        if(items){
          $scope.ic = items;
          $scope.options2 = {title: {
                      display: true,
                      text: 'Indice de confirmação',
                      position: 'bottom'
                  }
           }
          $scope.labels2 = ["Fui", "Não fui"];
          $scope.colores2 = ["#99FF99","#ff4d4d"];
          var menos = (100-$scope.ic.total).toFixed(1);
          var mais = $scope.ic.total;
          $scope.data2 = [mais, menos ];
        }
      });

      EventoService.GetComments3($scope.stalkeada).then(function(items) {
        
          $scope.options1 = {title: {
                    display: true,
                    text: 'Avaliações',
                    position: 'bottom'
                }
         }
           $scope.labels1 = ["Extrovertido", "Introvertido", "Realista","Curioso", "Solidário", "Racional","Organizado", "Criativo"];
          $scope.colores1 = ["#fff200", "#02fff2", "#ff9d00","#1867ce", "#e50be1", "#0e8c28","#ef370e", "#af0eef"];
          $scope.data1 =items.chart;
        
      }); 
      $scope.outro = $scope.outro.iduser

    $scope.$on("$ionicView.enter", function(event, data){
      $scope.pushnoti = {};
      if($scope.outro == $scope.user.iduser){
         $scope.followbutton = false;
         $scope.desseguirbutton = false;
         $scope.reportbutton = false;
         $scope.qvou = true;
      }else{
        $scope.reportbutton = true;
      }
      $scope.infosstalkeada={};
      EventoService.GetStalkear($scope.stalkeada.iduser).then(function(stalker) {
            $scope.infosstalkeada = stalker;
            if($scope.infosstalkeada.profilepic[8] == 's' && $scope.infosstalkeada.profilepic[9] == '3'){
            document.getElementById("imageidperfil_outro_evento_criados").src=$scope.infosstalkeada.profilepic+"?{{getTimeStamp()}}";
           }else{
             document.getElementById("imageidperfil_outro_evento_criados").src=$scope.infosstalkeada.profilepic;
           }
            //document.getElementById("imageidperfil_outro_evento_criados").src=$scope.infosstalkeada.profilepic+"?{{getTimeStamp()}}";
            $scope.frase = stalker.frase;
             if(stalker.borda == 0){
          $scope.estrelabb = false;
          $scope.estrelabs = false;
          $scope.estrelabg = false;
        }
        if(stalker.borda == 1){
          $scope.estrelabb = true;
          $scope.estrelabs = false;
          $scope.estrelabg = false;
        }
        if(stalker.borda == 2){
          $scope.estrelabb = false;
          $scope.estrelabs = true;
          $scope.estrelabg = false;
        }
        if(stalker.borda == 3){
          $scope.estrelabb = false;
          $scope.estrelabs = false;
          $scope.estrelabg = true;
        }
            if($scope.infosstalkeada.idade){
              $scope.infosstalkeada.idade = ", "+ $scope.infosstalkeada.idade +" anos";
            }else{
               $scope.infosstalkeada.idade ='';
            }
        });
      $scope.items = [];
      $scope.vezes = 0;
      $scope.newItems = [];
      $scope.noMoreItemsAvailable = false;
      $scope.lastidevento = 0;
      $scope.aux2 = 0;
      $scope.outro = formOutro.getForm();
      $scope.followbutton = false;
      $scope.desseguirbutton = false;

      EventoService.GetStalkear($scope.outro.iduser).then(function(items) {
        $scope.stalkeada = items;
        EventoService.GetCriados($scope.stalkeada).then(function(items) {
           $scope.CoisasCriado = true;
            $scope.CoisasFinalizado = false;
          if(items == 'E'){
            $scope.items = [];
          }else{
            for (var i = 0; i < items.length; i++) {
                var curr_date = (items[i].diainicio[8]+items[i].diainicio[9]);
                var h2 = (items[i].diainicio[11]+items[i].diainicio[12]);
                var m2 = (items[i].diainicio[14]+items[i].diainicio[15]);
                var curr_month = (items[i].diainicio[5]+items[i].diainicio[6]);
                var curr_year = (items[i].diainicio[0]+items[i].diainicio[1]+items[i].diainicio[2]+items[i].diainicio[3]);
                var j = curr_date + "/" + curr_month + "/" + curr_year+ ' '+h2 + ':' + m2;
                items[i].datainicio = j;
                if(items[i].estado == 0){
                  items[i].confirmacao = "Vai acontecer"
                }
                if(items[i].estado == 1){
                  items[i].confirmacao = "Finalizado"
                }
                if(items[i].estado == 2){
                  items[i].confirmacao = "Standy by, talvez aconteça"
                }
                if(items[i].estado == 3){
                  items[i].confirmacao = "Vai acontecer"
                }
                if(items[i].estado == 4){
                  items[i].confirmacao = "Cancelado"
                }
                if(items[i].estado == 5){
                  items[i].confirmacao = "Acabado"
                }
                if(items[i].estado == 6){
                  items[i].confirmacao = "Escondido"
                }
            }
            $scope.items = items.concat($scope.items);
            $scope.lastidvestido = $scope.items[0].idevento;
          }
        });
      });

                      // GET VALORES DE PONTOS E IC DA PESSOA

       EventoService.GetPontos($scope.stalkeada.iduser).then(function(items) {
        $scope.p = items;
        $scope.labels3 = ["Pontos"];
        $scope.colores3 = ["#ff4d4d"];
        $scope.data3 = [$scope.p];
      });
      EventoService.getIC($scope.stalkeada).then(function(items) {
        if(items){
          $scope.ic = items;
          $scope.options2 = {title: {
                      display: true,
                      text: 'Indice de confirmação',
                      position: 'bottom'
                  }
           }
          $scope.labels2 = ["Fui", "Não fui"];
          $scope.colores2 = ["#99FF99","#ff4d4d"];
          var menos = (100-$scope.ic.total).toFixed(1);
          var mais = $scope.ic.total;
          $scope.data2 = [mais, menos ];
        }
      });

      EventoService.GetComments3($scope.stalkeada).then(function(items) {
        
          $scope.options1 = {title: {
                    display: true,
                    text: 'Avaliações',
                    position: 'bottom'
                }
         }
          $scope.labels1 = ["Extrovertido", "Introvertido", "Realista","Curioso", "Solidário", "Racional","Organizado", "Criativo"];
          $scope.colores1 = ["#fff200", "#02fff2", "#ff9d00","#1867ce", "#e50be1", "#0e8c28","#ef370e", "#af0eef"];
          $scope.data1 =items.chart;
        
      });   

                      //Para ver se eu ja sigo esta pessoa ou não.
      $scope.auxusers.outro =  $scope.outro.iduser;
      $scope.auxusers.eu =  $scope.user.iduser;
      console.log("possoseguir", $scope.auxusers.outro, $scope.user.iduser)
      EventoService.possoseguir($scope.auxusers).then(function(items) {
        console.log("possoseguir", items)
        if(items){
          console.log($scope.outro,$scope.user.iduser)
          //// nao funciona, nao pegar os bloqueados
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/getfollow.php', {iduserseguindo : $scope.outro.iduser, 
                                                                    iduserseguidor : $scope.user.iduser}).then(function(res) {
            console.log( 'oi' , res.data[0].bloqueado );
            if(res.data[0]!='E'){
              if (res.data[0].bloqueado==0){ 
                $scope.desseguirbutton = true;
                $scope.followbutton = false;
                auxbloqueado = 1;
                $scope.qvou = true;
                console.log('ja sigo este cara');
              }
              if(res.data[0].bloqueado==2){
                console.log('nao sigo este cara');
                $scope.desseguirbutton = false;
                $scope.followbutton = true;
                auxbloqueado = 1;
                $scope.qvou = false;
              }
              if(res.data[0].bloqueado==1){
                console.log('tais bloqueado');
                $scope.desseguirbutton = false;
                $scope.followbutton = false;
                auxbloqueado = 3;
                $scope.items = [];
                $scope.qvou = false;
              }
              if($scope.outro == $scope.user.iduser){
                $scope.followbutton = false;
                $scope.desseguirbutton = false;
                $scope.reportbutton = false;
                $scope.qvou = true;
              }
            }else{
              $scope.followbutton = true;
              auxbloqueado = 2;
              $scope.qvou = false;
            }
             if($scope.outro == $scope.user.iduser){
                $scope.followbutton = false;
                $scope.desseguirbutton = false;
                $scope.reportbutton = false;
                $scope.qvou = true;
              }
          });
        }else{
          if($scope.outro == $scope.user.iduser){
            $scope.followbutton = false;
            $scope.desseguirbutton = false;
            $scope.reportbutton = false;
            $scope.qvou = true;
          }else{
            $scope.qvou = false;
          }
        }
      });                  
    });

    $scope.comentario = function(){
      formStalker.updateForm($scope.stalkeada);
      if(auxbloqueado!=3){
        $state.go('tabsController.comentariosdosoutrosnoperfil');
      }
    }

    $scope.seguir = function(){
      //console.log("oii", $scope.infosstalkeada.iduser)
      noti.recebe = $scope.infosstalkeada.iduser;
      noti.envia = $scope.user.iduser;
      noti.tipo = 11;
      noti.nomeevento = 'follow';
      EventoService.VerificaNotificacao(noti).then(function(res) {
        console.log(res);
        if(res){
          var msgnoti ='Nova pessoa esta t stalkeando';
          var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php';
          $http.post(link, {notificacao :msgnoti, 
                            idevento : $scope.user.iduser,
                            nomeevento : 'follow',
                            id_user_envia : $scope.user.iduser,
                            username_envia : $scope.user.username,
                            apelido_envia : $scope.user.apelido,
                            tipo : '11',
                            id_user_recebe : $scope.infosstalkeada.iduser});
        }
      });
      if(auxbloqueado == 2){
        var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/seguepessoa.php';
        $http.post(link, {iduserseguindo : $scope.infosstalkeada.iduser, 
                          usernameseguindo : $scope.stalkeada.username,
                          iduserseguidor : $scope.user.iduser,
                          apelidoseguindo : $scope.infosstalkeada.apelido,
                          apelidoseguidor : $scope.user.apelido,
                          profilepicseguindo : $scope.infosstalkeada.profilepic,
                          profilepicseguidor : $scope.user.profilepic,
                          devicetokenseguidor : $scope.user.devicetoken,
                          usernameseguidor : $scope.user.username}).then(function(res) {
          var alertPopup = $ionicPopup.alert({
            title: '(*•̀ᴗ•́*)و ̑̑',
            template: 'Pessoa adicionada as pessoas de interesse'
          }); 
          $scope.desseguirbutton = true;
          $scope.followbutton = false;
        });
      }else{
        var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/refollow.php'; // estado "Bloqueado"  = 2;
        $http.post(link, {iduserseguindo : $scope.infosstalkeada.iduser, 
                          iduserseguidor : $scope.user.iduser}).then(function(res) {  
          var alertPopup = $ionicPopup.alert({
            title: '(￣▽￣)ノ',
            template: 'Pessoa adicionada as pessoas de interesse'
          }); 
          $scope.desseguirbutton = true;
          $scope.followbutton = false;                
        });
      }
    }

    $scope.desseguir = function(){
      auxbloqueado = 0;
      var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/desfollow.php'; // estado "Bloqueado"  = 2;
      $http.post(link, {iduserseguindo : $scope.infosstalkeada.iduser, 
                        iduserseguidor : $scope.user.iduser}).then(function(res) {
        var alertPopup = $ionicPopup.alert({
          title: '(*꒦ິ⌓꒦ີ)',
          template: 'Não segues mais esta pessoa'
        }); 
        $scope.desseguirbutton = false;
        $scope.followbutton = true;                
      });
    }



    $scope.loadCriados = function() {
       $scope.CoisasCriado = true;
        $scope.CoisasFinalizado = false;
      if(auxbloqueado!=3){
        $scope.estadobutton = 0;
        $scope.items = [];
        EventoService.GetCriados($scope.stalkeada).then(function(items) {
          if(items == 'E'){
            $scope.items = [];
          }else{
            for (var i = 0; i < items.length; i++) {
                 var curr_date = (items[i].diainicio[8]+items[i].diainicio[9]);
                var h2 = (items[i].diainicio[11]+items[i].diainicio[12]);
                var m2 = (items[i].diainicio[14]+items[i].diainicio[15]);
                var curr_month = (items[i].diainicio[5]+items[i].diainicio[6]);
                var curr_year = (items[i].diainicio[0]+items[i].diainicio[1]+items[i].diainicio[2]+items[i].diainicio[3]);
                var j = curr_date + "/" + curr_month + "/" + curr_year+ ' '+h2 + ':' + m2;
                items[i].datainicio = j;
                if(items[i].estado == 0){
                  items[i].confirmacao = "Vai acontecer"
                }
                if(items[i].estado == 1){
                  items[i].confirmacao = "Finalizado"
                }
                if(items[i].estado == 2){
                  items[i].confirmacao = "Standy by, talvez aconteça"
                }
                if(items[i].estado == 3){
                  items[i].confirmacao = "Vai acontecer"
                }
                if(items[i].estado == 4){
                  items[i].confirmacao = "Cancelado"
                }
                if(items[i].estado == 5){
                  items[i].confirmacao = "Acabado"
                }
                if(items[i].estado == 6){
                  items[i].confirmacao = "Escondido"
                }
            }
            $scope.items = items.concat($scope.items);
            $scope.lastidvestido = $scope.items[0].idevento;
          }
        });
      }
    }

    $scope.loadAbertos = function() {
       $scope.CoisasCriado = false;
        $scope.CoisasFinalizado = true;
      if(auxbloqueado!=3){
        $scope.estadobutton = 1;
        $scope.items = [];
        EventoService.GetAbertos($scope.stalkeada.iduser).then(function(items) {  //mudar
          if(items == 'E'){
            $scope.items = [];
          }else{
            for (var i = 0; i < items.length; i++) {
                var curr_date = (items[i].diainicio[8]+items[i].diainicio[9]);
                var h2 = (items[i].diainicio[11]+items[i].diainicio[12]);
                var m2 = (items[i].diainicio[14]+items[i].diainicio[15]);
                var curr_month = (items[i].diainicio[5]+items[i].diainicio[6]);
                var curr_year = (items[i].diainicio[0]+items[i].diainicio[1]+items[i].diainicio[2]+items[i].diainicio[3]);
                var j = curr_date + "/" + curr_month + "/" + curr_year+ ' '+h2 + ':' + m2;
                items[i].datainicio = j;
            }
            $scope.items = items.concat($scope.items);
            $scope.lastidvestido = $scope.items[0].idevento;
          }
        });
      }
    }

    $scope.loadFechados = function() {
       $scope.CoisasCriado = false;
        $scope.CoisasFinalizado = true;
      if(auxbloqueado!=3){
        $scope.estadobutton = 2;
        $scope.items = [];
        //console.log($scope.user.iduser);
        EventoService.GetFinalizadosPerfil($scope.stalkeada.iduser).then(function(items) {         //mudar
          if(items=='E'){
            $scope.items = [];
          }else{
            for (var i = 0; i < items.length; i++) {
                var curr_date = (items[i].diainicio[8]+items[i].diainicio[9]);
                var h2 = (items[i].diainicio[11]+items[i].diainicio[12]);
                var m2 = (items[i].diainicio[14]+items[i].diainicio[15]);
                var curr_month = (items[i].diainicio[5]+items[i].diainicio[6]);
                var curr_year = (items[i].diainicio[0]+items[i].diainicio[1]+items[i].diainicio[2]+items[i].diainicio[3]);
                var j = curr_date + "/" + curr_month + "/" + curr_year+ ' '+h2 + ':' + m2;
                items[i].datainicio = j;
            }
            $scope.items = items.concat($scope.items);
            $scope.lastidvestido = $scope.items[0].idevento;
          }
        });
      }
    }

    $scope.loadMore = function() {
      if ($scope.estadobutton == 0&& auxbloqueado!=3) {
        EventoService.GetOldEventosCriados().then(function(items) {
        $scope.items = $scope.items.concat(items);
        $scope.$broadcast('scroll.infiniteScrollComplete');
          // an empty array indicates that there are no more items
          if (items.length <= 4) {
            $scope.noMoreItemsAvailable = true;
          }

        });
      }
      if ($scope.estadobutton == 1 && auxbloqueado!=3) {
        EventoService.GetOldEventosCriados().then(function(items) {
        $scope.items = $scope.items.concat(items);
        $scope.$broadcast('scroll.infiniteScrollComplete');
          // an empty array indicates that there are no more items
          if (items.length <= 4) {
            $scope.noMoreItemsAvailable = true;
          }
        });

        
      }
      if ($scope.estadobutton == 2 && auxbloqueado!=3) {
        EventoService.GetOldEventosCriados().then(function(items) {
        $scope.items = $scope.items.concat(items);
        $scope.$broadcast('scroll.infiniteScrollComplete');
          // an empty array indicates that there are no more items
          if (items.length <= 4) {
            $scope.noMoreItemsAvailable = true;
          }
        });

      
      }
    }

    $scope.reportar = function(){
      $scope.reportmsg = '';
      console.log($scope.stalkeada.username);
      $scope.report = [
      { text: "Nome impróprio", checked: false },
      { text: "Comportamento inadequado", checked: false },
      { text: "Foto inapropriada", checked: false },
      { text: "É um impostor", checked: false }];

        $ionicPopup.confirm({
          title: 'Você quer reportar essa pessoa pq?',
          content: '<ion-checkbox ng-repeat="item in report" style="color: #FCFCFC;" ng-model="item.checked" style="text-align: center;overflow: hidden;text-overflow: none !important; white-space: initial !important;" ng-checked="item.checked">{{item.text}}</ion-checkbox>',
          scope: $scope}).then(function(res) {
          if(res) {
            for (var h=0;h<3;h++){
              //console.log($scope.report[h].checked , h);
              if($scope.report[h].checked){
                $scope.reportmsg = $scope.reportmsg + $scope.report[h].text + ' ';
                //console.log($scope.reportmsg);
              }
            }
            if(h==3){
              console.log($scope.reportmsg);
              $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/reportaevento.php', {namereportado : $scope.stalkeada.username,
                                                                              reportadoid : $scope.stalkeada.iduser,
                                                                              iduserreportando : $scope.user.iduser,
                                                                              usernamereportando : $scope.user.username,
                                                                              tiporeport : 'usuario',
                                                                              motivo : $scope.reportmsg}).then(function (tes){
                $scope.response = tes.data;
                var alertPopup = $ionicPopup.alert({
                  title: 'Obrigado',
                  template: 'Esta pessoa esta agora sobre investigação, obrigado por manter a plataforma segura'
                });
              });
            }
          }
        });
      }

    $scope.enterItem =  function(item){
      //formEventoPerfil
      formEventoPerfil.updateForm(item);
      //formItem.updateForm(item);
      console.log(item.idevento);
      $state.go('tabsController.evento_do_eventoCriados_do_outro');
    }

}])

.controller('evento_do_eventoCriados_do_outroCtrl', ['$scope', '$stateParams', 'formItem', 'formUser', 'formOutro', '$http', '$timeout','$ionicPopup', 'EventoService', '$state', 'formEventoPerfil', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, formItem, formUser, formOutro, $http, $timeout, $ionicPopup, EventoService, $state, formEventoPerfil) {
    //$scope.evento = formItem.getForm();
    $scope.evento = formEventoPerfil.getForm();
    $scope.aux = formUser.getForm();
    $scope.nuser = 0;
    $scope.limiteconfirmacao ={};
    $scope.fim = {};
    $scope.dia = {};
    if(!$scope.evento.endereco){
      console.log($scope.evento.idevento)
      $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/geteventoporid.php', {idevento : $scope.evento.idevento}).then(function (result){
        $scope.evento = result.data[0];
        formEventoPerfil.updateForm($scope.evento);
        //formItem.updateForm($scope.evento);
     
    var hj = $scope.evento.diainicio;
    //$scope.dia = (hj[8]+hj[9]).valueOf()+'/'+(hj[5]+hj[6]).valueOf()+'/'+(hj[0]+hj[1]+hj[2]+hj[3])+' '+(hj[11]+hj[12]).valueOf()+':'+(hj[14]+hj[15]).valueOf();
    var hjf = $scope.evento.diafim;
    $scope.diafim =  (hjf[8]+hjf[9]).valueOf()+'/'+(hjf[5]+hjf[6]).valueOf()+'/'+(hjf[0]+hjf[1]+hjf[2]+hjf[3])+' '+(hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf();
    
    var hjd = $scope.evento.duracao;
    var hd = (hjd[0]+hjd[1]).valueOf();
    var md = (hjd[3]+hjd[4]).valueOf();
    $scope.duracao= hd+':'+md;

    var  hjl = $scope.evento.dialimiteconfirmacao;
    $scope.limiteconfirmacao.dia =  (hjl[8]+hjl[9]).valueOf()+'/'+(hjl[5]+hjl[6]).valueOf();
    $scope.limiteconfirmacao.hora =  (hjl[11]+hjl[12]).valueOf()+':'+(hjl[14]+hjl[15]).valueOf();  
    
    

    var hjf = $scope.evento.diafim;
    $scope.fim.dia =  (hjf[8]+hjf[9]).valueOf()+'/'+(hjf[5]+hjf[6]).valueOf()+'/'+(hjf[0]+hjf[1]+hjf[2]+hjf[3]);
    $scope.fim.hora = (hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf();
    $scope.dia.dia = (hj[8]+hj[9]).valueOf()+'/'+(hj[5]+hj[6]).valueOf();
    $scope.dia.hora = (hj[11]+hj[12]).valueOf()+':'+(hj[14]+hj[15]).valueOf() +' - '+(hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf() ;
      });
    }else{
      var hjl = $scope.evento.dialimiteconfirmacao;
        $scope.limiteconfirmacao.dia =  (hjl[8]+hjl[9]).valueOf()+'/'+(hjl[5]+hjl[6]).valueOf();
        $scope.limiteconfirmacao.hora =  (hjl[11]+hjl[12]).valueOf()+':'+(hjl[14]+hjl[15]).valueOf();  
      
      
        var hj = $scope.evento.diainicio;    
        ///$scope.dia = (hj[8]+hj[9]).valueOf()+'/'+(hj[5]+hj[6]).valueOf()+'/'+(hj[0]+hj[1]+hj[2]+hj[3])+' '+(hj[11]+hj[12]).valueOf()+':'+(hj[14]+hj[15]).valueOf();
        var hjf = $scope.evento.diafim;
        $scope.diafim =  (hjf[8]+hjf[9]).valueOf()+'/'+(hjf[5]+hjf[6]).valueOf()+'/'+(hjf[0]+hjf[1]+hjf[2]+hjf[3])+' '+(hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf();
        $scope.fim.dia =  (hjf[8]+hjf[9]).valueOf()+'/'+(hjf[5]+hjf[6]).valueOf()+'/'+(hjf[0]+hjf[1]+hjf[2]+hjf[3]);
        $scope.fim.hora = (hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf();
        $scope.dia.dia = (hj[8]+hj[9]).valueOf()+'/'+(hj[5]+hj[6]).valueOf();
        $scope.dia.hora = (hj[11]+hj[12]).valueOf()+':'+(hj[14]+hj[15]).valueOf() +' - '+(hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf() ;
    }

    $scope.$on("$ionicView.enter", function(event, data){
      $scope.items = [];
      //$scope.evento = formItem.getForm();
      $scope.evento = formEventoPerfil.getForm();
      
      if(!$scope.evento.endereco){
        console.log($scope.evento.idevento)
        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/geteventoporid.php', {idevento : $scope.evento.idevento}).then(function (result){
          $scope.evento = result.data[0];
          //formItem.updateForm($scope.evento);

          formEventoPerfil.updateForm($scope.evento);
        });
      }
      hj = $scope.evento.diainicio;
      //$scope.dia = (hj[8]+hj[9]).valueOf()+'/'+(hj[5]+hj[6]).valueOf()+'/'+(hj[0]+hj[1]+hj[2]+hj[3])+' '+(hj[11]+hj[12]).valueOf()+':'+(hj[14]+hj[15]).valueOf();
       hjf = $scope.evento.diafim;
      $scope.diafim =  (hjf[8]+hjf[9]).valueOf()+'/'+(hjf[5]+hjf[6]).valueOf()+'/'+(hjf[0]+hjf[1]+hjf[2]+hjf[3])+' '+(hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf();
      $scope.dia.dia = (hj[8]+hj[9]).valueOf()+'/'+(hj[5]+hj[6]).valueOf();
      $scope.dia.hora = (hj[11]+hj[12]).valueOf()+':'+(hj[14]+hj[15]).valueOf() +' - '+(hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf() ;
      
      EventoService.GetParticipantes($scope.evento.idevento).then(function(items) {
        $scope.nomeevento = items[0].nomeevento;
        for (var i = 0; i < items.length; i++) {
          if ($scope.aux.iduser == items[i].iduser) {
            $scope.nuser++;
          }
          if (items[i].estado == 0) {
            items[i].confirmacao = 'Sou o organizador';
          }
          if (items[i].estado == 1) {
            items[i].confirmacao = 'Aguardando confirmação';
          }
          if (items[i].estado == 2) {
            items[i].confirmacao = 'Confirmação aprovada';
          }
          if(items[i].borda == 0){
            items[i].bb = false;
            items[i].bs = false;
            items[i].bg = false;
          }
          if(items[i].borda == 1){
            items[i].bb = true;
            items[i].bs = false;
            items[i].bg = false;
          }
          if(items[i].borda == 2){
            items[i].bb = false;
            items[i].bs = true;
            items[i].bg = false;
          }
          if(items[i].borda == 3){
            items[i].bb = false;
            items[i].bs = false;
            items[i].bg = true;
          }
          if(items[i].profilepic[8] == 's' && items[i].profilepic[9] == '3'){
            items[i].profilepic = items[i].profilepic+"?{{getTimeStamp()}}";
           }else{
             items[i].profilepic = items[i].profilepic;
           }
          //items[i].profilepic = items[i].profilepic+"?{{getTimeStamp()}}";
        }
        $scope.items = items.concat($scope.items);
        
      });
    });

    if($scope.evento.genero == "masc"){
      $scope.masc = true;
      $scope.fem = false;
    }
    if($scope.evento.genero == "fem"){
        $scope.fem = true;
        $scope.masc = false;
    }
    if($scope.evento.genero == "todos"){
        $scope.fem = false;
        $scope.masc = false;
    }
    if($scope.evento.preco == 0 || $scope.evento.preco =="Gratuito"){
      $scope.evento.preco = "Gratuito";
      $scope.porpessoa = false;
      $scope.porlocal = false;
    }else{
      if($scope.evento.precopor == 1){
        $scope.porpessoa = true;
        $scope.porlocal = false;
      }else{
        $scope.porpessoa = false;
        $scope.porlocal = true;
      }
    }

    // $scope.enterItem =  function(item){
    //   formOutro.updateForm(item.iduser);
    //   console.log(item.iduser);
    //   $state.go('tabsController.perfil_outro_eventocriados');
    // }

}])

.controller('evento_do_eventoAbertos_do_outroCtrl', ['$scope', '$stateParams', 'formItem', 'formUser', 'formOutro', '$http', '$timeout','$ionicPopup', 'EventoService', '$state', 'formEventoAbertosTab', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, formItem, formUser, formOutro, $http, $timeout, $ionicPopup, EventoService, $state, formEventoAbertosTab) {
    //$scope.evento = formItem.getForm();
    $scope.evento = formEventoAbertosTab.getForm();
    $scope.aux = formUser.getForm();
    $scope.limiteconfirmacao ={};
    $scope.fim = {};
    $scope.dia = {};

    if(!$scope.evento.endereco){
      console.log($scope.evento.idevento)
      $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/geteventoporid.php', {idevento : $scope.evento.idevento}).then(function (result){
      $scope.evento = result.data[0];
        
      
      console.log($scope.evento.endereco);
      
      $scope.nuser = 0;

      var hj = $scope.evento.diainicio;
      //$scope.dia = (hj[8]+hj[9]).valueOf()+'/'+(hj[5]+hj[6]).valueOf()+'/'+(hj[0]+hj[1]+hj[2]+hj[3])+' '+(hj[11]+hj[12]).valueOf()+':'+(hj[14]+hj[15]).valueOf();
      var hjf = $scope.evento.diafim;
      $scope.diafim =  (hjf[8]+hjf[9]).valueOf()+'/'+(hjf[5]+hjf[6]).valueOf()+'/'+(hjf[0]+hjf[1]+hjf[2]+hjf[3])+' '+(hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf();
      var hjd = $scope.evento.duracao;
      var hd = (hjd[0]+hjd[1]).valueOf();
      var md = (hjd[3]+hjd[4]).valueOf();
      $scope.duracao= hd+':'+md;

      var  hjl = $scope.evento.dialimiteconfirmacao;
      $scope.limiteconfirmacao.dia =  (hjl[8]+hjl[9]).valueOf()+'/'+(hjl[5]+hjl[6]).valueOf();
      $scope.limiteconfirmacao.hora =  (hjl[11]+hjl[12]).valueOf()+':'+(hjl[14]+hjl[15]).valueOf();  
      
      

      var hjf = $scope.evento.diafim;
      $scope.fim.dia =  (hjf[8]+hjf[9]).valueOf()+'/'+(hjf[5]+hjf[6]).valueOf()+'/'+(hjf[0]+hjf[1]+hjf[2]+hjf[3]);
      $scope.fim.hora = (hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf();
      $scope.dia.dia = (hj[8]+hj[9]).valueOf()+'/'+(hj[5]+hj[6]).valueOf();
      $scope.dia.hora = (hj[11]+hj[12]).valueOf()+':'+(hj[14]+hj[15]).valueOf() +' - '+(hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf() ;
        });
    }

    $scope.$on("$ionicView.enter", function(event, data){
      $scope.items = [];
      //$scope.evento = formItem.getForm();
      $scope.evento = formEventoAbertosTab.getForm();
      $scope.limiteconfirmacao ={};
      $scope.fim = {};
      $scope.dia = {};
      if(!$scope.evento.endereco){
        console.log($scope.evento.idevento)
        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/geteventoporid.php', {idevento : $scope.evento.idevento}).then(function (result){
          $scope.evento = result.data[0];
         //formItem.updateForm($scope.evento);
         formEventoAbertosTab.updateForm($scope.evento);


        var hjl = $scope.evento.dialimiteconfirmacao;
        $scope.limiteconfirmacao.dia =  (hjl[8]+hjl[9]).valueOf()+'/'+(hjl[5]+hjl[6]).valueOf();
        $scope.limiteconfirmacao.hora =  (hjl[11]+hjl[12]).valueOf()+':'+(hjl[14]+hjl[15]).valueOf();  
      
      
        var hj = $scope.evento.diainicio;    
        ///$scope.dia = (hj[8]+hj[9]).valueOf()+'/'+(hj[5]+hj[6]).valueOf()+'/'+(hj[0]+hj[1]+hj[2]+hj[3])+' '+(hj[11]+hj[12]).valueOf()+':'+(hj[14]+hj[15]).valueOf();
        var hjf = $scope.evento.diafim;
        $scope.diafim =  (hjf[8]+hjf[9]).valueOf()+'/'+(hjf[5]+hjf[6]).valueOf()+'/'+(hjf[0]+hjf[1]+hjf[2]+hjf[3])+' '+(hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf();
        $scope.fim.dia =  (hjf[8]+hjf[9]).valueOf()+'/'+(hjf[5]+hjf[6]).valueOf()+'/'+(hjf[0]+hjf[1]+hjf[2]+hjf[3]);
        $scope.fim.hora = (hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf();
        $scope.dia.dia = (hj[8]+hj[9]).valueOf()+'/'+(hj[5]+hj[6]).valueOf();
        $scope.dia.hora = (hj[11]+hj[12]).valueOf()+':'+(hj[14]+hj[15]).valueOf() +' - '+(hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf() ;
         });
      }else{
        var hjl = $scope.evento.dialimiteconfirmacao;
        $scope.limiteconfirmacao.dia =  (hjl[8]+hjl[9]).valueOf()+'/'+(hjl[5]+hjl[6]).valueOf();
        $scope.limiteconfirmacao.hora =  (hjl[11]+hjl[12]).valueOf()+':'+(hjl[14]+hjl[15]).valueOf();  
      
      
        var hj = $scope.evento.diainicio;    
        ///$scope.dia = (hj[8]+hj[9]).valueOf()+'/'+(hj[5]+hj[6]).valueOf()+'/'+(hj[0]+hj[1]+hj[2]+hj[3])+' '+(hj[11]+hj[12]).valueOf()+':'+(hj[14]+hj[15]).valueOf();
        var hjf = $scope.evento.diafim;
        $scope.diafim =  (hjf[8]+hjf[9]).valueOf()+'/'+(hjf[5]+hjf[6]).valueOf()+'/'+(hjf[0]+hjf[1]+hjf[2]+hjf[3])+' '+(hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf();
        $scope.fim.dia =  (hjf[8]+hjf[9]).valueOf()+'/'+(hjf[5]+hjf[6]).valueOf()+'/'+(hjf[0]+hjf[1]+hjf[2]+hjf[3]);
        $scope.fim.hora = (hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf();
        $scope.dia.dia = (hj[8]+hj[9]).valueOf()+'/'+(hj[5]+hj[6]).valueOf();
        $scope.dia.hora = (hj[11]+hj[12]).valueOf()+':'+(hj[14]+hj[15]).valueOf() +' - '+(hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf() ;
      }
      EventoService.GetParticipantes($scope.evento.idevento).then(function(items) {
        $scope.nomeevento = items[0].nomeevento;
        for (var i = 0; i < items.length; i++) {
          if ($scope.aux.iduser == items[i].iduser) {
            $scope.nuser++;
          }
          if (items[i].estado == 0) {
            items[i].confirmacao = 'Sou o organizador';
          }
          if (items[i].estado == 1) {
            items[i].confirmacao = 'Aguardando confirmação';
          }
          if (items[i].estado == 2) {
            items[i].confirmacao = 'Confirmação aprovada';
          }
          if(items[i].borda == 0){
            items[i].bb = false;
            items[i].bs = false;
            items[i].bg = false;
          }
          if(items[i].borda == 1){
            items[i].bb = true;
            items[i].bs = false;
            items[i].bg = false;
          }
          if(items[i].borda == 2){
            items[i].bb = false;
            items[i].bs = true;
            items[i].bg = false;
          }
          if(items[i].borda == 3){
            items[i].bb = false;
            items[i].bs = false;
            items[i].bg = true;
          }
          if(items[i].profilepic[8] == 's' && items[i].profilepic[9] == '3'){
            items[i].profilepic = items[i].profilepic+"?{{getTimeStamp()}}";
           }else{
             items[i].profilepic = items[i].profilepic;
           }
        }
        $scope.items = items.concat($scope.items);
      });
    });
    if($scope.evento.genero == "masc"){
      $scope.masc = true;
      $scope.fem = false;
    }
    if($scope.evento.genero == "fem"){
        $scope.fem = true;
        $scope.masc = false;
    }
    if($scope.evento.genero == "todos"){
        $scope.fem = false;
        $scope.masc = false;
    }
    if($scope.evento.preco == 0 || $scope.evento.preco =="Gratuito"){
      $scope.evento.preco = "Gratuito";
      $scope.porpessoa = false;
      $scope.porlocal = false;
    }else{
      if($scope.evento.precopor == 1){
        $scope.porpessoa = true;
        $scope.porlocal = false;
      }else{
        $scope.porpessoa = false;
        $scope.porlocal = true;
      }
    }
    $scope.enterItem =  function(item){
      formOutro.updateForm(item);
      console.log(item.iduser)
      $state.go('tabsController.perfil_outro_eventoabertos');
    }


}])

.controller('convitescriarCtrl', ['$scope', '$stateParams', 'formItem', 'EventoService', 'formUser','$state', '$http', '$timeout','$ionicPopup', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, formItem, EventoService, formUser,$state, $http, $timeout, $ionicPopup) {

    $scope.user = formUser.getForm();
    if(!$scope.user.codigo || $scope.user.codigo == 'null'){
    $scope.user.codigo = '';
    }
    $scope.user.auxcodigo = '';
    $scope.criarcodigo = function(){
      var currentdate = new Date(); 
      var curr_date = (currentdate.getDate()<10?'0':'') + currentdate.getDate();
      var curr_month = (currentdate.getMonth()<10?'0':'') + (currentdate.getMonth() + 1); 
      var curr_year = currentdate.getFullYear();
      var h2 = (currentdate.getHours()<10?'0':'') + currentdate.getHours();
      var m2 = (currentdate.getMinutes()<10?'0':'') + currentdate.getMinutes();
      var j = curr_year + "-" + curr_month + "-" + curr_date+ ' '+h2 + ':' + m2 + ':00';

      var res2 = $scope.user.codigo.split(" ") ;
          if(res2.length>=1){
            for(var w = 0; w < res2.length; w++){
              $scope.user.auxcodigo = $scope.user.auxcodigo + res2[w];
            }
          }
      $scope.user.codigo = $scope.user.auxcodigo;
      console.log($scope.user.codigo.length,$scope.user.codigo )
      if($scope.user.codigo.length<6){
          var alertPopup = $ionicPopup.alert({
            title: 'Seu código é muito curto',
            template: 'Escreva outro'
          });
          $scope.user.codigo = '';
      }else{
        EventoService.confereconvite($scope.codigo).then(function(resp) {
          console.log(resp.success, "fewe")
          if(resp.success == false){
            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/criacodigouser.php' , {iduser :$scope.user.iduser, 
                                                                        codigo :  $scope.user.codigo,
                                                                        codigodatacriacao : j}).then(function(msg){
             if(msg.data.success == true){
              $scope.msn = 'Não se esqueça que seu código é: ' + $scope.user.codigo;
              var alertPopup = $ionicPopup.alert({
                title: 'Seu código foi criado',
                template: $scope.msn
              });
              alertPopup.then(function(){
                window.localStorage.setItem( 'user', JSON.stringify($scope.user));
                formUser.updateForm($scope.user);
                $state.go('tabsController.perfil');
              });
             }else{
              var alertPopup = $ionicPopup.alert({
                title: 'Ouve uma falha',
                template: 'Algo de certo não deu errado, O Q????'
              });
              alertPopup.then(function(){
                
                $state.go('tabsController.perfil');
              });
             } 
            });
          }else{
            var alertPopup = $ionicPopup.alert({
              title: 'Código ja existe',
              template: 'Crie um código!!'
            });
          }
        });
        
      }

      
    }

}])
   
.controller('perfilCtrl', ['$scope', '$stateParams','$http', 'EventoService', '$timeout', 'formUser', '$state', 'formItem', 'formtela','formpontos', 'formEditar', 'formEventoPerfil', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $http, EventoService, $timeout, formUser, $state, formItem, formtela, formpontos, formEditar, formEventoPerfil) {
  formEditar.updateForm(0);
  $scope.user = formUser.getForm();
  console.log($scope.user.codigo, "$scope.user.codigo")
  if(!$scope.user.codigo || $scope.user.codigo == 'null'){
    $scope.temcodigo = true;
    console.log("oi")
  }else{
    $scope.temcodigo = false;
  }

  if($scope.user.borda == 0){
    $scope.estrelabb = false;
    $scope.estrelabs = false;
    $scope.estrelabg = false;
    //$scope.brooch = false;
  }
  if($scope.user.borda == 1){
    $scope.estrelabb = true;
    $scope.estrelabs = false;
    $scope.estrelabg = false;
    //$scope.brooch = false;
  }
  if($scope.user.borda == 2){
    $scope.estrelabb = false;
    $scope.estrelabs = true;
    $scope.estrelabg = false;
    $scope.brooch = false;
  }
  if($scope.user.borda == 3){
    $scope.estrelabb = false;
    $scope.estrelabs = false;
    $scope.estrelabg = true;
    //$scope.brooch = false;
  }
  // if($scope.user.borda == 42){
  //   $scope.estrelabb = false;
  //   $scope.estrelabs = false;
  //   $scope.estrelabg = false;
  //   $scope.brooch = true;
  // }
  $scope.estadobutton = 0;  
  $scope.neventos= 0;
  $scope.neventosnao= 0;
  $scope.CoisasCriado = true;
  $scope.CoisasFinalizado = false;
  $scope.ic = {};
  $scope.atualiza ={};
  $scope.idader = '';
  $scope.frase = {};
  EventoService.getusuario($scope.user).then(function(user) {
        $scope.user = user;
        
        if(user.profilepic[8] == 's' && user.profilepic[9] == '3'){
         document.getElementById("imageid").src=user.profilepic+"?{{getTimeStamp()}}";
         }else{
          document.getElementById("imageid").src=user.profilepic;
         }
        console.log(user.profilepic)
        if($scope.user.borda == 0){
          $scope.estrelabb = false;
          $scope.estrelabs = false;
          $scope.estrelabg = false;
          //$scope.brooch = false;
        }
        if($scope.user.borda == 1){
          $scope.estrelabb = true;
          $scope.estrelabs = false;
          $scope.estrelabg = false;
          //$scope.brooch = false;
        }
        if($scope.user.borda == 2){
          $scope.estrelabb = false;
          $scope.estrelabs = true;
          $scope.estrelabg = false;
          //$scope.brooch = false;
        }
        if($scope.user.borda == 3){
          $scope.estrelabb = false;
          $scope.estrelabs = false;
          $scope.estrelabg = true;
          $scope.brooch = false;
        }
        // if($scope.user.borda == 42){
        //   $scope.estrelabb = false;
        //   $scope.estrelabs = false;
        //   $scope.estrelabg = false;
        //   $scope.brooch = true;
        // }
        if($scope.user.idade){
          $scope.idader = ", "+ $scope.user.idade +" anos";
        }
      });
  
  var infiscroll = 0;  

  $scope.noMoreItemsAvailable = true;



  var header = document.getElementById("barperfil");
    var btns = header.getElementsByClassName("btnperfil");
    for (var i = 0; i < btns.length; i++) {
      btns[i].addEventListener("click", function() {
        var current = document.getElementsByClassName("actperfil");
        current[0].className = current[0].className.replace(" actperfil", "");
        this.className += " actperfil";
      });
    }

  EventoService.GetPontos($scope.user.iduser).then(function(items) {
    $scope.p = items;
    $scope.labels3 = ["Pontos"];
    $scope.colores3 = ["#ff4d4d"];
    $scope.data3 = [$scope.p];
    $scope.atualiza.pontos = $scope.p;
    $scope.atualiza.iduser = $scope.user.iduser;
    EventoService.atualizarpontos($scope.atualiza);
  });


    $scope.$on("$ionicView.enter", function(event, data){
      var das = document.getElementById("barperfilprimeiro");
      var current = document.getElementsByClassName("actperfil");
      current[0].className = current[0].className.replace(" actperfil", "");
      das.className += " actperfil";
      $scope.user = formUser.getForm();
      console.log($scope.user.codigo)
      $scope.idader = '';
      var infiscroll = 0;
      $scope.CoisasCriado = false;
      $scope.CoisasFinalizado = false;
      $scope.items = [];
      $scope.vezes = 0;
      $scope.newItems = [];
      $scope.lastidevento = 0;
      $scope.aux = 0;
      $scope.frase = {};
      //$scope.ic = {};
      formEditar.updateForm(0);

      if($scope.user.idade){
        $scope.idader = ", "+ $scope.user.idade +" anos";
        console.log($scope.idader)
      }
      if(!$scope.user.codigo || $scope.user.codigo == 'null'){
        $scope.temcodigo = true;
        console.log("oi")
      }else{
        $scope.temcodigo = false;
      }
      EventoService.getIC($scope.user).then(function(items) {
        if(items){
          $scope.ic = items;
          $scope.options2 = {title: {
                      display: true,
                      text: 'Indice de confirmação',
                      position: 'bottom'
                  }
           }
          $scope.labels2 = ["Fui", "Não fui"];
          $scope.colores2 = ["#99FF99","#ff4d4d"];
          var menos = (100-$scope.ic.total).toFixed(1);
          var mais = $scope.ic.total;
          $scope.data2 = [mais, menos ];
        }
        
      });
      EventoService.getusuario($scope.user).then(function(user) {
        $scope.user = user;
        if($scope.user.borda == 0){
          $scope.estrelabb = false;
          $scope.estrelabs = false;
          $scope.estrelabg = false;
          //$scope.brooch = false;
        }
        if($scope.user.borda == 1){
          $scope.estrelabb = true;
          $scope.estrelabs = false;
          $scope.estrelabg = false;
          //$scope.brooch = false;
        }
        if($scope.user.borda == 2){
          $scope.estrelabb = false;
          $scope.estrelabs = true;
          $scope.estrelabg = false;
          //$scope.brooch = false;
        }
        if($scope.user.borda == 3){
          $scope.estrelabb = false;
          $scope.estrelabs = false;
          $scope.estrelabg = true;
          //$scope.brooch = false;
        }
        // if($scope.user.borda == 42){
        //   $scope.estrelabb = false;
        //   $scope.estrelabs = false;
        //   $scope.estrelabg = false;
        //   $scope.brooch = true;
        // }
        
        if(user.profilepic[8] == 's' && user.profilepic[9] == '3'){
         document.getElementById("imageid").src=user.profilepic+"?{{getTimeStamp()}}";
         }else{
          document.getElementById("imageid").src=user.profilepic;
         }
        if(user){
         EventoService.GetComments3($scope.user).then(function(items) {
          if(items){
            $scope.options = {title: {
                      display: true,
                      text: 'Avaliações',
                      position: 'bottom'}};
            $scope.labels = ["Extrovertido", "Introvertido", "Realista","Curioso", "Solidário", "Racional","Organizado", "Criativo"];
            $scope.colores = ["#fff200", "#02fff2", "#ff9d00","#1867ce", "#e50be1", "#0e8c28","#ef370e", "#af0eef"];
            $scope.data =items.chart;
            $scope.frase = items.mal;
          }
        }); 
        }
        
      });
      EventoService.GetPontos($scope.user.iduser).then(function(items) {
        $scope.p = items;
        $scope.labels3 = ["Pontos"];
        $scope.colores3 = ["#ff4d4d"];
        $scope.data3 = [$scope.p];
        $scope.atualiza.pontos = $scope.p;
        $scope.atualiza.iduser = $scope.user.iduser;
        EventoService.atualizarpontos($scope.atualiza);
      });

      $scope.tela = formtela.getForm();
      if ($scope.tela == 1) {
        formtela.updateForm(0);
        $state.go('tabsController.eventoFechado');
      }
      if ($scope.tela == 2) {
        formtela.updateForm(0);
        $state.go('tabsController.comentarios');
      }
    });


    $scope.loadCriados = function() {
      $scope.CoisasCriado = true;
      $scope.CoisasFinalizado = false;
      $scope.estadobutton = 0;
      $scope.items = [];
      console.log($scope.user.iduser)
      EventoService.GetCriadosPerfil($scope.user).then(function(items) {
        if(items=='E'){
          $scope.items = [];
        }else{
          for (var i = 0; i < items.length; i++) {
                var curr_date = (items[i].diainicio[8]+items[i].diainicio[9]);
                var h2 = (items[i].diainicio[11]+items[i].diainicio[12]);
                var m2 = (items[i].diainicio[14]+items[i].diainicio[15]);
                var curr_month = (items[i].diainicio[5]+items[i].diainicio[6]);
                var curr_year = (items[i].diainicio[0]+items[i].diainicio[1]+items[i].diainicio[2]+items[i].diainicio[3]);
                var j = curr_date + "/" + curr_month + "/" + curr_year+ ' '+h2 + ':' + m2;
                items[i].datainicio = j;
                if(items[i].estado == 0){
                  items[i].confirmacao = "Vai acontecer"
                }
                if(items[i].estado == 1){
                  items[i].confirmacao = "Finalizado"
                }
                if(items[i].estado == 2){
                  items[i].confirmacao = "Standy by, talvez aconteça"
                }
                if(items[i].estado == 3){
                  items[i].confirmacao = "Vai acontecer"
                }
                if(items[i].estado == 4){
                  items[i].confirmacao = "Cancelado"
                }
                if(items[i].estado == 5){
                  items[i].confirmacao = "Acabado"
                }
                if(items[i].estado == 6){
                  items[i].confirmacao = "Escondido"
                }
            }
          $scope.items = items;
          $scope.lastidvestido = $scope.items[0].idevento;
        }
      });
      $scope.noMoreItemsAvailable = false;
    }

    $scope.loadFechados = function() {
      $scope.CoisasCriado = false;
      $scope.CoisasFinalizado = true;
      $scope.estadobutton = 2;
      $scope.items = {};
      //console.log($scope.user.iduser);

      EventoService.GetFinalizadosPerfil($scope.user.iduser).then(function(items) {        
        //console.log(items)
        if(items=='E'){
          $scope.items = [];
        }else{
          for (var i = 0; i < items.length; i++) {
                var curr_date = (items[i].diainicio[8]+items[i].diainicio[9]);
                var h2 = (items[i].diainicio[11]+items[i].diainicio[12]);
                var m2 = (items[i].diainicio[14]+items[i].diainicio[15]);
                var curr_month = (items[i].diainicio[5]+items[i].diainicio[6]);
                var curr_year = (items[i].diainicio[0]+items[i].diainicio[1]+items[i].diainicio[2]+items[i].diainicio[3]);
                var j = curr_date + "/" + curr_month + "/" + curr_year+ ' '+h2 + ':' + m2;
                items[i].datainicio = j;
               
            }
          $scope.items = items;
          $scope.lastidvestido = $scope.items[0].idevento;
        }
      });
        
    }

      
    $scope.loadMore = function() {
      if ($scope.estadobutton == 0) {
        EventoService.GetOldEventosCriados($scope.user).then(function(items) {
        $scope.items = $scope.items.concat(items);
          console.log(infiscroll);
          // an empty array indicates that there are no more items
          if (items.length <= 4 && infiscroll > 0) {
            $scope.noMoreItemsAvailable = true;
            infiscroll = 0;
          }
          infiscroll++;

        $scope.$broadcast('scroll.infiniteScrollComplete');
        });
      }
      if ($scope.estadobutton == 2) {
        EventoService.GetOldEventosCriados().then(function(items) {
        $scope.items = $scope.items.concat(items);
        $scope.$broadcast('scroll.infiniteScrollComplete');
          // an empty array indicates that there are no more items
          if (items.length <= 4) {
            $scope.noMoreItemsAvailable = true;
          }
        });

      
      }
    }
          
    $scope.enterItem =  function(items){
      formEventoPerfil.updateForm(items);
      //formItem.updateForm(items);
      console.log(items.idevento);
      console.log(items.idadm);
      if ($scope.estadobutton == 2) {
        $state.go('tabsController.eventoFechado');
      }
      if ($scope.estadobutton == 0) {
        $state.go('tabsController.eventoCriado');
      }
    }

    $scope.entrar = function(){
      $state.go('tabsController.comentarios');
    }

    $scope.entracriacodigo = function(){
      $state.go('tabsController.convitescriar');
    }

    $scope.indice = function(){
      $state.go('tabsController.indice');
    }

    $scope.ranking = function(){
      $state.go('tabsController.ranking');
    }

}])

.controller('indiceCtrl', ['$scope', '$stateParams', 'formItem', 'EventoService', 'formUser','$state', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, formItem, EventoService, formUser,$state) {
  $scope.user = formUser.getForm();
  $scope.ic = {};

  EventoService.getIC($scope.user).then(function(ic) {
    if(ic){
      $scope.ic = ic;
    }
  });

}])

.controller('comentariosCtrl', ['$scope', '$stateParams', 'formItem', 'EventoService', 'formUser','$state', '$ionicPopup', '$http', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, formItem, EventoService, formUser,$state, $ionicPopup, $http) {
   
    $scope.user = formUser.getForm();
    $scope.items = {};
    $scope.it = {};
    $scope.mandeimal = {};
    $scope.mandeibem = {};
    $scope.mostraruim = false;
    $scope.mostratodos = true;
    $scope.mostrabom = false;

    var header2 = document.getElementById("barcome");
    var btns2 = header2.getElementsByClassName("btncome");
    for (var i = 0; i < btns2.length; i++) {
      btns2[i].addEventListener("click", function() {
        var current2 = document.getElementsByClassName("act");
        current2[0].className = current2[0].className.replace(" act", "");
        this.className += " act";
      });
    }

    EventoService.GetComments3($scope.user).then(function(items) {
      if(!items){
        $scope.items = {};
        $scope.mandeimal = {};
        $scope.mandeibem = {};
      }else{
         $scope.labels = ["Extrovertido", "Introvertido", "Realista","Curioso", "Solidário", "Racional","Organizado", "Criativo"];
        $scope.colores = ["#fff200", "#02fff2", "#ff9d00","#1867ce", "#e50be1", "#0e8c28","#ef370e", "#af0eef"];
        $scope.data =items.chart;
        $scope.ncomen = items.mal;
        $scope.mandeimal = items.ruins;
        $scope.mandeibem = items.bons;
        $scope.items = items.resto;
        for(var i = 0;i<items.tudo.length;i++){
           if(items.tudo[i].profilepic[8] == 's' && items.tudo[i].profilepic[9] == '3'){
             $scope.items[i].profilepic = items.tudo[i].profilepic+"?{{getTimeStamp()}}";
           }else{
              $scope.items[i].profilepic = items.tudo[i].profilepic;
           }
          //$scope.items[i].profilepic = items.tudo[i].profilepic+"?{{getTimeStamp()}}";
        }
        for(var i = 0;i<items.bons.length;i++){
          if(items.bons[i].profilepic[8] == 's' && items.bons[i].profilepic[9] == '3'){
             $scope.mandeibem[i].profilepic = items.bons[i].profilepic+"?{{getTimeStamp()}}";
           }else{
              $scope.mandeibem[i].profilepic = items.bons[i].profilepic;
           }
          //$scope.mandeibem[i].profilepic = items.bons[i].profilepic+"?{{getTimeStamp()}}";
        }
        for(var i = 0;i<items.ruins.length;i++){
          if(items.ruins[i].profilepic[8] == 's' && items.ruins[i].profilepic[9] == '3'){
             $scope.mandeimal[i].profilepic = items.ruins[i].profilepic+"?{{getTimeStamp()}}";
           }else{
              $scope.mandeimal[i].profilepic = items.ruins[i].profilepic;
           }
          //$scope.mandeimal[i].profilepic = items.ruins[i].profilepic+"?{{getTimeStamp()}}";
        }
        // document.getElementById("imageidComent").src=$scope.items.profilepic+"?{{getTimeStamp()}}";
        // document.getElementById("imageidComentmandeibem").src=$scope.mandeibem.profilepic+"?{{getTimeStamp()}}";
        // document.getElementById("imageidComentmandeimal").src=$scope.mandeimal.profilepic+"?{{getTimeStamp()}}";
      }
    });

    $scope.bom = function(){
      $scope.mostraruim = false;
      $scope.mostrabom = true;
      $scope.mostratodos = false;
    }
    $scope.ruim = function(){
      $scope.mostraruim = true;
      $scope.mostrabom = false;
      $scope.mostratodos = false;
    }
    $scope.todos = function(){
      $scope.mostraruim = false;
      $scope.mostrabom = false;
      $scope.mostratodos = true;
    }
    $scope.reportcoment = function(item){
      $ionicPopup.prompt({
                    title: 'Você quer reportar esse comentário pq?',
                    template: 'Não me venha reportando só pq tu quer, não me venha dar trabalho!!!!',
                   inputType: 'text',
                   inputPlaceholder: ' Linguajar ofensivo ou inapropriado'
                 }).then(function(texto) {
                  if(texto){
                    $scope.reportmsg = item.idavaliacao + ' (idavaliação) '+texto;
                    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/reportaevento.php', {namereportado : item.nomeavaliador,
                                                                              reportadoid : item.iduser,
                                                                              iduserreportando : $scope.user.iduser,
                                                                              usernamereportando : $scope.user.username,
                                                                              tiporeport : 'comentario',
                                                                              motivo : $scope.reportmsg}).then(function (tes){
                                 $scope.response = tes.data;
                                  var alertPopup = $ionicPopup.alert({
                                                          title: 'Obrigado',
                                                          template: 'Esta pessoa esta agora sobre investigação, obrigado por manter a plataforma segura'
                                                        });

                               });
                  }
                  
                 });
    }
  
      
}])

.controller('comentariosdosoutrosCtrl', ['$scope', '$stateParams', 'formItem', 'EventoService', 'formUser','$state', 'formOutro', 'formStalker', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, formItem, EventoService, formUser,$state, formOutro , formStalker) {
   
   $scope.user = formStalker.getForm();
   
   $scope.items = {};
   $scope.mandeimal = {};
    $scope.mandeibem = {};
    $scope.mostraruim = false;
    $scope.mostratodos = true;
    $scope.mostrabom = false;

    var header2 = document.getElementById("barcome");
    var btns2 = header2.getElementsByClassName("btncome");
    for (var i = 0; i < btns2.length; i++) {
      btns2[i].addEventListener("click", function() {
        var current2 = document.getElementsByClassName("act");
        current2[0].className = current2[0].className.replace(" act", "");
        this.className += " act";
      });
    }

    EventoService.GetComments3($scope.user).then(function(items) {
      if(!items){
        $scope.items = {};
      }else{
           $scope.labels = ["Extrovertido", "Introvertido", "Realista","Curioso", "Solidário", "Racional","Organizado", "Criativo"];
          $scope.colores = ["#fff200", "#02fff2", "#ff9d00","#1867ce", "#e50be1", "#0e8c28","#ef370e", "#af0eef"];
          $scope.data =items.chart;
          $scope.ncomen = items.mal;
          $scope.mandeimal = items.ruins;
          $scope.mandeibem = items.bons;
          $scope.items = items.resto;
           for(var i = 0;i<items.resto.length;i++){
           if(items.tudo[i].profilepic[8] == 's' && items.resto[i].profilepic[9] == '3'){
             $scope.items[i].profilepic = items.resto[i].profilepic+"?{{getTimeStamp()}}";
           }else{
              $scope.items[i].profilepic = items.resto[i].profilepic;
           }
          //$scope.items[i].profilepic = items.tudo[i].profilepic+"?{{getTimeStamp()}}";
        }
        for(var i = 0;i<items.bons.length;i++){
          if(items.bons[i].profilepic[8] == 's' && items.bons[i].profilepic[9] == '3'){
             $scope.mandeibem[i].profilepic = items.bons[i].profilepic+"?{{getTimeStamp()}}";
           }else{
              $scope.mandeibem[i].profilepic = items.bons[i].profilepic;
           }
          //$scope.mandeibem[i].profilepic = items.bons[i].profilepic+"?{{getTimeStamp()}}";
        }
        for(var i = 0;i<items.ruins.length;i++){
          if(items.ruins[i].profilepic[8] == 's' && items.ruins[i].profilepic[9] == '3'){
             $scope.mandeimal[i].profilepic = items.ruins[i].profilepic+"?{{getTimeStamp()}}";
           }else{
              $scope.mandeimal[i].profilepic = items.ruins[i].profilepic;
           }
          //$scope.mandeimal[i].profilepic = items.ruins[i].profilepic+"?{{getTimeStamp()}}";
        }
          // for(var i = 0;i<items.resto.length;i++){
          // $scope.items[i].profilepic = items.resto[i].profilepic+"?{{getTimeStamp()}}";
          // }
          // for(var i = 0;i<items.bons.length;i++){
          //   $scope.mandeibem[i].profilepic = items.bons[i].profilepic+"?{{getTimeStamp()}}";
          // }
          // for(var i = 0;i<items.ruins.length;i++){
          //   $scope.mandeimal[i].profilepic = items.ruins[i].profilepic+"?{{getTimeStamp()}}";
          // }
        }
      });
   

    
    $scope.bom = function(){
      console.log($scope.mandeibem);
      $scope.mostraruim = false;
      $scope.mostrabom = true;
      $scope.mostratodos = false;
    }
    $scope.ruim = function(){
      console.log($scope.mandeimal);
      $scope.mostraruim = true;
      $scope.mostrabom = false;
      $scope.mostratodos = false;
    }
    $scope.todos = function(){
      console.log($scope.items);
      $scope.mostraruim = false;
      $scope.mostrabom = false;
      $scope.mostratodos = true;
    }
  

}])

.controller('comentariosdosoutrosnoperfilCtrl', ['$scope', '$stateParams', 'formItem', 'EventoService', 'formUser','$state', 'formOutro', 'formStalker', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, formItem, EventoService, formUser,$state, formOutro , formStalker) {
   
  $scope.user = formStalker.getForm(); 
  $scope.items = {};
  $scope.mandeimal = {};
    $scope.mandeibem = {};
    $scope.mostraruim = false;
    $scope.mostratodos = true;
    $scope.mostrabom = false;

  var header2 = document.getElementById("barcome");
  var btns2 = header2.getElementsByClassName("btncome");
  for (var i = 0; i < btns2.length; i++) {
    btns2[i].addEventListener("click", function() {
      var current2 = document.getElementsByClassName("act");
      current2[0].className = current2[0].className.replace(" act", "");
      this.className += " act";
    });
  }

  EventoService.GetComments3($scope.user).then(function(items) {
      if(!items){
        $scope.items = {};
      }else{
           $scope.labels = ["Extrovertido", "Introvertido", "Realista","Curioso", "Solidário", "Racional","Organizado", "Criativo"];
          $scope.colores = ["#fff200", "#02fff2", "#ff9d00","#1867ce", "#e50be1", "#0e8c28","#ef370e", "#af0eef"];
          $scope.data =items.chart;
          $scope.ncomen = items.mal;
          $scope.mandeimal = items.ruins;
          $scope.mandeibem = items.bons;
          $scope.items = items.resto;
           for(var i = 0;i<items.resto.length;i++){
           if(items.tudo[i].profilepic[8] == 's' && items.resto[i].profilepic[9] == '3'){
             $scope.items[i].profilepic = items.resto[i].profilepic+"?{{getTimeStamp()}}";
           }else{
              $scope.items[i].profilepic = items.resto[i].profilepic;
           }
          //$scope.items[i].profilepic = items.tudo[i].profilepic+"?{{getTimeStamp()}}";
        }
        for(var i = 0;i<items.bons.length;i++){
          if(items.bons[i].profilepic[8] == 's' && items.bons[i].profilepic[9] == '3'){
             $scope.mandeibem[i].profilepic = items.bons[i].profilepic+"?{{getTimeStamp()}}";
           }else{
              $scope.mandeibem[i].profilepic = items.bons[i].profilepic;
           }
          //$scope.mandeibem[i].profilepic = items.bons[i].profilepic+"?{{getTimeStamp()}}";
        }
        for(var i = 0;i<items.ruins.length;i++){
          if(items.ruins[i].profilepic[8] == 's' && items.ruins[i].profilepic[9] == '3'){
             $scope.mandeimal[i].profilepic = items.ruins[i].profilepic+"?{{getTimeStamp()}}";
           }else{
              $scope.mandeimal[i].profilepic = items.ruins[i].profilepic;
           }
          //$scope.mandeimal[i].profilepic = items.ruins[i].profilepic+"?{{getTimeStamp()}}";
        }
        }
      });
   

    
    $scope.bom = function(){
      console.log($scope.mandeibem);
      $scope.mostraruim = false;
      $scope.mostrabom = true;
      $scope.mostratodos = false;
    }
    $scope.ruim = function(){
      console.log($scope.mandeimal);
      $scope.mostraruim = true;
      $scope.mostrabom = false;
      $scope.mostratodos = false;
    }
    $scope.todos = function(){
      console.log($scope.items);
      $scope.mostraruim = false;
      $scope.mostrabom = false;
      $scope.mostratodos = true;
    }
  
}])


.controller('comentariosperfiloutrosCtrl', ['$scope', '$stateParams', 'EventoService', '$state',  'formStalker', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, EventoService ,$state , formStalker) {
   
   $scope.user = formStalker.getForm();
   
   $scope.items = {};
   $scope.mandeimal = {};
    $scope.mandeibem = {};
    $scope.mostraruim = false;
    $scope.mostratodos = true;
    $scope.mostrabom = false;

    var header2 = document.getElementById("barcome");
    var btns2 = header2.getElementsByClassName("btncome");
    for (var i = 0; i < btns2.length; i++) {
      btns2[i].addEventListener("click", function() {
        var current2 = document.getElementsByClassName("act");
        current2[0].className = current2[0].className.replace(" act", "");
        this.className += " act";
      });
    }

    EventoService.GetComments3($scope.user).then(function(items) {
      if(!items){
        $scope.items = {};
      }else{
         $scope.labels = ["Extrovertido", "Introvertido", "Realista","Curioso", "Solidário", "Racional","Organizado", "Criativo"];
          $scope.colores = ["#fff200", "#02fff2", "#ff9d00","#1867ce", "#e50be1", "#0e8c28","#ef370e", "#af0eef"];
          $scope.data =items.chart;
          $scope.ncomen = items.mal;
          $scope.mandeimal = items.ruins;
          $scope.mandeibem = items.bons;
          $scope.items = items.resto;
           for(var i = 0;i<items.resto.length;i++){
           if(items.tudo[i].profilepic[8] == 's' && items.resto[i].profilepic[9] == '3'){
             $scope.items[i].profilepic = items.resto[i].profilepic+"?{{getTimeStamp()}}";
           }else{
              $scope.items[i].profilepic = items.resto[i].profilepic;
           }
          //$scope.items[i].profilepic = items.tudo[i].profilepic+"?{{getTimeStamp()}}";
        }
        for(var i = 0;i<items.bons.length;i++){
          if(items.bons[i].profilepic[8] == 's' && items.bons[i].profilepic[9] == '3'){
             $scope.mandeibem[i].profilepic = items.bons[i].profilepic+"?{{getTimeStamp()}}";
           }else{
              $scope.mandeibem[i].profilepic = items.bons[i].profilepic;
           }
          //$scope.mandeibem[i].profilepic = items.bons[i].profilepic+"?{{getTimeStamp()}}";
        }
        for(var i = 0;i<items.ruins.length;i++){
          if(items.ruins[i].profilepic[8] == 's' && items.ruins[i].profilepic[9] == '3'){
             $scope.mandeimal[i].profilepic = items.ruins[i].profilepic+"?{{getTimeStamp()}}";
           }else{
              $scope.mandeimal[i].profilepic = items.ruins[i].profilepic;
           }
          //$scope.mandeimal[i].profilepic = items.ruins[i].profilepic+"?{{getTimeStamp()}}";
        }
        }
      });
   

    
    $scope.bom = function(){
      console.log($scope.mandeibem);
      $scope.mostraruim = false;
      $scope.mostrabom = true;
      $scope.mostratodos = false;
    }
    $scope.ruim = function(){
      console.log($scope.mandeimal);
      $scope.mostraruim = true;
      $scope.mostrabom = false;
      $scope.mostratodos = false;
    }
    $scope.todos = function(){
      console.log($scope.items);
      $scope.mostraruim = false;
      $scope.mostrabom = false;
      $scope.mostratodos = true;
    }
  
}])

.controller('comentariosperfilaceitargeralCtrl', ['$scope', '$stateParams', 'EventoService', '$state',  'formStalker', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, EventoService ,$state , formStalker) {
   
   $scope.user = formStalker.getForm();
   
   $scope.items = {};
   $scope.mandeimal = {};
    $scope.mandeibem = {};
    $scope.mostraruim = false;
    $scope.mostratodos = true;
    $scope.mostrabom = false;

    var header2 = document.getElementById("barcome");
    var btns2 = header2.getElementsByClassName("btncome");
    for (var i = 0; i < btns2.length; i++) {
      btns2[i].addEventListener("click", function() {
        var current2 = document.getElementsByClassName("act");
        current2[0].className = current2[0].className.replace(" act", "");
        this.className += " act";
      });
    }

    EventoService.GetComments3($scope.user).then(function(items) {
      if(!items){
        $scope.items = {};
      }else{
         $scope.labels = ["Extrovertido", "Introvertido", "Realista","Curioso", "Solidário", "Racional","Organizado", "Criativo"];
          $scope.colores = ["#fff200", "#02fff2", "#ff9d00","#1867ce", "#e50be1", "#0e8c28","#ef370e", "#af0eef"];
          $scope.data =items.chart;
          $scope.ncomen = items.mal;
          $scope.mandeimal = items.ruins;
          $scope.mandeibem = items.bons;
          $scope.items = items.resto;
           for(var i = 0;i<items.resto.length;i++){
           if(items.tudo[i].profilepic[8] == 's' && items.resto[i].profilepic[9] == '3'){
             $scope.items[i].profilepic = items.resto[i].profilepic+"?{{getTimeStamp()}}";
           }else{
              $scope.items[i].profilepic = items.resto[i].profilepic;
           }
          //$scope.items[i].profilepic = items.tudo[i].profilepic+"?{{getTimeStamp()}}";
        }
        for(var i = 0;i<items.bons.length;i++){
          if(items.bons[i].profilepic[8] == 's' && items.bons[i].profilepic[9] == '3'){
             $scope.mandeibem[i].profilepic = items.bons[i].profilepic+"?{{getTimeStamp()}}";
           }else{
              $scope.mandeibem[i].profilepic = items.bons[i].profilepic;
           }
          //$scope.mandeibem[i].profilepic = items.bons[i].profilepic+"?{{getTimeStamp()}}";
        }
        for(var i = 0;i<items.ruins.length;i++){
          if(items.ruins[i].profilepic[8] == 's' && items.ruins[i].profilepic[9] == '3'){
             $scope.mandeimal[i].profilepic = items.ruins[i].profilepic+"?{{getTimeStamp()}}";
           }else{
              $scope.mandeimal[i].profilepic = items.ruins[i].profilepic;
           }
          //$scope.mandeimal[i].profilepic = items.ruins[i].profilepic+"?{{getTimeStamp()}}";
        }
        }
      });
   

    
    $scope.bom = function(){
      console.log($scope.mandeibem);
      $scope.mostraruim = false;
      $scope.mostrabom = true;
      $scope.mostratodos = false;
    }
    $scope.ruim = function(){
      console.log($scope.mandeimal);
      $scope.mostraruim = true;
      $scope.mostrabom = false;
      $scope.mostratodos = false;
    }
    $scope.todos = function(){
      console.log($scope.items);
      $scope.mostraruim = false;
      $scope.mostrabom = false;
      $scope.mostratodos = true;
    }
  

}])

.controller('comentariosperfilaceitarCtrl', ['$scope', '$stateParams', 'EventoService', '$state',  'formStalker', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, EventoService ,$state , formStalker) {
   
  $scope.user = formStalker.getForm(); 

  $scope.items = {};
  $scope.mandeimal = {};
  $scope.mandeibem = {};

  $scope.mostraruim = false;
  $scope.mostratodos = true;
  $scope.mostrabom = false;

    var header2 = document.getElementById("barcome");
    var btns2 = header2.getElementsByClassName("btncome");
    for (var i = 0; i < btns2.length; i++) {
      btns2[i].addEventListener("click", function() {
        var current2 = document.getElementsByClassName("act");
        current2[0].className = current2[0].className.replace(" act", "");
        this.className += " act";
      });
    }

    EventoService.GetComments3($scope.user).then(function(items) {
      if(!items){
        $scope.items = {};
      }else{
        $scope.labels = ["Extrovertido", "Introvertido", "Realista","Curioso", "Solidário", "Racional","Organizado", "Criativo"];
          $scope.colores = ["#fff200", "#02fff2", "#ff9d00","#1867ce", "#e50be1", "#0e8c28","#ef370e", "#af0eef"];
          $scope.data =items.chart;
          $scope.ncomen = items.mal;
          $scope.mandeimal = items.ruins;
          $scope.mandeibem = items.bons;
          $scope.items = items.resto;
          for(var i = 0;i<items.resto.length;i++){
           if(items.tudo[i].profilepic[8] == 's' && items.resto[i].profilepic[9] == '3'){
             $scope.items[i].profilepic = items.resto[i].profilepic+"?{{getTimeStamp()}}";
           }else{
              $scope.items[i].profilepic = items.resto[i].profilepic;
           }
          //$scope.items[i].profilepic = items.tudo[i].profilepic+"?{{getTimeStamp()}}";
        }
        for(var i = 0;i<items.bons.length;i++){
          if(items.bons[i].profilepic[8] == 's' && items.bons[i].profilepic[9] == '3'){
             $scope.mandeibem[i].profilepic = items.bons[i].profilepic+"?{{getTimeStamp()}}";
           }else{
              $scope.mandeibem[i].profilepic = items.bons[i].profilepic;
           }
          //$scope.mandeibem[i].profilepic = items.bons[i].profilepic+"?{{getTimeStamp()}}";
        }
        for(var i = 0;i<items.ruins.length;i++){
          if(items.ruins[i].profilepic[8] == 's' && items.ruins[i].profilepic[9] == '3'){
             $scope.mandeimal[i].profilepic = items.ruins[i].profilepic+"?{{getTimeStamp()}}";
           }else{
              $scope.mandeimal[i].profilepic = items.ruins[i].profilepic;
           }
          //$scope.mandeimal[i].profilepic = items.ruins[i].profilepic+"?{{getTimeStamp()}}";
        }
        }
      });
   

    
    $scope.bom = function(){
      console.log($scope.mandeibem);
      $scope.mostraruim = false;
      $scope.mostrabom = true;
      $scope.mostratodos = false;
    }
    $scope.ruim = function(){
      console.log($scope.mandeimal);
      $scope.mostraruim = true;
      $scope.mostrabom = false;
      $scope.mostratodos = false;
    }
    $scope.todos = function(){
      console.log($scope.items);
      $scope.mostraruim = false;
      $scope.mostrabom = false;
      $scope.mostratodos = true;
    }
  

}])

.controller('rankingCtrl', ['$scope', '$stateParams', 'formpontos', 'EventoService', '$http','$timeout','formUser', '$state', '$ionicPopup', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, formpontos, EventoService, $http, $timeout, formUser, $state,$ionicPopup ) {
  $scope.rank = false;
  $scope.use = true;

  var header = document.getElementById("barrank");
    var btns = header.getElementsByClassName("btnrank");
    for (var i = 0; i < btns.length; i++) {
      btns[i].addEventListener("click", function() {
        var current = document.getElementsByClassName("actranking");
        current[0].className = current[0].className.replace(" actranking", "");
        this.className += " actranking";
      });
    }

  $scope.ranking = function(){
    $scope.rank = true;
    $scope.use = false;
    $scope.nentendi = false;
    EventoService.Getranking().then(function (oi){
                                tamanho = oi.length;
                                $scope.items = oi;
                                for(var i = 0; i<tamanho;i++){
                                  $scope.items[i].colocacao = i+1; 
                                }
                             });
  }

  $scope.usar = function(){
    $scope.rank = false;
    $scope.use = true;
    $scope.nentendi = false;
  }

  $scope.entender = function(){
    $scope.rank = false;
    $scope.use = false;
    $scope.nentendi = true;
  }
  $scope.alerta = function(){
        var alertPopup = $ionicPopup.alert({
                title: '(ノ￣ー￣)ノ ● ＼(^ω^＼)',
                subTitle: 'Aguarde',
                template: 'Em breve mais johnson, não culpe nosso Dev'
              });
  }

  $scope.criadorestrelado = function(){
    $state.go("tabsController.nivelestrela");
  }

  

}])

.controller('nivelestrelaCtrl', ['$scope', '$stateParams', 'formpontos', 'EventoService', '$http','$timeout','formUser', '$state', '$ionicPopup',  // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, formpontos, EventoService, $http, $timeout, formUser, $state, $ionicPopup) {

  $scope.user = formUser.getForm();


  $scope.auxproxpontos = 50;
  $scope.auxproxcriados = 5;
  EventoService.GetCriadosacabados($scope.user).then(function(criados) {
      if(criados=='E'){
        $scope.criei = 0;
        $scope.progressPercentCriador = 0;
      }else{
        $scope.criei = criados.length;
        $scope.progressPercentCriador = criados.length;
      }
      if($scope.user.direitoborda == 0){
        $scope.estrelaatualn = true; 
        $scope.estrelaatualb = false;
        $scope.estrelaatuals = false;
        $scope.estrelaatualg = false;
        $scope.estrelaproxb = true;
        $scope.estrelaproxs = false;
        $scope.estrelaproxg = false;
        $scope.auxproxpontos = 50;
        $scope.auxproxcriados = 5;
        if($scope.user.pontos.valueOf()*2>=100){
          $scope.progressPercent = 100;
        }else{
          $scope.progressPercent = $scope.user.pontos.valueOf()*2;
        }
        if($scope.progressPercentCriador.valueOf()*20>=100){
          $scope.progressPercentCriador = 100;
        }else{
          $scope.progressPercentCriador = $scope.progressPercentCriador.valueOf()*20;
        }
      }
      if($scope.user.direitoborda == 1){
        $scope.estrelaatualn = false; 
        $scope.estrelaatualb = true;
        $scope.estrelaatuals = false;
        $scope.estrelaatualg = false;
        $scope.estrelaproxb = false;
        $scope.estrelaproxs = true;
        $scope.estrelaproxg = false;
        $scope.auxproxpontos = 100;
        $scope.auxproxcriados = 10;
     
        if($scope.user.pontos.valueOf()>=100){
          $scope.progressPercent = 100;
        }else{
         $scope.progressPercent = $scope.user.pontos.valueOf();
        }
        if($scope.progressPercentCriador.valueOf()>=10){
          $scope.progressPercentCriador = 100;
        }else{
          $scope.progressPercentCriador = $scope.progressPercentCriador.valueOf()*10;
        }
      }
      if($scope.user.direitoborda == 2){
        $scope.estrelaatualn = false; 
        $scope.estrelaatualb = false;
        $scope.estrelaatuals = true;
        $scope.estrelaatualg = false;
        $scope.estrelaproxb = false;
        $scope.estrelaproxs = false;
        $scope.estrelaproxg = true;
        $scope.auxproxpontos = 200;
        $scope.auxproxcriados = 20;
        
        if(($scope.user.pontos.valueOf()/2) >= 200){
          $scope.progressPercent = 100;
        }else{
         $scope.progressPercent = 2+$scope.user.pontos.valueOf()/2;
        }
        if($scope.progressPercentCriador.valueOf()>=20){
          $scope.progressPercentCriador = 100;
        }else{
          console.log($scope.progressPercentCriador)
          $scope.progressPercentCriador = 2+$scope.progressPercentCriador.valueOf()*5;
        }
      }     // Muda layout da tela
      if($scope.user.direitoborda == 3){
        $scope.estrelaatualn = false; 
        $scope.estrelaatualb = false;
        $scope.estrelaatuals = false;
        $scope.estrelaatualg = false;
        $scope.estrelaproxb = false;
        $scope.estrelaproxs = false;
        $scope.estrelaproxg = false;
      }
    });
  //$scope.progressPercent = $scope.user.pontos;
  $scope.$on("$ionicView.enter", function(event, data){
    $scope.user = formUser.getForm();
    var northlat = $scope.user.northlat;
    var southlat = $scope.user.southlat;
    var westlng = $scope.user.westlng;
    var eastlng = $scope.user.eastlng;
    var lat = $scope.user.lat;
    var long = $scope.user.long;
    EventoService.getusuario($scope.user).then(function(user) {
        $scope.user = user;
          $scope.user.northlat = northlat;
          $scope.user.southlat = southlat;
          $scope.user.westlng = westlng;
          $scope.user.eastlng = eastlng;
          $scope.user.lat =  lat;
          $scope.user.long =  long;
        formUser.updateForm($scope.user);
      });
    $scope.auxproxpontos = 50;
    $scope.auxproxcriados = 5;
    EventoService.GetCriadosacabados($scope.user).then(function(criados) {
      if(criados=='E'){
        $scope.criei = 0;
        $scope.progressPercentCriador = 0;
      }else{
        $scope.criei = criados.length;
        $scope.progressPercentCriador = criados.length;
      }
      if($scope.user.direitoborda == 0){
        $scope.estrelaatualn = true; 
        $scope.estrelaatualb = false;
        $scope.estrelaatuals = false;
        $scope.estrelaatualg = false;
        $scope.estrelaproxb = true;
        $scope.estrelaproxs = false;
        $scope.estrelaproxg = false;
        $scope.estrelault =false;
        $scope.auxproxpontos = 50;
        $scope.auxproxcriados = 5;
        if($scope.user.pontos.valueOf()*2>=100){
          $scope.progressPercent = 100;
        }else{
          $scope.progressPercent = $scope.user.pontos.valueOf()*2;
        }
        if($scope.progressPercentCriador.valueOf()*20>=100){
          $scope.progressPercentCriador = 100;
        }else{
          $scope.progressPercentCriador = $scope.progressPercentCriador.valueOf()*20;
        }
      }
      if($scope.user.direitoborda == 1){
        $scope.estrelaatualn = false; 
        $scope.estrelaatualb = true;
        $scope.estrelaatuals = false;
        $scope.estrelaatualg = false;
        $scope.estrelaproxb = false;
        $scope.estrelaproxs = true;
        $scope.estrelaproxg = false;
        $scope.estrelault =false;
        $scope.auxproxpontos = 100;
        $scope.auxproxcriados = 10;
     
        if($scope.user.pontos.valueOf()>=100){
          $scope.progressPercent = 100;
        }else{
         $scope.progressPercent = $scope.user.pontos.valueOf();
        }
        if($scope.progressPercentCriador.valueOf()>=10){
          $scope.progressPercentCriador = 100;
        }else{
          $scope.progressPercentCriador = $scope.progressPercentCriador.valueOf()*10;
        }
      }
      if($scope.user.direitoborda == 2){
        $scope.estrelaatualn = false; 
        $scope.estrelaatualb = false;
        $scope.estrelaatuals = true;
        $scope.estrelaatualg = false;
        $scope.estrelaproxb = false;
        $scope.estrelaproxs = false;
        $scope.estrelaproxg = true;
        $scope.estrelault =false;
        $scope.auxproxpontos = 200;
        $scope.auxproxcriados = 20;
        
        if(($scope.user.pontos.valueOf()/2) >= 200){
          $scope.progressPercent = 100;
        }else{
         $scope.progressPercent = 2+$scope.user.pontos.valueOf()/2;
        }
        if($scope.progressPercentCriador.valueOf()>=20){
          $scope.progressPercentCriador = 100;
        }else{
          console.log($scope.progressPercentCriador)
          $scope.progressPercentCriador = 2+$scope.progressPercentCriador.valueOf()*5;
        }
      }     // Muda layout da tela
      if($scope.user.direitoborda == 3){
        $scope.estrelaatualn = false; 
        $scope.estrelaatualb = false;
        $scope.estrelaatuals = false;
        $scope.estrelaatualg = false;
        $scope.estrelaproxb = false;
        $scope.estrelaproxs = false;
        $scope.estrelaproxg = false;
        $scope.estrelault =true;
      }
    });
  });


  $scope.compra = function(usuario){
    
    EventoService.GetCriadosacabados(usuario).then(function(criados) {
      $scope.criei = criados.length;
      console.log(criados.length, usuario.direitoborda,usuario.pontos)
      if(usuario.direitoborda == 0){
        if(criados.length<5){
          var alertPopup = $ionicPopup.alert({
              title: 'ᕙ( * •̀ ᗜ •́ * )ᕗ',
              template: 'Você precisa criar mais eventos para poder comprar'
            });
        }else{
          if(usuario.pontos<49){
            var alertPopup = $ionicPopup.alert({
                title: '(ノ￣ー￣)ノ ● ＼(^ω^＼)',
                template: 'Não tens pontos suficiente, tente ir em mais eventos ou crie ou avalie em eventos que você foi e não avaliou ninguem, uma pessoa basta'
              });
          }else{
            var po = usuario.pontos.valueOf() - 50;
            var myPopup = $ionicPopup.show({
                                title: 'Confirmação',
                                subTitle: 'Upar?',
                                scope: $scope,
                                buttons: [
                                  { text: 'Não' },
                                  {
                                    text: '<b>Sim</b>',
                                    type: 'button-positive',
                                    onTap: function(e) {
                                      $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/gastapontospessoaevento.php', {idevento : -10,
                                                        iduser : $scope.user.iduser,
                                                        borda : $scope.user.borda,
                                                        username: $scope.user.username,
                                                        apelido : $scope.user.apelido,
                                                        nomeevento :  "Comprou borda bronze", 
                                                        estado : 10,
                                                        pontos: -50});
                                      
                                      $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/compraestrela.php' , {iduser : usuario.iduser,
                                                                                direitoborda : 1,
                                                                                pontos: po}).then(function(result) {
                                        $state.reload();
                                        EventoService.AtualizaEstrelaPessoaevento();
                                        if (result.data.success == true){
                                          console.log(result.data.msg);
                                          $state.reload();
                                          } else {
                                          console.log(result.data.msg);
                                          }
                                        });
                                    }
                                  }
                                ]});
          }
        }
      }
      if(usuario.direitoborda == 1){
        if(criados.length<10){
          var alertPopup = $ionicPopup.alert({
              title: 'ᕙ( * •̀ ᗜ •́ * )ᕗ',
              template: 'Você precisa criar mais eventos para poder comprar'
            });
        }else{
          if(usuario.pontos<99){
            var alertPopup = $ionicPopup.alert({
                title: '(ノ￣ー￣)ノ ● ＼(^ω^＼)',
                template: 'Não tens pontos suficiente, tente ir em mais eventos ou crie ou avalie em eventos que você foi e não avaliou ninguem, uma pessoa basta'
              });
          }else{
            var po = usuario.pontos.valueOf()-100;
            console.log(po)
            var myPopup = $ionicPopup.show({
                                
                                title: 'Confirmação',
                                subTitle: 'Upar?',
                                scope: $scope,
                                buttons: [
                                  { text: 'Não' },
                                  {
                                    text: '<b>Sim</b>',
                                    type: 'button-positive',
                                    onTap: function(e) {
                                      $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/gastapontospessoaevento.php', {idevento : -20,
                                                        iduser : $scope.user.iduser,
                                                        borda : $scope.user.borda,
                                                        username: $scope.user.username,
                                                        apelido : $scope.user.apelido,
                                                        nomeevento :  "Comprou borda prata", 
                                                        estado : 10,
                                                        pontos: -100});
                                      $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/compraestrela.php' , {iduser : usuario.iduser,
                                                                                direitoborda : 2,
                                                                                pontos : po}).then(function(result) {
                                        $state.reload();
                                        EventoService.AtualizaEstrelaPessoaevento();
                                        if (result.data.success == true){
                                          console.log(result.data.msg);
                                          $state.reload();
                                          } else {
                                          console.log(result.data.msg);
                                          }
                                        });
                                    }
                                  }
                                ]});
          }
        }
      }
      if(usuario.direitoborda == 2){
        if(criados.length<20){
          var alertPopup = $ionicPopup.alert({
              title: 'ᕙ( * •̀ ᗜ •́ * )ᕗ',
              template: 'Você precisa criar mais eventos para poder comprar'
            });
        }else{
          if(usuario.pontos<199){
            var alertPopup = $ionicPopup.alert({
                title: '(ノ￣ー￣)ノ ● ＼(^ω^＼)',
                template: 'Não tens pontos suficiente, tente ir em mais eventos ou crie ou avalie em eventos que você foi e não avaliou ninguem, uma pessoa basta'
              });
          }else{
            var po = usuario.pontos.valueOf() - 200;
            var myPopup = $ionicPopup.show({
                                
                                title: 'Confirmação',
                                subTitle: 'Upar?',
                                scope: $scope,
                                buttons: [
                                  { text: 'Não' },
                                  {
                                    text: '<b>Sim</b>',
                                    type: 'button-positive',
                                    onTap: function(e) {
                                      $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/gastapontospessoaevento.php', {idevento : -30,
                                                        iduser : $scope.user.iduser,
                                                        borda : $scope.user.borda,
                                                        username: $scope.user.username,
                                                        apelido : $scope.user.apelido,
                                                        nomeevento :  "Comprou borda OURO", 
                                                        estado : 10,
                                                        pontos: -200});
                                      $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/compraestrela.php' , {iduser : usuario.iduser,
                                                                                direitoborda : 3,
                                                                                pontos : po}).then(function(result) {
                                        $state.reload();
                                        EventoService.AtualizaEstrelaPessoaevento();
                                        if (result.data.success == true){
                                          console.log(result.data.msg);
                                          
                                          } else {
                                          console.log(result.data.msg);
                                          }
                                        });
                                    }
                                  }
                                ]});
          }
        }
      }

    });
  }

}])

.controller('infoestrelaCtrl', ['$scope', '$stateParams', 'formItem', 'EventoService', 'formUser','$state', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, formItem, EventoService, formUser,$state) {

}])

.controller('perfilFollowCtrl', ['$scope', '$stateParams', 'formOutro', 'formItem', 'EventoService','$http', '$timeout', '$ionicPopup', 'formUser', 'formStalker','$state',  // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, formOutro, formItem, EventoService,$http, $timeout, $ionicPopup, formUser, formStalker, $state) {

   $scope.estadobutton = 0; 
    $scope.stalkeada = {};
    $scope.neventos= 0;
    $scope.neventosnao= 0;
    $scope.p =0;
    $scope.outro = formOutro.getForm();
    $scope.user = formUser.getForm();
    $scope.stalkeada = $scope.outro;
    $scope.followbutton = false;
    $scope.desseguirbutton = false;
    $scope.CoisasCriado = true;
    $scope.CoisasFinalizado = false;
    $scope.auxusers = {};
    $scope.frase = {};
    var auxbloqueado = 0;
    var noti = {};
    $scope.qvou = true;
    $scope.infosstalkeada ={};
    var header = document.getElementById("barperfiloutroev");
    var btns = header.getElementsByClassName("btnperfilotro");
    for (var i = 0; i < btns.length; i++) {
      btns[i].addEventListener("click", function() {
        var current = document.getElementsByClassName("actpf");
        current[0].className = current[0].className.replace(" actpf", "");
        this.className += " actpf";
      });
    }


    EventoService.GetStalkear($scope.stalkeada.iduser).then(function(stalker) {
        $scope.infosstalkeada = stalker;
         if($scope.infosstalkeada.profilepic[8] == 's' && $scope.infosstalkeada.profilepic[9] == '3'){
             document.getElementById("imageidperfilFollow").src=$scope.infosstalkeada.profilepic+"?{{getTimeStamp()}}";
           }else{
             document.getElementById("imageidperfilFollow").src=$scope.infosstalkeada.profilepic;
           }
        //document.getElementById("imageidperfilFollow").src=$scope.infosstalkeada.profilepic+"?{{getTimeStamp()}}";
        $scope.frase = stalker.frase;
         if(stalker.borda == 0){
          $scope.estrelabb = false;
          $scope.estrelabs = false;
          $scope.estrelabg = false;
        }
        if(stalker.borda == 1){
          $scope.estrelabb = true;
          $scope.estrelabs = false;
          $scope.estrelabg = false;
        }
        if(stalker.borda == 2){
          $scope.estrelabb = false;
          $scope.estrelabs = true;
          $scope.estrelabg = false;
        }
        if(stalker.borda == 3){
          $scope.estrelabb = false;
          $scope.estrelabs = false;
          $scope.estrelabg = true;
        }
        
        if($scope.infosstalkeada.idade){
          $scope.infosstalkeada.idade = ", "+ $scope.infosstalkeada.idade +" anos";
        }else{
           $scope.infosstalkeada.idade ='';
        }
    });
    

    EventoService.GetPontos($scope.stalkeada.iduser).then(function(items) {
        $scope.p = items;
        $scope.labels3 = ["Pontos"];
        $scope.colores3 = ["#ff4d4d"];
        $scope.data3 = [$scope.p];
      });
      EventoService.getIC($scope.stalkeada).then(function(items) {
        if(items){
          $scope.ic = items;
          $scope.options2 = {title: {
                      display: true,
                      text: 'Indice de confirmação',
                      position: 'bottom'
                  }
           }
          $scope.labels2 = ["Fui", "Não fui"];
          $scope.colores2 = ["#99FF99","#ff4d4d"];
          var menos = (100-$scope.ic.total).toFixed(1);
          var mais = $scope.ic.total;
          $scope.data2 = [mais, menos ];
        }
       
      });

      EventoService.GetComments3($scope.stalkeada).then(function(items) {
        
          $scope.options1 = {title: {
                    display: true,
                    text: 'Avaliações',
                    position: 'bottom'
                }
         }
          $scope.labels1 = ["Extrovertido", "Introvertido", "Realista","Curioso", "Solidário", "Racional","Organizado", "Criativo"];
          $scope.colores1 = ["#fff200", "#02fff2", "#ff9d00","#1867ce", "#e50be1", "#0e8c28","#ef370e", "#af0eef"];
          $scope.data1 =items.chart;
        
      }); 


    $scope.$on("$ionicView.enter", function(event, data){
    
    $scope.followbutton = false;
    $scope.desseguirbutton = false; 
    $scope.items = [];
    $scope.vezes = 0;
    $scope.newItems = [];
    $scope.noMoreItemsAvailable = false;
    $scope.lastidevento = 0;
    $scope.aux2 = 0;
    $scope.outro = formOutro.getForm();
    $scope.infosstalkeada ={};
    $scope.frase = {};

    auxbloqueado = 0;

    if($scope.outro.iduser == $scope.user.iduser){
       $scope.followbutton = false;
       $scope.desseguirbutton = false;
       $scope.reportbutton = false;
       $scope.qvou = true;
    }else{
      $scope.reportbutton = true;
    }
    
    
    
    
    EventoService.GetStalkear($scope.stalkeada.iduser).then(function(stalker) {
        $scope.infosstalkeada = stalker;
        if($scope.infosstalkeada.profilepic[8] == 's' && $scope.infosstalkeada.profilepic[9] == '3'){
             document.getElementById("imageidperfilFollow").src=$scope.infosstalkeada.profilepic+"?{{getTimeStamp()}}";
           }else{
             document.getElementById("imageidperfilFollow").src=$scope.infosstalkeada.profilepic;
           }
        $scope.frase = stalker.frase;
         if(stalker.borda == 0){
          $scope.estrelabb = false;
          $scope.estrelabs = false;
          $scope.estrelabg = false;
        }
        if(stalker.borda == 1){
          $scope.estrelabb = true;
          $scope.estrelabs = false;
          $scope.estrelabg = false;
        }
        if(stalker.borda == 2){
          $scope.estrelabb = false;
          $scope.estrelabs = true;
          $scope.estrelabg = false;
        }
        if(stalker.borda == 3){
          $scope.estrelabb = false;
          $scope.estrelabs = false;
          $scope.estrelabg = true;
        }
        if($scope.infosstalkeada.idade){
          $scope.infosstalkeada.idade = ", "+ $scope.infosstalkeada.idade +" anos";
        }else{
           $scope.infosstalkeada.idade ='';
        }
    });
      
    EventoService.GetPontos($scope.stalkeada.iduser).then(function(items) {
      $scope.p = items;
      $scope.labels3 = ["Pontos"];
      $scope.colores3 = ["#ff4d4d"];
      $scope.data3 = [$scope.p];
    });
    
    EventoService.getIC($scope.stalkeada).then(function(items) {
      if(items){
        $scope.ic = items;
        $scope.options2 = {title: {
                    display: true,
                    text: 'Indice de confirmação',
                    position: 'bottom'
                }
         }
        $scope.labels2 = ["Fui", "Não fui"];
        $scope.colores2 = ["#99FF99","#ff4d4d"];
        var menos = (100-$scope.ic.total).toFixed(1);
        var mais = $scope.ic.total;
        $scope.data2 = [mais, menos ];
      }
    });

    EventoService.GetComments3($scope.stalkeada).then(function(items) {
      
        $scope.options1 = {title: {
                  display: true,
                  text: 'Avaliações',
                  position: 'bottom'
              }
       }
        $scope.labels1 = ["Extrovertido", "Introvertido", "Realista","Curioso", "Solidário", "Racional","Organizado", "Criativo"];
        $scope.colores1 = ["#fff200", "#02fff2", "#ff9d00","#1867ce", "#e50be1", "#0e8c28","#ef370e", "#af0eef"];
        $scope.data1 =items.chart;
    }); 

    EventoService.GetCriados($scope.stalkeada).then(function(items) {
      if(items=='E'){
        $scope.items = [];
      }else{
        for (var i = 0; i < items.length; i++) {
            var curr_date = (items[i].diainicio[8]+items[i].diainicio[9]);
            var h2 = (items[i].diainicio[11]+items[i].diainicio[12]);
            var m2 = (items[i].diainicio[14]+items[i].diainicio[15]);
            var curr_month = (items[i].diainicio[5]+items[i].diainicio[6]);
            var curr_year = (items[i].diainicio[0]+items[i].diainicio[1]+items[i].diainicio[2]+items[i].diainicio[3]);
            var j = curr_date + "/" + curr_month + "/" + curr_year+ ' '+h2 + ':' + m2;
            items[i].datainicio = j;
            if(items[i].estado == 0){
              items[i].confirmacao = "Vai acontecer"
            }
            if(items[i].estado == 1){
              items[i].confirmacao = "Finalizado"
            }
            if(items[i].estado == 2){
              items[i].confirmacao = "Standy by, talvez aconteça"
            }
            if(items[i].estado == 3){
              items[i].confirmacao = "Vai acontecer"
            }
            if(items[i].estado == 4){
              items[i].confirmacao = "Cancelado"
            }
            if(items[i].estado == 5){
              items[i].confirmacao = "Acabado"
            }
            if(items[i].estado == 6){
              items[i].confirmacao = "Escondido"
            }
        }
      $scope.items = items;
      $scope.lastidvestido = $scope.items[0].idevento;
      }
    });

    $scope.auxusers.outro =  $scope.outro.iduser;
    $scope.auxusers.eu =  $scope.user.iduser;
    console.log($scope.auxusers.eu, $scope.auxusers.outro)
    EventoService.possoseguir($scope.auxusers).then(function(items) {
      console.log(items, 'dentro do perfil follow')
        if(items){
          console.log($scope.outro,$scope.user.iduser)
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/getfollow.php', {iduserseguindo : $scope.outro.iduser, 
                          iduserseguidor : $scope.user.iduser}).then(function(res) {
                            console.log( 'oi' , res.data[0].bloqueado );
                            if(res.data[0]!='E'){
                              if (res.data[0].bloqueado==0){ 
                              $scope.desseguirbutton = true;
                              $scope.followbutton = false;
                              auxbloqueado = 1;
                              $scope.qvou = true;
                              console.log('ja sigo este cara');
                              }
                              if(res.data[0].bloqueado==2){
                              console.log('nao sigo este cara');
                              $scope.desseguirbutton = false;
                              $scope.followbutton = true;
                              auxbloqueado = 1;
                              $scope.qvou = false;
                              }
                              if(res.data[0].bloqueado==1){
                              console.log('tais bloqueado');
                              $scope.desseguirbutton = false;
                              $scope.followbutton = false;
                              auxbloqueado = 3;
                              $scope.items = [];
                              $scope.qvou = false;
                              }
                              if($scope.outro == $scope.user.iduser){
                                 $scope.followbutton = false;
                                 $scope.desseguirbutton = false;
                                 $scope.reportbutton = false;
                                 $scope.qvou = true;
                              }
                            }else{
                               $scope.followbutton = true;
                                auxbloqueado = 2;
                                $scope.qvou = false;
                            }
                             if($scope.outro == $scope.user.iduser){
                                 $scope.followbutton = false;
                                 $scope.desseguirbutton = false;
                                 $scope.reportbutton = false;
                                 $scope.qvou = true;
                              }
                          });
        }else{
          if($scope.outro.iduser == $scope.user.iduser){
            $scope.followbutton = false;
            $scope.desseguirbutton = false;
            $scope.reportbutton = false;
            $scope.qvou = true;
          }else{
            $scope.desseguirbutton = true;
            $scope.qvou = false;
          }
        }
      });  
         
              
    });

    $scope.seguir = function(){
      noti.recebe = $scope.outro.iduser;
      noti.envia = $scope.user.iduser;
      noti.tipo = 11;
      EventoService.VerificaNotificacao(noti).then(function(res) {
        console.log(res);
        if(res){
          var msgnoti ='Nova pessoa esta t stalkeando';
          var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php';
            $http.post(link, {notificacao :msgnoti, 
                                idevento : $scope.user.iduser,
                                nomeevento : 'follow',
                                id_user_envia : $scope.user.iduser,
                                username_envia : $scope.user.username,
                                apelido_envia : $scope.user.apelido,
                                tipo : '11',
                                id_user_recebe : $scope.outro.iduser});
        }
      });
      if(auxbloqueado == 2){
        var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/seguepessoa.php';
            $http.post(link, {iduserseguindo : $scope.outro.iduser, 
                          usernameseguindo : $scope.stalkeada.username,
                          iduserseguidor : $scope.user.iduser,
                          apelidoseguindo : $scope.infosstalkeada.apelido,
                          apelidoseguidor : $scope.user.apelido,
                          profilepicseguindo : $scope.infosstalkeada.profilepic,
                          profilepicseguidor : $scope.user.profilepic,
                          devicetokenseguidor : $scope.user.devicetoken,
                          usernameseguidor : $scope.user.username}).then(function(res) {
                          console.log(res.success);
                                var alertPopup = $ionicPopup.alert({
                                                            title: '(*•̀ᴗ•́*)و ̑̑',
                                                            template: 'Pessoa adicionada as pessoas de interesse'
                                                          }); 
                                
                            
                            $scope.desseguirbutton = true;
                            $scope.followbutton = false;
                          });
      }else{
         var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/refollow.php'; // estado "Bloqueado"  = 2;
            $http.post(link, {iduserseguindo : $scope.outro.iduser, 
                          iduserseguidor : $scope.user.iduser}).then(function(res) {
                            
                                var alertPopup = $ionicPopup.alert({
                                                            title: '(￣▽￣)ノ',
                                                            template: 'Pessoa adicionada as pessoas de interesse'
                                                          }); 
                                $scope.desseguirbutton = true;
                                $scope.followbutton = false;
                            
                          });
      }
    }

    $scope.desseguir = function(){
      auxbloqueado = 0;
        var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/desfollow.php'; // estado "Bloqueado"  = 2;
            $http.post(link, {iduserseguindo : $scope.outro.iduser, 
                          iduserseguidor : $scope.user.iduser}).then(function(res) {
                            
                                var alertPopup = $ionicPopup.alert({
                                                            title: '(*꒦ິ⌓꒦ີ)',
                                                            template: 'Não segues mais esta pessoa'
                                                          }); 
                                $scope.desseguirbutton = false;
                                $scope.followbutton = true;
                            
                          });
    }

    $scope.comentario = function(){
        formStalker.updateForm($scope.stalkeada);
        if(auxbloqueado!=3){
          $state.go('tabsController.comentariosdosoutrosnoperfil');
        }
    }

    $scope.loadCriados = function() {
      $scope.CoisasCriado = true;
      $scope.CoisasFinalizado = false;
      if(auxbloqueado!=3){
        $scope.estadobutton = 0;
        $scope.items = [];
        EventoService.GetCriados($scope.stalkeada).then(function(items) {
          if(items=='E'){
          $scope.items = [];
        }else{
          for (var i = 0; i < items.length; i++) {
                var curr_date = (items[i].diainicio[8]+items[i].diainicio[9]);
                var h2 = (items[i].diainicio[11]+items[i].diainicio[12]);
                var m2 = (items[i].diainicio[14]+items[i].diainicio[15]);
                var curr_month = (items[i].diainicio[5]+items[i].diainicio[6]);
                var curr_year = (items[i].diainicio[0]+items[i].diainicio[1]+items[i].diainicio[2]+items[i].diainicio[3]);
                var j = curr_date + "/" + curr_month + "/" + curr_year+ ' '+h2 + ':' + m2;
                items[i].datainicio = j;
                if(items[i].estado == 0){
                  items[i].confirmacao = "Vai acontecer"
                }
                if(items[i].estado == 1){
                  items[i].confirmacao = "Finalizado"
                }
                if(items[i].estado == 2){
                  items[i].confirmacao = "Standy by, talvez aconteça"
                }
                if(items[i].estado == 3){
                  items[i].confirmacao = "Vai acontecer"
                }
                if(items[i].estado == 4){
                  items[i].confirmacao = "Cancelado"
                }
                if(items[i].estado == 5){
                  items[i].confirmacao = "Acabado"
                }
                if(items[i].estado == 6){
                  items[i].confirmacao = "Escondido"
                }
            }
          $scope.items = items;
          $scope.lastidvestido = $scope.items[0].idevento;
        }
        });
      }
    }

    $scope.loadAbertos = function() {
      $scope.CoisasCriado = false;
      $scope.CoisasFinalizado = true;
      if(auxbloqueado!=3){
        $scope.estadobutton = 1;
        $scope.items = [];
        EventoService.GetAbertos($scope.stalkeada.iduser).then(function(items) {  //mudar
          if(items == 'E'){
            $scope.items = [];
          }else{
            for (var i = 0; i < items.length; i++) {
                var curr_date = (items[i].diainicio[8]+items[i].diainicio[9]);
                var h2 = (items[i].diainicio[11]+items[i].diainicio[12]);
                var m2 = (items[i].diainicio[14]+items[i].diainicio[15]);
                var curr_month = (items[i].diainicio[5]+items[i].diainicio[6]);
                var curr_year = (items[i].diainicio[0]+items[i].diainicio[1]+items[i].diainicio[2]+items[i].diainicio[3]);
                var j = curr_date + "/" + curr_month + "/" + curr_year+ ' '+h2 + ':' + m2;
                items[i].datainicio = j;
            }
            $scope.items = items;
            $scope.lastidvestido = $scope.items[0].idevento;
          }
        });
      }
    }

    $scope.loadFechados = function() {
      $scope.CoisasCriado = false;
      $scope.CoisasFinalizado = true;
      if(auxbloqueado!=3){
        $scope.estadobutton = 2;
        $scope.items = [];
        //console.log($scope.user.iduser);
        EventoService.GetFinalizadosPerfil($scope.stalkeada.iduser).then(function(items) {         //mudar
          if(items=='E'){
            $scope.items = [];
          }else{
            for (var i = 0; i < items.length; i++) {
                var curr_date = (items[i].diainicio[8]+items[i].diainicio[9]);
                var h2 = (items[i].diainicio[11]+items[i].diainicio[12]);
                var m2 = (items[i].diainicio[14]+items[i].diainicio[15]);
                var curr_month = (items[i].diainicio[5]+items[i].diainicio[6]);
                var curr_year = (items[i].diainicio[0]+items[i].diainicio[1]+items[i].diainicio[2]+items[i].diainicio[3]);
                var j = curr_date + "/" + curr_month + "/" + curr_year+ ' '+h2 + ':' + m2;
                items[i].datainicio = j;
            }
            $scope.items = items;
            $scope.lastidvestido = $scope.items[0].idevento;
          }
        });
      }   
    }

    $scope.loadMore = function() {
      if ($scope.estadobutton == 0 && auxbloqueado!=3) {
        EventoService.GetOldEventosCriados().then(function(items) {
        $scope.items = $scope.items.concat(items);
        $scope.$broadcast('scroll.infiniteScrollComplete');
          // an empty array indicates that there are no more items
          if (items.length <= 4) {
            $scope.noMoreItemsAvailable = true;
          }

        });
       

      }
      if ($scope.estadobutton == 1 && auxbloqueado!=3) {
        EventoService.GetOldEventosCriados().then(function(items) {
        $scope.items = $scope.items.concat(items);
        $scope.$broadcast('scroll.infiniteScrollComplete');
          // an empty array indicates that there are no more items
          if (items.length <= 4) {
            $scope.noMoreItemsAvailable = true;
          }
        });

        
      }
      if ($scope.estadobutton == 2 && auxbloqueado!=3) {
        EventoService.GetOldEventosCriados().then(function(items) {
        $scope.items = $scope.items.concat(items);
        $scope.$broadcast('scroll.infiniteScrollComplete');
          // an empty array indicates that there are no more items
          if (items.length <= 4) {
            $scope.noMoreItemsAvailable = true;
          }
        });

      
      }
    }

    $scope.reportar = function(){
      $scope.reportmsg = '';
      console.log($scope.stalkeada.username);
        $scope.report = [
      { text: "Nome impróprio", checked: false },
      { text: "Comportamento inadequado", checked: false, style:"text-align: center;overflow: hidden;text-overflow: none !important; white-space: initial !important;" },
      { text: "Foto inapropriada", checked: false },
      { text: "É um impostor", checked: false }
     ];
        $ionicPopup.confirm({
          title: 'Você quer reportar essa pessoa pq?',
          content: '<ion-checkbox ng-repeat="item in report" style="color: #FCFCFC;" ng-model="item.checked" ng-checked="item.checked">{{item.text}}</ion-checkbox>',
          scope: $scope
        })
        .then(function(res) {
          if(res) {
            for (var h=0;h<3;h++){
              //console.log($scope.report[h].checked , h);
              if($scope.report[h].checked){
                $scope.reportmsg = $scope.reportmsg + $scope.report[h].text + ' ';
                //console.log($scope.reportmsg);
              }
            }

            if(h==3){
              console.log($scope.reportmsg);
               $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/reportaevento.php', {namereportado : $scope.stalkeada.username,
                                                                              reportadoid : $scope.stalkeada.iduser,
                                                                              iduserreportando : $scope.user.iduser,
                                                                              usernamereportando : $scope.user.username,
                                                                              tiporeport : 'usuario',
                                                                              motivo : $scope.reportmsg}).then(function (tes){
                                 $scope.response = tes.data;
                                  var alertPopup = $ionicPopup.alert({
                                                          title: 'Obrigado',
                                                          template: 'Esta pessoa esta agora sobre investigação, obrigado por manter a plataforma segura'
                                                        });

                               });
            }
            
          }
        });
    }

    // $scope.enterItem =  function(item){
    //   formItem.updateForm(item);
    //   console.log(item.idevento);
    // }

}])
   
.controller('perfilOutroCtrl', ['$scope', '$stateParams', 'formOutro', 'formItem', 'EventoService','$http', '$timeout', '$ionicPopup', 'formUser', 'formStalker','$state','formvimdofiltro','formvimdofiltroperfil',  // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, formOutro, formItem, EventoService,$http, $timeout, $ionicPopup, formUser, formStalker, $state, formvimdofiltro, formvimdofiltroperfil) {

  
  $scope.stalkeada = {};
  $scope.auxusers = {};
  $scope.estadobutton = 0; 
  $scope.neventos= 0;
  $scope.neventosnao= 0;
  $scope.p =0;
  $scope.frase = {};
  $scope.vimdofiltro = formvimdofiltroperfil.getForm();


  $scope.outro = formOutro.getForm();
  $scope.user = formUser.getForm();

  $scope.stalkeada = $scope.outro;
  $scope.infosstalkeada={};
  EventoService.GetStalkear($scope.stalkeada.iduser).then(function(stalker) {
        $scope.infosstalkeada = stalker;
        if($scope.infosstalkeada.profilepic[8] == 's' && $scope.infosstalkeada.profilepic[9] == '3'){
             document.getElementById("imageidperfilOutro").src=$scope.infosstalkeada.profilepic+"?{{getTimeStamp()}}";
           }else{
             document.getElementById("imageidperfilOutro").src=$scope.infosstalkeada.profilepic;
           }
        $scope.frase = stalker.frase;
         if(stalker.borda == 0){
          $scope.estrelabb = false;
          $scope.estrelabs = false;
          $scope.estrelabg = false;
        }
        if(stalker.borda == 1){
          $scope.estrelabb = true;
          $scope.estrelabs = false;
          $scope.estrelabg = false;
        }
        if(stalker.borda == 2){
          $scope.estrelabb = false;
          $scope.estrelabs = true;
          $scope.estrelabg = false;
        }
        if(stalker.borda == 3){
          $scope.estrelabb = false;
          $scope.estrelabs = false;
          $scope.estrelabg = true;
        }
        if($scope.infosstalkeada.idade){
          $scope.infosstalkeada.idade = ", "+ $scope.infosstalkeada.idade +" anos";
        }else{
           $scope.infosstalkeada.idade ='';
        }
  });
  var header = document.getElementById("barperfiloutroev");
    var btns = header.getElementsByClassName("btnperfilotro");
    for (var i = 0; i < btns.length; i++) {
      btns[i].addEventListener("click", function() {
        var current = document.getElementsByClassName("actpo");
        current[0].className = current[0].className.replace(" actpo", "");
        this.className += " actpo";
      });
    }


  $scope.followbutton = false;
  $scope.desseguirbutton = false;

  $scope.qvou = true;

    $scope.CoisasCriado = true;
    $scope.CoisasFinalizado = false;

  var auxbloqueado = 0;
  var noti = {};

   EventoService.GetPontos($scope.stalkeada.iduser).then(function(items) {
        $scope.p = items;
        $scope.labels3 = ["Pontos"];
        $scope.colores3 = ["#ff4d4d"];
        $scope.data3 = [$scope.p];
      });
      EventoService.getIC($scope.stalkeada).then(function(items) {
        if(items){
          $scope.ic = items;
          $scope.options2 = {title: {
                      display: true,
                      text: 'Indice de confirmação',
                      position: 'bottom'
                  }
           }
          $scope.labels2 = ["Fui", "Não fui"];
          $scope.colores2 = ["#99FF99","#ff4d4d"];
          var menos = (100-$scope.ic.total).toFixed(1);
          var mais = $scope.ic.total;
          $scope.data2 = [mais, menos ];
        }
      });

      EventoService.GetComments3($scope.stalkeada).then(function(items) {
        
          $scope.options1 = {title: {
                    display: true,
                    text: 'Avaliações',
                    position: 'bottom'
                }
         }
          $scope.labels1 = ["Extrovertido", "Introvertido", "Realista","Curioso", "Solidário", "Racional","Organizado", "Criativo"];
          $scope.colores1 = ["#fff200", "#02fff2", "#ff9d00","#1867ce", "#e50be1", "#0e8c28","#ef370e", "#af0eef"];
          $scope.data1 =items.chart;
        
      }); 



  $scope.$on("$ionicView.enter", function(event, data){
    $scope.vimdofiltro = formvimdofiltroperfil.getForm();
    $scope.items = [];
    $scope.newItems = [];
    $scope.frase = {};

    $scope.vezes = 0;
    $scope.lastidevento = 0;
    $scope.aux2 = 0;

    $scope.outro = formOutro.getForm();
    $scope.stalkeada = $scope.outro;
    $scope.infosstalkeada={};
    EventoService.GetStalkear($scope.outro.iduser).then(function(stalker) {
        $scope.infosstalkeada = stalker;
         if($scope.infosstalkeada.profilepic[8] == 's' && $scope.infosstalkeada.profilepic[9] == '3'){
             document.getElementById("imageidperfilOutro").src=$scope.infosstalkeada.profilepic+"?{{getTimeStamp()}}";
           }else{
             document.getElementById("imageidperfilOutro").src=$scope.infosstalkeada.profilepic;
           }
        $scope.frase = stalker.frase;
         if(stalker.borda == 0){
          $scope.estrelabb = false;
          $scope.estrelabs = false;
          $scope.estrelabg = false;
        }
        if(stalker.borda == 1){
          $scope.estrelabb = true;
          $scope.estrelabs = false;
          $scope.estrelabg = false;
        }
        if(stalker.borda == 2){
          $scope.estrelabb = false;
          $scope.estrelabs = true;
          $scope.estrelabg = false;
        }
        if(stalker.borda == 3){
          $scope.estrelabb = false;
          $scope.estrelabs = false;
          $scope.estrelabg = true;
        }
        if($scope.infosstalkeada.idade){
          $scope.infosstalkeada.idade = ", "+ $scope.infosstalkeada.idade +" anos";
        }else{
           $scope.infosstalkeada.idade ='';
        }
    });
    
    $scope.followbutton = false;
    $scope.desseguirbutton = false;
    $scope.noMoreItemsAvailable = false;

    $scope.CoisasCriado = true;
    $scope.CoisasFinalizado = false;

    EventoService.GetPontos($scope.outro.iduser).then(function(items) {
        $scope.p = items;
        $scope.labels3 = ["Pontos"];
        $scope.colores3 = ["#ff4d4d"];
        $scope.data3 = [$scope.p];
      });
      EventoService.getIC($scope.outro).then(function(items) {
        if(items){
          $scope.ic = items;
          $scope.options2 = {title: {
                      display: true,
                      text: 'Indice de confirmação',
                      position: 'bottom'
                  }
           }
          $scope.labels2 = ["Fui", "Não fui"];
          $scope.colores2 = ["#99FF99","#ff4d4d"];
          var menos = (100-$scope.ic.total).toFixed(1);
          var mais = $scope.ic.total;
          $scope.data2 = [mais, menos ];
        }
      });

      EventoService.GetComments3($scope.outro).then(function(items) {
        
          $scope.options1 = {title: {
                    display: true,
                    text: 'Avaliações',
                    position: 'bottom'
                }
         }
           $scope.labels1 = ["Extrovertido", "Introvertido", "Realista","Curioso", "Solidário", "Racional","Organizado", "Criativo"];
          $scope.colores1 = ["#fff200", "#02fff2", "#ff9d00","#1867ce", "#e50be1", "#0e8c28","#ef370e", "#af0eef"];
          $scope.data1 =items.chart;
        
      }); 

      EventoService.GetCriados($scope.stalkeada).then(function(items) {
        if(items!='E'){
          for (var i = 0; i < items.length; i++) {
                var curr_date = (items[i].diainicio[8]+items[i].diainicio[9]);
                var h2 = (items[i].diainicio[11]+items[i].diainicio[12]);
                var m2 = (items[i].diainicio[14]+items[i].diainicio[15]);
                var curr_month = (items[i].diainicio[5]+items[i].diainicio[6]);
                var curr_year = (items[i].diainicio[0]+items[i].diainicio[1]+items[i].diainicio[2]+items[i].diainicio[3]);
                var j = curr_date + "/" + curr_month + "/" + curr_year+ ' '+h2 + ':' + m2;
                items[i].datainicio = j;
                if(items[i].estado == 0){
                  items[i].confirmacao = "Vai acontecer"
                }
                if(items[i].estado == 1){
                  items[i].confirmacao = "Finalizado"
                }
                if(items[i].estado == 2){
                  items[i].confirmacao = "Standy by, talvez aconteça"
                }
                if(items[i].estado == 3){
                  items[i].confirmacao = "Vai acontecer"
                }
                if(items[i].estado == 4){
                  items[i].confirmacao = "Cancelado"
                }
                if(items[i].estado == 5){
                  items[i].confirmacao = "Acabado"
                }
                if(items[i].estado == 6){
                  items[i].confirmacao = "Escondido"
                }
            }
          $scope.items = items;
          $scope.lastidvestido = $scope.items[0].idevento;
        }else{
          $scope.items = [];
          $scope.lastidevento = 0;
          auxbloqueado = 3;
        }
      //});
    });

    $scope.auxusers.outro =  $scope.outro.iduser;
    $scope.auxusers.eu =  $scope.user.iduser;

      $scope.outro= $scope.outro.iduser;
      $scope.auxusers.outro =  $scope.outro;
      $scope.auxusers.eu =  $scope.user.iduser;


      EventoService.possoseguir($scope.auxusers).then(function(items) {
        console.log(items)
        if(items){
          console.log($scope.outro,$scope.user.iduser)
          //// nao funciona, nao pegar os bloqueados
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/getfollow.php', {iduserseguindo : $scope.outro, 
                                                                    iduserseguidor : $scope.user.iduser}).then(function(res) {
            console.log( 'oi' , res.data[0].bloqueado, res.data[0] );
            if(res.data[0]!='E'){
              if (res.data[0].bloqueado==0){ 
                $scope.desseguirbutton = true;
                $scope.followbutton = false;
                auxbloqueado = 1;
                $scope.qvou = true;
                console.log('ja sigo este cara');
              }
              if(res.data[0].bloqueado==2){
                console.log('nao sigo este cara');
                $scope.desseguirbutton = false;
                $scope.followbutton = true;
                auxbloqueado = 1;
                $scope.qvou = false;
              }
              if(res.data[0].bloqueado==1){
                console.log('tais bloqueado');
                $scope.desseguirbutton = false;
                $scope.followbutton = false;
                auxbloqueado = 3;
                $scope.items = [];
                $scope.qvou = false;
              }
              if($scope.outro == $scope.user.iduser){
                $scope.followbutton = false;
                $scope.desseguirbutton = false;
                $scope.reportbutton = false;
                $scope.qvou = true;
              }
            }else{
                $scope.followbutton = true;
                auxbloqueado = 2;
                $scope.qvou = false;
            }
            if($scope.outro == $scope.user.iduser){
              $scope.followbutton = false;
              $scope.desseguirbutton = false;
              $scope.reportbutton = false;
              $scope.qvou = true;
            }
          });
        }else{
          if($scope.outro == $scope.user.iduser){
            $scope.followbutton = false;
            $scope.desseguirbutton = false;
            $scope.reportbutton = false;
            $scope.qvou = true;
          }else{
            $scope.qvou = false;
          }
        }
      });        
    });
 
    if($scope.outro.iduser == $scope.user.iduser){
      $scope.followbutton = false;
      $scope.desseguirbutton = false;
      $scope.reportbutton = false;
      var alertPopup = $ionicPopup.alert({
        title: '(●♡∀♡)',
        template: 'Que pessoa bela'
      }); 
    } 

  $scope.seguir = function(){
    noti.recebe = $scope.outro.iduser;
    noti.envia = $scope.user.iduser;
    noti.tipo = 11;
    noti.nomeevento = 'follow';
    console.log(auxbloqueado, "auxbloqueado == 2")
    EventoService.VerificaNotificacao(noti).then(function(res) {
      console.log(res);
      if(res){
        var msgnoti ='Nova pessoa esta t stalkeando';
        var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php';
          $http.post(link, {notificacao :msgnoti, 
                              idevento : $scope.user.iduser,
                              nomeevento : 'follow',
                              id_user_envia : $scope.user.iduser,
                              username_envia : $scope.user.username,
                              apelido_envia : $scope.user.apelido,
                              tipo : '11',
                              id_user_recebe : $scope.outro.iduser});
      }
    });
    if(auxbloqueado == 2){
      var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/seguepessoa.php';
      $http.post(link, {iduserseguindo : $scope.infosstalkeada.iduser, 
                        usernameseguindo : $scope.stalkeada.username,
                        iduserseguidor : $scope.user.iduser,
                        apelidoseguindo : $scope.infosstalkeada.apelido,
                        apelidoseguidor : $scope.user.apelido,
                        profilepicseguindo : $scope.infosstalkeada.profilepic,
                        profilepicseguidor : $scope.user.profilepic,
                        devicetokenseguidor : $scope.user.devicetoken,
                        usernameseguidor : $scope.user.username}).then(function(res) {
        console.log(res.success);
        var alertPopup = $ionicPopup.alert({
          title: '(*•̀ᴗ•́*)و ̑̑',
          template: 'Pessoa adicionada as pessoas de interesse'
        });
        $scope.desseguirbutton = true;
        $scope.followbutton = false;
      });
    }else{
       var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/refollow.php'; // estado "Bloqueado"  = 2;
          $http.post(link, {iduserseguindo : $scope.infosstalkeada.iduser, 
                            iduserseguidor : $scope.user.iduser}).then(function(res) {           
            var alertPopup = $ionicPopup.alert({
              title: '(￣▽￣)ノ',
              template: 'Pessoa adicionada as pessoas de interesse'
            }); 
            $scope.desseguirbutton = true;
            $scope.followbutton = false;             
          });
    }
  }

  $scope.desseguir = function(){
    auxbloqueado = 0;
      var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/desfollow.php'; // estado "Bloqueado"  = 2;
          $http.post(link, {iduserseguindo : $scope.infosstalkeada.iduser, 
                        iduserseguidor : $scope.user.iduser}).then(function(res) {
                          
                              var alertPopup = $ionicPopup.alert({
                                                          title: '(*꒦ິ⌓꒦ີ)',
                                                          template: 'Não segues mais esta pessoa'
                                                        }); 
                              $scope.desseguirbutton = false;
                              $scope.followbutton = true;
                          
                        });
  }

  $scope.comentario = function(){
    formStalker.updateForm($scope.stalkeada);
    if(auxbloqueado!=3){
      $state.go('tabsController.comentariosperfiloutros');
    }
  }

  $scope.loadCriados = function() {
    $scope.CoisasCriado = true;
    $scope.CoisasFinalizado = false;
    if(auxbloqueado!=3){
      $scope.estadobutton = 0;
      $scope.items = [];
      EventoService.GetCriados($scope.stalkeada).then(function(items) {
        if(items == 'E'){
          $scope.items = [];
        }else{
          for (var i = 0; i < items.length; i++) {
                var curr_date = (items[i].diainicio[8]+items[i].diainicio[9]);
                var h2 = (items[i].diainicio[11]+items[i].diainicio[12]);
                var m2 = (items[i].diainicio[14]+items[i].diainicio[15]);
                var curr_month = (items[i].diainicio[5]+items[i].diainicio[6]);
                var curr_year = (items[i].diainicio[0]+items[i].diainicio[1]+items[i].diainicio[2]+items[i].diainicio[3]);
                var j = curr_date + "/" + curr_month + "/" + curr_year+ ' '+h2 + ':' + m2;
                items[i].datainicio = j;
                if(items[i].estado == 0){
                  items[i].confirmacao = "Vai acontecer"
                }
                if(items[i].estado == 1){
                  items[i].confirmacao = "Finalizado"
                }
                if(items[i].estado == 2){
                  items[i].confirmacao = "Standy by, talvez aconteça"
                }
                if(items[i].estado == 3){
                  items[i].confirmacao = "Vai acontecer"
                }
                if(items[i].estado == 4){
                  items[i].confirmacao = "Cancelado"
                }
                if(items[i].estado == 5){
                  items[i].confirmacao = "Acabado"
                }
                if(items[i].estado == 6){
                  items[i].confirmacao = "Escondido"
                }
            }
          $scope.items = items.concat($scope.items);
          $scope.lastidvestido = $scope.items[0].idevento;
        }
      });
    }
  }
  
  $scope.loadAbertos = function() {
    $scope.CoisasCriado = false;
    $scope.CoisasFinalizado = true;
    if(auxbloqueado!=3){
      $scope.estadobutton = 1;
      $scope.items = [];
      EventoService.GetAbertos($scope.stalkeada.iduser).then(function(items) {  //mudar
        if(items == 'E'){
          $scope.items = [];
        }else{
          for (var i = 0; i < items.length; i++) {
                var curr_date = (items[i].diainicio[8]+items[i].diainicio[9]);
                var h2 = (items[i].diainicio[11]+items[i].diainicio[12]);
                var m2 = (items[i].diainicio[14]+items[i].diainicio[15]);
                var curr_month = (items[i].diainicio[5]+items[i].diainicio[6]);
                var curr_year = (items[i].diainicio[0]+items[i].diainicio[1]+items[i].diainicio[2]+items[i].diainicio[3]);
                var j = curr_date + "/" + curr_month + "/" + curr_year+ ' '+h2 + ':' + m2;
                items[i].datainicio = j;
            }
          $scope.items = items.concat($scope.items);
          $scope.lastidvestido = $scope.items[0].idevento;
        }
      });
    }
  }
  
  $scope.loadFechados = function() {
    $scope.CoisasCriado = false;
    $scope.CoisasFinalizado = true;
    if(auxbloqueado!=3){
      $scope.estadobutton = 2;
      $scope.items = [];
      //console.log($scope.user.iduser);
      EventoService.GetFinalizadosPerfil($scope.stalkeada.iduser).then(function(items) {         //mudar
        if(items=='E'){
          $scope.items = [];
        }else{
          for (var i = 0; i < items.length; i++) {
                var curr_date = (items[i].diainicio[8]+items[i].diainicio[9]);
                var h2 = (items[i].diainicio[11]+items[i].diainicio[12]);
                var m2 = (items[i].diainicio[14]+items[i].diainicio[15]);
                var curr_month = (items[i].diainicio[5]+items[i].diainicio[6]);
                var curr_year = (items[i].diainicio[0]+items[i].diainicio[1]+items[i].diainicio[2]+items[i].diainicio[3]);
                var j = curr_date + "/" + curr_month + "/" + curr_year+ ' '+h2 + ':' + m2;
                items[i].datainicio = j;
            }
          $scope.items = items.concat($scope.items);
          $scope.lastidvestido = $scope.items[0].idevento;
        }
      });
    }
  }
    
  $scope.loadMore = function() {
    if ($scope.estadobutton == 0 && auxbloqueado!=3) {
      EventoService.GetOldEventosCriados().then(function(items) {
        $scope.items = $scope.items.concat(items);
        $scope.$broadcast('scroll.infiniteScrollComplete');
        if (items.length <= 4) {
          $scope.noMoreItemsAvailable = true;
        }
      });
    }
    if ($scope.estadobutton == 1 && auxbloqueado!=3) {
      EventoService.GetOldEventosCriados().then(function(items) {
        $scope.items = $scope.items.concat(items);
        $scope.$broadcast('scroll.infiniteScrollComplete');
        if (items.length <= 4) {
          $scope.noMoreItemsAvailable = true;
        }
      });

      
    }
    if ($scope.estadobutton == 2 && auxbloqueado!=3) {
      EventoService.GetOldEventosCriados().then(function(items) {
        $scope.items = $scope.items.concat(items);
        $scope.$broadcast('scroll.infiniteScrollComplete');
        if (items.length <= 4) {
          $scope.noMoreItemsAvailable = true;
        }
      });
    }
  }

  $scope.reportar = function(){
    $scope.reportmsg = '';
    console.log($scope.stalkeada.username);
    $scope.report = [
    { text: "Nome impróprio", checked: false },
    { text: "Comportamento inadequado", checked: false },
    { text: "Foto inapropriada", checked: false },
    { text: "É um impostor", checked: false }
    ];
    $ionicPopup.confirm({
      title: 'Você quer reportar essa pessoa pq?',
      content: '<ion-checkbox ng-repeat="item in report"  style="color: #FCFCFC;" ng-model="item.checked"  ng-checked="item.checked">{{item.text}}</ion-checkbox>',
      scope: $scope
    }).then(function(res) {
      if(res) {
        for (var h=0;h<3;h++){
          //console.log($scope.report[h].checked , h);
          if($scope.report[h].checked){
            $scope.reportmsg = $scope.reportmsg + $scope.report[h].text + ' ';
            //console.log($scope.reportmsg);
          }
        }
        if(h==3){
          console.log($scope.reportmsg);
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/reportaevento.php', {namereportado : $scope.stalkeada.username,
                                                                          reportadoid : $scope.stalkeada.iduser,
                                                                          iduserreportando : $scope.user.iduser,
                                                                          usernamereportando : $scope.user.username,
                                                                          tiporeport : 'usuario',
                                                                          motivo : $scope.reportmsg}).then(function (tes){
            $scope.response = tes.data;
            var alertPopup = $ionicPopup.alert({
              title: 'Obrigado',
              template: 'Esta pessoa esta agora sobre investigação, obrigado por manter a plataforma segura'
            });
          });
        }
      }
    });
  }

}])
       
.controller('loginCtrl', ['$scope', '$stateParams', '$state', 'EventoService','$ionicPopup','$timeout','formUser','$ionicLoading','$q','formLoc', 'formtipologin', 'formCodigo', '$http',  // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $state, EventoService, $ionicPopup, $timeout, formUser, $ionicLoading, $q, formLoc, formtipologin, formCodigo, $http) {
    $scope.user = {
      email: '',
      password: ''
    };
    $scope.codigo = formCodigo.getForm();

    $scope.usuario ={};
    $scope.concordo = { checked: false };
    var lat;
    var long;
    var myLatlng;
    var spherical; 
    var north; 
    var west; 
    var south; 
    var east;
    var raio;
    navigator.geolocation.getCurrentPosition(function(position){
      raio = 50000*0.71;
      lat  = position.coords.latitude;
      long = position.coords.longitude;
      $scope.user.lat =  position.coords.latitude;
      $scope.user.long =  position.coords.longitude;

      myLatlng = new google.maps.LatLng(lat, long);
      spherical = google.maps.geometry.spherical; 
      north = spherical.computeOffset(myLatlng, raio, 0); 
      west  = spherical.computeOffset(myLatlng, raio, -90); 
      south = spherical.computeOffset(myLatlng, raio, 180); 
      east  = spherical.computeOffset(myLatlng, raio, 90);
      $scope.user.northlat = north.lat();
      $scope.user.westlng = west.lng();
      $scope.user.southlat = south.lat();
      $scope.user.eastlng = east.lng();
      formLoc.updateForm($scope.user);
    },function (error) { 
      if (error.code == error.PERMISSION_DENIED)
          console.log("you denied me :-(");
          $scope.semloc = true;
      });

    $scope.$on("$ionicView.enter", function(event, data){
      $scope.user = {
        email: '',
        password: ''
      };
      $scope.codigo = formCodigo.getForm();
      $scope.usuario ={};
      $scope.concordo = { checked: false };
      navigator.geolocation.getCurrentPosition(function(position){
        raio = 50000*0.71;
        lat  = position.coords.latitude;
        long = position.coords.longitude;
        $scope.user.lat =  position.coords.latitude;
        $scope.user.long =  position.coords.longitude;

        myLatlng = new google.maps.LatLng(lat, long);
        spherical = google.maps.geometry.spherical; 
        north = spherical.computeOffset(myLatlng, raio, 0); 
        west  = spherical.computeOffset(myLatlng, raio, -90); 
        south = spherical.computeOffset(myLatlng, raio, 180); 
        east  = spherical.computeOffset(myLatlng, raio, 90);
        $scope.user.northlat = north.lat();
        $scope.user.westlng = west.lng();
        $scope.user.southlat = south.lat();
        $scope.user.eastlng = east.lng();
        formLoc.updateForm($scope.user);
      },function (error) { 
        if (error.code == error.PERMISSION_DENIED)
            console.log("you denied me :-(");
            $scope.semloc = true;
        });
    });
    $scope.checkLoginState = function(){
    facebookConnectPlugin.login(["public_profile","email","user_birthday"],function(result){
            console.log(result)
          },
          function (result) {}
        );
   }

                


    $scope.facebookSignIn = function(){
      // if ($scope.concordo.checked) {
        facebookConnectPlugin.login(["public_profile","email"],function(result){
        //calling api after login success
        facebookConnectPlugin.api(
          "me/picture?width=600&height=600&redirect=false",
          ["public_profile"],
          function (res) {
            $scope.user.profilepic = res.data.url;
          },
          function (res) {}
        );

         facebookConnectPlugin.api("/me?fields=email,name,gender,age_range",
         ["public_profile","email"]
         ,function(userData){
             //API success callback
              //alert(JSON.stringify(userData));
              $scope.user.email = userData.email;
              $scope.user.apelido = userData.name;
              $scope.user.username = userData.name.replace(/\s/g,'');
              $scope.user.password = userData.id;
              EventoService.verificanome($scope.user.username).then(function(success){                  
                if(success){
                  $scope.user.username = $scope.user.username +$scope.user.password[0]+$scope.user.password[1]+$scope.user.password[2];
                }
                  
                 
              if(userData.gender){
                if(userData.gender == "male"){
                  $scope.user.genero = "masc";
                }else{
                  $scope.user.genero = "fem";
                }
              } 
              if(userData.birthda){
               var today = new Date();
                var birthDate = new Date(userData.birthday);
                $scope.user.idade = today.getFullYear() - birthDate.getFullYear();
                var m = today.getMonth() - birthDate.getMonth();
                if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
                    $scope.user.idade--;
                } 
              }
              if(userData.age_range){
                $scope.user.idade =userData.age_range;
              }
              EventoService.Entrando($scope.user).then(function(data){
                  if(data.success){
                    $scope.user.devicetoken = window.localStorage.getItem( 'token' );
                    $scope.user.iduser = data[0].iduser;
                    EventoService.Mudadevice($scope.user);
                    $ionicLoading.hide();
                    formtipologin.updateForm(1);
                    var alertPopup = $ionicPopup.alert({
                        title: 'Olá', 
                        template: 'Bem vindo!',
                        buttons: [
                            {
                              text: 'oi',
                              type: 'button-positive'
                            }]
                          
                  });
                   alertPopup.then(function(){
                    
                        window.localStorage.setItem( 'user', JSON.stringify(data[0]));
                            formUser.updateForm(data[0]);
                            $state.go('tabsController.home');
                          })  
                 }else{
                  
                  if(!$scope.user.idade){
                    $ionicPopup.prompt({
                    title: '2 coisinhas rapidinho',
                    template: 'Quantos anos voce tem?',
                     inputType: 'number',
                     inputPlaceholder: ' Idade'
                   }).then(function(idade) {
                    $scope.user.idade = idade;
                      if(!$scope.user.genero){
                        var confirmPopup = $ionicPopup.show({
                         title: 'Outra coisa...',
                         template: 'Qual seu gênero?',
                         buttons: [
                            { text: 'Masculino',
                              type: 'button-positive',
                              onTap: function(e){
                                $scope.user.genero = "masc";
                                EventoService.CriaConta($scope.user).then(function(resp){
                                  if(resp.success){
                                    formtipologin.updateForm(1);
                                    var alertPopup = $ionicPopup.alert({
                                          title: 'Olá', 
                                          template: 'Bem vindo!',
                                          buttons: [
                                              {
                                                text: 'oi',
                                                type: 'button-positive'
                                              }]     
                                    });
                                    alertPopup.then(function(){
                                      $scope.loc = formLoc.getForm();
                                      if($scope.loc){
                                        $scope.user.lat =  $scope.loc.lat;
                                        $scope.user.long =  $scope.loc.long;
                                        $scope.user.northlat = $scope.loc.northlat;
                                        $scope.user.westlng = $scope.loc.westlng;
                                        $scope.user.southlat = $scope.loc.southlat;
                                        $scope.user.eastlng = $scope.loc.eastlng;
                                        //console.log($scope.loc.eastlng)
                                      }else{
                                        navigator.geolocation.getCurrentPosition(function(position){
                                        console.log("to aqui")
                                        raio = 50000*0.71;
                                        lat  = position.coords.latitude;
                                        long = position.coords.longitude;
                                        $scope.user.lat =  position.coords.latitude;
                                        $scope.user.long =  position.coords.longitude;

                                        myLatlng = new google.maps.LatLng(lat, long);
                                        spherical = google.maps.geometry.spherical; 
                                        north = spherical.computeOffset(myLatlng, raio, 0); 
                                        west  = spherical.computeOffset(myLatlng, raio, -90); 
                                        south = spherical.computeOffset(myLatlng, raio, 180); 
                                        east  = spherical.computeOffset(myLatlng, raio, 90);
                                        $scope.user.northlat = north.lat();
                                        $scope.user.westlng = west.lng();
                                        $scope.user.southlat = south.lat();
                                        $scope.user.eastlng = east.lng();
                                        formLoc.updateForm($scope.user);
                                      },function (error) { 
                                        if (error.code == error.PERMISSION_DENIED)
                                            console.log("you denied me :-(");
                                            $scope.semloc = true;
                                        });
                                      }
                                      EventoService.confereconvite($scope.codigo).then(function(resp) {
                                    var currentdate = new Date();
                                    currentdate.setDate(currentdate.getDate() - 7);
                                    var curr_date = (currentdate.getDate()<10?'0':'') + currentdate.getDate();
                                    var curr_month = (currentdate.getMonth()<10?'0':'') + (currentdate.getMonth() + 1); 
                                    var curr_year = currentdate.getFullYear();
                                    var h2 = (currentdate.getHours()<10?'0':'') + currentdate.getHours();
                                    var m2 = (currentdate.getMinutes()<10?'0':'') + currentdate.getMinutes();
                                    var j = curr_year + "-" + curr_month + "-" + curr_date+ ' '+h2 + ':' + m2 + ':00';
                                    console.log(j, resp[0].codigodatacriacao)
                                    if(resp[0].codigodatacriacao > j){
                                      resp[0].numcodigo = parseInt(resp[0].numcodigo) + 1
                                      console.log(resp[0].numcodigo)
                                      $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/somanumcodigo.php', {iduser : resp[0].iduser,
                                                                                                            numcodigo : resp[0].numcodigo});
                                    }
                                });
                                    
                                      formUser.updateForm($scope.user);
                                      $state.go('tabsController.home');
                                    })  
                                  }else{
                                    alert(resp.msg);
                                  }
                                }) 
                              }},
                            {
                              text: 'Feminino',
                              type: 'button-positive',
                              onTap: function(e){
                                $scope.user.genero = "fem";
                                EventoService.CriaConta($scope.user).then(function(resp){
                                  if(resp.success){
                                    formtipologin.updateForm(1);
                                    var alertPopup = $ionicPopup.alert({
                                          title: 'Olá', 
                                          template: 'Bem vindo!',
                                          buttons: [
                                              {
                                                text: 'oi',
                                                type: 'button-positive'
                                              }]     
                                    });
                                    alertPopup.then(function(){
                                      $scope.loc = formLoc.getForm();
                                      if($scope.loc){
                                        $scope.user.lat =  $scope.loc.lat;
                                        $scope.user.long =  $scope.loc.long;
                                        $scope.user.northlat = $scope.loc.northlat;
                                        $scope.user.westlng = $scope.loc.westlng;
                                        $scope.user.southlat = $scope.loc.southlat;
                                        $scope.user.eastlng = $scope.loc.eastlng;
                                        //console.log($scope.loc.eastlng)
                                      }else{
                                        navigator.geolocation.getCurrentPosition(function(position){
                                        console.log("to aqui")
                                        raio = 50000*0.71;
                                        lat  = position.coords.latitude;
                                        long = position.coords.longitude;
                                        $scope.user.lat =  position.coords.latitude;
                                        $scope.user.long =  position.coords.longitude;

                                        myLatlng = new google.maps.LatLng(lat, long);
                                        spherical = google.maps.geometry.spherical; 
                                        north = spherical.computeOffset(myLatlng, raio, 0); 
                                        west  = spherical.computeOffset(myLatlng, raio, -90); 
                                        south = spherical.computeOffset(myLatlng, raio, 180); 
                                        east  = spherical.computeOffset(myLatlng, raio, 90);
                                        $scope.user.northlat = north.lat();
                                        $scope.user.westlng = west.lng();
                                        $scope.user.southlat = south.lat();
                                        $scope.user.eastlng = east.lng();
                                        formLoc.updateForm($scope.user);
                                      },function (error) { 
                                        if (error.code == error.PERMISSION_DENIED)
                                            console.log("you denied me :-(");
                                            $scope.semloc = true;
                                        });
                                      }
                                      EventoService.confereconvite($scope.codigo).then(function(resp) {
                                            var currentdate = new Date();
                                            currentdate.setDate(currentdate.getDate() - 7);
                                            var curr_date = (currentdate.getDate()<10?'0':'') + currentdate.getDate();
                                            var curr_month = (currentdate.getMonth()<10?'0':'') + (currentdate.getMonth() + 1); 
                                            var curr_year = currentdate.getFullYear();
                                            var h2 = (currentdate.getHours()<10?'0':'') + currentdate.getHours();
                                            var m2 = (currentdate.getMinutes()<10?'0':'') + currentdate.getMinutes();
                                            var j = curr_year + "-" + curr_month + "-" + curr_date+ ' '+h2 + ':' + m2 + ':00';
                                          console.log(j, resp.codigodatacriacao)
                                            if(resp[0].codigodatacriacao < j){
                                            }else{
                                              resp[0].numcodigo = parseInt(resp[0].numcodigo) + 1;
                                              console.log(resp[0].numcodigo);
                                              $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/somanumcodigo.php', {iduser : resp[0].iduser,
                                                                                                                    numcodigo : resp[0].numcodigo}).then(function (tes){
                                             
                                              });
                                            }
                                        });
                                      formUser.updateForm($scope.user);
                                      $state.go('tabsController.home');
                                    })  
                                  }else{
                                    alert(resp.msg);
                                  }
                                }) 
                              }}]
                        });
                      }
                      
                   });
                  }
                 }
                }); 
              });
          },function(error){
             //API error callback
             alert(JSON.stringify(error));
          });
       },function(error){
          //authenication error callback
          alert(JSON.stringify(error));
         });
     //  }else{
     //    var alertPopup = $ionicPopup.alert({
     //          title: 'ԅ( ˘ω˘ ԅ)',
     //          template: 'Para que possa entrar você precisa concordar com os termos de uso no app, afinal de contas nao queremos nenhum mal entendido'
     //    });
     // }
      
    }

    $scope.login = function() {
      // //console.log( $scope.user.email);
      if($scope.user.email){
          $ionicLoading.show();
      var authenticationData = {
        Username : $scope.user.email,
        Password : $scope.user.password,
          };
        
        var authenticationDetails = new AmazonCognitoIdentity.AuthenticationDetails(authenticationData);
          
        var poolData = {
          UserPoolId : 'us-east-1_nOWA67ADf', // Your user pool id here
          ClientId : '8k5rbqhifi5r1hb2j4n1u07li'// Your client id here
        };
        
          var userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);
        
          var userData = {
              Username : $scope.user.email,
              Pool : userPool,
          };
        
          var cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);
          
        cognitoUser.authenticateUser(authenticationDetails, {
              onSuccess: function (result) {
            var accessToken = result.getAccessToken().getJwtToken();
            //console.log(accessToken); 
              },

              onFailure: function(err) {
                  //alert(err.message || JSON.stringify(err));
                  $ionicLoading.hide();
              },
          });

      EventoService.Entrando($scope.user).then(function(data){

        if(data.success){
          $scope.user.devicetoken = window.localStorage.getItem( 'token' );
          $scope.user.iduser = data[0].iduser;
          EventoService.Mudadevice($scope.user);
          $ionicLoading.hide();

          var alertPopup = $ionicPopup.alert({
              title: 'Olá', 
              template: 'Bem vindo!',
              buttons: [
                  {
                    text: 'oi',
                    type: 'button-positive'
                  }]
                
        });
         alertPopup.then(function(){
          formtipologin.updateForm(2);
              window.localStorage.setItem( 'user', JSON.stringify(data[0]));
                  formUser.updateForm(data[0]);
                  $state.go('tabsController.home');
                })  
       }else{
        $ionicLoading.hide();
        var alertPopup = $ionicPopup.alert({
              title: 'Login falhou',
              template: data.msg
        });
       }
      });   
     }else{
        var alertPopup = $ionicPopup.alert({
              title: 'ԅ( ˘ω˘ ԅ)',
              template: 'Coloque o email'
        });
     }
   }

    $scope.Esqueci = function(){
      if(!$scope.user.email){
        var alertPopup = $ionicPopup.alert({
              title: 'Nos ajude',
              template: 'Complete o campo de email para refazer sua senha'
        });
      }
      var poolData = {
        UserPoolId : 'us-east-1_nOWA67ADf', // Your user pool id here
        ClientId : '8k5rbqhifi5r1hb2j4n1u07li'// Your client id here
      };
  
      var userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);
  
      var userData = {
        Username : $scope.user.email,
        Pool : userPool,
      };
  
      var cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);
    
      cognitoUser.forgotPassword({
        onSuccess: function (result) {
            console.log('call result: ' + result);
        },
        onFailure: function(err) {
            //alert(err);
          console.log(err);
        },
        inputVerificationCode() {
           $ionicPopup.prompt({
                            title: 'Enviamos um código',
                            template: 'Insira o código de verificação no seu email',
                           inputType: 'text',
                           inputPlaceholder: 'XXXXXX'
                         }).then(function(verificationCode) {
                          if(!verificationCode || verificationCode == ""){
                            console.log("nao dei")
                          }else{
                            $ionicPopup.prompt({
                            title: 'Nova senha',
                            template: 'Qual vai ser minha nova senha que nao esquecerei?',
                           inputType: 'text',
                           inputPlaceholder: 'Diwo1234'
                        }).then(function(newPassword) {
                          if(!newPassword || newPassword == ""){
                            var alertPopup = $ionicPopup.alert({
                              title: '-.-"',
                              template: 'Escreva uma nova senha de acordo com as regras'
                            });
                          }else{
                            cognitoUser.confirmPassword(verificationCode, newPassword, this);
                            $scope.usuario.email = $scope.user.email;
                            $scope.usuario.password = newPassword;
                            EventoService.atualizarsenha($scope.usuario).then(function(data){
                              if (data) {
                                var alertPopup = $ionicPopup.alert({
                                  title: 'Deu boa',
                                  template: 'Senha alterada com sucesso, agora é só não esquecer dessa!'
                                });
                              }else{
                                var alertPopup = $ionicPopup.alert({
                                  title: 'Deu ruim',
                                  template: 'Senha não pode ser alterada, tente novamente, se o problema persistir contate a gente!'
                                });
                              }
                              
                            });;
                          }
                       }); 
                          }
                         
                  });
        }
    });
     }

}])

   
.controller('nomeuserCtrl', ['$scope', '$stateParams', '$ionicPopup', '$http', '$timeout', 'EventoService','formUser','$state',  // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $ionicPopup, $timeout, $http, EventoService, formUser, $state) {

  $scope.user = formUser.getForm();
  $scope.userexiste = false;
  $scope.usernexite = false;
  $scope.verifique = false;
  $scope.verifica = function(){
    EventoService.verificanome($scope.user.username).then(function(success){
    console.log(success, "'dasd",$scope.user.email, $scope.user.genero )                         
      if(!success){
        $scope.usernexite = true;
        $scope.userexiste = false;
        $scope.verifique = false;
      }else{
        $scope.userexiste = true;
        $scope.usernexite = false;
        $scope.verifique = false;
      }
    });
  };

  $scope.pronto = function(){   
  console.log($scope.usernexite)                
    if($scope.usernexite){
      EventoService.CriaConta($scope.user);
      EventoService.Entrando($scope.user).then(function(data){
        var alertPopup = $ionicPopup.alert({
              title: 'Olá', 
              template: 'Bem vindo!',
              buttons: [
                  {
                    text: 'oi',
                    type: 'button-positive'
                  }]
        });
         alertPopup.then(function(){
                  formUser.updateForm(data[0]);
                  $state.go('tabsController.home');
                })  

      }, function(errMsg){
        var alertPopup = $ionicPopup.alert({
              title: 'Login falhou',
              template: errMsg.msg
        });
      })
    }else{
      $scope.verifique = true;
    }
  };
}])
   
.controller('EditEvCtrl', ['$scope', '$stateParams', '$ionicPopup', '$http', '$cordovaDevice', '$timeout', 'EventoService','formUser','$state', 'formEventoAbertosTab', 'formEventoEdita','$cordovaCamera', '$cordovaFile', '$cordovaFileTransfer', '$cordovaDevice',  '$ionicLoading',  // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $ionicPopup, $http, $cordovaDevice, $timeout, EventoService, formUser, $state,formEventoAbertosTab, formEventoEdita$cordovaCamera, $cordovaFile, $cordovaFileTransfer, $cordovaDevice,  $ionicLoading) {
  $scope.evento = {};
  $scope.evento = formEventoEdita.getForm();
  $scope.auxfoto = '';
  $scope.user = formUser.getForm();
  var mudoufoto = false;
  var noti = {};
  $scope.pushnoti = {};

  $scope.limiteconfirmacao ={};
  $scope.fim = {};
  $scope.inicio = {};

  var auxdiainicio = $scope.evento.diainicio;

  $scope.evento.dateconfirma = $scope.evento.dialimiteconfirmacao.toLocaleString();
  $scope.evento.dateinicio = $scope.evento.diainicio;
  $scope.evento.datefim = $scope.evento.diafim;
  
  var currentdate = new Date(); 
  var curr_date = (currentdate.getDate()<10?'0':'') + currentdate.getDate();
  var curr_month = (currentdate.getMonth()<9?'0':'') + (currentdate.getMonth() + 1); //Months are zero based
  var curr_year = currentdate.getFullYear();
  var curr_h = (currentdate.getHours()<10?'0':'') + currentdate.getHours();
  var curr_m = (currentdate.getMinutes()<10?'0':'') + currentdate.getMinutes();
  var curr_j = curr_year + "-" + curr_month + "-" + curr_date+ ' '+curr_h + ':' + curr_m + ':' + '00';
  
  EventoService.verificahorariopessoaevento($scope.user).then(function(items) {
    if (items!="Error") {
      $scope.auxdata = items;
    }
  });

  $scope.mudafotoevento = function (optionsCamera) {
    var optionsCamera = {
          quality : 100,
          sourceType : 0,
          allowEdit : true,
          targetWidth: 720,
          targetHeight: 400
    };
    $cordovaCamera.getPicture(optionsCamera).then(function(imageData) {
      $scope.imgURI = imageData;
      mudoufoto = true;
      document.getElementById("imageidEventoEditEv").src=imageData;
    }, function(err) {
      console.log(err);
    });
    
  }

  $scope.mudaconfirma = function(){
    novaconfirma_date = ($scope.evento.dateconfirma.getDate()<10?'0':'') + $scope.evento.dateconfirma.getDate();
    novaconfirma_month = ($scope.evento.dateconfirma.getMonth()<9?'0':'') + ($scope.evento.dateconfirma.getMonth() + 1); //Months are zero based
    novaconfirma_year = $scope.evento.dateconfirma.getFullYear();
    novaconfirma_h = ($scope.evento.dateconfirma.getHours()<10?'0':'') + $scope.evento.dateconfirma.getHours();
    novaconfirma_m = ($scope.evento.dateconfirma.getMinutes()<10?'0':'') + $scope.evento.dateconfirma.getMinutes();
    novaconfirma_s = ($scope.evento.dateconfirma.getSeconds()<10?'0':'') + $scope.evento.dateconfirma.getSeconds();
    var novaconfirmaj = novaconfirma_year + "-" + novaconfirma_month + "-" + novaconfirma_date+ ' '+novaconfirma_h + ':' + novaconfirma_m + ':' + novaconfirma_s;
    

    if(curr_j>novaconfirmaj){
      var alertPopup = $ionicPopup.alert({
                  title: '(*ﾉ´□`)ﾉ~',
                  template: 'Muito em cima da hora para mudar pra ontem'
                });
      
    }else{
      if(novaconfirmaj>$scope.evento.diainicio){
        var alertPopup = $ionicPopup.alert({
                  title: 'ヽ ( ꒪д꒪ )ﾉ',
                  template: 'Evento nao pode começar depois da data limite de confirmação'
                });
      }else{
        $scope.limiteconfirmacao.dia =  novaconfirma_date +'/'+ novaconfirma_month;
        $scope.limiteconfirmacao.hora =  novaconfirma_h+':'+novaconfirma_m;  
        $scope.evento.dialimiteconfirmacao = novaconfirmaj;
        $scope.evento.dateconfirma = $scope.evento.dateconfirma.toLocaleString();
      }
    }
  }
  
  $scope.mudainicio = function(){
    var datainvalida = 0;
    
    novadateinicio_date = ($scope.evento.dateinicio.getDate()<10?'0':'') + $scope.evento.dateinicio.getDate();
    novadateinicio_month = ($scope.evento.dateinicio.getMonth()<9?'0':'') + ($scope.evento.dateinicio.getMonth() + 1); //Months are zero based
    novadateinicio_year = $scope.evento.dateinicio.getFullYear();
    novadateinicio_h = ($scope.evento.dateinicio.getHours()<10?'0':'') + $scope.evento.dateinicio.getHours();
    novadateinicio_m = ($scope.evento.dateinicio.getMinutes()<10?'0':'') + $scope.evento.dateinicio.getMinutes();
    novadateinicio_s = ($scope.evento.dateinicio.getSeconds()<10?'0':'') + $scope.evento.dateinicio.getSeconds();
    $scope.evento.semana = $scope.evento.dateinicio.getDay();
    var novadateinicioj = novadateinicio_year + "-" + novadateinicio_month + "-" + novadateinicio_date+ ' '+novadateinicio_h + ':' + novadateinicio_m + ':' + novadateinicio_s;
    
    if(curr_j>novadateinicioj){
      var alertPopup = $ionicPopup.alert({
                  title: '(*ﾉ´□`)ﾉ~',
                  template: 'Muito em cima da hora para mudar pra ontem'
                });
      
    }else{
      if($scope.evento.dialimiteconfirmacao>novadateinicioj){
        var alertPopup = $ionicPopup.alert({
                    title: '(*ﾉ´□`)ﾉ~',
                    template: 'Data de inicio não pode ser antes que a data limite de confirmação'
                  });
        
      }else{
        for(var r = 0;r<$scope.auxdata.length; r++){
          //console.log($scope.auxdata[r].idevento, $scope.auxdata[r].diainicio, $scope.auxdata[r].diafim , we ,$scope.evento.diafim);
          if($scope.evento.idevento!=$scope.auxdata[r].idevento){
            if (($scope.auxdata[r].diainicio <= novadateinicioj && $scope.auxdata[r].diafim >= novadateinicioj)  ) {
              datainvalida = 1;
            }
          }
        }
        if(r==$scope.auxdata.length && datainvalida == 1){
          var alertPopup = $ionicPopup.alert({
            title: 'Oww!!',
            template: 'Tu ja tem um evento marcado nesse horário :/'
          });
        }
        if(novadateinicioj>$scope.evento.datefim){
          console.log("to aquiwenqieni")
          $scope.fim.dia =  '??'+'/'+'??';
          $scope.fim.hora = '??'+':'+'??';
        }
        if(r==$scope.auxdata.length && datainvalida == 0){
          if($scope.evento.semana == 0){
            $scope.evento.semana = "Domingo";
          }
          if($scope.evento.semana == 1){
            $scope.evento.semana = "Segunda-feira";
          }
          if($scope.evento.semana == 2){
            $scope.evento.semana = "Terça-feira";
          }
          if($scope.evento.semana == 3){
            $scope.evento.semana = "Quarta-feira";
          }
          if($scope.evento.semana == 4){
            $scope.evento.semana = "Quinta-feira";
          }
          if($scope.evento.semana == 5){
            $scope.evento.semana = "Sexta-feira";
          }
          if($scope.evento.semana == 6){
            $scope.evento.semana = "Sábado";
          }
          $scope.inicio.dia =  novadateinicio_date +'/'+ novadateinicio_month;
          $scope.inicio.hora =  novadateinicio_h+':'+novadateinicio_m;  
          $scope.evento.diainicio = novadateinicioj;
          $scope.evento.dateinicio = $scope.evento.dateinicio.toLocaleString();
        }
      }
    }
  }

  $scope.mudafim = function(){
    var datainvalida = 0;
    
    novadatefim_date = ($scope.evento.datefim.getDate()<10?'0':'') + $scope.evento.datefim.getDate();
    novadatefim_month = ($scope.evento.datefim.getMonth()<9?'0':'') + ($scope.evento.datefim.getMonth() + 1); //Months are zero based
    novadatefim_year = $scope.evento.datefim.getFullYear();
    novadatefim_h = ($scope.evento.datefim.getHours()<10?'0':'') + $scope.evento.datefim.getHours();
    novadatefim_m = ($scope.evento.datefim.getMinutes()<10?'0':'') + $scope.evento.datefim.getMinutes();
    novadatefim_s = ($scope.evento.datefim.getSeconds()<10?'0':'') + $scope.evento.datefim.getSeconds();
    var novadatedatefimj = novadatefim_year + "-" + novadatefim_month + "-" + novadatefim_date+ ' '+novadatefim_h + ':' + novadatefim_m + ':' + novadatefim_s;
    
    if(curr_j>novadatedatefimj){
      var alertPopup = $ionicPopup.alert({
                  title: '(*ﾉ´□`)ﾉ~',
                  template: 'Muito em cima da hora para mudar pra ontem'
                });
      
    }else{
      if($scope.evento.dialimiteconfirmacao>novadatedatefimj){
        var alertPopup = $ionicPopup.alert({
                    title: '(*ﾉ´□`)ﾉ~',
                    template: 'Data de fim não pode ser antes que a data limite de confirmação'
                  });
        
      }else{
        if($scope.evento.diainicio>=novadatedatefimj){
        var alertPopup = $ionicPopup.alert({
                    title: '(*ﾉ´□`)ﾉ~',
                    template: 'Data de fim não pode ser antes que a data de início'
                  });
        }else{
          for(var r = 0;r<$scope.auxdata.length; r++){
            if($scope.evento.idevento!=$scope.auxdata[r].idevento){
              if (($scope.auxdata[r].diainicio <= novadatedatefimj && $scope.auxdata[r].diafim >= novadatedatefimj)  ) {
                datainvalida = 1;
              }
            }
          }
          if(r==$scope.auxdata.length && datainvalida == 1){
            var alertPopup = $ionicPopup.alert({
              title: 'Oww!!',
              template: 'Tu ja tem um evento marcado nesse horário :/'
            });
          }
          if(r==$scope.auxdata.length && datainvalida == 0){
            $scope.fim.dia =  novadatefim_date +'/'+ novadatefim_month;
            $scope.fim.hora =  novadatefim_h+':'+novadatefim_m;  
            $scope.evento.diafim = novadatedatefimj;
            $scope.evento.datefim = $scope.evento.datefim.toLocaleString();
          }
        }
      }
    }
  }
  
  var hjf = $scope.evento.diafim;
  $scope.fim.dia =  (hjf[8]+hjf[9]).valueOf()+'/'+(hjf[5]+hjf[6]).valueOf();
  $scope.fim.hora = (hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf();
  
  var hj = $scope.evento.diainicio;
  $scope.inicio.dia = (hj[8]+hj[9]).valueOf()+'/'+(hj[5]+hj[6]).valueOf();
  $scope.inicio.hora = (hj[11]+hj[12]).valueOf()+':'+(hj[14]+hj[15]).valueOf();


  var  hjl = $scope.evento.dialimiteconfirmacao;
  $scope.limiteconfirmacao.dia =  (hjl[8]+hjl[9]).valueOf()+'/'+(hjl[5]+hjl[6]).valueOf();
  $scope.limiteconfirmacao.hora =  (hjl[11]+hjl[12]).valueOf()+':'+(hjl[14]+hjl[15]).valueOf();  
  
    $scope.evento.auxtag1 = '';
    $scope.evento.auxtag2 = '';
    $scope.evento.auxtag3 = '';
    $scope.evento.auxtagbutton1 = false;
    $scope.evento.auxtagbutton2 = false;
    $scope.evento.auxtagbutton3 = false;
    $scope.evento.auxtag4 = '';
    $scope.evento.auxtag5 = '';
    $scope.evento.auxtag6 = '';
    $scope.evento.auxtagbutton4 = false;
    $scope.evento.auxtagbutton5 = false;
    $scope.evento.auxtagbutton6 = false;
    $scope.evento.auxtag7 = '';
    $scope.evento.auxtag8 = '';
    $scope.evento.auxtag9 = '';
    $scope.evento.auxtagbutton7 = false;
    $scope.evento.auxtagbutton8 = false;
    $scope.evento.auxtagbutton9 = false;


    $scope.auxtags = {};
    EventoService.Gettags($scope.evento.idevento).then(function(tags) {
      var auxauxtagbut = true;
      $scope.auxtags = tags;
      for(var  i =0; i< tags.length;i++){
         if($scope.evento.auxtagbutton1 == false && auxauxtagbut){
            $scope.evento.auxtag1 = tags[i].tag;
            $scope.evento.auxtagbutton1 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton2 == false && auxauxtagbut){
            console.log($scope.evento.auxtagbutton2)
            $scope.evento.auxtag2 = tags[i].tag;
            $scope.evento.auxtagbutton2 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton3 == false && auxauxtagbut){
            $scope.evento.auxtag3 = tags[i].tag;
            $scope.evento.auxtagbutton3 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton4 == false && auxauxtagbut){
            $scope.evento.auxtag4 = tags[i].tag;
            $scope.evento.auxtagbutton4 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton5 == false && auxauxtagbut){
            $scope.evento.auxtag5 = tags[i].tag;
            $scope.evento.auxtagbutton5 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton6 == false && auxauxtagbut){
            $scope.evento.auxtag6 = tags[i].tag;
            $scope.evento.auxtagbutton6 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton7 == false && auxauxtagbut){
            $scope.evento.auxtag7 = tags[i].tag;
            $scope.evento.auxtagbutton7 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton8 == false && auxauxtagbut){
            $scope.evento.auxtag8 = tags[i].tag;
            $scope.evento.auxtagbutton8 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton9 == false && auxauxtagbut){
            $scope.evento.auxtag9 = tags[i].tag;
            $scope.evento.auxtagbutton9 = true;
            auxauxtagbut = false;
          }
          auxauxtagbut = true;
      } 
    });

    var auxauxtagbut = false;
    $scope.adicionatag = function(){
      if($scope.evento.addtag!=''){
        var res2 = $scope.evento.addtag.split(" ") ;
          if(res2.length>1){
            for(var w = 0; w < res2.length; w++){
              var t = res2[w].toLowerCase();
             console.log(t)
            }
            $scope.evento.addtag = res2[0];
          }
        if(!auxauxtagbut){
          auxauxtagbut = true;
          if($scope.evento.auxtagbutton1 == false && auxauxtagbut){
            $scope.evento.auxtag1 = '#' +$scope.evento.addtag;
            $scope.evento.auxtagbutton1 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton2 == false && auxauxtagbut){
            $scope.evento.auxtag2 = '#' +$scope.evento.addtag;
            $scope.evento.auxtagbutton2 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton3 == false && auxauxtagbut){
            $scope.evento.auxtag3 = '#' +$scope.evento.addtag;
            $scope.evento.auxtagbutton3 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton4 == false && auxauxtagbut){
            $scope.evento.auxtag4 = '#' +$scope.evento.addtag;
            $scope.evento.auxtagbutton4 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton5 == false && auxauxtagbut){
            $scope.evento.auxtag5 = '#' +$scope.evento.addtag;
            $scope.evento.auxtagbutton5 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton6 == false && auxauxtagbut){
            $scope.evento.auxtag6 = '#' +$scope.evento.addtag;
            $scope.evento.auxtagbutton6 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton7 == false && auxauxtagbut){
            $scope.evento.auxtag7 = '#' +$scope.evento.addtag;
            $scope.evento.auxtagbutton7 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton8 == false && auxauxtagbut){
            $scope.evento.auxtag8 = '#' +$scope.evento.addtag;
            $scope.evento.auxtagbutton8 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton9 == false && auxauxtagbut){
            $scope.evento.auxtag9 = '#' +$scope.evento.addtag;
            $scope.evento.auxtagbutton9 = true;
            auxauxtagbut = false;
          }
        }
      }
      $scope.evento.addtag = '';
    }

    $scope.tiratag1 = function(){
        $scope.evento.auxtagbutton1 = false;
        $scope.evento.auxtag1 = '';
    }
    $scope.tiratag2 = function(){
        $scope.evento.auxtagbutton2 = false;
        $scope.evento.auxtag2 = '';
    }
    $scope.tiratag3 = function(){
        $scope.evento.auxtagbutton3 = false;
        $scope.evento.auxtag3 = '';
    }
    $scope.tiratag4 = function(){
        $scope.evento.auxtagbutton4 = false;
        $scope.evento.auxtag4 = '';
    }
    $scope.tiratag5 = function(){
        $scope.evento.auxtagbutton5 = false;
        $scope.evento.auxtag5 = '';
    }
    $scope.tiratag6 = function(){
        $scope.evento.auxtagbutton6 = false;
        $scope.evento.auxtag6 = '';
    }
    $scope.tiratag7 = function(){
        $scope.evento.auxtagbutton7 = false;
        $scope.evento.auxtag7 = '';
    }
    $scope.tiratag8 = function(){
        $scope.evento.auxtagbutton8 = false;
        $scope.evento.auxtag8 = '';
    }
    $scope.tiratag9 = function(){
        $scope.evento.auxtagbutton9 = false;
        $scope.evento.auxtag9 = '';
    }

    $scope.mudaloc = function(){
      formEventoEdita.updateForm($scope.evento);
      $state.go('tabsController.EditaEventoPart2')
    }

    $scope.mudamais = function(){
      formEventoEdita.updateForm($scope.evento);
      $state.go('tabsController.EditaEventoPart3')
    }

    $scope.salvar = function(evento){
      if ($scope.evento.nomeevento == '') {
        var alertPopup = $ionicPopup.alert({
          title: 'ʕ•ᴥ•ʔ',
          template: 'Coloque um titulo válido'
        });
      }else{
        if($scope.evento.diafim <$scope.evento.diainicio){
          var alertPopup = $ionicPopup.alert({
            title: 'ʕ•ᴥ•ʔ',
            template: 'Data de termino eh antes do dia de inicio!! Assim não da'
          });
        }else{
         var existe = 0;
          var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/deletatag.php';
          $http.post(link, {idevento : $scope.evento.idevento}).then(function(items) {
            if($scope.evento.auxtagbutton1 == true){
              existe = 0;
              var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criartag.php';
              $http.post(link, {idevento : $scope.evento.idevento, 
                                      tag : $scope.evento.auxtag1});
            }
            if($scope.evento.auxtagbutton2 == true){
              existe = 0;
              var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criartag.php';
              $http.post(link, {idevento : $scope.evento.idevento, 
                                      tag : $scope.evento.auxtag2});
            }
            if($scope.evento.auxtagbutton3 == true){
              existe = 0;
              var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criartag.php';
              $http.post(link, {idevento : $scope.evento.idevento, 
                                      tag : $scope.evento.auxtag3});
            }
            if($scope.evento.auxtagbutton4 == true){
              existe = 0;
              var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criartag.php';
              $http.post(link, {idevento : $scope.evento.idevento, 
                                      tag : $scope.evento.auxtag4});
            }
            if($scope.evento.auxtagbutton5 == true){
              existe = 0;
              var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criartag.php';
              $http.post(link, {idevento : $scope.evento.idevento, 
                                      tag : $scope.evento.auxtag5});
            }
            if($scope.evento.auxtagbutton6 == true){
              existe = 0;
              var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criartag.php';
              $http.post(link, {idevento : $scope.evento.idevento, 
                                      tag : $scope.evento.auxtag6});
            }
            if($scope.evento.auxtagbutton7 == true){
              existe = 0;
              var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criartag.php';
              $http.post(link, {idevento : $scope.evento.idevento, 
                                      tag : $scope.evento.auxtag7});
            }
            if($scope.evento.auxtagbutton8 == true){
              existe = 0;
              var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criartag.php';
              $http.post(link, {idevento : $scope.evento.idevento, 
                                      tag : $scope.evento.auxtag8});
            }
            if($scope.evento.auxtagbutton9 == true){
              existe = 0;
              var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criartag.php';
              $http.post(link, {idevento : $scope.evento.idevento, 
                                      tag : $scope.evento.auxtag9});
            }
          });

          console.log($scope.imgURI)
          if($scope.imgURI != "img/ev.png"){ 
            $scope.auxfoto = $scope.evento.nomeevento + $scope.evento.diainicio;
            var mystring = String($scope.auxfoto);
            mystring = mystring.replace(/[^a-zA-Z0-9]/g, '');
            $scope.evento.eventopic = 'https://s3.amazonaws.com/diwoappprofilepics/eventopicsdiwo/' + mystring + '.jpg';
          }else{
             $scope.evento.eventopic = "img/ev.png";
          }
            if(mudoufoto == true){
              var url = "http://ec2-3-84-65-68.compute-1.amazonaws.com/uploadfotoevento.php";
                                      // File for Upload
              var targetPath = $scope.imgURI;
             
              // File name only
              //var name = $scope.imgURI.substr(imageData.lastIndexOf('/') + 1);
              var filename = mystring + '.jpg';
              // NO CASO SERIA O NOME DO USUARIO.jpg O fileName
              var options = {
                fileKey: "file",
                fileName: filename,
                chunkedMode: false,
                mimeType: "multipart/form-data"
              };
              $cordovaFileTransfer.upload(url, targetPath, options).then(function(result) {
               EventoService.atualizarevento($scope.evento).then(function(msg){
                $ionicLoading.hide();
        var alertPopup = $ionicPopup.alert({
                title: 'ʕ•ᴥ•ʔ',
                template: msg
              });
        alertPopup.then(function(){

          EventoService.GetParticipantes($scope.evento.idevento).then(function(items) {
            $scope.msgnoti = 'O evento: '+$scope.evento.nomeevento +' foi mudado'
            for (var i = 0; i < items.length; i++) {
              if ($scope.user.iduser != items[i].iduser) {
                noti.recebeusername = items[i].username;
                noti.recebe = items[i].iduser;
                noti.envia = $scope.user.iduser;
                noti.tipo = 4;
                noti.nomeevento = $scope.evento.nomeevento;
                EventoService.VerificaNotificacao(noti).then(function(res) {
                  console.log(res);
                  if(res){
                    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : $scope.msgnoti, 
                          idevento : $scope.evento.idevento,
                          nomeevento : $scope.evento.nomeevento,
                          id_user_envia : $scope.user.iduser,
                          username_envia : $scope.user.username,
                          apelido_envia : $scope.user.apelido,
                          tipo : '4',    //update no evento
                          id_user_recebe : noti.recebe}).then(function (res){
                         $scope.response = res.data;
                         console.log($scope.response.msg)
                    });
                    EventoService.getusuario2(noti.recebeusername).then(function(user) {
                      $scope.pushnoti.titulo =  'Mudanças!' ;
                      $scope.pushnoti.msg = $scope.msgnoti;
                      $scope.pushnoti.token = user.devicetoken;
                      EventoService.MandaPushNoti($scope.pushnoti);
                    });
                  }
                });
              }
            }
          })
          formEventoAbertosTab.updateForm($scope.evento);
          $state.go('tabsController.evento_do_eventoAbertos');
        })
        }, function(errMsg) {
          var alertPopup = $ionicPopup.alert({
            title: 'Register failed!',
            template: errMsg
          });
        })
              }, function(err) {
                $ionicPopup.alert({
                  title: 'Sorry!',
                  template: 'Aconteceu um probleminha, tente de novo'
                });
                $ionicLoading.hide();
              }, function (progress) {
                $ionicLoading.show({
                  title: '┗(＾0＾)┓',
                  template: '┗(＾0＾)┓'
                });
              });
            }

       
                
      }
     }
      
    }
  

}])

   
.controller('filtroCtrl', ['$scope', '$stateParams', 'formUser', 'EventoService', '$timeout', '$http','$filter','formItem', '$state','formOutro', '$cordovaGeolocation', 'formvimdofiltro','formvimdofiltroperfil',  // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, formUser, EventoService, $timeout, $http,$filter, formItem, $state,formOutro, $cordovaGeolocation, formvimdofiltro, formvimdofiltroperfil) {
  $scope.user = formUser.getForm();
  $scope.pegaevento ={};
  $scope.auxevento = {};
  $scope.tuto = {};
  $scope.viewtitle = "Procura / Filtra";
  $scope.filtro ={ genero:"todos", precof: "ambos",  raio: 1220, preco : -1, raiokm: "50", tipo : "tag", dificuldade : "Qual a dificuldade do evento?", dificuldaden : 1};
    
    var header = document.getElementById("barfiltro");
    var btns = header.getElementsByClassName("btnfiltro");
    for (var i = 0; i < btns.length; i++) {
      btns[i].addEventListener("click", function() {
        var current = document.getElementsByClassName("actfil");
        current[0].className = current[0].className.replace(" actfil", "");
        this.className += " actfil";
      });
    }

    var header2 = document.getElementById("rqrq");
    var btns2 = header2.getElementsByClassName("btnsearch");
    console.log(btns2.length)
    for (var f = 0; f < btns2.length; f++) {
      btns2[f].addEventListener("click", function() {
        var current2 = document.getElementsByClassName("actitro");
        current2[0].className = current2[0].className.replace(" actitro", "");
        this.className += " actitro";
      });
    }

    $scope.CoisasDoSearch = false;
    $scope.CoisasDoFiltro = false;
    $scope.BotaoDoFiltro = false;
    $scope.TipoDoFiltro = true;
    $scope.CoisasDoFiltroRaio = false;
    $scope.CoisasDoSearchPessoa = false;
    $scope.CoisasDoSearchLugar = false;
    $scope.Raiobusca = false;
    $scope.CoisasPreco = false;
    $scope.listlength = 20;
    $scope.filtra ={};
    $scope.eventos = {};

  var aux = 0;
  var aux2 = 0;
  var aux3 = 0;

  var lat  = $scope.user.lat;
  var long  =  $scope.user.long;

  $scope.filtro.northlat = $scope.user.northlat;
  $scope.filtro.westlng = $scope.user.westlng;
  $scope.filtro.southlat = $scope.user.southlat;
  $scope.filtro.eastlng = $scope.user.eastlng;

  $scope.$on("$ionicView.enter", function(event, data){
    $scope.viewtitle = "Procura / Filtra";
    var das = document.getElementById("hash");
    var current = document.getElementsByClassName("actitro");
    current[0].className = current[0].className.replace(" actitro", "");
    das.className += " actitro";

    $scope.filtro ={ genero:"todos", precof: "ambos",precovalor: 0, precovalorescrito:"Grátis",   raio: 1220, preco : -1, raiokm: "50", tipo : "tag", dificuldade : "Qual a dificuldade do evento?", dificuldaden : 1};
    
    $scope.user = formUser.getForm();
    $scope.filtro.northlat = $scope.user.northlat;
    $scope.filtro.westlng = $scope.user.westlng;
    $scope.filtro.southlat = $scope.user.southlat;
    $scope.filtro.eastlng = $scope.user.eastlng;
    

  });

  $scope.buscaaa = function(){
    $scope.viewtitle = "Procura";
    $scope.precoevento = false;
    $scope.CoisasDoSearch = false;
    $scope.CoisasDoFiltro = false;
    $scope.BotaoDoFiltro = false;
    $scope.TipoDoFiltro = true;
    $scope.CoisasDoFiltroRaio = false;
    $scope.CoisasDoSearchPessoa = false;
    $scope.CoisasDoSearchLugar = false;
    $scope.CoisasPreco = false;
    $scope.eventos = {};
    $scope.filtro ={ genero:"todos", precof: "ambos",precovalor: 0, precovalorescrito:"Grátis",  raio: 1220, preco : -1, raiokm: "50", tipo : "tag", dificuldade : "Qual a dificuldade do evento?", dificuldaden : 1};
  }
  $scope.filtraaa = function(){
    $scope.viewtitle = "Filtra";
    $scope.Raiobusca = false;
    $scope.CoisasDoSearch = false;
    $scope.CoisasDoFiltro = true;
    $scope.BotaoDoFiltro = true;
    $scope.CoisasPreco = true;
    $scope.TipoDoFiltro = false;
    $scope.CoisasDoFiltroRaio = true;
    $scope.CoisasDoSearchPessoa = false;
    $scope.CoisasDoSearchLugar = false;
    $scope.CoisasFiltradas = false;
    $scope.precoevento = false;

    $scope.filtro ={ genero:"todos", precof: "ambos",precovalor: 0, precovalorescrito:"Grátis",   raio: 50, preco : -1, raiokm: "50", tipo : "tag", dificuldade : "Qual a dificuldade do evento?", dificuldaden : 1};
    $scope.filtro.northlat = $scope.user.northlat;
    $scope.filtro.westlng = $scope.user.westlng;
    $scope.filtro.southlat = $scope.user.southlat;
    $scope.filtro.eastlng = $scope.user.eastlng;
    EventoService.filtro($scope.user).then(function(filt){
      $scope.tuto = filt;
      $scope.eventos = filt;
    });
  }

  $scope.ch = function(){
    if($scope.filtro.dificuldaden == 1){
      $scope.filtro.dificuldade = "Não importa";
      if(aux2>0){
        $scope.tuto.tamanho = aux2;
        $scope.tuto.filtro = $scope.filtro;
        $scope.tuto.filtro.lat = $scope.user.lat;
        $scope.tuto.filtro.long = $scope.user.long;
        EventoService.Filtradinamicamente21($scope.tuto).then(function(destilado){
          $scope.eventos = destilado;
        });
      }
    }
    if($scope.filtro.dificuldaden == 2){
      $scope.eventos = {};
      $scope.filtro.dificuldade = "Fácil";
      if(aux2>0){
        $scope.tuto.tamanho = aux2;
        $scope.tuto.filtro = $scope.filtro;
        $scope.tuto.filtro.lat = $scope.user.lat;
        $scope.tuto.filtro.long = $scope.user.long;
        EventoService.Filtradinamicamente21($scope.tuto).then(function(destilado){
          $scope.eventos = destilado;
        });
      }
    }
    if($scope.filtro.dificuldaden == 3){
      $scope.eventos = {};
      $scope.filtro.dificuldade = "Moderado";
      if(aux2>0){
        $scope.tuto.tamanho = aux2;
        $scope.tuto.filtro = $scope.filtro;
        $scope.tuto.filtro.lat = $scope.user.lat;
        $scope.tuto.filtro.long = $scope.user.long;
        EventoService.Filtradinamicamente21($scope.tuto).then(function(destilado){
          $scope.eventos = destilado;
        });
      }
    }
    if($scope.filtro.dificuldaden == 4){
      $scope.eventos = {};
      $scope.filtro.dificuldade = "Difícil";
      if(aux2>0){
        $scope.tuto.tamanho = aux2;
        $scope.tuto.filtro = $scope.filtro;
        $scope.tuto.filtro.lat = $scope.user.lat;
        $scope.tuto.filtro.long = $scope.user.long;
        EventoService.Filtradinamicamente21($scope.tuto).then(function(destilado){
          $scope.eventos = destilado;
        });
      }
    }
  }

  $scope.pushNotification = { checked: false};
  
  $scope.sexo = function(){
    if($scope.pushNotification.checked){
      $scope.filtro.genero = $scope.user.genero;
      if(aux2>0){
        $scope.tuto.tamanho = aux2;
        $scope.tuto.filtro = $scope.filtro;
        $scope.tuto.filtro.lat = $scope.user.lat;
        $scope.tuto.filtro.long = $scope.user.long;
        $scope.eventos = {};
        EventoService.Filtradinamicamente21($scope.tuto).then(function(destilado){
          $scope.eventos = destilado;
          //console.log("danodmsa", $scope.eventos.length)
        });
      }
    }else{
      $scope.filtro.genero = "todos";
        if(aux2>0){
        $scope.tuto.tamanho = aux2;
        console.log($scope.tuto.tamanho, "tamanho")
        $scope.tuto.filtro = $scope.filtro;
        $scope.tuto.filtro.lat = $scope.user.lat;
        $scope.tuto.filtro.long = $scope.user.long;
        $scope.eventos = {};
        EventoService.Filtradinamicamente21($scope.tuto).then(function(destilado){
          $scope.eventos = destilado;
          //console.log("danodmsa", $scope.eventos.length)
        });
      }
    }
  }

  $scope.buscafiltropreco = { checked: false };
  $scope.precoevento = false;

  $scope.precodabusca = function(){
    if(!$scope.BotaoDoFiltro){
      if($scope.buscafiltropreco.checked){
        $scope.precoevento = true;
        $scope.filtro.precof = "gratis";
        $scope.filtro.precovalor = 0;
        $scope.filtro.precovalorescrito = "Grátis";
        $scope.tuto.tamanho = aux2;
        $scope.tuto.filtro = $scope.filtro;
        $scope.tuto.filtro.lat = $scope.user.lat;
        $scope.tuto.filtro.long = $scope.user.long;
        console.log($scope.tuto)
        EventoService.Filtradinamicamente21($scope.tuto).then(function(destilado){
          $scope.CoisasFiltradas = true;
          $scope.eventos = destilado;
          
        });
      }else{
        $scope.precoevento = false;
        $scope.filtro.precof = "ambos";
        $scope.filtro.precovalor = 0;
        $scope.filtro.precovalorescrito = "Grátis";
        $scope.tuto.tamanho = aux2;
        $scope.tuto.filtro = $scope.filtro;
        $scope.tuto.filtro.lat = $scope.user.lat;
        $scope.tuto.filtro.long = $scope.user.long;
        EventoService.Filtradinamicamente21($scope.tuto).then(function(destilado){
          $scope.eventos = destilado;
          $scope.CoisasFiltradas = true;
        });
      }
    }else{
      if($scope.buscafiltropreco.checked){
        $scope.precoevento = true;
        $scope.filtro.precof = "gratis";
        $scope.filtro.preco = 0;
        $scope.filtro.precovalor = 0;
        $scope.filtro.precovalorescrito = "Grátis";
        $scope.tuto.tamanho = aux2;
        $scope.tuto.filtro = $scope.filtro;
        $scope.tuto.filtro.lat = $scope.user.lat;
        $scope.tuto.filtro.long = $scope.user.long;
      }else{
        $scope.precoevento = false;
        $scope.filtro.precof = "ambos";
        $scope.filtro.preco = -1;
        $scope.filtro.precovalor = 0;
      }
      
    }
  }

  $scope.mudapreco = function(valor){
    if(!$scope.BotaoDoFiltro){
      if(valor == 0){
        $scope.filtro.precof = "gratis";
        $scope.filtro.precovalor = 0;
        $scope.filtro.precovalorescrito = "Grátis";
        $scope.tuto.tamanho = aux2;
        $scope.tuto.filtro = $scope.filtro;
        $scope.tuto.filtro.lat = $scope.user.lat;
        $scope.tuto.filtro.long = $scope.user.long;
        EventoService.Filtradinamicamente21($scope.tuto).then(function(destilado){
          $scope.eventos = destilado;

        });
      }else{
        $scope.filtro.precof = "pago";
        $scope.filtro.precovalor = valor;
        $scope.filtro.precovalorescrito = valor + " dinheiros";
        $scope.tuto.tamanho = aux2;
        $scope.tuto.filtro = $scope.filtro;
        $scope.tuto.filtro.lat = $scope.user.lat;
        $scope.tuto.filtro.long = $scope.user.long;
        EventoService.Filtradinamicamente21($scope.tuto).then(function(destilado){
          $scope.eventos = destilado;
        });
      }
    }else{
      if(valor == 0){
        $scope.filtro. precof = "gratis";
        $scope.filtro.precovalor = 0;
        $scope.filtro.precovalorescrito = "Grátis";
      }else{
        $scope.filtro. precof = "pago";
        $scope.filtro.precovalor = valor;
        $scope.filtro.precovalorescrito = valor + " dinheiros";
      }
    }
  }

  $scope.buscafiltro = { checked: false };
  $scope.raiodabusca = function(){
    console.log("raiodabusca", $scope.user.lat, $scope.user.long)
    if($scope.buscafiltro.checked){
      $scope.CoisasDoFiltroRaio = true;
      $scope.filtro.raio = 120;
      $scope.filtro.raiokm = '120';
      $scope.tuto.tamanho = aux2;
      $scope.tuto.filtro = $scope.filtro;
      console.log($scope.user.lat, $scope.user.long)
      $scope.tuto.filtro.lat = $scope.user.lat;
      $scope.tuto.filtro.long = $scope.user.long;
      EventoService.Filtradinamicamente21($scope.tuto).then(function(destilado){
        $scope.eventos = destilado;
      });
    }else{
      $scope.CoisasDoFiltroRaio = false;
      $scope.tuto.tamanho = aux2;
      $scope.tuto.filtro = $scope.filtro;
      $scope.tuto.filtro.lat = $scope.user.lat;
      $scope.tuto.filtro.long = $scope.user.long;
      $scope.filtro.raio = 1220;
      $scope.eventos = {};
      EventoService.Filtradinamicamente21($scope.tuto).then(function(destilado){
        $scope.eventos = destilado;
      });
    }
  }
  
  EventoService.Getalltags().then(function (oi){
    $scope.items = oi;
  });

  $scope.mudafiltro1 = function() {
    $scope.filtro.tipo = "tag";
    $scope.eventos = {};
    $scope.auxevento = {};
    //console.log($scope.filtro.search);
    EventoService.Getalltags().then(function (oi){
      $scope.listlength = oi.length
      $scope.items = oi;
    });
    $scope.CoisasDoSearch = true;
    $scope.CoisasDoSearchPessoa = false;
    $scope.CoisasDoSearchLugar = false;
    $scope.CoisasDoFiltroRaio = false;
    $scope.CoisasDoFiltro = false;
    $scope.BotaoDoFiltro = false;
    $scope.Raiobusca = false;
    $scope.CoisasPreco = false;
    $scope.precoevento = false;
  }

  $scope.mudafiltro2 = function() {
    $scope.filtro.tipo = "pessoa";
    $scope.eventos = {};
    $scope.auxevento = {};
    //console.log($scope.filtro.search);
    EventoService.Getusers().then(function (ola){
      $scope.listlength = ola.length
      $scope.pessoas = ola;
    });
    $scope.CoisasDoSearchPessoa = true;
    $scope.CoisasDoSearch = false;
    $scope.CoisasDoSearchLugar = false;
    $scope.CoisasDoFiltroRaio = false;
    $scope.CoisasDoFiltro = false;
    $scope.BotaoDoFiltro = false;
    $scope.Raiobusca = false;
    $scope.CoisasPreco = false;
    $scope.precoevento = false;
  }

  $scope.mudafiltro3 = function() {
    $scope.filtro.tipo = "lugar";
    $scope.eventos = {};
    $scope.auxevento = {};
    //console.log($scope.filtro.search);
    EventoService.Getcidades().then(function (salut){
      $scope.listlength = salut.length
      $scope.places = salut;
    });
    $scope.CoisasDoSearchPessoa = false;
    $scope.CoisasDoSearch = false;
    $scope.CoisasDoSearchLugar = true;
    $scope.CoisasDoFiltroRaio = false;
    $scope.CoisasDoFiltro = false;
    $scope.BotaoDoFiltro = false;
    $scope.Raiobusca = false;
    $scope.CoisasPreco = false;
    $scope.precoevento = false;
  }

  $scope.abrir = function(item){
    $scope.CoisasFiltradas = true;
    $scope.CoisasDoFiltro = true;
    $scope.BotaoDoFiltro = false;
    $scope.CoisasDoSearch = false;
    $scope.CoisasDoSearchPessoa = false;
    $scope.CoisasDoSearchLugar = false;
    $scope.CoisasDoFiltroRaio = false;
    
    
    if ($scope.filtro.tipo == "tag") {
      $scope.Raiobusca = true;
      $scope.CoisasPreco = true;
      $scope.auxevento = {};
      item.iduser = $scope.user.iduser;
      EventoService.Getfiltradotag(item).then(function (filtrado){
        $scope.eventos = {};
        aux2 = 0;
        $scope.pegaevento.iduser = $scope.user.iduser;
        for (var i = 0; i < filtrado.length ; i++) {
          $scope.pegaevento.idevento = filtrado[i].idevento;
          //console.log($scope.pegaevento.idevento , $scope.pegaevento.iduser)
            EventoService.Getfiltradotag2($scope.pegaevento).then(function (bye){
              if (bye !='e') { 
                $scope.eventos[aux2] = bye;
                $scope.tuto[aux2] = $scope.eventos[aux2];
                aux2++;
              }
            });
        }
      });
    }
    if ($scope.filtro.tipo == "pessoa"){
      $scope.Raiobusca = false;
      $scope.CoisasPreco = false;
      $scope.CoisasDoFiltroRaio = false;
      $scope.CoisasDoFiltro = false;
      $scope.BotaoDoFiltro = false;
      $scope.precoevento = false;
      formOutro.updateForm(item);
      formvimdofiltroperfil.updateForm(true);
      $state.go('tabsController.perfilOutro');
    }
    if ($scope.filtro.tipo == "lugar") {
      $scope.CoisasDoFiltroRaio = false;
      $scope.Raiobusca = false;
      $scope.CoisasPreco = true;
      //console.log(item.cidade);
      EventoService.Getfiltradocidade(item.cidade).then(function (filtrado){
        aux = filtrado.nrow;
        $scope.listlength = filtrado.nrow;
        $scope.eventos = {};
        aux2 = 0;
        $scope.pegaevento.iduser = $scope.user.iduser;
          for (var i = 0; i < filtrado.nrow ; i++) {
            $scope.pegaevento.idevento = filtrado[i].idevento;
            EventoService.Geteventoporid($scope.pegaevento).then(function (bye){
              if (bye !='e') { 
                $scope.eventos[aux2] = bye;
                $scope.tuto[aux2] = $scope.eventos[aux2];
                aux2++;
              }
            });
          }
      });
    }
  }

  $scope.onde = function(){
    if($scope.TipoDoFiltro){
      $scope.filtro.raiokm = $scope.filtro.raio;
      $scope.tuto.filtro.lat = $scope.user.lat;
      $scope.tuto.filtro.long = $scope.user.long;
      if(aux2>0){
        $scope.tuto.tamanho = aux2;
        $scope.tuto.filtro = $scope.filtro;
        $scope.BotaoDoFiltro = false;
        $scope.eventos = {};
        EventoService.Filtradinamicamente21($scope.tuto).then(function(destilado){
          $scope.eventos = destilado;
        });
      }
    }else{
      $scope.filtro.raiokm = $scope.filtro.raio;

      var raio = $scope.filtro.raio*1000*0.71;
      var myLatlng = new google.maps.LatLng($scope.user.lat, $scope.user.long);
      var spherical = google.maps.geometry.spherical; 
      var north = spherical.computeOffset(myLatlng, raio, 0); 
      var west  = spherical.computeOffset(myLatlng, raio, -90); 
      var south = spherical.computeOffset(myLatlng, raio, 180); 
      var east  = spherical.computeOffset(myLatlng, raio, 90); 
      $scope.filtro.northlat = north.lat();
      $scope.filtro.westlng = west.lng();
      $scope.filtro.southlat = south.lat();
      $scope.filtro.eastlng = east.lng();
    }
  }

  $scope.procurar =  function(){
    if ($scope.filtro.tipo == "tag") {
      $scope.CoisasDoSearch = true;
      $scope.CoisasDoSearchPessoa = false;
      $scope.CoisasDoSearchLugar = false;
   
    }
    if ($scope.filtro.tipo == "pessoa") {
      $scope.CoisasDoSearchPessoa = true;
      $scope.CoisasDoSearch = false;
      $scope.CoisasDoSearchLugar = false;
      
    }
    if ($scope.filtro.tipo == "lugar") {
      $scope.CoisasDoSearchPessoa = false;
      $scope.CoisasDoSearch = false;
      $scope.CoisasDoSearchLugar = true;
    }
    //console.log($scope.tipo);
    $scope.listlength = 20;
    $scope.CoisasDoFiltro = false;
    $scope.BotaoDoFiltro = false;
    $scope.CoisasFiltradas = false;
    $scope.CoisasDoFiltroRaio = false;
    $scope.CoisasPreco = false;
    $scope.precoevento = false;
  }

  $scope.cancelar =  function(){
    $scope.CoisasFiltradas = false;
    $scope.filtro ={ genero:"todos", precof: "ambos", raio: 1220, raiokm: "50", tipo : "tag", dificuldade : "Qual a dificuldade do evento?"};
    $scope.CoisasDoSearch = false;
    $scope.CoisasDoSearchPessoa = false;
    $scope.CoisasDoSearchLugar = false;
    $scope.TipoDoFiltro = true;
    $scope.precoevento = false;
    $scope.CoisasDoFiltro = false;
    $scope.BotaoDoFiltro = false;
    $scope.CoisasDoFiltroRaio = false;
    $scope.Raiobusca = false;
    $scope.CoisasPreco = false;
    $scope.pushNotification.checked=false;
    $scope.buscafiltropreco.checked=false;
    $scope.buscafiltro.checked=false;
  }

  $scope.limpar =  function(){
    $scope.CoisasDoSearch = false;
    $scope.CoisasDoFiltro = true;
    $scope.BotaoDoFiltro = true;
    $scope.TipoDoFiltro = false;
    $scope.CoisasDoFiltroRaio = true;
    $scope.CoisasDoSearchPessoa = false;
    $scope.CoisasDoSearchLugar = false;
    $scope.CoisasFiltradas = false;
    $scope.Raiobusca = false;
    $scope.CoisasPreco = true;
    $scope.pushNotification.checked=false;
    $scope.buscafiltropreco.checked=false;
    $scope.filtro ={ genero:"todos", precof: "ambos",preco : -1,  raio: 50, raiokm: "50", tipo : "tag", dificuldade : "Qual a dificuldade do evento?", dificuldaden : 1};
    $scope.filtro.northlat = $scope.user.northlat;
    $scope.filtro.westlng = $scope.user.westlng;
    $scope.filtro.southlat = $scope.user.southlat;
    $scope.filtro.eastlng = $scope.user.eastlng;
  }

  $scope.filtra =  function(){
    if ($scope.filtro.dificuldade == "Qual a dificuldade do evento?") {$scope.filtro.dificuldade = "Não importa";}

      $scope.eventos = {};
      EventoService.Geteventofiltrado($scope.filtro).then(function (destilado){
        $scope.eventos = destilado;
        console.log(destilado);
      });
   
    $scope.CoisasFiltradas = true;
    $scope.CoisasDoFiltro = false;
    $scope.BotaoDoFiltro = false;
    $scope.CoisasDoFiltroRaio = false;
    $scope.CoisasDoSearch = false;
    $scope.CoisasDoSearchPessoa = false;
    $scope.CoisasDoSearchLugar = false;
    $scope.TipoDoFiltro = false;
    $scope.CoisasPreco = false;
    $scope.precoevento = false;
  }

  $scope.enterItem = function(eventos){
    console.log(eventos, $scope.eventos[eventos].idevento);
    formItem.updateForm($scope.eventos[eventos]);
    
    if($scope.eventos[eventos].estado == 0 || $scope.eventos[eventos].estado == 2){
      $state.go('tabsController.eventoAberto');
      formvimdofiltro.updateForm(true);
    }else{
      $state.go('tabsController.eventofiltroEncerrado');
    }
    
  }

}])
   
.controller('chatCtrl', ['$scope', '$stateParams', '$timeout', '$ionicScrollDelegate', 'formUser', '$http', 'formItem', '$interval', 'EventoService', 'formEventoAbertosTab', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $timeout, $ionicScrollDelegate, formUser, $http, formItem, $interval, EventoService, formEventoAbertosTab) {
  $scope.user = formUser.getForm();
  $scope.evento = formEventoAbertosTab.getForm();
  $scope.data = {};
  $scope.messages = [];
  // $scope.hideTime = true;
  //console.log( $scope.user.username);
  var isIOS = ionic.Platform.isWebView() && ionic.Platform.isIOS();


  $scope.$on("$ionicView.enter", function(event, data){
    $scope.evento = formEventoAbertosTab.getForm();
    $scope.user = formUser.getForm();
    $scope.data = {};
    $scope.messages = {};
    $scope.messages = [];
    //alert($scope.evento.idevento)
     EventoService.Getmsg($scope.evento.idevento).then(function(result) {
        $scope.messages = result;
      });
  });

   $interval( function() {
          //   $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/getmsg.php' , {idevento : $scope.evento.idevento}).then(function(result) {
          // // console.log(result.data[0].idevento);
          // //   console.log("estou aqui");
          // if (result.data.success != false) {
          //     $scope.messages = result.data;
          // }
          // });
      EventoService.Getmsg($scope.evento.idevento).then(function(result) {
        $scope.messages = result;
      });

    }, 5000);

  // $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/getmsg.php' , {idevento : $scope.evento.idevento}).then(function(result) {
  //         if (result.data.success != false ) {
  //             $scope.messages = result.data;
  //         }
          
  //         });

   EventoService.Getmsg($scope.evento.idevento).then(function(result) {
        $scope.messages = result;
      });


   $scope.auxev = {};
  $scope.auxev.iduser = $scope.user.iduser;
  $scope.auxev.idevento = $scope.evento.idevento;
  EventoService.GetNotiOn($scope.auxev).then(function(notion) {
    $scope.notion = notion;
  });
  $scope.ativanoti = function(){
    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/mudanotievento.php', {idevento : $scope.auxev.idevento, iduser : $scope.auxev.iduser, chatnotion : 0});
    $scope.notion = true;
  }
  $scope.desativanoti = function(){
    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/mudanotievento.php', {idevento : $scope.auxev.idevento, iduser : $scope.auxev.iduser, chatnotion : 1});
    $scope.notion = false;
  }

  $scope.sendMessage = function() {
    var d = new Date();
    console.log(d);
    d = d.toLocaleTimeString().replace(/:\d+ /, ' ');
    var data = new Date();
    var dataFormatada = ("0" + data.getDate()).substr(-2) + "/" 
        + ("0" + (data.getMonth() + 1)).substr(-2) + "/" + data.getFullYear();

     // var dataFormatada2 =  (data.getFullYear() + "-" + ("0" + (data.getMonth() + 1)).substr(-2) + "-" + ("0" + data.getDate()).substr(-2) );


        dataFormatada = (d + ' '+dataFormatada);
        console.log(dataFormatada);

    if(!$scope.data.message){
      console.log(  "mensagem "+$scope.data.message);
     }else{
      console.log($scope.data.message,  $scope.messages,  $scope.messages[0]);
    
      if($scope.messages[0]){
        $scope.messages.push({
          username: $scope.user.username,
          mensagem: $scope.data.message,
          tempo: dataFormatada,
          idevento : $scope.evento.idevento, 
          iduser : $scope.user.iduser, 
          apelido : $scope.user.apelido
        });
      }else{
        $scope.messages[0] = {
          username: $scope.user.username,
          mensagem: $scope.data.message,
          tempo: dataFormatada,
          idevento : $scope.evento.idevento, 
          iduser : $scope.user.iduser, 
          apelido : $scope.user.apelido
        };
      }
      if($scope.data.message != '' || $scope.data.message){
         var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criarmsg.php';
                      $http.post(link, {idevento : $scope.evento.idevento, 
                                        mensagem :  $scope.data.message,
                                        iduser : $scope.user.iduser, 
                                        username : $scope.user.username,
                                        apelido : $scope.user.apelido,
                                        tempo : dataFormatada}).then(function (res){
                    $scope.response = res.data;
                    console.log($scope.response.msg);
                  });
          EventoService.GetParticipantesNotifica($scope.evento.idevento).then(function(parti) {
          $scope.nomeevento = parti[0].nomeevento;
          for (var i = 0; i < parti.length; i++) {
            if (parti[i].estado!=7 && parti[i].estado!=8 && parti[i].iduser != $scope.user.iduser) {
              $scope.pushnoti.titulo = "Nova mensagem";
              $scope.pushnoti.msg = 'Chat do '+$scope.evento.nomeevento + ' tem mensagem nova' ;
              $scope.pushnoti.token = parti[i].devicetoken;
              EventoService.MandaPushNoti($scope.pushnoti);
            }          
          }      
        });
      }
      delete $scope.data.message;
      $ionicScrollDelegate.scrollBottom(true);
     }
  };


  $scope.inputUp = function() {
    if (isIOS) $scope.data.keyboardHeight = 216;
    $timeout(function() {
      $ionicScrollDelegate.scrollBottom(true);
    }, 300);

  };

  $scope.inputDown = function() {
    if (isIOS) $scope.data.keyboardHeight = 0;
    $ionicScrollDelegate.resize();
  };

  $scope.closeKeyboard = function() {
    // cordova.plugins.Keyboard.close();
  };

}])

.controller('perfilAceitarGeralCtrl', ['$scope', '$state', '$stateParams', 'formAux', 'formUser', 'EventoService', '$timeout', '$http','$ionicPopup', 'formStalker', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $state, $stateParams, formAux, formUser, EventoService, $timeout, $http, $ionicPopup, formStalker) {

    $scope.aux = formAux.getAux();      // Infos da notificação
    // console.log($scope.aux.id_user_recebe);
    // console.log($scope.aux.id_user_envia);
    // console.log($scope.aux.idnotificacao);
    $scope.user = formUser.getForm();
    //console.log($scope.aux);
    $scope.auxdata = {};
    $scope.estadobutton = 0;
    $scope.stalkeada = {}; 
    $scope.stalkeada.iduser = $scope.aux.id_user_envia;
    $scope.stalkeada.username = $scope.aux.username_envia;
    $scope.neventos= 0;
    $scope.neventosnao= 0;
    $scope.p =0;
    $scope.ic = 0;
    $scope.infoevento ={};
    $scope.CoisasCriado = true;
    $scope.CoisasFinalizado = false;
    $scope.pushnoti = {};
    var noti={};
    $scope.infosstalkeada ={};
    EventoService.GetStalkear($scope.aux.id_user_envia).then(function(stalker) {
        $scope.infosstalkeada = stalker;
        if($scope.infosstalkeada.profilepic[8] == 's' && $scope.infosstalkeada.profilepic[9] == '3'){
             document.getElementById("imageidperfilAceitarGeral").src=$scope.infosstalkeada.profilepic+"?{{getTimeStamp()}}";
           }else{
             document.getElementById("imageidperfilAceitarGeral").src=$scope.infosstalkeada.profilepic;
           }
       // document.getElementById("imageidperfilAceitarGeral").src=$scope.infosstalkeada.profilepic+"?{{getTimeStamp()}}";
        $scope.frase = stalker.frase;
         if(stalker.borda == 0){
          $scope.estrelabb = false;
          $scope.estrelabs = false;
          $scope.estrelabg = false;
        }
        if(stalker.borda == 1){
          $scope.estrelabb = true;
          $scope.estrelabs = false;
          $scope.estrelabg = false;
        }
        if(stalker.borda == 2){
          $scope.estrelabb = false;
          $scope.estrelabs = true;
          $scope.estrelabg = false;
        }
        if(stalker.borda == 3){
          $scope.estrelabb = false;
          $scope.estrelabs = false;
          $scope.estrelabg = true;
        }
        if($scope.infosstalkeada.idade){
          $scope.infosstalkeada.idade = ", "+ $scope.infosstalkeada.idade +" anos";
        }else{
           $scope.infosstalkeada.idade ='';
        }
    });
    
    var header = document.getElementById("barperfiloutroev");
    var btns = header.getElementsByClassName("btnperfilotro");
    for (var i = 0; i < btns.length; i++) {
      btns[i].addEventListener("click", function() {
        var current = document.getElementsByClassName("actpag");
        current[0].className = current[0].className.replace(" actpag", "");
        this.className += " actpag";
      });
    }

    EventoService.GetPontos($scope.stalkeada.iduser).then(function(items) {
        $scope.p = items;
        $scope.labels3 = ["Pontos"];
        $scope.colores3 = ["#ff4d4d"];
        $scope.data3 = [$scope.p];
      });
      EventoService.getIC($scope.stalkeada).then(function(items) {
        if(items){
          $scope.ic = items;
          $scope.options2 = {title: {
                      display: true,
                      text: 'Indice de confirmação',
                      position: 'bottom'
                  }
           }
          $scope.labels2 = ["Fui", "Não fui"];
          $scope.colores2 = ["#99FF99","#ff4d4d"];
          var menos = (100-$scope.ic.total).toFixed(1);
          var mais = $scope.ic.total;
          $scope.data2 = [mais, menos ];
        }
      });
      console.log('antes', $scope.stalkeada.iduser)
      EventoService.GetComments3($scope.stalkeada).then(function(items) {
        
          $scope.options1 = {title: {
                    display: true,
                    text: 'Avaliações',
                    position: 'bottom'
                }
         }
           $scope.labels1 = ["Extrovertido", "Introvertido", "Realista","Curioso", "Solidário", "Racional","Organizado", "Criativo"];
          $scope.colores1 = ["#fff200", "#02fff2", "#ff9d00","#1867ce", "#e50be1", "#0e8c28","#ef370e", "#af0eef"];
          $scope.data1 =items.chart;
        
      }); 


    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/geteventoporid.php', {idevento :  $scope.aux.idevento}).then(function (result){
      $scope.infoevento = result.data[0];
    });

    $scope.comentario = function(){
      formStalker.updateForm($scope.stalkeada);
      $state.go('comentariosperfilaceitargeral');
    }
    
    $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/getpessoaevento.php", {iduser : $scope.outro,
                                                                    estado : '3'}).then(function(response) {
      pontos = response.data[0];
      if (pontos=='E') {
        $scope.neventos = parseFloat(0);
      }else{
         $scope.neventos =parseFloat(pontos.length);
      }
      for(var i=0;i<pontos.length;i++){
        $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/geteventopessoaevento.php", {idevento : pontos[i].idevento,
                                                                              estado : '3'}).then(function(response) {
          var novo = response.data[0];
          for(var j=0 ;j<response.data[0].length;j++){
            if (novo[j].iduser == $scope.user.iduser && !$scope.desseguirbutton && $scope.outro != $scope.user.iduser) {
              $scope.followbutton = true;
              //console.log('fui no evento com este cara e nao sigo', $scope.outro , $scope.user.iduser);
            }
          }
        });
      }
    });   

    if(parseInt($scope.infoevento.patual)>=parseInt($scope.infoevento.pmax)){
      var alertPopup = $ionicPopup.alert({
                      title: ' ٩( ᐛ )و ',
                      template: 'Evento é um sucesso, mas o numero máximo de pessoas foi atingido. Como o evento é seu, tu pode confirmar essa pessoa mesmo assim'
                    });
    }                                                                

    $scope.$on("$ionicView.enter", function(event, data){
      $scope.items = [];
      $scope.vezes = 0;
      $scope.newItems = [];
      $scope.noMoreItemsAvailable = false;
      $scope.lastidevento = 0;
      $scope.aux2 = 0;
      $scope.aux = formAux.getAux();
      $scope.user = formUser.getForm();
      $scope.stalkeada = {}; 
      $scope.stalkeada.iduser = $scope.aux.id_user_envia;
      $scope.stalkeada.username = $scope.aux.username_envia;
      $scope.CoisasCriado = true;
      $scope.CoisasFinalizado = false;
      $scope.pushnoti = {};
      $scope.infosstalkeada ={};
      EventoService.GetStalkear($scope.aux.id_user_envia).then(function(stalker) {
          $scope.infosstalkeada = stalker;
           if($scope.infosstalkeada.profilepic[8] == 's' && $scope.infosstalkeada.profilepic[9] == '3'){
             document.getElementById("imageidperfilAceitarGeral").src=$scope.infosstalkeada.profilepic+"?{{getTimeStamp()}}";
           }else{
             document.getElementById("imageidperfilAceitarGeral").src=$scope.infosstalkeada.profilepic;
           }
          //document.getElementById("imageidperfilAceitarGeral").src=$scope.infosstalkeada.profilepic+"?{{getTimeStamp()}}";
          $scope.frase = stalker.frase;
          if(stalker.borda == 0){
          $scope.estrelabb = false;
          $scope.estrelabs = false;
          $scope.estrelabg = false;
        }
        if(stalker.borda == 1){
          $scope.estrelabb = true;
          $scope.estrelabs = false;
          $scope.estrelabg = false;
        }
        if(stalker.borda == 2){
          $scope.estrelabb = false;
          $scope.estrelabs = true;
          $scope.estrelabg = false;
        }
        if(stalker.borda == 3){
          $scope.estrelabb = false;
          $scope.estrelabs = false;
          $scope.estrelabg = true;
        }
          if($scope.infosstalkeada.idade){
            $scope.infosstalkeada.idade = ", "+ $scope.infosstalkeada.idade +" anos";
          }else{
             $scope.infosstalkeada.idade ='';
          }
      });
      
   

      EventoService.GetStalkear($scope.aux.id_user_envia).then(function(stalker) {
        $scope.stalkeada = stalker;
        EventoService.GetCriados($scope.stalkeada).then(function(items) {
          if(items == 'E'){
            $scope.items = [];
          }else{
            for (var i = 0; i < items.length; i++) {
                var curr_date = (items[i].diainicio[8]+items[i].diainicio[9]);
                var h2 = (items[i].diainicio[11]+items[i].diainicio[12]);
                var m2 = (items[i].diainicio[14]+items[i].diainicio[15]);
                var curr_month = (items[i].diainicio[5]+items[i].diainicio[6]);
                var curr_year = (items[i].diainicio[0]+items[i].diainicio[1]+items[i].diainicio[2]+items[i].diainicio[3]);
                var j = curr_date + "/" + curr_month + "/" + curr_year+ ' '+h2 + ':' + m2;
                items[i].datainicio = j;
                if(items[i].estado == 0){
                  items[i].confirmacao = "Vai acontecer"
                }
                if(items[i].estado == 1){
                  items[i].confirmacao = "Finalizado"
                }
                if(items[i].estado == 2){
                  items[i].confirmacao = "Standy by, talvez aconteça"
                }
                if(items[i].estado == 3){
                  items[i].confirmacao = "Vai acontecer"
                }
                if(items[i].estado == 4){
                  items[i].confirmacao = "Cancelado"
                }
                if(items[i].estado == 5){
                  items[i].confirmacao = "Acabado"
                }
                if(items[i].estado == 6){
                  items[i].confirmacao = "Escondido"
                }
            }
            $scope.items = items.concat($scope.items);
            $scope.lastidvestido = $scope.items[0].idevento;
          }
        });
      });

      $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/geteventoporid.php', {idevento :  $scope.aux.idevento}).then(function (result){
        $scope.infoevento = result.data[0];
      });

      if(parseInt($scope.infoevento.patual)>=parseInt($scope.infoevento.pmax)){
        var alertPopup = $ionicPopup.alert({
                      title: ' ٩( ᐛ )و ',
                      template: 'Evento é um sucesso, mas o numero máximo de pessoas foi atingido. Como o evento é seu, tu pode confirmar essa pessoa mesmo assim'
        });
      }  

      EventoService.GetPontos($scope.stalkeada.iduser).then(function(items) {
        $scope.p = items;
        $scope.labels3 = ["Pontos"];
        $scope.colores3 = ["#ff4d4d"];
        $scope.data3 = [$scope.p];
      });
      EventoService.getIC($scope.stalkeada).then(function(items) {
        if(items){
          $scope.ic = items;
          $scope.options2 = {title: {
                      display: true,
                      text: 'Indice de confirmação',
                      position: 'bottom'
                  }
           }
          $scope.labels2 = ["Fui", "Não fui"];
          $scope.colores2 = ["#99FF99","#ff4d4d"];
          var menos = (100-$scope.ic.total).toFixed(1);
          var mais = $scope.ic.total;
          $scope.data2 = [mais, menos ];
        }
      });
      console.log('antes', $scope.stalkeada.iduser)
      EventoService.GetComments3($scope.stalkeada).then(function(items) {
        
          $scope.options1 = {title: {
                    display: true,
                    text: 'Avaliações',
                    position: 'bottom'
                }
         }
           $scope.labels1 = ["Extrovertido", "Introvertido", "Realista","Curioso", "Solidário", "Racional","Organizado", "Criativo"];
          $scope.colores1 = ["#fff200", "#02fff2", "#ff9d00","#1867ce", "#e50be1", "#0e8c28","#ef370e", "#af0eef"];
          $scope.data1 =items.chart;
        
      }); 


      $scope.stalkeada.diainicio = $scope.infoevento.diainicio ;
      $scope.stalkeada.diafim = $scope.infoevento.diafim ;
      EventoService.verificahorariopessoaeventoaguardando($scope.stalkeada).then(function(items) {
        $scope.auxdata = items;
      });
                      //Para ver se eu ja sigo esta pessoa ou não.
      $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/getpessoaevento.php", {iduser : $scope.outro,
                                                                       estado : '3'}).then(function(response) {
                  pontos = response.data[0];
                  if (pontos=='E') {
                    $scope.neventos = parseFloat(0);
                  }else{
                    $scope.neventos =parseFloat(pontos.length);
                  }
                  for(var i=0;i<pontos.length;i++){
                          $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/geteventopessoaevento.php", {idevento : pontos[i].idevento,
                                                                              estado : '3'}).then(function(response) {
                                var novo = response.data[0];
                                for(var j=0 ;j<response.data[0].length;j++){
                                  if (novo[j].iduser == $scope.user.iduser && !$scope.desseguirbutton && $scope.outro != $scope.user.iduser) {
                                    $scope.followbutton = true;
                                    //console.log('fui no evento com este cara e nao sigo', $scope.outro , $scope.user.iduser);
                                  }
                                }
                          });
                  }
      });   
    });

    $scope.entrar = function(){
        formUser.updateForm($scope.aux);
        $state.go('tabsController.comentarios');

    }
    
    $scope.aceitar =  function(){
      $scope.aux.aceito = 2;
      $scope.aux.confirmacao = 'Confirmação aceita';
      $scope.msgnoti = ('Tu foi aceito no evento: ' + $scope.aux.nomeevento);
      //console.log($scope.msgnoti);
      EventoService.atualizarpessoaeventosconfirma($scope.auxdata);
      EventoService.atualizarpessoaevento($scope.aux).then(function(msg){
        var alertPopup = $ionicPopup.alert({
                title: 'Enviando confirmação',
                template: 'Vamos avisar para não se esquecer de comparecer no evento'
              });
        $scope.infoevento.patual = parseInt($scope.infoevento.patual)+1;
        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/addpessoaevento.php', {idevento : $scope.aux.idevento,
                                                                          patual : $scope.infoevento.patual});
        noti.recebeusername = $scope.infosstalkeada.username;
        noti.recebe = $scope.aux.id_user_envia;
        noti.envia = $scope.aux.id_user_recebe;
        noti.tipo = 2;
        noti.nomeevento = $scope.aux.nomeevento;
        EventoService.VerificaNotificacao(noti).then(function(res) {
          if(res){
            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : $scope.msgnoti, 
                          idevento : $scope.aux.idevento,
                          nomeevento : $scope.aux.nomeevento,
                          id_user_envia : $scope.aux.id_user_recebe,
                          username_envia : $scope.user.username,
                          apelido_envia : $scope.aux.apelido,
                          tipo : '2',
                          id_user_recebe : $scope.aux.id_user_envia});
            EventoService.getusuario2(noti.recebeusername).then(function(user) {
              $scope.pushnoti.titulo =  'Boraaa!!!' ;
              $scope.pushnoti.msg = $scope.msgnoti;
              $scope.pushnoti.token = user.devicetoken;
               EventoService.MandaPushNoti($scope.pushnoti);
            });
          }
        });
        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacao.php', {idnotificacao : $scope.aux.idnotificacao});
          alertPopup.then(function(){
            $state.go('geral');
          })
      }, function(errMsg) {
            var alertPopup = $ionicPopup.alert({
              title: 'Register failed!',
              template: errMsg
            });
      })  
    }

    $scope.recusar =  function(){
           var confirmPopup = $ionicPopup.show({
                   title: 'ATENÇÃO!!!',
                   template: 'Ao recusar esta pessoa não poderá mais entrar neste evento, tens certeza disso?',
                   buttons: [
                      { text: 'Não',
                        type: 'button-assertive'},
                      {
                        text: 'Sim',
                        type: 'button-positive',
                        onTap: function(e){
                        $scope.msgnoti = ('Tu foi negado pra comparecer nome evento: ' + $scope.aux.nomeevento + ', mas segue o day');
                        console.log($scope.msgnoti);
              noti.recebeusername = $scope.infosstalkeada.username;
              noti.recebe = $scope.aux.id_user_envia;
              noti.envia = $scope.aux.id_user_recebe;
              noti.tipo = 3;
              noti.nomeevento = $scope.aux.nomeevento;
              EventoService.VerificaNotificacao(noti).then(function(res) {
                console.log(res);
                if(res){
                  $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : $scope.msgnoti, 
                                idevento : $scope.aux.idevento,
                                nomeevento : $scope.aux.nomeevento,
                                id_user_envia : $scope.aux.id_user_recebe,
                                username_envia : $scope.user.username,
                                apelido_envia : $scope.aux.apelido,
                                tipo : '3',
                                id_user_recebe : $scope.aux.id_user_envia});
                  $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacao.php', {idnotificacao : $scope.aux.idnotificacao});
                  EventoService.getusuario2(noti.recebeusername).then(function(user) {
                    $scope.pushnoti.titulo = $scope.evento.nomeevento + ' negado';
                    $scope.pushnoti.msg = $scope.msgnoti;
                    $scope.pushnoti.token = user.devicetoken;
                     EventoService.MandaPushNoti($scope.pushnoti);
                  });
                }
              });
              $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser : $scope.aux.id_user_envia,
                                                                                  idevento : $scope.aux.idevento,
                                                                                  estado: '1'});
              $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletachat.php', {iduser : $scope.aux.id_user_envia,
                                                                            idevento : $scope.aux.idevento  });
              $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/pessoanaoevento.php', {iduser : $scope.aux.id_user_envia, 
                                                                                idevento : $scope.aux.idevento,
                                                                                nomeevento : $scope.aux.nomeevento,
                                                                                estado : '2'});//foi nao foi aceito
              $state.go('geral');
                             }
                      }
                           ]
                   })
    }

    $scope.loadCriados = function() {
      $scope.CoisasCriado = true;
    $scope.CoisasFinalizado = false;
        $scope.estadobutton = 0;
        $scope.items = [];
        EventoService.GetCriados($scope.stalkeada).then(function(items) {
          if(items == 'E'){
            $scope.items = [];
          }else{
            for (var i = 0; i < items.length; i++) {
                var curr_date = (items[i].diainicio[8]+items[i].diainicio[9]);
                var h2 = (items[i].diainicio[11]+items[i].diainicio[12]);
                var m2 = (items[i].diainicio[14]+items[i].diainicio[15]);
                var curr_month = (items[i].diainicio[5]+items[i].diainicio[6]);
                var curr_year = (items[i].diainicio[0]+items[i].diainicio[1]+items[i].diainicio[2]+items[i].diainicio[3]);
                var j = curr_date + "/" + curr_month + "/" + curr_year+ ' '+h2 + ':' + m2;
                items[i].datainicio = j;
                if(items[i].estado == 0){
                  items[i].confirmacao = "Vai acontecer"
                }
                if(items[i].estado == 1){
                  items[i].confirmacao = "Finalizado"
                }
                if(items[i].estado == 2){
                  items[i].confirmacao = "Standy by, talvez aconteça"
                }
                if(items[i].estado == 3){
                  items[i].confirmacao = "Vai acontecer"
                }
                if(items[i].estado == 4){
                  items[i].confirmacao = "Cancelado"
                }
                if(items[i].estado == 5){
                  items[i].confirmacao = "Acabado"
                }
                if(items[i].estado == 6){
                  items[i].confirmacao = "Escondido"
                }
            }
            $scope.items = items.concat($scope.items);
            $scope.lastidvestido = $scope.items[0].idevento;
          }
        });
    }
    
    $scope.loadAbertos = function() {
      $scope.CoisasCriado = false;
    $scope.CoisasFinalizado = true;
        $scope.estadobutton = 1;
        $scope.items = [];
        EventoService.GetAbertos($scope.stalkeada.iduser).then(function(items) {  //mudar
          if(items == 'E'){
            $scope.items = [];
          }else{
            for (var i = 0; i < items.length; i++) {
                var curr_date = (items[i].diainicio[8]+items[i].diainicio[9]);
                var h2 = (items[i].diainicio[11]+items[i].diainicio[12]);
                var m2 = (items[i].diainicio[14]+items[i].diainicio[15]);
                var curr_month = (items[i].diainicio[5]+items[i].diainicio[6]);
                var curr_year = (items[i].diainicio[0]+items[i].diainicio[1]+items[i].diainicio[2]+items[i].diainicio[3]);
                var j = curr_date + "/" + curr_month + "/" + curr_year+ ' '+h2 + ':' + m2;
                items[i].datainicio = j;
            }
            $scope.items = items.concat($scope.items);
            $scope.lastidvestido = $scope.items[0].idevento;
          }
        });
    }
    
    $scope.loadFechados = function() {
      $scope.CoisasCriado = false;
    $scope.CoisasFinalizado = true;
        $scope.estadobutton = 2;
        $scope.items = [];
        EventoService.GetFinalizadosPerfil($scope.stalkeada.iduser).then(function(items) {         //mudar
          if(items =='E'){
            $scope.items = [];
          }else{
            for (var i = 0; i < items.length; i++) {
                var curr_date = (items[i].diainicio[8]+items[i].diainicio[9]);
                var h2 = (items[i].diainicio[11]+items[i].diainicio[12]);
                var m2 = (items[i].diainicio[14]+items[i].diainicio[15]);
                var curr_month = (items[i].diainicio[5]+items[i].diainicio[6]);
                var curr_year = (items[i].diainicio[0]+items[i].diainicio[1]+items[i].diainicio[2]+items[i].diainicio[3]);
                var j = curr_date + "/" + curr_month + "/" + curr_year+ ' '+h2 + ':' + m2;
                items[i].datainicio = j;
            }
            $scope.items = items.concat($scope.items);
            $scope.lastidvestido = $scope.items[0].idevento;
          }
        });      
    }
    
    $scope.loadMore = function() {
      if ($scope.estadobutton == 0) {
        EventoService.GetOldEventosCriados().then(function(items) {
        $scope.items = $scope.items.concat(items);
        $scope.$broadcast('scroll.infiniteScrollComplete');
          if (items.length <= 4) {
            $scope.noMoreItemsAvailable = true;
          }

        });
      }
      if ($scope.estadobutton == 1) {
        EventoService.GetOldEventosCriados().then(function(items) {
        $scope.items = $scope.items.concat(items);
        $scope.$broadcast('scroll.infiniteScrollComplete');
          if (items.length <= 4) {
            $scope.noMoreItemsAvailable = true;
          }
        });

        
      }
      if ($scope.estadobutton == 2) {
        EventoService.GetOldEventosCriados().then(function(items) {
        $scope.items = $scope.items.concat(items);
        $scope.$broadcast('scroll.infiniteScrollComplete');
          if (items.length <= 4) {
            $scope.noMoreItemsAvailable = true;
          }
        });

      
      }
    }

}])

.controller('geralCtrl', ['$scope', '$stateParams', 'formUser', 'formLoc', 'EventoService', 'formAux', '$state','$timeout', '$ionicPopup', '$http', 'formOutro', 'formItem', 'formtela', 'formtelanoti', 'formtipologin','formEventoPerfil', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, formUser, formLoc, EventoService, formAux, $state, $timeout, $ionicPopup, $http, formOutro, formItem, formtela, formtelanoti, formtipologin, formEventoPerfil) {
  $scope.tipologin = formtipologin.getForm();  
  $scope.comentario = '';
  var aux1= 0;
  var aux2= 0;
  var k = 0;
  var noti ={};
  var ultima_noti_data;
  $scope.aux = formUser.getForm();
  EventoService.GetComentariosfeitos($scope.aux).then(function(coments) { //
        aux1 = coments.length;
        $scope.feitos = coments;
      });
  $scope.$on("$ionicView.enter", function(event, data){
      $scope.tipologin = formtipologin.getForm(); 
      $scope.items = [];
      $scope.evento = {};
      $scope.comentariovalido = {};
      $scope.outro ={};
      $scope.primeiro = [];
      $scope.segundo = [];
      $scope.terceiro = [];
      $scope.comentario = '';
      $scope.quarto = false;
      var aux1= 0;
      var aux2= 0;
      var k = 0;
      var noti ={};
      var ultima_noti_data;
      $scope.data = {showDelete: false};
      $scope.aux = formUser.getForm();

      EventoService.GetComentariosfeitos($scope.aux).then(function(coments) { //
        aux1 = coments.length;
        $scope.feitos = coments;
      });
      formtelanoti.updateForm(1);

      EventoService.GetNotificacoes1($scope.aux).then(function(aux) {
        console.log(aux, "Nododoosoa")
        if(aux == "error"){
          $scope.primeiro = false;
          $scope.segundo = false;
          $scope.terceiro =false;

        }else{
          for (var i = 0; i < 3; i++) {
            if(aux[0] && aux[0]!="error"){
              $scope.primeiro = aux[0];
              var curr_date = (aux[0].datadecriacao[8]+aux[0].datadecriacao[9]);
              var h2 = (aux[0].datadecriacao[11]+aux[0].datadecriacao[12]);
              h2 = parseInt(h2)-3;
              console.log(h2)
              var m2 = (aux[0].datadecriacao[14]+aux[0].datadecriacao[15]);
              var curr_month = (aux[0].datadecriacao[5]+aux[0].datadecriacao[6]);
              var curr_year = (aux[0].datadecriacao[0]+aux[0].datadecriacao[1]+aux[0].datadecriacao[2]+aux[0].datadecriacao[3]);
              var j = curr_date + "/" + curr_month + "/" + curr_year+ ' '+h2 + ':' + m2;
              $scope.primeiro.datadeenvio = j;
            }else{
               $scope.primeiro = false;
            }
            if(aux[1]){
              $scope.segundo = aux[1];
              var curr_date = (aux[1].datadecriacao[8]+aux[1].datadecriacao[9]);
              var h2 = (aux[1].datadecriacao[11]+aux[1].datadecriacao[12]);
              h2 = parseInt(h2)-3;
              var m2 = (aux[1].datadecriacao[14]+aux[1].datadecriacao[15]);
              var curr_month = (aux[1].datadecriacao[5]+aux[1].datadecriacao[6]);
              var curr_year = (aux[1].datadecriacao[0]+aux[1].datadecriacao[1]+aux[1].datadecriacao[2]+aux[1].datadecriacao[3]);
              var j = curr_date + "/" + curr_month + "/" + curr_year+ ' '+h2 + ':' + m2;
              $scope.segundo.datadeenvio = j;
            }
            else{
               $scope.segundo = false;
            }
            if(aux[2]){
              $scope.terceiro = aux[2];
              var curr_date = (aux[2].datadecriacao[8]+aux[2].datadecriacao[9]);
              var h2 = (aux[2].datadecriacao[11]+aux[2].datadecriacao[12]);
              h2 = parseInt(h2)-3;
              var m2 = (aux[2].datadecriacao[14]+aux[2].datadecriacao[15]);
              var curr_month = (aux[2].datadecriacao[5]+aux[2].datadecriacao[6]);
              var curr_year = (aux[2].datadecriacao[0]+aux[2].datadecriacao[1]+aux[2].datadecriacao[2]+aux[2].datadecriacao[3]);
              var j = curr_date + "/" + curr_month + "/" + curr_year+ ' '+h2 + ':' + m2;
              $scope.terceiro.datadeenvio = j;
            }else{
               $scope.terceiro = false;
            }
            if(aux[3]){
              $scope.quarto = true;
            }else{
              $scope.quarto = false;
            }
          }     
        }
        
      });
      

    });
  

  $scope.enviar =  function(comentario){
    if(!comentario || comentario == ''){
      var alertPopup = $ionicPopup.alert({
          title: '＿φ(°-°=)',
          template: 'Escreva algo para gente antes de enviar plz!!'
        });
    }else{
     var alertPopup = $ionicPopup.alert({
          title: '(◍˃̵͈̑ᴗ˂̵͈̑)',
          template: 'Obrigado pelo feedback'
        });
        alertPopup.then(function(){
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/reportaevento.php', {namereportado : 'diwoapp',
                                                                  reportadoid : 'nada',
                                                                  iduserreportando : $scope.aux.iduser,
                                                                  usernamereportando : $scope.aux.username,
                                                                  tiporeport : 'fale conosco',
                                                                  motivo : comentario});
          //console.log(comentario)
          $scope.comentario = '';
          //$scope.comentario = "  ";
          $state.reload();
          });
    }
  }

  $scope.logout =  function(){
    $scope.user = {};
    $scope.loc = formLoc.getForm();
    formLoc.updateForm();
    formAux.updateAux();
    formUser.updateForm();
    formItem.updateForm();
    formOutro.updateForm();
    formtela.updateForm();
    formtelanoti.updateForm();
    formtipologin.updateForm();
    if($scope.loc){
      $scope.user.lat =  $scope.loc.lat;
      $scope.user.long =  $scope.loc.long;
      $scope.user.northlat = $scope.loc.northlat;
      $scope.user.westlng = $scope.loc.westlng;
      $scope.user.southlat = $scope.loc.southlat;
      $scope.user.eastlng = $scope.loc.eastlng;
      //console.log($scope.loc.eastlng)
    }
    formUser.updateForm($scope.user);
    EventoService.Mudadevice($scope.user);
    window.localStorage.removeItem('user')
    if($scope.tipologin == 1){
       facebookConnectPlugin.logout(function(){

          $state.go('logando');
        },
        function(fail){
           var alertPopup = $ionicPopup.alert({
            title: '( ;°Д°)',
            template: 'Aconteceu algum problema nao planejado'
          });
        });
    }
    $state.go('logando');
  }


  $scope.enterItem =  function(item){
      formAux.updateAux(item.tipo);
      $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/geteventoporid.php', {idevento : item.idevento}).then(function (result){
        $scope.infoevento = result.data[0];
        formItem.updateForm($scope.infoevento);
        console.log($scope.infoevento.idevento);
      });
      if (item.tipo == '1') {
        formAux.updateAux(item);
        $state.go('perfilAceitarGeral');
      }
      if (item.tipo == '8') {
        var alertPopup = $ionicPopup.alert({
          title: '(((( ;°Д°))))',
          template: 'Muita gente querendo ir no evento, mas como tu que manda podes aceitar ou não, ai é contigo'
        });
        alertPopup.then(function(){
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacao.php', {idnotificacao : item.idnotificacao}).then(function (res){
            $scope.response = res.data;
            console.log($scope.response.msg)
          });
          $state.go('perfilAceitarGeral');
        })
      }
      if (item.tipo == '2') {
        var alertPopup = $ionicPopup.alert({
          title: '⁽(◍˃̵͈̑ᴗ˂̵͈̑)⁽',
          template: 'Agora é se preparar e não se esqueçer de comparecer ao evento'
        });
        alertPopup.then(function(){
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacao.php', {idnotificacao : item.idnotificacao}).then(function (res){
            $scope.response = res.data;
            console.log($scope.response.msg)
          });
          $state.reload();
        })
      }
      if (item.tipo == '3') {
        var alertPopup = $ionicPopup.alert({
          title: '（╬ಠ益ಠ)',
          template: 'Não se esqueça de comparecer aos eventos para seu indice de confirmação ser altos sempre'
        });
        alertPopup.then(function(){
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacao.php', {idnotificacao : item.idnotificacao}).then(function (res){
            $scope.response = res.data;
            console.log($scope.response.msg)
          });
          $state.reload();
        })
      }
      if (item.tipo == '4') {
        var alertPopup = $ionicPopup.alert({
          title: '(￣ω￣)',
          template: 'Fica de olho que mudou o evento, o organizador resolveu mudar algo no evento'
        });
        alertPopup.then(function(){
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacao.php', {idnotificacao : item.idnotificacao}).then(function (res){
            $scope.response = res.data;
            console.log($scope.response.msg)
          });
          $state.go('tabsController.eventosAbertos');
        })
      }
      if (item.tipo == '5') {
        var alertPopup = $ionicPopup.alert({
          title: 'ε-(>o<)',
          template: 'Nao vou mais, tive que cancelar'
        });
        alertPopup.then(function(){
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacao.php', {idnotificacao : item.idnotificacao}).then(function (res){
            $scope.response = res.data;
            console.log($scope.response.msg)
          });
          $state.reload();
        })
      }
      if (item.tipo == '13') {
        var alertPopup = $ionicPopup.alert({
          title: '(ﾉ^ヮ^)ﾉ*:・ﾟ✧',
          template: item.notificacao
        });
        alertPopup.then(function(){
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacao.php', {idnotificacao : item.idnotificacao}).then(function (res){
            $scope.response = res.data;
            console.log($scope.response.msg)
          });
          $state.reload();
        })
      }
      if (item.tipo == '9') {
        var alertPopup = $ionicPopup.alert({
          title: 'ಥ_ಥ',
          template: 'Você foi retirado do evento por algum motivo'
        });
        alertPopup.then(function(){
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacao.php', {idnotificacao : item.idnotificacao}).then(function (res){
            $scope.response = res.data;
            console.log($scope.response.msg)
          });
          $state.reload();
        })
      }
      if (item.tipo == '6' && item.id_user_envia == $scope.aux.iduser) {
        formtela.updateForm(1);
        var confirmPopup = $ionicPopup.show({
                   title: 'Confirme pá nóx',
                   template: 'Você foi mesmo no evento?',
                   buttons: [
                      { text: 'Não',
                        type: 'button-assertive',
                        onTap: function(e){
                          item.confirmacao = 'Não estive presente no evento ocorrido';
                          item.aceito = '5'; 
                          EventoService.atualizarpessoaevento(item);
                          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacao.php', {idnotificacao : item.idnotificacao}).then(function (res){
                               $scope.response = res.data;
                               console.log($scope.response.msg)
                             });
                           $state.reload();

                        }},
                      {
                        text: 'Sim',
                        type: 'button-positive',
                        onTap: function(e){
                          formAux.updateAux(item);
                          $state.go('qmFoiMesmo');
                        }}]
                 });
       }
       if (item.tipo == '6' && item.id_user_envia !=  $scope.aux.iduser) {
        formtela.updateForm(1);
        item.id_user_envia = $scope.aux.iduser;
          var confirmPopup = $ionicPopup.show({
                   title: 'Confirme pá nóx',
                   template: 'Você foi mesmo no evento?',
                   buttons: [
                      { text: 'Não',
                        type: 'button-assertive',
                        onTap: function(e){
                          item.confirmacao = 'Não estive presente no evento ocorrido';
                          item.aceito = '5'; 
                          EventoService.atualizarpessoaevento(item);
                            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacao.php', {idnotificacao : item.idnotificacao}).then(function (res){
                               $scope.response = res.data;
                               console.log($scope.response.msg)
                             });
                            $state.reload();

                        }},
                      {
                        text: 'Sim',
                        type: 'button-positive',
                        onTap: function(e){
                          formAux.updateAux(item);
                          $state.go('tabsController.avaliaODoEvento');
                        }}]
                 });

      }
      if (item.tipo == '10') {
        var alertPopup = $ionicPopup.alert({
          title: '└(・-・)┘',
          template: 'Não foi dessa vez'
        });
        alertPopup.then(function(){
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacao.php', {idnotificacao : item.idnotificacao}).then(function (res){
            $scope.response = res.data;
            console.log($scope.response.msg)
          });
          $state.reload();
        })
      }
      if (item.tipo == '11') {
        var alertPopup = $ionicPopup.alert({
          title: '⁽(◍˃̵͈̑ᴗ˂̵͈̑)⁽',
          template: 'Sou muito pop'
        });
        alertPopup.then(function(){
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacao.php', {idnotificacao : item.idnotificacao}).then(function (res){
            $scope.response = res.data;
            console.log($scope.response.msg)
          });
          $state.reload();
        })
      }
       if(item.tipo == '12'){
        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/geteventoporid.php', {idevento :  item.idevento}).then(function (result){
          $scope.evento = result.data[0];
        });
        var myPopup = $ionicPopup.show({
                        template: 'Uma pessoa desistiu e agora o numero de pessoas confirmadas no evento é menor que o minimo. Deseja fazer o evento mesmo assim? (Caso cancele nao receberás penalidade)',
                        title: 'Vish',
                        scope: $scope,
                        buttons: [
                       { text: 'Vou ver' 
                         //close popup and do nothing
                       },
                       {
                        text: 'Vai rolar',
                        type: 'button-balanced',
                        onTap: function(e) {  
                          console.log('evento acontece normalmente')
                        }
                       },
                       {
                        text: 'Cancelar',
                        type: 'button-assertive',
                        onTap: function(e) { 
                          EventoService.Cancelarevento($scope.evento);
                          console.log('Vou cancelar o evento', $scope.evento.nomeevento);
                        }
                       }]
                      });
       }

       if (item.tipo == '7') {
          
          //console.log(item.idevento);
          //console.log(item.id_user_envia);

          for (var i = 0 ; i<aux1 ; i++){
            if ($scope.feitos[i].idevento == item.idevento && item.id_user_envia == $scope.feitos[i].idpessoaavaliada && item.username_envia == $scope.feitos[i].nomepessoaavaliada) {
              $scope.comentariovalido = $scope.feitos[i]; 
              aux2 = 1;
              k++;
            }
          }
          if (aux2 == 1) {
            formtela.updateForm(1);
            var alertPopup = $ionicPopup.alert({
                      title: 'ヽ(〃･ω･)ﾉ',
                      template: 'Curioso? Vamos ver o que escreveram sobre mim'
                    });
            //formtela.updateForm(2);
            alertPopup.then(function(){
                   $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacao.php', {idnotificacao : item.idnotificacao}).then(function (res){
                               $scope.response = res.data;
                               console.log($scope.response.msg)
                             });
              formEventoPerfil.updateForm($scope.evento);
              $state.go('tabsController.perfil');
            })
          }else{

            var alertPopup = $ionicPopup.alert({
                      title: '(`へ´*)ノ',
                      template: 'Avalie!!! Conseguirás ver só se você avaliar o outro, tipo um troca troca'
                    });
            alertPopup.then(function(){
                   $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacao.php', {idnotificacao : item.idnotificacao}).then(function (res){
                               $scope.response = res.data;
                               console.log($scope.response.msg)
                             });
                   $scope.outro.iduser = item.id_user_envia;
                   formOutro.updateForm($scope.outro);
                   formtela.updateForm(1); 
                   formEventoPerfil.updateForm($scope.evento);
                            // TEM QUE IR PARA PAGINA DE AVALIAR A PESSOA NAQUELE EVENTO
                          $state.go('tabsController.perfil');
                    })

          }

       }

   
   }


}])

.controller('sobreCtrl', ['$scope', '$stateParams', 'formItem', 'EventoService', 'formUser','$state', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, formItem, EventoService, formUser,$state) {

}])
   
.controller('notificaEsCtrl', ['$scope', '$stateParams', 'formUser', 'EventoService', 'formAux', '$state','$timeout', '$ionicPopup', '$http', 'formOutro', 'formItem', 'formtela', 'formtelanoti','formEventoPerfil', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, formUser, EventoService, formAux, $state, $timeout, $ionicPopup, $http, formOutro, formItem, formtela, formtelanoti, formEventoPerfil) {
  
   $scope.data = {showDelete: false};
   $scope.evento = {};
   $scope.comentariovalido = {};
   $scope.outro ={};
   $scope.aux = formUser.getForm();
   console.log($scope.aux);
   var aux1= 0;
   var aux2= 0;
   var k = 0;
   var noti ={};
   var ultima_noti_data;
   formtelanoti.updateForm(2);

   $scope.$on("$ionicView.enter", function(event, data){
      $scope.items = [];
      $scope.evento = {};
      $scope.comentariovalido = {};
      $scope.outro ={};
      var aux1= 0;
      var aux2= 0;
      var k = 0;
      var noti ={};
      var ultima_noti_data;
      $scope.data = {showDelete: false};
      $scope.aux = formUser.getForm();
      EventoService.GetNotificacoes($scope.aux).then(function(aux) {
        for (var i = 0; i < aux.nrow; i++) {
          $scope.items[i] = aux[i];
          console.log($scope.items[i].notificacao);
          ultima_noti_data = $scope.items[0].datadecriacao;
          var curr_date = (aux[i].datadecriacao[8]+aux[i].datadecriacao[9]);
          var h2 = (aux[i].datadecriacao[11]+aux[i].datadecriacao[12]);
          h2 = parseInt(h2)-3;
          var m2 = (aux[i].datadecriacao[14]+aux[i].datadecriacao[15]);
          var curr_month = (aux[i].datadecriacao[5]+aux[i].datadecriacao[6]);
          var curr_year = (aux[i].datadecriacao[0]+aux[i].datadecriacao[1]+aux[i].datadecriacao[2]+aux[i].datadecriacao[3]);
          var j = curr_date + "/" + curr_month + "/" + curr_year+ ' '+h2 + ':' + m2;
          $scope.items[i].datadeenvio = j;
        }     
      });
      EventoService.GetComentariosfeitos($scope.aux).then(function(coments) { //
        aux1 = coments.length;
        $scope.feitos = coments;
      });
    });

   $scope.onItemDelete = function(item) {
    $scope.items.splice($scope.items.indexOf(item), 1);
    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacao.php', {idnotificacao : item.idnotificacao});
   };

    $scope.enterItem =  function(item){
      formAux.updateAux(item.tipo);
      $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/geteventoporid.php', {idevento : item.idevento}).then(function (result){
        $scope.infoevento = result.data[0];
        formItem.updateForm($scope.infoevento);
        console.log($scope.infoevento.idevento);
      });
      if (item.tipo == '1') {
        formAux.updateAux(item);
        $state.go('perfilAceitar');
      }
      if (item.tipo == '8') {
        var alertPopup = $ionicPopup.alert({
          title: '(((( ;°Д°))))',
          template: 'Muita gente querendo ir no evento, mas como tu que manda podes aceitar ou não, ai é contigo'
        });
        alertPopup.then(function(){
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacao.php', {idnotificacao : item.idnotificacao}).then(function (res){
            $scope.response = res.data;
            console.log($scope.response.msg)
          });
          $state.go('perfilAceitar');
        })
      }
      if (item.tipo == '2') {
        var alertPopup = $ionicPopup.alert({
          title: '⁽(◍˃̵͈̑ᴗ˂̵͈̑)⁽',
          template: 'Agora é se preparar e não se esqueçer de comparecer ao evento'
        });
        alertPopup.then(function(){
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacao.php', {idnotificacao : item.idnotificacao}).then(function (res){
            $scope.response = res.data;
            console.log($scope.response.msg)
          });
          $state.reload();
        })
      }
      if (item.tipo == '3') {
        var alertPopup = $ionicPopup.alert({
          title: '（╬ಠ益ಠ)',
          template: 'Não se esqueça de comparecer aos eventos para seu indice de confirmação ser altos sempre'
        });
        alertPopup.then(function(){
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacao.php', {idnotificacao : item.idnotificacao}).then(function (res){
            $scope.response = res.data;
            console.log($scope.response.msg)
          });
          $state.reload();
        })
      }
      if (item.tipo == '4') {
        var alertPopup = $ionicPopup.alert({
          title: '(￣ω￣)',
          template: 'Fica de olho que mudou o evento, o organizador resolveu mudar algo no evento'
        });
        alertPopup.then(function(){
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacao.php', {idnotificacao : item.idnotificacao}).then(function (res){
            $scope.response = res.data;
            console.log($scope.response.msg)
          });
          $state.go('tabsController.eventosAbertos');
        })
      }
      if (item.tipo == '5') {
        var alertPopup = $ionicPopup.alert({
          title: 'ε-(>o<)',
          template: 'Nao vou mais, tive que cancelar'
        });
        alertPopup.then(function(){
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacao.php', {idnotificacao : item.idnotificacao}).then(function (res){
            $scope.response = res.data;
            console.log($scope.response.msg)
          });
          $state.reload();
        })
      }
       if (item.tipo == '13') {
        var alertPopup = $ionicPopup.alert({
          title: '(ﾉ^ヮ^)ﾉ*:・ﾟ✧',
          template: item.notificacao
        });
        alertPopup.then(function(){
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacao.php', {idnotificacao : item.idnotificacao}).then(function (res){
            $scope.response = res.data;
            console.log($scope.response.msg)
          });
          $state.reload();
        })
      }
      if (item.tipo == '9') {
        var alertPopup = $ionicPopup.alert({
          title: 'ಥ_ಥ',
          template: 'Você foi retirado do evento por algum motivo'
        });
        alertPopup.then(function(){
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacao.php', {idnotificacao : item.idnotificacao}).then(function (res){
            $scope.response = res.data;
            console.log($scope.response.msg)
          });
          $state.reload();
        })
      }
      if (item.tipo == '6' && item.id_user_envia == $scope.aux.iduser) {
        formtela.updateForm(1);
        var confirmPopup = $ionicPopup.show({
                   title: 'Confirme pá nóx',
                   template: 'Você foi mesmo no evento?',
                   buttons: [
                      { text: 'Não',
                        type: 'button-assertive',
                        onTap: function(e){
                          item.confirmacao = 'Não estive presente no evento ocorrido';
                          item.aceito = '5'; 
                          EventoService.atualizarpessoaevento(item);
                          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacao.php', {idnotificacao : item.idnotificacao}).then(function (res){
                               $scope.response = res.data;
                               console.log($scope.response.msg)
                             });
                           $state.reload();

                        }},
                      {
                        text: 'Sim',
                        type: 'button-positive',
                        onTap: function(e){
                          formAux.updateAux(item);
                          $state.go('qmFoiMesmo');
                        }}]
                 });
       }
       if (item.tipo == '6' && item.id_user_envia !=  $scope.aux.iduser) {
        formtela.updateForm(1);
        item.id_user_envia = $scope.aux.iduser;
          var confirmPopup = $ionicPopup.show({
                   title: 'Confirme pá nóx',
                   template: 'Você foi mesmo no evento?',
                   buttons: [
                      { text: 'Não',
                        type: 'button-assertive',
                        onTap: function(e){
                          item.confirmacao = 'Não estive presente no evento ocorrido';
                          item.aceito = '5'; 
                          EventoService.atualizarpessoaevento(item);
                            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacao.php', {idnotificacao : item.idnotificacao}).then(function (res){
                               $scope.response = res.data;
                               console.log($scope.response.msg)
                             });
                            $state.reload();

                        }},
                      {
                        text: 'Sim',
                        type: 'button-positive',
                        onTap: function(e){
                          formAux.updateAux(item);
                          $state.go('tabsController.avaliaODoEvento');
                        }}]
                 });

      }
      if (item.tipo == '10') {
        var alertPopup = $ionicPopup.alert({
          title: '└(・-・)┘',
          template: 'Não foi dessa vez'
        });
        alertPopup.then(function(){
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacao.php', {idnotificacao : item.idnotificacao}).then(function (res){
            $scope.response = res.data;
            console.log($scope.response.msg)
          });
          $state.reload();
        })
      }
      if (item.tipo == '11') {
        var alertPopup = $ionicPopup.alert({
          title: '⁽(◍˃̵͈̑ᴗ˂̵͈̑)⁽',
          template: 'Sou muito pop'
        });
        alertPopup.then(function(){
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacao.php', {idnotificacao : item.idnotificacao}).then(function (res){
            $scope.response = res.data;
            console.log($scope.response.msg)
          });
          $state.reload();
        })
      }
       if(item.tipo == '12'){
        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/geteventoporid.php', {idevento :  item.idevento}).then(function (result){
          $scope.evento = result.data[0];
        });
        var myPopup = $ionicPopup.show({
                        template: 'Uma pessoa desistiu e agora o numero de pessoas confirmadas no evento é menor que o minimo. Deseja fazer o evento mesmo assim? (Caso cancele nao receberás penalidade)',
                        title: 'Vish',
                        scope: $scope,
                        buttons: [
                       { text: 'Vou ver' 
                         //close popup and do nothing
                       },
                       {
                        text: 'Vai rolar',
                        type: 'button-balanced',
                        onTap: function(e) {  
                          console.log('evento acontece normalmente')
                        }
                       },
                       {
                        text: 'Cancelar',
                        type: 'button-assertive',
                        onTap: function(e) { 
                          EventoService.Cancelarevento($scope.evento);
                          console.log('Vou cancelar o evento', $scope.evento.nomeevento);
                        }
                       }]
                      });
       }

       if (item.tipo == '7') {
          
          //console.log(item.idevento);
          //console.log(item.id_user_envia);
          for (var i = 0 ; i<aux1 ; i++){
            if ($scope.feitos[i].idevento == item.idevento && item.id_user_envia == $scope.feitos[i].idpessoaavaliada && item.username_envia == $scope.feitos[i].nomepessoaavaliada) {
              $scope.comentariovalido = $scope.feitos[i]; 
              aux2 = 1;
              k++;
            }
          }
          if (aux2 == 1) {
            formtela.updateForm(1);
            var alertPopup = $ionicPopup.alert({
                      title: 'ヽ(〃･ω･)ﾉ',
                      template: 'Curioso? Vamos ver o que escreveram sobre mim'
                    });
            formtela.updateForm(2);
          alertPopup.then(function(){
                   $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacao.php', {idnotificacao : item.idnotificacao}).then(function (res){
                               $scope.response = res.data;
                               console.log($scope.response.msg)
                             });
                  formEventoPerfil.updateForm($scope.evento);
                  $state.go('tabsController.perfil');
                    })
          }else{

            var alertPopup = $ionicPopup.alert({
                      title: '(`へ´*)ノ',
                      template: 'Avalie!!! Conseguirás ver só se você avaliar o outro, tipo um troca troca'
                    });
            alertPopup.then(function(){
                   $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacao.php', {idnotificacao : item.idnotificacao}).then(function (res){
                               $scope.response = res.data;
                               console.log($scope.response.msg)
                             });
                   $scope.outro.iduser = item.id_user_envia;
                   formOutro.updateForm($scope.outro);
                   formtela.updateForm(1); 
                   formEventoPerfil.updateForm($scope.evento);

                            // TEM QUE IR PARA PAGINA DE AVALIAR A PESSOA NAQUELE EVENTO
                          $state.go('tabsController.perfil');
                    })

          }

       }

   
   }
   $scope.doRefresh = function() {
    var refresh = {};
    refresh.iduser = $scope.aux.iduser;  
    refresh.datadaultima = ultima_noti_data;
          console.log($scope.aux.iduser , ultima_noti_data)
           EventoService.GetNoti(refresh).then(function(resp) {
              console.log(resp, resp.length);
              if(resp == "Error"){
                console.log("Nao tem notificação nova")
              }else{
                $scope.items =resp.concat($scope.items);
              }
            });

        $scope.$broadcast('scroll.refreshComplete');
        }


}])

.controller('perfilAceitarCtrl', ['$scope', '$state', '$stateParams', 'formAux', 'formUser', 'EventoService', '$timeout', '$http','$ionicPopup', 'formStalker', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $state, $stateParams, formAux, formUser, EventoService, $timeout, $http, $ionicPopup, formStalker) {

    $scope.aux = formAux.getAux();      // Infos da notificação
    // console.log($scope.aux.id_user_recebe);
    // console.log($scope.aux.id_user_envia);
    // console.log($scope.aux.idnotificacao);
    $scope.user = formUser.getForm();
    //console.log($scope.aux);
    $scope.auxdata = {};
    $scope.estadobutton = 0;
    $scope.stalkeada = {}; 
    $scope.stalkeada.iduser = $scope.aux.id_user_envia;
    $scope.stalkeada.username = $scope.aux.username_envia;
    $scope.neventos= 0;
    $scope.neventosnao= 0;
    $scope.p =0;
    $scope.ic = 0;
    $scope.infoevento ={};
    $scope.CoisasCriado = true;
    $scope.CoisasFinalizado = false;
    $scope.pushnoti = {};
    var noti={};
    $scope.infosstalkeada ={};
    EventoService.GetStalkear($scope.aux.id_user_envia).then(function(stalker) {
        $scope.infosstalkeada = stalker;
        if($scope.infosstalkeada.profilepic[8] == 's' && $scope.infosstalkeada.profilepic[9] == '3'){
             document.getElementById("imageidperfilAceitar").src=$scope.infosstalkeada.profilepic+"?{{getTimeStamp()}}";
           }else{
             document.getElementById("imageidperfilAceitar").src=$scope.infosstalkeada.profilepic;
           }
        //document.getElementById("imageidperfilAceitar").src=$scope.infosstalkeada.profilepic+"?{{getTimeStamp()}}";
        $scope.frase = stalker.frase;
         if(stalker.borda == 0){
          $scope.estrelabb = false;
          $scope.estrelabs = false;
          $scope.estrelabg = false;
        }
        if(stalker.borda == 1){
          $scope.estrelabb = true;
          $scope.estrelabs = false;
          $scope.estrelabg = false;
        }
        if(stalker.borda == 2){
          $scope.estrelabb = false;
          $scope.estrelabs = true;
          $scope.estrelabg = false;
        }
        if(stalker.borda == 3){
          $scope.estrelabb = false;
          $scope.estrelabs = false;
          $scope.estrelabg = true;
        }
        if($scope.infosstalkeada.idade){
          $scope.infosstalkeada.idade = ", "+ $scope.infosstalkeada.idade +" anos";
        }else{
           $scope.infosstalkeada.idade ='';
        }
    });
    var header = document.getElementById("barperfiloutroev");
    var btns = header.getElementsByClassName("btnperfilotro");
    for (var i = 0; i < btns.length; i++) {
      btns[i].addEventListener("click", function() {
        var current = document.getElementsByClassName("actpa");
        current[0].className = current[0].className.replace(" actpa", "");
        this.className += " actpa";
      });
    }

   

    EventoService.GetPontos($scope.stalkeada.iduser).then(function(items) {
        $scope.p = items;
        $scope.labels3 = ["Pontos"];
        $scope.colores3 = ["#ff4d4d"];
        $scope.data3 = [$scope.p];
      });
      EventoService.getIC($scope.stalkeada).then(function(items) {
        if(items){
          $scope.ic = items;
          $scope.options2 = {title: {
                      display: true,
                      text: 'Indice de confirmação',
                      position: 'bottom'
                  }
           }
          $scope.labels2 = ["Fui", "Não fui"];
          $scope.colores2 = ["#99FF99","#ff4d4d"];
          var menos = (100-$scope.ic.total).toFixed(1);
          var mais = $scope.ic.total;
          $scope.data2 = [mais, menos ];
        }
      });
      console.log('antes', $scope.stalkeada.iduser)
      EventoService.GetComments3($scope.stalkeada).then(function(items) {
        
          $scope.options1 = {title: {
                    display: true,
                    text: 'Avaliações',
                    position: 'bottom'
                }
         }
          $scope.labels1 = ["Extrovertido", "Introvertido", "Realista","Curioso", "Solidário", "Racional","Organizado", "Criativo"];
          $scope.colores1 = ["#fff200", "#02fff2", "#ff9d00","#1867ce", "#e50be1", "#0e8c28","#ef370e", "#af0eef"];
          $scope.data1 =items.chart;
        
      }); 


    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/geteventoporid.php', {idevento :  $scope.aux.idevento}).then(function (result){
      $scope.infoevento = result.data[0];
    });

    $scope.comentario = function(){
      formStalker.updateForm($scope.stalkeada);
      $state.go('comentariosperfilaceitar');
    }
    
    $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/getpessoaevento.php", {iduser : $scope.outro,
                                                                    estado : '3'}).then(function(response) {
      pontos = response.data[0];
      if (pontos=='E') {
        $scope.neventos = parseFloat(0);
      }else{
         $scope.neventos =parseFloat(pontos.length);
      }
      for(var i=0;i<pontos.length;i++){
        $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/geteventopessoaevento.php", {idevento : pontos[i].idevento,
                                                                              estado : '3'}).then(function(response) {
          var novo = response.data[0];
          for(var j=0 ;j<response.data[0].length;j++){
            if (novo[j].iduser == $scope.user.iduser && !$scope.desseguirbutton && $scope.outro != $scope.user.iduser) {
              $scope.followbutton = true;
              //console.log('fui no evento com este cara e nao sigo', $scope.outro , $scope.user.iduser);
            }
          }
        });
      }
    });   

    if(parseInt($scope.infoevento.patual)>=parseInt($scope.infoevento.pmax)){
      var alertPopup = $ionicPopup.alert({
                      title: ' ٩( ᐛ )و ',
                      template: 'Evento é um sucesso, mas o numero máximo de pessoas foi atingido. Como o evento é seu, tu pode confirmar essa pessoa mesmo assim'
                    });
    }                                                                

    $scope.$on("$ionicView.enter", function(event, data){
      $scope.items = [];
      $scope.vezes = 0;
      $scope.newItems = [];
      $scope.noMoreItemsAvailable = false;
      $scope.lastidevento = 0;
      $scope.aux2 = 0;
      $scope.aux = formAux.getAux();
      $scope.user = formUser.getForm();
      $scope.stalkeada = {}; 
      $scope.stalkeada.iduser = $scope.aux.id_user_envia;
      $scope.stalkeada.username = $scope.aux.username_envia;
      $scope.CoisasCriado = true;
      $scope.CoisasFinalizado = false;
      $scope.pushnoti = {};
      $scope.infosstalkeada ={};
      EventoService.GetStalkear($scope.aux.id_user_envia).then(function(stalker) {
          $scope.infosstalkeada = stalker;
          if($scope.infosstalkeada.profilepic[8] == 's' && $scope.infosstalkeada.profilepic[9] == '3'){
             document.getElementById("imageidperfilAceitar").src=$scope.infosstalkeada.profilepic+"?{{getTimeStamp()}}";
           }else{
             document.getElementById("imageidperfilAceitar").src=$scope.infosstalkeada.profilepic;
           }
         //document.getElementById("imageidperfilAceitar").src=$scope.infosstalkeada.profilepic+"?{{getTimeStamp()}}";
          $scope.frase = stalker.frase;
           if(stalker.borda == 0){
          $scope.estrelabb = false;
          $scope.estrelabs = false;
          $scope.estrelabg = false;
        }
        if(stalker.borda == 1){
          $scope.estrelabb = true;
          $scope.estrelabs = false;
          $scope.estrelabg = false;
        }
        if(stalker.borda == 2){
          $scope.estrelabb = false;
          $scope.estrelabs = true;
          $scope.estrelabg = false;
        }
        if(stalker.borda == 3){
          $scope.estrelabb = false;
          $scope.estrelabs = false;
          $scope.estrelabg = true;
        }
          if($scope.infosstalkeada.idade){
            $scope.infosstalkeada.idade = ", "+ $scope.infosstalkeada.idade +" anos";
          }else{
             $scope.infosstalkeada.idade ='';
          }

        EventoService.GetCriados($scope.stalkeada).then(function(items) {
          if(items == 'E'){
            $scope.items = [];
          }else{
            for (var i = 0; i < items.length; i++) {
                var curr_date = (items[i].diainicio[8]+items[i].diainicio[9]);
                var h2 = (items[i].diainicio[11]+items[i].diainicio[12]);
                var m2 = (items[i].diainicio[14]+items[i].diainicio[15]);
                var curr_month = (items[i].diainicio[5]+items[i].diainicio[6]);
                var curr_year = (items[i].diainicio[0]+items[i].diainicio[1]+items[i].diainicio[2]+items[i].diainicio[3]);
                var j = curr_date + "/" + curr_month + "/" + curr_year+ ' '+h2 + ':' + m2;
                items[i].datainicio = j;
                if(items[i].estado == 0){
                  items[i].confirmacao = "Vai acontecer"
                }
                if(items[i].estado == 1){
                  items[i].confirmacao = "Finalizado"
                }
                if(items[i].estado == 2){
                  items[i].confirmacao = "Standy by, talvez aconteça"
                }
                if(items[i].estado == 3){
                  items[i].confirmacao = "Vai acontecer"
                }
                if(items[i].estado == 4){
                  items[i].confirmacao = "Cancelado"
                }
                if(items[i].estado == 5){
                  items[i].confirmacao = "Acabado"
                }
                if(items[i].estado == 6){
                  items[i].confirmacao = "Escondido"
                }
            }
            $scope.items = items.concat($scope.items);
            $scope.lastidvestido = $scope.items[0].idevento;
          }
        });
      });

      $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/geteventoporid.php', {idevento :  $scope.aux.idevento}).then(function (result){
        $scope.infoevento = result.data[0];
      });

      if(parseInt($scope.infoevento.patual)>=parseInt($scope.infoevento.pmax)){
        var alertPopup = $ionicPopup.alert({
                      title: ' ٩( ᐛ )و ',
                      template: 'Evento é um sucesso, mas o numero máximo de pessoas foi atingido. Como o evento é seu, tu pode confirmar essa pessoa mesmo assim'
        });
      }  

      EventoService.GetPontos($scope.stalkeada.iduser).then(function(items) {
        $scope.p = items;
        $scope.labels3 = ["Pontos"];
        $scope.colores3 = ["#ff4d4d"];
        $scope.data3 = [$scope.p];
      });
      EventoService.getIC($scope.stalkeada).then(function(items) {
        if(items){
          $scope.ic = items;
          $scope.options2 = {title: {
                      display: true,
                      text: 'Indice de confirmação',
                      position: 'bottom'
                  }
           }
          $scope.labels2 = ["Fui", "Não fui"];
          $scope.colores2 = ["#99FF99","#ff4d4d"];
          var menos = (100-$scope.ic.total).toFixed(1);
          var mais = $scope.ic.total;
          $scope.data2 = [mais, menos ];
        }
      });
      console.log('antes', $scope.stalkeada.iduser)
      EventoService.GetComments3($scope.stalkeada).then(function(items) {
        
          $scope.options1 = {title: {
                    display: true,
                    text: 'Avaliações',
                    position: 'bottom'
                }
         }
          $scope.labels1 = ["Extrovertido", "Introvertido", "Realista","Curioso", "Solidário", "Racional","Organizado", "Criativo"];
          $scope.colores1 = ["#fff200", "#02fff2", "#ff9d00","#1867ce", "#e50be1", "#0e8c28","#ef370e", "#af0eef"];
          $scope.data1 =items.chart;
        
      }); 


      $scope.stalkeada.diainicio = $scope.infoevento.diainicio ;
      $scope.stalkeada.diafim = $scope.infoevento.diafim ;
      EventoService.verificahorariopessoaeventoaguardando($scope.stalkeada).then(function(items) {
        $scope.auxdata = items;
      });
                      //Para ver se eu ja sigo esta pessoa ou não.
      $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/getpessoaevento.php", {iduser : $scope.outro,
                                                                       estado : '3'}).then(function(response) {
                  pontos = response.data[0];
                  if (pontos=='E') {
                    $scope.neventos = parseFloat(0);
                  }else{
                    $scope.neventos =parseFloat(pontos.length);
                  }
                  for(var i=0;i<pontos.length;i++){
                          $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/geteventopessoaevento.php", {idevento : pontos[i].idevento,
                                                                              estado : '3'}).then(function(response) {
                                var novo = response.data[0];
                                for(var j=0 ;j<response.data[0].length;j++){
                                  if (novo[j].iduser == $scope.user.iduser && !$scope.desseguirbutton && $scope.outro != $scope.user.iduser) {
                                    $scope.followbutton = true;
                                    //console.log('fui no evento com este cara e nao sigo', $scope.outro , $scope.user.iduser);
                                  }
                                }
                          });
                  }
      });   
    });

    $scope.entrar = function(){
        formUser.updateForm($scope.aux);
        $state.go('tabsController.comentarios');

    }
    
    $scope.aceitar =  function(){
      $scope.aux.aceito = 2;
      $scope.aux.confirmacao = 'Confirmação aceita';
      $scope.msgnoti = ('Tu foi aceito no evento: ' + $scope.aux.nomeevento);
      //console.log($scope.msgnoti);
      EventoService.atualizarpessoaeventosconfirma($scope.auxdata);
      EventoService.atualizarpessoaevento($scope.aux).then(function(msg){
        var alertPopup = $ionicPopup.alert({
                title: 'Enviando confirmação',
                template: 'Vamos avisar para não se esquecer de comparecer no evento'
              });
        $scope.infoevento.patual = parseInt($scope.infoevento.patual)+1;
        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/addpessoaevento.php', {idevento : $scope.aux.idevento,
                                                                          patual : $scope.infoevento.patual});
        noti.recebeusername = $scope.infosstalkeada.username;
        noti.recebe = $scope.aux.id_user_envia;
        noti.envia = $scope.aux.id_user_recebe;
        noti.tipo = 2;
        noti.nomeevento = $scope.aux.nomeevento;
        EventoService.VerificaNotificacao(noti).then(function(res) {
          if(res){
            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : $scope.msgnoti, 
                          idevento : $scope.aux.idevento,
                          nomeevento : $scope.aux.nomeevento,
                          id_user_envia : $scope.aux.id_user_recebe,
                          username_envia : $scope.user.username,
                          apelido_envia : $scope.user.apelido,
                          tipo : '2',
                          id_user_recebe : $scope.aux.id_user_envia});
           EventoService.getusuario2(noti.recebeusername).then(function(user) {
              $scope.pushnoti.titulo =  'Boraaa!!!' ;
              $scope.pushnoti.msg = $scope.msgnoti;
              $scope.pushnoti.token = user.devicetoken;
               EventoService.MandaPushNoti($scope.pushnoti);
            });
          }
        });
        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacao.php', {idnotificacao : $scope.aux.idnotificacao});
          alertPopup.then(function(){
            $state.go('tabsController.notificaEs');
          })
      }, function(errMsg) {
            var alertPopup = $ionicPopup.alert({
              title: 'Register failed!',
              template: errMsg
            });
      })  
    }

    $scope.recusar =  function(){
           var confirmPopup = $ionicPopup.show({
                   title: 'ATENÇÃO!!!',
                   template: 'Ao recusar esta pessoa não poderá mais entrar neste evento, tens certeza disso?',
                   buttons: [
                      { text: 'Não',
                        type: 'button-assertive'},
                      {
                        text: 'Sim',
                        type: 'button-positive',
                        onTap: function(e){
                        $scope.msgnoti = ('Tu foi negado pra comparecer nome evento: ' + $scope.aux.nomeevento + ', mas segue o day');
                        console.log($scope.msgnoti);
              noti.recebeusername = $scope.infosstalkeada.username;
              noti.recebe = $scope.aux.id_user_envia;
              noti.envia = $scope.aux.id_user_recebe;
              noti.tipo = 3;
              noti.nomeevento = $scope.aux.nomeevento;
              EventoService.VerificaNotificacao(noti).then(function(res) {
                console.log(res);
                if(res){
                  $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : $scope.msgnoti, 
                                idevento : $scope.aux.idevento,
                                nomeevento : $scope.aux.nomeevento,
                                id_user_envia : $scope.aux.id_user_recebe,
                                username_envia : $scope.user.username,
                                apelido_envia : $scope.aux.apelido,
                                tipo : '3',
                                id_user_recebe : $scope.aux.id_user_envia});
                  $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacao.php', {idnotificacao : $scope.aux.idnotificacao});
                  EventoService.getusuario2(noti.recebeusername).then(function(user) {
                    $scope.pushnoti.titulo = $scope.evento.nomeevento + ' negado';
                    $scope.pushnoti.msg = $scope.msgnoti;
                    $scope.pushnoti.token = user.devicetoken;
                     EventoService.MandaPushNoti($scope.pushnoti);
                  });
                }
              });
              $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser : $scope.aux.id_user_envia,
                                                                                  idevento : $scope.aux.idevento,
                                                                                  estado: '1'});
              $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletachat.php', {iduser : $scope.aux.id_user_envia,
                                                                            idevento : $scope.aux.idevento  });
              $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/pessoanaoevento.php', {iduser : $scope.aux.id_user_envia, 
                                                                                idevento : $scope.aux.idevento,
                                                                                nomeevento : $scope.aux.nomeevento,
                                                                                estado : '2'});//foi nao foi aceito
              $state.go('tabsController.notificaEs');
                             }
                      }
                           ]
                   })
    }

    $scope.loadCriados = function() {
      $scope.CoisasCriado = true;
    $scope.CoisasFinalizado = false;
        $scope.estadobutton = 0;
        $scope.items = [];
        EventoService.GetCriados($scope.stalkeada).then(function(items) {
          if(items == 'E'){
            $scope.items = [];
          }else{
            for (var i = 0; i < items.length; i++) {
                var curr_date = (items[i].diainicio[8]+items[i].diainicio[9]);
                var h2 = (items[i].diainicio[11]+items[i].diainicio[12]);
                var m2 = (items[i].diainicio[14]+items[i].diainicio[15]);
                var curr_month = (items[i].diainicio[5]+items[i].diainicio[6]);
                var curr_year = (items[i].diainicio[0]+items[i].diainicio[1]+items[i].diainicio[2]+items[i].diainicio[3]);
                var j = curr_date + "/" + curr_month + "/" + curr_year+ ' '+h2 + ':' + m2;
                items[i].datainicio = j;
                if(items[i].estado == 0){
                  items[i].confirmacao = "Vai acontecer"
                }
                if(items[i].estado == 1){
                  items[i].confirmacao = "Finalizado"
                }
                if(items[i].estado == 2){
                  items[i].confirmacao = "Standy by, talvez aconteça"
                }
                if(items[i].estado == 3){
                  items[i].confirmacao = "Vai acontecer"
                }
                if(items[i].estado == 4){
                  items[i].confirmacao = "Cancelado"
                }
                if(items[i].estado == 5){
                  items[i].confirmacao = "Acabado"
                }
                if(items[i].estado == 6){
                  items[i].confirmacao = "Escondido"
                }
            }
            $scope.items = items.concat($scope.items);
            $scope.lastidvestido = $scope.items[0].idevento;
          }
        });
    }
    
    $scope.loadAbertos = function() {
      $scope.CoisasCriado = false;
    $scope.CoisasFinalizado = true;
        $scope.estadobutton = 1;
        $scope.items = [];
        EventoService.GetAbertos($scope.stalkeada.iduser).then(function(items) {  //mudar
          if(items == 'E'){
            $scope.items = [];
          }else{
            for (var i = 0; i < items.length; i++) {
                var curr_date = (items[i].diainicio[8]+items[i].diainicio[9]);
                var h2 = (items[i].diainicio[11]+items[i].diainicio[12]);
                var m2 = (items[i].diainicio[14]+items[i].diainicio[15]);
                var curr_month = (items[i].diainicio[5]+items[i].diainicio[6]);
                var curr_year = (items[i].diainicio[0]+items[i].diainicio[1]+items[i].diainicio[2]+items[i].diainicio[3]);
                var j = curr_date + "/" + curr_month + "/" + curr_year+ ' '+h2 + ':' + m2;
                items[i].datainicio = j;
            }
            $scope.items = items.concat($scope.items);
            $scope.lastidvestido = $scope.items[0].idevento;
          }
        });
    }
    
    $scope.loadFechados = function() {
      $scope.CoisasCriado = false;
    $scope.CoisasFinalizado = true;
        $scope.estadobutton = 2;
        $scope.items = [];
        EventoService.GetFinalizadosPerfil($scope.stalkeada.iduser).then(function(items) {         //mudar
          if(items =='E'){
            $scope.items = [];
          }else{
            for (var i = 0; i < items.length; i++) {
                var curr_date = (items[i].diainicio[8]+items[i].diainicio[9]);
                var h2 = (items[i].diainicio[11]+items[i].diainicio[12]);
                var m2 = (items[i].diainicio[14]+items[i].diainicio[15]);
                var curr_month = (items[i].diainicio[5]+items[i].diainicio[6]);
                var curr_year = (items[i].diainicio[0]+items[i].diainicio[1]+items[i].diainicio[2]+items[i].diainicio[3]);
                var j = curr_date + "/" + curr_month + "/" + curr_year+ ' '+h2 + ':' + m2;
                items[i].datainicio = j;
            }
            $scope.items = items.concat($scope.items);
            $scope.lastidvestido = $scope.items[0].idevento;
          }
        });      
    }
    
    $scope.loadMore = function() {
      if ($scope.estadobutton == 0) {
        EventoService.GetOldEventosCriados().then(function(items) {
        $scope.items = $scope.items.concat(items);
        $scope.$broadcast('scroll.infiniteScrollComplete');
          if (items.length <= 4) {
            $scope.noMoreItemsAvailable = true;
          }

        });
      }
      if ($scope.estadobutton == 1) {
        EventoService.GetOldEventosCriados().then(function(items) {
        $scope.items = $scope.items.concat(items);
        $scope.$broadcast('scroll.infiniteScrollComplete');
          if (items.length <= 4) {
            $scope.noMoreItemsAvailable = true;
          }
        });

        
      }
      if ($scope.estadobutton == 2) {
        EventoService.GetOldEventosCriados().then(function(items) {
        $scope.items = $scope.items.concat(items);
        $scope.$broadcast('scroll.infiniteScrollComplete');
          if (items.length <= 4) {
            $scope.noMoreItemsAvailable = true;
          }
        });

      
      }
    }

}])
   
.controller('eventoCriadoCtrl', ['$scope', '$stateParams', 'formItem', 'formUser', 'formOutro', '$http', '$timeout','$ionicPopup', 'EventoService', '$state', 'formEditar', 'formEventoPerfil', 'formEventoEditaperfil',// The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, formItem, formUser, formOutro, $http, $timeout, $ionicPopup, EventoService, $state, formEditar, formEventoPerfil, formEventoEditaperfil) {
    //$scope.evento = formItem.getForm();
    $scope.evento = formEventoPerfil.getForm();
    
    console.log($scope.evento.nomeevento);
    $scope.aux = formUser.getForm();
    $scope.EditEvento = true;
    $scope.desisti = true;
    $scope.repete = false;
    $scope.data = {};
    $scope.nuser = 0;
    $scope.items = [];
    var noti = {};
    $scope.limiteconfirmacao ={};
    $scope.fim = {};
    $scope.dia = {};
    $scope.pushnoti = {};
    //console.log($scope.aux.iduser);

    if ($scope.evento.estado == 1 || $scope.evento.estado == 5) {
      console.log('éstado 1');
      $scope.EditEvento = false;
      $scope.repete = true;
      $scope.desisti = false;
    }else{
       console.log('éstado 0');
      $scope.EditEvento = true;
          $scope.repete = false;
    }
    if($scope.evento.genero == "masc"){
      $scope.masc = true;
      $scope.fem = false;
    }
    if($scope.evento.genero == "fem"){
        $scope.fem = true;
        $scope.masc = false;
    }
    if($scope.evento.genero == "todos"){
        $scope.fem = false;
        $scope.masc = false;
    }
    if($scope.evento.preco == 0 || $scope.evento.preco =="Gratuito"){
      $scope.evento.preco = "Gratuito";
      $scope.porpessoa = false;
      $scope.porlocal = false;
    }else{
      if($scope.evento.precopor == 1){
        $scope.porpessoa = true;
        $scope.porlocal = false;
      }else{
        $scope.porpessoa = false;
        $scope.porlocal = true;
      }
    }
    
    EventoService.GetParticipantes($scope.evento.idevento).then(function(items) {
      $scope.nomeevento = items[0].nomeevento;
       for (var i = 0; i < items.length; i++) {
        if(items[i].iduser == $scope.aux.iduser){
                    if(items[i].estado =='9'){
                     $scope.ocultabotao = false;
                    }else{
                      $scope.ocultabotao = true;
                    }
                  }
        if ($scope.aux.iduser != items[i].iduser) {
          $scope.nuser++;
        }
        if (items[i].estado == 0) {
          items[i].confirmacao = 'Sou o organizador';
        }
        if (items[i].estado == 1) {
          items[i].confirmacao = 'Aguardando confirmação';
        }
        if (items[i].estado == 2) {
          items[i].confirmacao = 'Confirmação aprovada';
        }
        if(items[i].borda == 0){
            items[i].bb = false;
            items[i].bs = false;
            items[i].bg = false;
          }
          if(items[i].borda == 1){
            items[i].bb = true;
            items[i].bs = false;
            items[i].bg = false;
          }
          if(items[i].borda == 2){
            items[i].bb = false;
            items[i].bs = true;
            items[i].bg = false;
          }
          if(items[i].borda == 3){
            items[i].bb = false;
            items[i].bs = false;
            items[i].bg = true;
          }
          if(items[i].profilepic[8] == 's' && items[i].profilepic[9] == '3'){
             items[i].profilepic=items[i].profilepic+"?{{getTimeStamp()}}";
           }else{
             items[i].profilepic=items[i].profilepic;
           }
          //items[i].profilepic = items[i].profilepic+"?{{getTimeStamp()}}";
      }
      $scope.items = items.concat($scope.items);
    });
    
    $scope.tag = '';

    var hj = new Date();
    var currentdate = new Date(); 
    var curr_date = (currentdate.getDate()<10?'0':'') + currentdate.getDate();
    var curr_month = (currentdate.getMonth()<10?'0':'') + (currentdate.getMonth() + 1); //Months are zero based
    var curr_year = currentdate.getFullYear();
    var h2 = (currentdate.getHours()<10?'0':'') + currentdate.getHours();
    var m2 = (currentdate.getMinutes()<10?'0':'') + currentdate.getMinutes();
    
    hj = $scope.evento.diainicio;
    
    var ano = (hj[0]+hj[1]+hj[2]+hj[3]).valueOf()-curr_year;
    var mes = (hj[5]+hj[6]).valueOf()-curr_month;
    var dia = (hj[8]+hj[9]).valueOf()-curr_date;
    var h = (hj[11]+hj[12]).valueOf()-h2;
    var m = (hj[14]+hj[15]).valueOf()-m2;
    
    //$scope.dia = (hj[8]+hj[9]).valueOf()+'/'+(hj[5]+hj[6]).valueOf()+'/'+(hj[0]+hj[1]+hj[2]+hj[3])+' '+(hj[11]+hj[12]).valueOf()+':'+(hj[14]+hj[15]).valueOf();

    var  hjl = $scope.evento.dialimiteconfirmacao;
    var anol = (hjl[0]+hjl[1]+hjl[2]+hjl[3]).valueOf()-curr_year;
    var mesl = (hjl[5]+hjl[6]).valueOf()-curr_month;
    var dial = (hjl[8]+hjl[9]).valueOf()-curr_date;
    var hl = (hjl[11]+hjl[12]).valueOf()-h2;
    var ml = (hjl[14]+hjl[15]).valueOf()-m2;

    $scope.dialimiteconfirmacao =  (hjl[8]+hjl[9]).valueOf()+'/'+(hjl[5]+hjl[6]).valueOf()+'/'+(hjl[0]+hjl[1]+hjl[2]+hjl[3])+' '+(hjl[11]+hjl[12]).valueOf()+':'+(hjl[14]+hjl[15]).valueOf();
  
    var hjd = $scope.evento.duracao;
    var hd = (hjd[0]+hjd[1]).valueOf();
    var md = (hjd[3]+hjd[4]).valueOf();
    $scope.duracao= hd+':'+md;

    var  hjl = $scope.evento.dialimiteconfirmacao;
    $scope.limiteconfirmacao.dia =  (hjl[8]+hjl[9]).valueOf()+'/'+(hjl[5]+hjl[6]).valueOf();
    $scope.limiteconfirmacao.hora =  (hjl[11]+hjl[12]).valueOf()+':'+(hjl[14]+hjl[15]).valueOf();  
    
    

    var hjf = $scope.evento.diafim;
    $scope.fim.dia =  (hjf[8]+hjf[9]).valueOf()+'/'+(hjf[5]+hjf[6]).valueOf()+'/'+(hjf[0]+hjf[1]+hjf[2]+hjf[3]);
    $scope.fim.hora = (hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf();
    $scope.dia.dia = (hj[8]+hj[9]).valueOf()+'/'+(hj[5]+hj[6]).valueOf();
    $scope.dia.hora = (hj[11]+hj[12]).valueOf()+':'+(hj[14]+hj[15]).valueOf() +' - '+(hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf() ;


    $scope.diafim =  (hjf[8]+hjf[9]).valueOf()+'/'+(hjf[5]+hjf[6]).valueOf()+'/'+(hjf[0]+hjf[1]+hjf[2]+hjf[3])+' '+(hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf();
    

     EventoService.Gettags($scope.evento.idevento).then(function(tags) {
        for(var  i =0; i< tags.length;i++){
          $scope.tag = ($scope.tag + ' ' + tags[i].tag);
        } 
     });


    var zone;

          // YELLOW ZONE qualquer pessoa confirmada por confirmar a pessoa que nao foi confirmada
    if(anol == 0 && mesl == 0 && dial == 0 && ((hl == 1 && ml<30 && ml>0)||(hl==0 && ml > 30)|| (hl==1 && ml>-30))){
      console.log('YELLOW-ZONE');
       $scope.EditEvento =true;
       zone = 'yellow';
    }
          // RED ZONE 
    if(anol<0 || mesl < 0 ||(anol == 0 && mesl == 0 && (dial < 0 || (dial==0 && ((hl == 0 && ml<=0)||(hl < 0)))))){
      console.log('RED-ZONE');
      $scope.EditEvento =false;
      zone = 'red';
    }
    if((anol == 0 && mesl <= 0 && dial < -1 )||(ano<0)){
      console.log('BLACK-ZONE');
      $scope.EditEvento =false;
      zone = 'black';
    }

    $scope.$on("$ionicView.enter", function(event, data){
      //$scope.evento = formItem.getForm();
      $scope.evento = formEventoPerfil.getForm();
      
      $scope.tag = '';
      $scope.pushnoti = {};
      EventoService.Gettags($scope.evento.idevento).then(function(tags) {
        for(var  i =0; i< tags.length;i++){
          $scope.tag = ($scope.tag + ' ' + tags[i].tag);
        } 
      });

      var hj = new Date();
      var currentdate = new Date(); 
      var curr_date = (currentdate.getDate()<10?'0':'') + currentdate.getDate();
      var curr_month = (currentdate.getMonth()<10?'0':'') + (currentdate.getMonth() + 1); //Months are zero based
      var curr_year = currentdate.getFullYear();
      var h2 = (currentdate.getHours()<10?'0':'') + currentdate.getHours();
      var m2 = (currentdate.getMinutes()<10?'0':'') + currentdate.getMinutes();
      
      hj = $scope.evento.diainicio;
      
      var ano = (hj[0]+hj[1]+hj[2]+hj[3]).valueOf()-curr_year;
      var mes = (hj[5]+hj[6]).valueOf()-curr_month;
      var dia = (hj[8]+hj[9]).valueOf()-curr_date;
      var h = (hj[11]+hj[12]).valueOf()-h2;
      var m = (hj[14]+hj[15]).valueOf()-m2;
      
      //$scope.dia = (hj[8]+hj[9]).valueOf()+'/'+(hj[5]+hj[6]).valueOf()+'/'+(hj[0]+hj[1]+hj[2]+hj[3])+' '+(hj[11]+hj[12]).valueOf()+':'+(hj[14]+hj[15]).valueOf();

      var  hjl = $scope.evento.dialimiteconfirmacao;
      var anol = (hjl[0]+hjl[1]+hjl[2]+hjl[3]).valueOf()-curr_year;
      var mesl = (hjl[5]+hjl[6]).valueOf()-curr_month;
      var dial = (hjl[8]+hjl[9]).valueOf()-curr_date;
      var hl = (hjl[11]+hjl[12]).valueOf()-h2;
      var ml = (hjl[14]+hjl[15]).valueOf()-m2;

      $scope.dialimiteconfirmacao =  (hjl[8]+hjl[9]).valueOf()+'/'+(hjl[5]+hjl[6]).valueOf()+'/'+(hjl[0]+hjl[1]+hjl[2]+hjl[3])+' '+(hjl[11]+hjl[12]).valueOf()+':'+(hjl[14]+hjl[15]).valueOf();
    
      var hjf = $scope.evento.diafim;

      $scope.diafim =  (hjf[8]+hjf[9]).valueOf()+'/'+(hjf[5]+hjf[6]).valueOf()+'/'+(hjf[0]+hjf[1]+hjf[2]+hjf[3])+' '+(hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf();
      var hjd = $scope.evento.duracao;
      var hd = (hjd[0]+hjd[1]).valueOf();
      var md = (hjd[3]+hjd[4]).valueOf();
      $scope.duracao= hd+':'+md;

      var  hjl = $scope.evento.dialimiteconfirmacao;
      $scope.limiteconfirmacao.dia =  (hjl[8]+hjl[9]).valueOf()+'/'+(hjl[5]+hjl[6]).valueOf();
      $scope.limiteconfirmacao.hora =  (hjl[11]+hjl[12]).valueOf()+':'+(hjl[14]+hjl[15]).valueOf();  
      
      

      var hjf = $scope.evento.diafim;
      $scope.fim.dia =  (hjf[8]+hjf[9]).valueOf()+'/'+(hjf[5]+hjf[6]).valueOf()+'/'+(hjf[0]+hjf[1]+hjf[2]+hjf[3]);
      $scope.fim.hora = (hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf();
      $scope.dia.dia = (hj[8]+hj[9]).valueOf()+'/'+(hj[5]+hj[6]).valueOf();
      $scope.dia.hora = (hj[11]+hj[12]).valueOf()+':'+(hj[14]+hj[15]).valueOf() +' - '+(hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf() ;


      var zone;
          // YELLOW ZONE qualquer pessoa confirmada por confirmar a pessoa que nao foi confirmada
      if(anol == 0 && mesl == 0 && dial == 0 && ((hl == 1 && ml<30 && ml>0)||(hl==0 && ml > 30)|| (hl==1 && ml>-30))){
        console.log('YELLOW-ZONE');
         $scope.EditEvento =true;
         zone = 'yellow';
      }
            // RED ZONE 
      if(anol<0 || mesl < 0 ||(anol == 0 && mesl == 0 && (dial < 0 || (dial==0 && ((hl == 0 && ml<=0)||(hl < 0)))))){
        console.log('RED-ZONE');
        $scope.EditEvento =false;
        zone = 'red';
      }
      if((anol == 0 && mesl <= 0 && dial < -1 )||(ano<0)){
      console.log('BLACK-ZONE');
      $scope.EditEvento =false;
      zone = 'black';
    }

    });
    
    // $scope.Ocultar =  function(evento){
    //   $scope.ocultabotao = false;
    //   $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/ocultarpessoaevento.php", {idevento : evento.idevento,
    //                                                                       iduser: $scope.aux.iduser,
    //                                                                       estado : 9});
    //   $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/ocultarevento.php", {idevento : evento.idevento,
    //                                                                  estado : 6});
    // }
    // $scope.DESOcultar =  function(evento){
    //   $scope.ocultabotao = true;
    //   $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/ocultarpessoaevento.php", {idevento : evento.idevento,
    //                                                                       iduser: $scope.aux.iduser,
    //                                                                       estado : 3});
    //   if(zone == 'black' ){
    //     $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/ocultarevento.php", {idevento : evento.idevento,
    //                                                                  estado : 5});
    //   }else{
    //     $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/ocultarevento.php", {idevento : evento.idevento,
    //                                                                  estado : 0});
    //   }
      
    // }
    //     });
    $scope.desistir = function(){
      if(zone == 'red' || zone == 'yellow'){
                          if(zone == 'red' ){
                             var myPopup = $ionicPopup.show({
                                template: '<input type="text" placeholder="Escreva aqui pq nao vai rolar" ng-model="data.desculpa">',
                                title: 'ATENÇÃOOOO!!!',
                                subTitle: 'Você esta preste a cancelar seu evento faltando muito pouco para seu começo, tens certeza disso?. Se tu realmente cancelar estaremos te dando um cartão vermelho. Para saber mais sobre eles va no seu indice de confirmação',
                                scope: $scope,
                                buttons: [
                                  { text: 'Não' },
                                  {
                                    text: '<b>Sim</b>',
                                    type: 'button-positive',
                                    onTap: function(e) {
                                      // console.log($scope.items.length);
                                       var notifica = ("Desisti de fazer o evento, " + $scope.data.desculpa);
                                        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacaoporevento.php' , {idevento : $scope.evento.idevento,
                                                                                                    nomeevento : $scope.evento.nomeevento}).then(function(response) {console.log(response, 'deleta')});
                                     
                                   for (var i = 0; i < $scope.items.length; i++) {
                                    if ($scope.aux.iduser != $scope.items[i].iduser) {
                                          noti.recebeusername = $scope.items[i].username;
                                          noti.recebe = $scope.items[i].iduser;
                                          noti.envia = $scope.aux.iduser;
                                          noti.tipo = 4;
                                          noti.nomeevento = $scope.evento.nomeevento;
                                         console.log('enviando msg', $scope.evento.idevento,noti.envia, noti.recebe, noti.nomeevento, notifica)
                                        
                                            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : notifica, 
                                                    idevento : $scope.evento.idevento,
                                                    nomeevento : $scope.evento.nomeevento,
                                                    id_user_envia : $scope.aux.iduser,
                                                    username_envia : $scope.aux.username,
                                                    apelido_envia : $scope.aux.apelido,
                                                    tipo : '5',   
                                                    id_user_recebe : noti.recebe}).then(function (res){
                                                   $scope.response = res.data;
                                                   console.log($scope.response.msg)
                                                 });
                                            EventoService.getusuario2(noti.recebeusername).then(function(user) {
                                              $scope.pushnoti.titulo = $scope.evento.nomeevento + ' Cancelado';
                                              $scope.pushnoti.msg = notifica;
                                              $scope.pushnoti.token = user.devicetoken;
                                               EventoService.MandaPushNoti($scope.pushnoti);
                                            });
                                    }
                                  }

                                      for(var i = 0; i< $scope.items.length; i++){
                      
                                        
                                        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser : $scope.items[i].iduser,
                                                                                                           idevento : $scope.evento.idevento});
                                      }

                                         $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/penalidade.php', {iduser : $scope.aux.iduser,
                                                                                                     idevento : $scope.evento.idevento,
                                                                                                     username : $scope.aux.username,
                                                                                                     tipopenalidade : '2'});     // tipo2 saiu na redzone         
                                       $scope.evento.estado = "3";                
                                     EventoService.atualizarevento($scope.evento);
                                                          $state.go('tabsController.perfil');
                                                          }
                                  }]
                                 });

                                      console.log('criador do evento cancelando proprio evento');
                       }else{
                             var myPopup = $ionicPopup.show({
                                template: '<input type="text" placeholder="Escreva aqui pq nao vai rolar" ng-model="data.desculpa">',
                                title: 'ATENÇÃO!!!',
                                subTitle: 'Você esta preste a cancelar seu evento faltando pouco para seu começo, tens certeza disso?. Se tu realmente cancelar estaremos te dando um cartão amarelo. Para saber mais sobre eles va no seu indice de confirmação',
                                scope: $scope,
                                buttons: [
                                  { text: 'Não' },
                                  {
                                    text: '<b>Sim</b>',
                                    type: 'button-positive',
                                    onTap: function(e) {
                                      // console.log($scope.items.length);
                                       var notifica = ("Desisti de fazer o evento, " + $scope.data.desculpa);
                                      // console.log(notifica);
                                      // console.log($scope.aux.iduser);
                                     $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacaoporevento.php' , {idevento : $scope.evento.idevento,
                                                                                                    nomeevento : $scope.evento.nomeevento}).then(function(response) {console.log(response, 'deleta')});
                                      EventoService.GetParticipantes($scope.evento.idevento).then(function(ppl) {
                                   for (var i = 0; i < ppl.length; i++) {
                                    if ($scope.aux.iduser != ppl[i].iduser) {
                                          noti.recebeusername = ppl[i].username;
                                          noti.recebe = ppl[i].iduser;
                                          noti.envia = $scope.aux.iduser;
                                          noti.tipo = 4;
                                          noti.nomeevento = $scope.evento.nomeevento;
                                          EventoService.VerificaNotificacao(noti).then(function(res) {
                                            console.log(res);
                                            if(res){
                                            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : notifica, 
                                                    idevento : $scope.evento.idevento,
                                                    nomeevento : $scope.evento.nomeevento,
                                                    id_user_envia : $scope.aux.iduser,
                                                    username_envia : $scope.aux.username,
                                                    apelido_envia : $scope.aux.apelido,
                                                    tipo : '5',   
                                                    id_user_recebe : noti.recebe}).then(function (res){
                                                   $scope.response = res.data;
                                                   console.log($scope.response.msg)
                                                 });
                                            EventoService.getusuario2(noti.recebeusername).then(function(user) {
                                              $scope.pushnoti.titulo = $scope.evento.nomeevento + ' Cancelado';
                                              $scope.pushnoti.msg = notifica;
                                              $scope.pushnoti.token = user.devicetoken;
                                               EventoService.MandaPushNoti($scope.pushnoti);
                                            });
                                    }
                                  });
                                        }
                                  }
                                 })
                                      for(var i = 0; i< $scope.items.length; i++){
                               
                                        
                                        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser : $scope.items[i].iduser,
                                                                                                           idevento : $scope.evento.idevento});
                                      }
                                       $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/penalidade.php', {iduser : $scope.aux.iduser,
                                                                                                     idevento : $scope.evento.idevento,
                                                                                                     username : $scope.aux.username,
                                                                                                     tipopenalidade : '1'});   // tipo 1 saiu na yellow zone               
                                       $scope.evento.estado = "3";                
                                     EventoService.atualizarevento($scope.evento);
                                                          $state.go('tabsController.perfil');
                                                          }
                                  }]
                                 });

                                      console.log('criador do evento cancelando proprio evento');
                       }
        }else{
           var myPopup = $ionicPopup.show({
                  template: '<input type="text" placeholder="Escreva aqui pq nao vai rolar" ng-model="data.desculpa">',
                  title: 'ATENÇÃO!!!',
                  subTitle: 'Você esta preste a deletar seu evento, tens certeza disso?',
                  scope: $scope,
                  buttons: [
                    { text: 'Não' },
                    {
                      text: '<b>Sim</b>',
                      type: 'button-positive',
                      onTap: function(e) {
                        // console.log($scope.items.length);
                         var notifica = ("Desisti de fazer o evento, " + $scope.data.desculpa);
                        // console.log(notifica);
                        // console.log($scope.aux.iduser);
                     $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacaoporevento.php' , {idevento : $scope.evento.idevento,
                                                                                                    nomeevento : $scope.evento.nomeevento}).then(function(response) {console.log(response, 'deleta')});
                                   EventoService.GetParticipantes($scope.evento.idevento).then(function(ppl) {
                                   for (var i = 0; i < ppl.length; i++) {
                                    if ($scope.aux.iduser != ppl[i].iduser) {
                                          noti.recebeusername = ppl[i].username
                                          noti.recebe = ppl[i].iduser;
                                          noti.envia = $scope.aux.iduser;
                                          noti.tipo = 4;
                                          noti.nomeevento = $scope.evento.nomeevento;
                                          EventoService.VerificaNotificacao(noti).then(function(res) {
                                            console.log(res);
                                            if(res){
                                              $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : notifica, 
                                                      idevento : $scope.evento.idevento,
                                                      nomeevento : $scope.evento.nomeevento,
                                                      id_user_envia : $scope.aux.iduser,
                                                      username_envia : $scope.aux.username,
                                                      apelido_envia : $scope.aux.apelido,
                                                      tipo : '5',   
                                                      id_user_recebe : noti.recebe}).then(function (res){
                                                     $scope.response = res.data;
                                                     console.log($scope.response.msg)
                                                   });
                                              EventoService.getusuario2(noti.recebeusername).then(function(user) {
                                                $scope.pushnoti.titulo = $scope.evento.nomeevento + ' Cancelado';
                                                $scope.pushnoti.msg = notifica;
                                                $scope.pushnoti.token = user.devicetoken;
                                                 EventoService.MandaPushNoti($scope.pushnoti);
                                              });
                                            }
                                          });
                                        }
                                  }
                                 })
                        for(var i = 0; i< $scope.items.length; i++){
            
                          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser : $scope.items[i].iduser,
                                                                                             idevento : $scope.evento.idevento});
                        }
                                        
                         $scope.evento.estado = "3";                
                       EventoService.atualizarevento($scope.evento);
                                            $state.go('tabsController.perfil');
                                            }
                    }]
                   });
        }

    }

    $scope.editar = function(){
      formEditar.updateForm(1);
      formEventoEditaperfil.updateForm($scope.evento)
      $state.go('tabsController.repeteEventoPart1');
    }


    $scope.enterItem =  function(item){
      formOutro.updateForm(item);
      //console.log(item.iduser);
      $state.go('tabsController.perfil_outro_evento_criados');
    }

}])
    
.controller('eventoAbertoCtrl', ['$scope', '$stateParams', 'formItem', 'formUser', 'formtelaCriar', 'formOutro', '$http', '$timeout','$ionicPopup', 'EventoService', '$state','$cordovaSocialSharing', 'formvimdofiltro', 'formEventoEditahome','formvimdofiltroperfil',// The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, formItem, formUser, formtelaCriar, formOutro, $http, $timeout, $ionicPopup, EventoService, $state, $cordovaSocialSharing, formvimdofiltro, formEventoEditahome, formvimdofiltroperfil) {

  $scope.evento = formItem.getForm();
  $scope.aux = formUser.getForm();

  $scope.tag = '';
  $scope.nuser = 0;
  var datainvalida = 0;

  $scope.borala = true;
  $scope.aviso =false;
  $scope.desistir = false;
  $scope.reserva = false;
  $scope.chathome = false;
  $scope.pinza = false;
  $scope.despinza = false;
  $scope.data = {};
  $scope.auxdata ={};
  $scope.limiteconfirmacao ={};
  $scope.fim = {};
  $scope.dia = {};
  $scope.pushnoti ={};

  var hj = $scope.evento.diainicio;
  var ano = (hj[0]+hj[1]+hj[2]+hj[3]).valueOf();
  var mes = (hj[5]+hj[6]).valueOf();
  var dia = (hj[8]+hj[9]).valueOf();

  var h = (hj[11]+hj[12]).valueOf();
  var m = (hj[14]+hj[15]).valueOf();

  var vdf = formvimdofiltro.getForm();
  $scope.vimdofiltroEA =false;
  if(vdf){
    $scope.vimdofiltroEA = vdf;
  }

  var currentdate = new Date(); 
  var curr_date = (currentdate.getDate()<10?'0':'') + currentdate.getDate();
  var curr_month = (currentdate.getMonth()<10?'0':'') + (currentdate.getMonth() + 1); 
  var curr_year = currentdate.getFullYear();
  var h2 = (currentdate.getHours()<10?'0':'') + currentdate.getHours();
  var m2 = (currentdate.getMinutes()<10?'0':'') + currentdate.getMinutes();
    

  var hjd = $scope.evento.duracao;
  var hd = (hjd[0]+hjd[1]).valueOf();
  var md = (hjd[3]+hjd[4]).valueOf();
  $scope.duracao = hd+':'+md;

  var  hjl = $scope.evento.dialimiteconfirmacao;
  $scope.limiteconfirmacao.dia =  (hjl[8]+hjl[9]).valueOf()+'/'+(hjl[5]+hjl[6]).valueOf();
  $scope.limiteconfirmacao.hora =  (hjl[11]+hjl[12]).valueOf()+':'+(hjl[14]+hjl[15]).valueOf();  
  
  

  var hjf = $scope.evento.diafim;
  $scope.fim.dia =  (hjf[8]+hjf[9]).valueOf()+'/'+(hjf[5]+hjf[6]).valueOf()+'/'+(hjf[0]+hjf[1]+hjf[2]+hjf[3]);
  $scope.fim.hora = (hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf();
  $scope.dia.dia = dia+'/'+mes;
  $scope.dia.hora = h+':'+m +' - '+(hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf() ;

  if($scope.limiteconfirmacao.dia == $scope.dia.dia){
    $scope.limsemana = $scope.evento.semana;
  }else{
    if($scope.evento.semana == "Segunda-feira"){
      $scope.limsemana = "Domingo";
    }
    if($scope.evento.semana == "Terça-feira"){
      $scope.limsemana = "Segunda-feira";
    }
    if($scope.evento.semana == "Quarta-feira"){
      $scope.limsemana = "Terça-feira";
    }
    if($scope.evento.semana == "Quinta-feira"){
      $scope.limsemana = "Quarta-feira";
    }
    if($scope.evento.semana == "Sexta-feira"){
      $scope.limsemana = "Quinta-feira";
    }
    if($scope.evento.semana == "Sábado"){
      $scope.limsemana = "Sexta-feira";
    }
    if($scope.evento.semana == "Domingo"){
      $scope.limsemana = "Sábado";
    }
  }
  var zone;
  var meuestado;
  var noti = {};
  var confirm = $scope.aux.iduser;

  var ano5 = (hjl[0]+hjl[1]+hjl[2]+hjl[3]).valueOf()-curr_year;
  var mes5 = (hjl[5]+hjl[6]).valueOf()-curr_month;
  var dia5 = (hjl[8]+hjl[9]).valueOf()-curr_date;
  var h5 = (hjl[11]+hjl[12]).valueOf()-h2;
  var m5 = (hjl[14]+hjl[15]).valueOf()-m2;

  
  console.log(ano5, mes5, dia5,h5, m5 , 'COMOMO?')
  if(ano5 == 0 && mes5 == 0 && dia5 == 0 && ((h5 == 1 && m5<30 && m5>0)||(h5==0 && m5 > 30)|| (h5==1 && m5>-30))){
    console.log('YELLOWZONE');
    zone = 'yellow';
    $scope.confirmaPessoa =true;
  }
  if(ano5<0 || mes5 < 0 ||(ano5 == 0 && mes5 == 0 && (dia5 < 0 || (dia5==0 && ((h5 == 0 && m5<=0)||(h5 < 0)) )))){
    console.log('REDZONE');
    $scope.borala = false;
    $scope.aviso =true;
    zone = 'red';
    $scope.confirmaPessoa =false;
    $scope.deletarPessoa = false;
    $scope.edita = false;
  }else{
    $scope.borala = true;
    $scope.aviso =false;
  }

  if($scope.evento.adm ==  $scope.aux.iduser){
    $scope.deletarPessoa = true;
    $scope.confirmaPessoa =true;
    if(zone == 'red'){
      $scope.edita = false;
      $scope.deletarPessoa = false;
    }else{
      $scope.edita = true;
    }
  }
  console.log("numeor", $scope.evento.pmin, $scope.evento.patual , $scope.evento.pmax)
  
    if(parseInt($scope.evento.pmin)>parseInt($scope.evento.patual)){
      $scope.menorqpmin = true;
      $scope.nopmin = false;
      $scope.entre = false;
      $scope.cheio = false;
    }
    if(parseInt($scope.evento.pmin)==parseInt($scope.evento.patual)){
      $scope.menorqpmin = false;
      $scope.nopmin = true;
      $scope.entre = false;
      $scope.cheio = false;
    }

    if(parseInt($scope.evento.pmin)<parseInt($scope.evento.patual) && parseInt($scope.evento.pmax)>parseInt($scope.evento.patual)){
      $scope.menorqpmin = false;
      $scope.nopmin = false;
      $scope.entre = true;
      $scope.cheio = false;
      console.log("nao cheio")
    }
    if(parseInt($scope.evento.pmin)<parseInt($scope.evento.patual) && parseInt($scope.evento.pmax)<=parseInt($scope.evento.patual)){
      $scope.menorqpmin = false;
      $scope.nopmin = false;
      $scope.entre = false;
      $scope.cheio = true;
      console.log(" cheio", $scope.evento.pmin.valueOf() , $scope.evento.patual.valueOf(), $scope.evento.pmax.valueOf())
    }
     
    // $scope.auxfoto = $scope.evento.nomeevento + $scope.evento.diainicio;
    // var mystring = String($scope.auxfoto);
    // mystring = mystring.replace(/[^a-zA-Z0-9]/g, '');
    // $scope.evento.eventopic = 'https://s3.amazonaws.com/diwoappprofilepics/eventopicsdiwo/' + mystring + '.jpg';
  

  console.log($scope.evento.patual , $scope.evento.pmin)
  if(parseInt($scope.evento.patual) < parseInt($scope.evento.pmin) && zone == 'red'){
    console.log('Evento não acontece por falta de pessoas')
  }
  if(parseInt($scope.evento.patual) < parseInt($scope.evento.pmin) && zone == 'yellow'){
    console.log('Evento esta com poucas pessoas, talvez ele nao aconteça')
  }
  
  if($scope.evento.preco == 0 || $scope.evento.preco =="Gratuito"){
      $scope.evento.preco = "Gratuito";
      $scope.porpessoa = false;
      $scope.porlocal = false;
    }else{
      if($scope.evento.precopor == 1){
        $scope.porpessoa = true;
        $scope.porlocal = false;
      }else{
        $scope.porpessoa = false;
        $scope.porlocal = true;
      }
    }

  if($scope.evento.genero == "masc"){
      $scope.masc = true;
      $scope.fem = false;
  }
  if($scope.evento.genero == "fem"){
      $scope.fem = true;
      $scope.masc = false;
  }
  if($scope.evento.genero == "todos"){
      $scope.fem = false;
      $scope.masc = false;
  }


  $scope.$on("$ionicView.enter", function(event, data){

    $scope.tag = '';
    $scope.items = [];
    $scope.pinza = false;
    $scope.despinza = false;
    $scope.evento = formItem.getForm();
    $scope.aux = formUser.getForm();
    datainvalida = 0;

    $scope.menorqpmin = false;
    $scope.nopmin = false;
    $scope.entre = false;
    $scope.cheio = false;

    $scope.auxdata ={};
    $scope.pushnoti = {};
    var hjd = $scope.evento.duracao;
    var hd = (hjd[0]+hjd[1]).valueOf();
    var md = (hjd[3]+hjd[4]).valueOf();
    $scope.duracao = hd+':'+md;

    var  hjl = $scope.evento.dialimiteconfirmacao;
    $scope.limiteconfirmacao.dia =  (hjl[8]+hjl[9]).valueOf()+'/'+(hjl[5]+hjl[6]).valueOf();
    $scope.limiteconfirmacao.hora =  (hjl[11]+hjl[12]).valueOf()+':'+(hjl[14]+hjl[15]).valueOf();  
    
    

    var hjf = $scope.evento.diafim;
    $scope.fim.dia =  (hjf[8]+hjf[9]).valueOf()+'/'+(hjf[5]+hjf[6]).valueOf()+'/'+(hjf[0]+hjf[1]+hjf[2]+hjf[3]);
    $scope.fim.hora = (hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf();
    $scope.dia.dia = dia+'/'+mes;
    $scope.dia.hora = h+':'+m +' - '+(hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf() ;

            // Ve se eu tenho ou não interesse nesse evento
    $scope.auxpinza ={};
    $scope.auxpinza.iduser = $scope.aux.iduser;
    $scope.auxpinza.idevento = $scope.evento.idevento;
    var vdf = formvimdofiltro.getForm();
    $scope.vimdofiltroEA =false;
    if(vdf){
      $scope.vimdofiltroEA = vdf;
    }
    if(parseInt($scope.evento.pmin)>parseInt($scope.evento.patual)){
      $scope.menorqpmin = true;
      $scope.nopmin = false;
      $scope.entre = false;
      $scope.cheio = false;
    }
    if(parseInt($scope.evento.pmin)==parseInt($scope.evento.patual)){
      $scope.menorqpmin = false;
      $scope.nopmin = true;
      $scope.entre = false;
      $scope.cheio = false;
    }

    if(parseInt($scope.evento.pmin)<parseInt($scope.evento.patual) && parseInt($scope.evento.pmax)>parseInt($scope.evento.patual)){
      $scope.menorqpmin = false;
      $scope.nopmin = false;
      $scope.entre = true;
      $scope.cheio = false;
      console.log("nao cheio")
    }
    if(parseInt($scope.evento.pmin)<parseInt($scope.evento.patual) && parseInt($scope.evento.pmax)<=parseInt($scope.evento.patual)){
      $scope.menorqpmin = false;
      $scope.nopmin = false;
      $scope.entre = false;
      $scope.cheio = true;
      console.log(" cheio", $scope.evento.pmin.valueOf() , $scope.evento.patual.valueOf(), $scope.evento.pmax.valueOf())
    }

    if($scope.evento.preco == 0 || $scope.evento.preco =="Gratuito"){
      $scope.evento.preco = "Gratuito";
      $scope.porpessoa = false;
      $scope.porlocal = false;
    }else{
      if($scope.evento.precopor == 1){
        $scope.porpessoa = true;
        $scope.porlocal = false;
      }else{
        $scope.porpessoa = false;
        $scope.porlocal = true;
      }
    }

    EventoService.verificahorariopessoaeventoconfirmados($scope.aux).then(function(items) {
      $scope.auxdata = items;
      for(var r = 0;r<$scope.auxdata.length; r++){
        //console.log($scope.auxdata[r].idevento, $scope.auxdata[r].diainicio, $scope.auxdata[r].diafim , we ,$scope.evento.diafim);
        if($scope.evento.idevento!=$scope.auxdata[r].idevento){
          if (($scope.auxdata[r].diainicio < $scope.evento.diainicio && $scope.auxdata[r].diafim > $scope.evento.diainicio) || ($scope.auxdata[r].diainicio<$scope.evento.diafim && $scope.auxdata[r].diafim>$scope.evento.diafim) ||($scope.auxdata[r].diainicio > $scope.evento.diainicio && $scope.auxdata[r].diafim<$scope.evento.diafim) || ($scope.auxdata[r].diainicio < $scope.evento.diainicio && $scope.auxdata[r].diafim>$scope.evento.diafim) ) {
            console.log('horario invalido');
            datainvalida = 1;
          }
        }
      }
    });

    if($scope.aux.iduser != $scope.evento.adm){
       $scope.edita = false;
       console.log($scope.auxpinza.iduser , $scope.auxpinza.idevento)
      EventoService.Getpinza($scope.auxpinza).then(function(items) {
        //alert(items.success)
        console.log(items.success,"qeqew" )
        if(items.success != false){
          if (items[0].estado == 7) {
            $scope.pinza = false;
            $scope.despinza = true;
            console.log('eh favorito')
          }
        }else{
          console.log('N eh')
          $scope.pinza = true;
          $scope.despinza = false;
        } 
      });
    }else{
       if(zone == 'red'){
          $scope.edita = false;
        }else{
          $scope.edita = true;
        }
      $scope.pinza = false;
      $scope.despinza = false;
    }
    
            //Pega tags do evento
    EventoService.Gettags($scope.evento.idevento).then(function(tags) {
      for(var  i =0; i< tags.length;i++){
        $scope.tag = ($scope.tag + ' ' + tags[i].tag);
      } 
    });
            //Capacidade do evento
    if(parseInt($scope.evento.pmax) <= parseInt($scope.evento.patual)){
        console.log('Evento cheio');
        $scope.borala = false;
        $scope.reserva = true;
    }
    console.log($scope.evento.idevento, "bug")
    EventoService.GetParticipantes($scope.evento.idevento).then(function(parti) {
      console.log(parti.length , "parti.length");
      $scope.nomeevento = parti[0].nomeevento;
      console.log($scope.nomeevento, "bug dentro")
      for (var i = 0; i < parti.length; i++) {
        if ($scope.aux.iduser == parti[i].iduser && parti[i].estado!=7 && parti[i].estado!=8) {
          $scope.nuser++;
          $scope.borala = false;
          $scope.reserva = false;
          $scope.desistir = true;
          $scope.chathome = true;
        }
        if ($scope.aux.iduser == parti[i].iduser) {
          meuestado = parti[i].estado;
        }
        if ($scope.aux.iduser == parti[i].iduser && parti[i].estado == 7) {
          $scope.pinza = false;
          $scope.despinza = true;
        }
        if ($scope.aux.iduser == parti[i].iduser && parti[i].estado == 8) {
          $scope.reserva = false;
          var alertPopup = $ionicPopup.alert({
                          title: 'ლ(*꒪ヮ꒪*)ლ',
                          template: 'Tais na fila da reserva, se vagar t avisaremos'
          });
          console.log('reservado');
        }            
      }


    });
    console.log($scope.evento.idevento, "bug")
    EventoService.GetParticipantesSemFav($scope.evento.idevento).then(function(items) {
      console.log(items[0].iduser, "bug dentro")
      for (var i = 0; i < items.length; i++) {
        if (items[i].estado == 0) {
          items[i].confirmacao = 'Sou o organizador';
          $scope.criador = items[i].iduser;
        }
        if (items[i].estado == 1) {
          items[i].confirmacao = 'Aguardando confirmação';
        }
        if (items[i].estado == 2) {
          items[i].confirmacao = 'Confirmado';
        }
        if(items[i].borda == 0){
            items[i].bb = false;
            items[i].bs = false;
            items[i].bg = false;
          }
          if(items[i].borda == 1){
            items[i].bb = true;
            items[i].bs = false;
            items[i].bg = false;
          }
          if(items[i].borda == 2){
            items[i].bb = false;
            items[i].bs = true;
            items[i].bg = false;
          }
          if(items[i].borda == 3){
            items[i].bb = false;
            items[i].bs = false;
            items[i].bg = true;
          }
          if(items[i].profilepic[8] == 's' && items[i].profilepic[9] == '3'){
             items[i].profilepic=items[i].profilepic+"?{{getTimeStamp()}}";
           }else{
             items[i].profilepic=items[i].profilepic;
           }

      }
      $scope.items = items;
     
      
    });
  });
    //  $scope.share = function() {
    //         $cordovaSocialSharing.canShareVia("twitter", 'Oii', '', 'http://diwoapp.com.br/politica-de-privacidade/').then(function(result) {
    //             $cordovaSocialSharing.shareViaTwitter('Oii', '', 'http://diwoapp.com.br/politica-de-privacidade/');
    //         }, function(error) {
    //             alert("Cannot share on Twitter");
    //         });
    //     }

      
    $scope.share = function(t, msg, img, link){  
        if(t == 'w')
            window.plugins.socialsharing
            .shareViaWhatsApp(msg, '', link);
        else if(t == 'f')
            window.cordova.plugins.socialsharing
            .shareViaFacebook(msg, img, link);    
        else if(t == 't')
            window.cordova.plugins.socialsharing
            .shareViaTwitter(msg, img, link);    
        else if(t == 'sms')
            window.cordova.plugins.socialsharing
            .shareViaSMS(msg+' '+img+' '+link);    
        else
        {
            var sub = 'Beautiful images inside ..';
            window.cordova.plugins.socialsharing
            .shareViaEmail(msg, sub, '');        
        }    
    }

  $scope.enterItem =  function(item){
    formOutro.updateForm(item);
    //console.log(item.iduser);
    formvimdofiltroperfil.updateForm(false);
    $state.go('tabsController.perfilOutro');
  }

  $scope.Vermapa = function(){
    $state.go('tabsController.ver_onde_mapa');
  }

  $scope.editar = function(){
    formEventoEditahome.updateForm($scope.evento)
    $state.go('tabsController.EditaEEAPart1');
    //$state.go('tabsController.EditaEventoPart1');
  }

  $scope.aprova = function(item){
    console.log(meuestado)
    if(meuestado == 1 || meuestado == 8 || meuestado == 7 ){
                var alertPopup = $ionicPopup.alert({
                          title: '(°ロ°)☝',
                          template: 'Ainda não foi confirmado para poder aprovar alguem'
                        });
    }else{
      if(item.estado == 1 ){
        if (item.iduser!=$scope.aux.iduser  && confirm!= item.iduser) {
                confirm = item.iduser;
                console.log(item.iduser, $scope.aux.iduser);
                $scope.msgnoti = ('Tu foi aceito no evento: ' + $scope.evento.nomeevento);
                $scope.evento.patual = parseInt($scope.evento.patual)+1;
                $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/addpessoaevento.php', {idevento : $scope.evento.idevento,
                                                                                patual : $scope.evento.patual});
                $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpessoaevento.php' , {iduser : item.iduser,
                                                                                  idevento : $scope.evento.idevento,
                                                                                  confirmacao : 'Confirmação aceita',
                                                                                  estado :2});
                noti.recebeusername = item.username;
                noti.recebe = item.iduser;
                noti.envia = $scope.aux.iduser;
                noti.tipo = 2;
                noti.nomeevento = $scope.evento.nomeevento;
                $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacaoporids.php", {id_user_recebe : $scope.evento.adm,
                                                                              id_user_envia: item.iduser,
                                                                              nomeevento: noti.nomeevento,
                                                                              tipo : '1'});
                EventoService.VerificaNotificacao(noti).then(function(res) {
                  console.log(res);
                  if(res){
                    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : $scope.msgnoti, 
                                          idevento : $scope.evento.idevento,
                                          nomeevento : $scope.evento.nomeevento,
                                          id_user_envia : $scope.aux.iduser,
                                          username_envia : $scope.aux.username,
                                          apelido_envia : $scope.aux.apelido,
                                          tipo : '2',
                                          id_user_recebe : noti.recebe});
                    EventoService.getusuario2(noti.recebeusername).then(function(user) {
                      $scope.pushnoti.titulo =  'Boraaa!!!' ;
                      $scope.pushnoti.msg = $scope.msgnoti;
                      $scope.pushnoti.token = user.devicetoken;
                       EventoService.MandaPushNoti($scope.pushnoti);
                    });
                  }
                });
                 var alertPopup = $ionicPopup.alert({
                          title: '(/^▽^)/',
                          template: 'Vamos avisa-lo que ele foi aprovado, obrigado.'
                        });
                 item.confirmacao = 'Confirmação aprovada';

              
        }else{
          if(confirm ==  item.iduser){
            var alertPopup = $ionicPopup.alert({
                          title: '༼ つ ◕_◕ ༽つ',
                          template: 'Ja esta confirmado nesse evento!!!'
                        });
          }else{
              var alertPopup = $ionicPopup.alert({
                          title: 'ಠ_ಠ',
                          template: 'Seria muito facil tu se aceitar no evento né?'
                        });
          }
        }
      }
      if(item.estado == 2 ){
        var alertPopup = $ionicPopup.alert({
                      title: '༼ つ ◕_◕ ༽つ',
                      template: 'Ja esta confirmado nesse evento!!!'
                    });
        console.log('Ja estou confirmado')
      }
      console.log($scope.evento.diainicio)
      if(item.estado == 8 ){
        if(parseInt($scope.evento.patual)<parseInt($scope.evento.pmax)  && confirm!= item.iduser){
                confirm = item.iduser;
                console.log(item.iduser, $scope.aux.iduser);
                $scope.msgnoti = ('Tu foi aceito no evento: ' + $scope.evento.nomeevento);
                $scope.evento.patual = parseInt($scope.evento.patual)+1;
                $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/addpessoaevento.php', {idevento : $scope.evento.idevento,
                                                                                patual : $scope.evento.patual});
                $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpessoaevento.php' , {iduser : item.iduser,
                                                                                  idevento : $scope.evento.idevento,
                                                                                  confirmacao : 'Confirmação aceita',
                                                                                  estado :2});
                noti.recebeusername = item.username;
                noti.recebe = item.iduser;
                noti.envia = $scope.aux.iduser;
                noti.tipo = 2;
                noti.nomeevento = $scope.evento.nomeevento;
                EventoService.VerificaNotificacao(noti).then(function(res) {
                  console.log(res);
                  if(res){
                    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : $scope.msgnoti, 
                                          idevento : $scope.evento.idevento,
                                          nomeevento : $scope.evento.nomeevento,
                                          id_user_envia : $scope.aux.iduser,
                                          username_envia : $scope.aux.username,
                                          apelido_envia : $scope.aux.apelido,
                                          tipo : '2',
                                          id_user_recebe : noti.recebe});
                    EventoService.getusuario2(noti.recebeusername).then(function(user) {
                      $scope.pushnoti.titulo =  'Boraaa!!!' ;
                      $scope.pushnoti.msg = $scope.msgnoti;
                      $scope.pushnoti.token = user.devicetoken;
                       EventoService.MandaPushNoti($scope.pushnoti);
                    });
                  }
                });
                  var alertPopup = $ionicPopup.alert({
                      title: '(°◡°♡).:｡',
                      template: 'Vamos confirmar a presença dele!!'
                    });
                 item.confirmacao = 'Confirmação aprovada';
         
        console.log('Ja estou confirmado')
        }else{
          var confirmPopup = $ionicPopup.show({
                   title: '(◕⌓◕;)',
                   template: 'Evento esta cheio, deseja confirmar essa pessoa mesmo assim?',
                   buttons: [
                      { text: 'Não',
                        type: 'button-assertive'},
                      {
                        text: 'Sim',
                        type: 'button-positive',
                        onTap: function(e){
                          confirm = item.iduser;
                          console.log(item.iduser, $scope.aux.iduser);
                          $scope.msgnoti = ('Tu foi aceito no evento: ' + $scope.evento.nomeevento);
                          $scope.evento.patual = parseInt($scope.evento.patual)+1;
                          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/addpessoaevento.php', {idevento : $scope.evento.idevento,
                                                                                          patual : $scope.evento.patual});
                          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpessoaevento.php' , {iduser : item.iduser,
                                                                                            idevento : $scope.evento.idevento,
                                                                                            confirmacao : 'Confirmação aceita',
                                                                                            estado :2});
                          noti.recebeusername = item.username;
                          noti.recebe = item.iduser;
                          noti.envia = $scope.aux.iduser;
                          noti.tipo = 2;
                          noti.nomeevento = $scope.evento.nomeevento;
                          EventoService.VerificaNotificacao(noti).then(function(res) {
                            console.log(res);
                            if(res){
                              $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : $scope.msgnoti, 
                                                    idevento : $scope.evento.idevento,
                                                    nomeevento : $scope.evento.nomeevento,
                                                    id_user_envia : $scope.aux.iduser,
                                                    username_envia : $scope.aux.username,
                                                    apelido_envia : $scope.aux.apelido,
                                                    tipo : '2',
                                                    id_user_recebe : noti.recebe});
                              EventoService.getusuario2(noti.recebeusername).then(function(user) {
                                $scope.pushnoti.titulo =  'Boraaa!!!' ;
                                $scope.pushnoti.msg = $scope.msgnoti;
                                $scope.pushnoti.token = user.devicetoken;
                                 EventoService.MandaPushNoti($scope.pushnoti);
                              });
                            }
                          });
                            var alertPopup = $ionicPopup.alert({
                                title: '(°◡°♡).:｡',
                                template: 'Vamos confirmar a presença dele!!'
                              });
                           item.confirmacao = 'Confirmação aprovada';
                              }
                             }
                           ]
                   })
            // var alertPopup = $ionicPopup.alert({
            //             title: '(◕⌓◕;)',
            //             template: 'Evento esta cheio, ou aumenta o numero de vagas ou escolha alguem para excluir do evento'
            //           });
          console.log('Esta cheio o evento')
        }
      }
      if (item.estado == 0) {
                var alertPopup = $ionicPopup.alert({
                          title: 'ლ(́◉◞౪◟◉‵ლ)',
                          template: 'Ja sou o organizador, não preciso me confirmar'
                        });
      }
    }
  }

  $scope.onItemDelete = function(item) {
    if (item.iduser == $scope.aux.iduser) {
      var alertPopup = $ionicPopup.alert({
                      title: 'Oi?',
                      template: 'Tu és o organizador, não podes se deletar do seu evento, podes cancelar ele'
      });
    }else{
      var confirmPopup = $ionicPopup.show({
                   title: 'ATENÇÃO!!!',
                   template: 'Você esta preste excluir pessoa do evento, ela não poderá mais entrar neste evento, tens certeza disso?',
                   buttons: [
                      { text: 'Não',
                        type: 'button-assertive'},
                      {
                        text: 'Sim',
                        type: 'button-positive',
                        onTap: function(e){
                        noti.recebeusername = item.username;
                        noti.recebe = item.iduser;
                        noti.envia = $scope.aux.iduser;
                        noti.tipo = 9;
                        noti.nomeevento = $scope.evento.nomeevento;
                        EventoService.VerificaNotificacao(noti).then(function(res) {
                          console.log(res);
                          if(res){
                            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : 'Tu foi retirado do evento', 
                                                                                            idevento : $scope.evento.idevento,
                                                                                            nomeevento : $scope.evento.nomeevento,
                                                                                            id_user_envia : $scope.aux.iduser,
                                                                                            username_envia : $scope.aux.username,
                                                                                            apelido_envia : $scope.aux.apelido,
                                                                                            tipo : '9', //pessoa kickada
                                                                                            id_user_recebe : noti.recebe});
                            EventoService.getusuario2(noti.recebeusername).then(function(user) {
                                              $scope.pushnoti.titulo = $scope.evento.nomeevento;
                                              $scope.pushnoti.msg = 'Tu foi retirado do evento: ' + $scope.evento.nomeevento;
                                              $scope.pushnoti.token = user.devicetoken;
                                               EventoService.MandaPushNoti($scope.pushnoti);
                                            });
                          }
                        });
                          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser :item.iduser,
                                                                                              idevento : $scope.evento.idevento});
                          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletachat.php', {iduser : item.iduser,
                                                                                      idevento : $scope.aux.idevento}); 
                          if(item.estado == 2){
                           $scope.evento.patual = parseInt($scope.evento.patual)-1;
                          }
                          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/addpessoaevento.php', {idevento : $scope.evento.idevento,
                                                                                          patual : $scope.evento.patual});     
                          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/pessoanaoevento.php', {iduser : item.iduser, 
                                                                                          idevento : $scope.evento.idevento,
                                                                                          nomeevento : $scope.evento.nomeevento,
                                                                                          estado : '1'});//foi kickado
                                                                                             

                          $scope.items.splice($scope.items.indexOf(item), 1);      
                              }
                             }
                           ]
                   })


      
    }
  }  

  $scope.confirma = function(){
    if(datainvalida==1){
      var alertPopup = $ionicPopup.alert({
        title: 'ಠ_ಠ',
        template: 'Ja tens um evento marcado nesta data querido'
      });
    }else{
      if ($scope.nuser == 0) {
            if (!$scope.evento.idevento || !$scope.aux.iduser) {
                            var alertPopup = $ionicPopup.alert({
                            title: 'Vish deu ruim',
                            template: 'Favor refaça seu login'
                          });

            }else{
              if(zone == 'yellow'){
                var confirmPopup = $ionicPopup.show({
                     title: 'ZONA AMARELA',
                     template: 'Evento esta na ZONA AMARELA, caso voce desista uma vez que confirmado a presença tu sofrerás um cartão amarelo. Deseja ir mesmo assim?',
                     buttons: [
                        { text: 'Não sei se vou',
                          type: 'button-assertive',
                          onTap: function(e){
                            console.log('nada acontece');
                          }},
                        {
                          text: 'Quero ir',
                          type: 'button-positive',
                          onTap: function(e){
                            $scope.confirmacao = 'aguardando confirmação';
                            $scope.estado = '1';
                  // console.log($scope.evento.idevento);
                  // console.log($scope.aux.iduser);
                  // console.log($scope.confirmacao);
                  // console.log($scope.nomeevento);
                  // console.log($scope.estado);
                  var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/irevento.php';
                  $http.post(link, {idevento : $scope.evento.idevento,
                                  idadm : $scope.evento.adm, 
                                  admusername : $scope.evento.admusername, 
                                  diainicio : $scope.evento.diainicio,
                                  diafim : $scope.evento.diafim,
                                  iduser : $scope.aux.iduser,
                                  borda : $scope.aux.borda,
                                  username: $scope.aux.username,
                                  profilepic : $scope.aux.profilepic,
                                  devicetoken : $scope.aux.devicetoken,
                                  apelido : $scope.aux.apelido,
                                  confirmacao : $scope.confirmacao,
                                  nomeevento :  $scope.nomeevento,
                                  eventopic : $scope.evento.eventopic, 
                                  estado : $scope.estado}).then(function (res){
                    $scope.response = res.data;
                    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser : $scope.aux.iduser,
                                                                                idevento : $scope.evento.idevento,
                                                                                estado: '5'});
                    if ($scope.response.success == true) {
                      $scope.msgnoti = ('To querendo ir no evento: ' + $scope.evento.nomeevento);
                      noti.recebe = $scope.evento.adm;
                      noti.envia = $scope.aux.iduser;
                      noti.tipo = 1;
                      noti.nomeevento = $scope.evento.nomeevento;
                      EventoService.VerificaNotificacao(noti).then(function(res) {
                        console.log(res);
                        if(res){
                          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificacriador.php', {notificacao : $scope.msgnoti, 
                                  idevento : $scope.evento.idevento,
                                  nomeevento : $scope.evento.nomeevento,
                                  id_user_envia : $scope.aux.iduser,
                                  username_envia : $scope.aux.username,
                                  apelido_envia : $scope.aux.apelido,
                                  tipo : '1',
                                  id_user_recebe : $scope.evento.adm});
                          
                          EventoService.getusuario2($scope.evento.admusername).then(function(user) {
                            $scope.pushnoti.titulo = $scope.evento.nomeevento;
                            $scope.pushnoti.msg = $scope.aux.username + " quer participar do evento";
                            $scope.pushnoti.token = user.devicetoken;
                             EventoService.MandaPushNoti($scope.pushnoti);
                          });
                         
                        }
                      });
                      $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacaoporids.php", {id_user_recebe : noti.recebe,
                                                                                id_user_envia: noti.envia,
                                                                                nomeevento: noti.nomeevento,
                                                                                tipo : '5'});
                      var alertPopup = $ionicPopup.alert({
                        title: 'Parabéns',
                        template: $scope.response.msg
                      });
                      alertPopup.then(function(){
                        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser : $scope.aux.iduser,
                                                                                idevento : $scope.evento.idevento,
                                                                                estado: '7'}).then(function (res){
                        $scope.response = res.data;
                        //console.log(i);
                        $scope.fav = false;
                        });
                        $state.go('tabsController.home');
                      });
                      
                    }else{
                      var alertPopup = $ionicPopup.alert({
                        title: 'Ocorreu uma falha',
                        template: $scope.response.msg
                      });
                    }
                    console.log($scope.response.msg);
                });
                          }}]
                   });
              }else{
                  $scope.confirmacao = 'aguardando confirmação';
                  $scope.estado = '1';
                  // console.log($scope.evento.idevento);
                  // console.log($scope.aux.iduser);
                  // console.log($scope.confirmacao);
                  // console.log($scope.nomeevento);
                  // console.log($scope.estado);
                  var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/irevento.php';
                  $http.post(link, {idevento : $scope.evento.idevento,
                                  idadm : $scope.evento.adm, 
                                  admusername : $scope.evento.admusername, 
                                  diainicio : $scope.evento.diainicio,
                                  diafim : $scope.evento.diafim,
                                  iduser : $scope.aux.iduser,
                                  borda : $scope.aux.borda,
                                  username: $scope.aux.username,
                                  profilepic : $scope.aux.profilepic,
                                  devicetoken : $scope.aux.devicetoken,
                                  apelido : $scope.aux.apelido,
                                  confirmacao : $scope.confirmacao,
                                  nomeevento :  $scope.nomeevento, 
                                  eventopic : $scope.evento.eventopic,
                                  estado : $scope.estado}).then(function (res){
                    $scope.response = res.data;
                    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser : $scope.aux.iduser,
                                                                                idevento : $scope.evento.idevento,
                                                                                estado: '5'});
                    if ($scope.response.success == true) {
                      $scope.msgnoti = ('To querendo ir no evento: ' + $scope.evento.nomeevento);
                      noti.recebe = $scope.evento.adm;
                      noti.envia = $scope.aux.iduser;
                      noti.tipo = 1;
                      noti.nomeevento = $scope.evento.nomeevento;
                      EventoService.VerificaNotificacao(noti).then(function(res) {
                        console.log(res);
                        if(res){
                          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificacriador.php', {notificacao : $scope.msgnoti, 
                                  idevento : $scope.evento.idevento,
                                  nomeevento : $scope.evento.nomeevento,
                                  id_user_envia : $scope.aux.iduser,
                                  username_envia : $scope.aux.username,
                                  apelido_envia : $scope.aux.apelido,
                                  tipo : '1',
                                  id_user_recebe : $scope.evento.adm});
                         EventoService.getusuario2($scope.evento.admusername).then(function(user) {
                            $scope.pushnoti.titulo = $scope.evento.nomeevento;
                            $scope.pushnoti.msg = $scope.aux.username + " quer participar do evento";
                            $scope.pushnoti.token = user.devicetoken;
                             EventoService.MandaPushNoti($scope.pushnoti);
                          });
                        }
                      });
                      $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacaoporids.php", {id_user_recebe : noti.recebe,
                                                                                id_user_envia: noti.envia,
                                                                                nomeevento: noti.nomeevento,
                                                                                tipo : '5'});


                                  /// PEDIR CONTATO DE ALGUEM DE FORA PARA FAZER O SERVIÇO DE CHAMAR
                      
                      // $scope.carinha = '';
                      // $ionicPopup.prompt({
                      //     title: 'Qual nome devo dar?',
                      //     template: 'Não vamos esquecer de dar nomes aos bois',
                      //    inputType: 'text',
                      //    inputPlaceholder: '@insta ou numero pra whats ou email'
                      //  }).then(function(nomeevento) {
                      //   $scope.carinha = nomeevento
                      // console.log($scope.carinha)
                      // });




                      var alertPopup = $ionicPopup.alert({
                        title: 'Parabéns',
                        template: $scope.response.msg
                      });
                      alertPopup.then(function(){
                        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser : $scope.aux.iduser,
                                                                                idevento : $scope.evento.idevento,
                                                                                estado: '7'}).then(function (res){
                        $scope.response = res.data;
                        //console.log(i);
                        $scope.fav = false;
                        });
                        $state.go('tabsController.home');
                      });
                      
                    }else{
                      var alertPopup = $ionicPopup.alert({
                        title: 'Ocorreu uma falha',
                        template: $scope.response.msg
                      });
                    }
                    console.log($scope.response.msg);
                });
              }
            }
      
      }else{
        $scope.borala = false;
        $scope.desistir = true;
      }
      $state.reload();
    }
  }

  $scope.reservar = function(){
    var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/reservar.php';
                  $http.post(link, {idevento : $scope.evento.idevento, 
                                idadm : $scope.evento.adm, 
                                admusername : $scope.evento.admusername,
                                apelido : $scope.aux.apelido,  
                                iduser : $scope.aux.iduser,
                                diainicio : $scope.evento.diainicio,
                                diafim : $scope.evento.diafim,
                                username: $scope.aux.username,
                                confirmacao : 'na fila',
                                profilepic: $scope.aux.profilepic,
                                devicetoken : $scope.aux.devicetoken,
                                nomeevento :  $scope.nomeevento, 
                                estado : '8'}).then(function (res){
                  $scope.response = res.data;
                  var alertPopup = $ionicPopup.alert({
                      title: 'ヾ(･д･ヾ)',
                      template: 'Vamos avisar que tu ta querendo ir, vai que aumentao o limite máximo ou alguem desiste né? T avisaremos se algo acontecer'
                    });
                    $scope.msgnoti = ('To querendo ir no evento: ' + $scope.evento.nomeevento + ' mas ele esta cheio, da pra fazer algo?');
                    //console.log($scope.msgnoti);
                    noti.recebe = $scope.evento.adm;
                    noti.envia = $scope.aux.iduser;
                    noti.tipo = 8; // solicitando reserva
                    noti.nomeevento = $scope.evento.nomeevento;
                    EventoService.VerificaNotificacao(noti).then(function(res) {
                      console.log(res);
                      if(res){
                        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificacriador.php', {notificacao : $scope.msgnoti, 
                                idevento : $scope.evento.idevento,
                                nomeevento : $scope.evento.nomeevento,
                                id_user_envia : $scope.aux.iduser,
                                username_envia : $scope.aux.username,
                                apelido_envia : $scope.aux.apelido,
                                tipo : '1',
                                id_user_recebe : $scope.evento.adm}).then(function (res){
                               $scope.response = res.data;
                               //console.log($scope.response.msg)
                             });
                        EventoService.getusuario2($scope.evento.admusername).then(function(user) {
                            $scope.pushnoti.titulo = $scope.evento.nomeevento;
                            $scope.pushnoti.msg = $scope.aux.username + " quer participar do evento";
                            $scope.pushnoti.token = user.devicetoken;
                             EventoService.MandaPushNoti($scope.pushnoti);
                          });
                      }
                    });
                    $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacaoporids.php", {id_user_recebe : noti.recebe,
                                                                              id_user_envia: noti.envia,
                                                                              nomeevento: noti.nomeevento,
                                                                              tipo : '5'});
                  $scope.reserva = false;
              });
    $state.reload();
  }

  $scope.desfavorita = function(){
    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser : $scope.aux.iduser,
                                                                        idevento : $scope.evento.idevento,
                                                                        estado: '7'});
    $scope.pinza = true;
    $scope.despinza = false;
  }

  $scope.favorita = function(){
 //    console.log("pinza", $scope.evento.adm, $scope.evento.admusername, $scope.aux.iduser, $scope.evento.diainicio, $scope.evento.diafim,
 // $scope.aux.borda,
 // $scope.aux.username,
 // $scope.aux.profilepic,
 // $scope.aux.devicetoken,
 // $scope.aux.apelido,
 // 'interesse',
 // $scope.nomeevento, )
    var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/irevento.php';
    $http.post(link, {idevento : $scope.evento.idevento, 
                              idadm : $scope.evento.adm, 
                              admusername : $scope.evento.admusername, 
                              iduser : $scope.aux.iduser,
                              diainicio : $scope.evento.diainicio,
                              diafim : $scope.evento.diafim,
                              borda : $scope.aux.borda,
                              username: $scope.aux.username,
                              profilepic : $scope.aux.profilepic,
                              devicetoken : $scope.aux.devicetoken,
                              apelido : $scope.aux.apelido,
                              confirmacao : 'interesse',
                              nomeevento :  $scope.nomeevento,
                              eventopic : $scope.evento.eventopic, 
                              estado : '7'});
    $scope.pinza = false;
    $scope.despinza = true;
  }

  $scope.reportar = function(){
    $scope.reportmsg = '';
    //console.log($scope.evento.admusername);
    $scope.report = [
      { text: "Conteúdo impróprio", checked: false },
      { text: "Linguajar inadequado", checked: false },
      { text: "Discurso de ódio", checked: false },
      { text: "Substancias ilicitas ", checked: false }
    ];
    $ionicPopup.confirm({
        title: 'Você quer reportar esse evento pq?',
        content: '<ion-checkbox ng-repeat="item in report" style="color: #FCFCFC;" ng-model="item.checked"  ng-checked="item.checked">{{item.text}}</ion-checkbox>',
        scope: $scope
    }).then(function(res) {
        if(res) {
          for (var h=0;h<3;h++){
            //console.log($scope.report[h].checked , h);
            if($scope.report[h].checked){
              $scope.reportmsg = $scope.reportmsg + $scope.report[h].text + ' ';
              //console.log($scope.reportmsg);
            }
          }
          if(h==3){
            console.log($scope.reportmsg);
            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/reportaevento.php', {namereportado : $scope.evento.admusername,
                                                                            reportadoid : $scope.evento.idevento,
                                                                            iduserreportando : $scope.aux.iduser,
                                                                            usernamereportando : $scope.aux.username,
                                                                            tiporeport : 'evento',
                                                                            motivo : $scope.reportmsg}).then(function (tes){
              $scope.response = tes.data;
              var alertPopup = $ionicPopup.alert({
                                        title: 'Obrigado',
                                        template: 'Este evento esta agora sobre avaliação, obrigado por manter a plataforma organizada'
              });
            });
          }
        }
    });
  }

  $scope.deletar =  function(){
    if ($scope.criador == $scope.aux.iduser) {
      if(zone == 'red' || zone == 'yellow'){
        if(zone == 'red' ){
          var myPopup = $ionicPopup.show({
                template: '<input type="text" placeholder="Escreva aqui pq nao vai rolar" ng-model="data.desculpa">',
                title: 'ATENÇÃOOOOOO!!!',
                subTitle: 'Você esta preste a cancelar seu evento faltando muito pouco para seu começo, tens certeza disso?. Se tu realmente cancelar estaremos te dando um cartão vermelho. Para saber mais sobre eles va no seu indice de confirmação',
                scope: $scope,
                buttons: [
                  { text: 'Não' },
                  {
                    text: '<b>Sim</b>',
                    type: 'button-positive',
                    onTap: function(e) {
                      // console.log($scope.items.length);
                       var notifica = ("Desisti de fazer o evento, " + $scope.data.desculpa);
                      // console.log(notifica);
                      // console.log($scope.aux.iduser);
                    
                      formtelaCriar.updateForm(1);
                       $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacaoporevento.php' , {idevento : $scope.evento.idevento,
                                                                                    nomeevento : $scope.evento.nomeevento});
                      
                      $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/penalidade.php', {iduser : $scope.aux.iduser,
                                                                                   idevento : $scope.evento.idevento,
                                                                                   username : $scope.aux.username,
                                                                                   tipopenalidade : '2'});     // tipo2 saiu na redzone         
                      EventoService.GetParticipantes($scope.evento.idevento).then(function(ppl) {
                                   for (var i = 0; i < ppl.length; i++) {
                                    if ($scope.aux.iduser != ppl[i].iduser) {
                                          noti.recebeusername = ppl[i].username;
                                          noti.recebe = ppl[i].iduser;
                                          noti.envia = $scope.aux.iduser;
                                          noti.tipo = 4;
                                          noti.nomeevento = $scope.evento.nomeevento;
                                          EventoService.VerificaNotificacao(noti).then(function(res) {
                                            console.log(res);
                                            if(res){
                                            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : notifica, 
                                                    idevento : $scope.evento.idevento,
                                                    nomeevento : $scope.evento.nomeevento,
                                                    id_user_envia : $scope.aux.iduser,
                                                    username_envia : $scope.aux.username,
                                                    apelido_envia : $scope.aux.apelido,
                                                    tipo : '5',   
                                                    id_user_recebe : noti.recebe}).then(function (res){
                                                   $scope.response = res.data;
                                                   console.log($scope.response.msg)
                                                 });
                                              EventoService.getusuario2(noti.recebeusername).then(function(user) {
                                                $scope.pushnoti.titulo = $scope.evento.nomeevento + ' Cancelado';
                                                $scope.pushnoti.msg = notifica;
                                                $scope.pushnoti.token = user.devicetoken;
                                                 EventoService.MandaPushNoti($scope.pushnoti);
                                              });
                                            }
                                          });
                                        }
                                  }
                                 })
                      for(var i = 0; i< $scope.items.length; i++){
                        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser : $scope.items[i].iduser,
                                                                                           idevento : $scope.evento.idevento});
                      }
                      $scope.evento.estado = "3";                
                      EventoService.atualizarevento($scope.evento);
                      $state.go('tabsController.home');
                    }
                  }
                ]
          });
          console.log('criador do evento cancelando proprio evento');
        }else{
          var myPopup = $ionicPopup.show({
                      template: '<input type="text" placeholder="Escreva aqui pq nao vai rolar" ng-model="data.desculpa">',
                      title: 'ATENÇÃO!!!',
                      subTitle: 'Você esta preste a cancelar seu evento faltando pouco para seu começo, tens certeza disso?. Se tu realmente cancelar estaremos te dando um cartão amarelo. Para saber mais sobre eles va no seu indice de confirmação',
                      scope: $scope,
                      buttons: [
                        { text: 'Não' },
                        {
                          text: '<b>Sim</b>',
                          type: 'button-positive',
                          onTap: function(e) {
                            // console.log($scope.items.length);
                             var notifica = ("Desisti de fazer o evento, " + $scope.data.desculpa);
                            // console.log(notifica);
                            // console.log($scope.aux.iduser);
                          
                            formtelaCriar.updateForm(1);
                             $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacaoporevento.php' , {idevento : $scope.evento.idevento,
                                                                                          nomeevento : $scope.evento.nomeevento});
                            
                           
                            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/penalidade.php', {iduser : $scope.aux.iduser,
                                                                                       idevento : $scope.evento.idevento,
                                                                                       username : $scope.aux.username,
                                                                                       tipopenalidade : '1'});   // tipo 1 saiu na yellow zone               
                            EventoService.GetParticipantes($scope.evento.idevento).then(function(ppl) {
                                   for (var i = 0; i < ppl.length; i++) {
                                    console.log('Enviando')
                                    if ($scope.aux.iduser != ppl[i].iduser) {
                                          noti.recebeusername = ppl[i].username;
                                          noti.recebe = ppl[i].iduser;
                                          noti.envia = $scope.aux.iduser;
                                          noti.tipo = 4;
                                          noti.nomeevento = $scope.evento.nomeevento;
                                          EventoService.VerificaNotificacao(noti).then(function(res) {
                                            console.log(res);
                                            if(res){
                                              console.log('Enviando de vdd')
                                              $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : notifica, 
                                                      idevento : $scope.evento.idevento,
                                                      nomeevento : $scope.evento.nomeevento,
                                                      id_user_envia : $scope.aux.iduser,
                                                      username_envia : $scope.aux.username,
                                                      apelido_envia : $scope.aux.apelido,
                                                      tipo : '5',   
                                                      id_user_recebe : noti.recebe}).then(function (res){
                                                     $scope.response = res.data;
                                                     console.log($scope.response.msg)
                                                   });
                                                EventoService.getusuario2(noti.recebeusername).then(function(user) {
                                                  $scope.pushnoti.titulo = $scope.evento.nomeevento + ' Cancelado';
                                                  $scope.pushnoti.msg = notifica;
                                                  $scope.pushnoti.token = user.devicetoken;
                                                   EventoService.MandaPushNoti($scope.pushnoti);
                                                });
                                              }
                                            });
                                        }
                                  }
                                 })
                             for(var i = 0; i< $scope.items.length; i++){
                              $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser : $scope.items[i].iduser,
                                                                                                 idevento : $scope.evento.idevento});
                            }
                            $scope.evento.estado = "3";                
                            EventoService.atualizarevento($scope.evento);
                            $state.go('tabsController.home');
                          }
                        }
                      ]
          });
          console.log('criador do evento cancelando proprio evento');
        }
      }else{
        var myPopup = $ionicPopup.show({
                  template: '<input type="text" placeholder="Escreva aqui pq nao vai rolar" ng-model="data.desculpa">',
                  title: 'SÉRIO?!?!',
                  subTitle: 'Você esta preste a deletar seu evento, tens certeza disso?',
                  scope: $scope,
                  buttons: [
                    { text: 'Não' },
                    {
                      text: '<b>Sim</b>',
                      type: 'button-positive',
                      onTap: function(e) {
                        // console.log($scope.items.length);
                         var notifica = ("Desisti de fazer o evento, " + $scope.data.desculpa);
                        // console.log(notifica);
                        // console.log($scope.aux.iduser);
                      
                        formtelaCriar.updateForm(1);
                         $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacaoporevento.php' , {idevento : $scope.evento.idevento,
                                                                                                    nomeevento : $scope.evento.nomeevento}).then(function(response) {console.log(response, 'deleta')});
                                    
                        
                        EventoService.GetParticipantes($scope.evento.idevento).then(function(ppl) {
                                   for (var i = 0; i < ppl.length; i++) {
                                    if ($scope.aux.iduser != ppl[i].iduser) {
                                          noti.recebeusername = ppl[i].username
                                          noti.recebe = ppl[i].iduser;
                                          noti.envia = $scope.aux.iduser;
                                          noti.tipo = 4;
                                          noti.nomeevento = $scope.evento.nomeevento;
                                          EventoService.VerificaNotificacao(noti).then(function(res) {
                                            console.log(res);
                                            if(res){
                                            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : notifica, 
                                                    idevento : $scope.evento.idevento,
                                                    nomeevento : $scope.evento.nomeevento,
                                                    id_user_envia : $scope.aux.iduser,
                                                    username_envia : $scope.aux.username,
                                                    apelido_envia : $scope.aux.apelido,
                                                    tipo : '5',   
                                                    id_user_recebe : noti.recebe}).then(function (res){
                                                   $scope.response = res.data;
                                                   console.log($scope.response.msg)
                                                 });
                                                EventoService.getusuario2(noti.recebeusername).then(function(user) {
                                                  $scope.pushnoti.titulo = $scope.evento.nomeevento + ' Cancelado';
                                                  $scope.pushnoti.msg = notifica;
                                                  $scope.pushnoti.token = user.devicetoken;
                                                   EventoService.MandaPushNoti($scope.pushnoti);
                                                });
                                              }
                                            });
                                        }
                                  }
                                 })
                          for(var i = 0; i< $scope.items.length; i++){
                          
                          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser : $scope.items[i].iduser,
                                                                                             idevento : $scope.evento.idevento});
                        }              
                         $scope.evento.estado = "3";                
                       EventoService.atualizarevento($scope.evento);
                                            $state.go('tabsController.home');
                                            }
                    }]
                   });

                        console.log('criador do evento cancelando proprio evento');
        }
              
      }else{
        if (meuestado!=1) {


         if(zone == 'red' || zone == 'yellow'){
                          if(zone == 'red' ){

                               var confirmPopup = $ionicPopup.show({
                                         title: 'ATENÇÃO!!!',
                                         template: 'Você esta preste a desistir de um evento faltando muito pouco tempo para seu começo, tens certeza disso? Se tu realmente cancelar estaremos te dando um cartão vermelho. Para saber mais sobre eles va no seu indice de confirmação ',
                                         buttons: [
                                            { text: 'Não',
                                              type: 'button-assertive'},
                                            {
                                              text: 'Sim',
                                              type: 'button-positive',
                                              onTap: function(e){
                                               noti.recebeusername = $scope.evento.admusername; 
                                                noti.recebe = $scope.criador;
                                            noti.envia = $scope.aux.iduser;
                                            noti.tipo = 5;
                                            noti.nomeevento = $scope.evento.nomeevento;
                                            EventoService.VerificaNotificacao(noti).then(function(res) {
                                              console.log(res);
                                              if(res){
                                                $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : 'Desisti de ir no seu evento, perdão', 
                                                      idevento : $scope.evento.idevento,
                                                      nomeevento : $scope.evento.nomeevento,
                                                      id_user_envia : $scope.aux.iduser,
                                                      username_envia : $scope.aux.username,
                                                      apelido_envia : $scope.aux.apelido,
                                                      tipo : '5', //pessoa desistiu
                                                      id_user_recebe : $scope.criador});
                                                EventoService.getusuario2(noti.recebeusername).then(function(user) {
                                                  $scope.pushnoti.titulo = 'Desisti';
                                                  $scope.pushnoti.msg = $scope.aux.username + ' desistiu de ir no seu evento';
                                                  $scope.pushnoti.token = user.devicetoken;
                                                   EventoService.MandaPushNoti($scope.pushnoti);
                                                });
                                              }
                                            });
                                            $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacaoporids.php", {id_user_recebe : noti.recebe,
                                                                              id_user_envia: noti.envia,
                                                                              nomeevento: noti.nomeevento,
                                                                              tipo : '1'});
                                            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/penalidade.php', {iduser : $scope.aux.iduser,
                                                                                           idevento : $scope.evento.idevento,
                                                                                           username : $scope.aux.username,
                                                                                           tipopenalidade : '2'});     // tipo2 saiu na redzone  
                                            if(meuestado == 2){
                                               $scope.evento.patual = parseInt($scope.evento.patual)-1;
                                            }
                                            if(parseInt($scope.evento.patual)<parseInt($scope.evento.pmin)){
                                              $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/mudaestadoevento.php', {idevento : $scope.evento.idevento,
                                                                                                            estado : '2'});
                                              $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : 'ATENÇÃO!! Numero de pessoas agora nao bate o mínimo.', 
                                                          idevento : $scope.evento.idevento,
                                                          nomeevento : $scope.evento.nomeevento,
                                                          id_user_envia : $scope.aux.iduser,
                                                          username_envia : $scope.aux.username,
                                                          apelido_envia : $scope.aux.apelido,
                                                          tipo : '12', //pessoa desistiu com menos pessoas para acontecer ou nao um evento
                                                          id_user_recebe : $scope.criador});
                                            }
                                            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/addpessoaevento.php', {idevento : $scope.evento.idevento,
                                                                                                            patual : $scope.evento.patual});    
                                            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser : $scope.aux.iduser,
                                                                                                              idevento : $scope.evento.idevento});
                                            $state.go('tabsController.home');
                                                    }
                                                   }
                                                 ]
                                         })
                             }else{
                                 var confirmPopup = $ionicPopup.show({
                                         title: 'ATENÇÃO!!!',
                                         template: 'Você esta preste a desistir de um evento faltando pouco tempo para seu começo, tens certeza disso? Se tu realmente cancelar estaremos te dando um cartão amarelo. Para saber mais sobre eles va no seu indice de confirmação',
                                         buttons: [
                                            { text: 'Não',
                                              type: 'button-assertive'},
                                            {
                                              text: 'Sim',
                                              type: 'button-positive',
                                              onTap: function(e){
                                                noti.recebeusername = $scope.evento.username;
                                                noti.recebe = $scope.criador;
                                            noti.envia = $scope.aux.iduser;
                                            noti.tipo = 5;
                                            noti.nomeevento = $scope.evento.nomeevento;
                                              EventoService.VerificaNotificacao(noti).then(function(res) {
                                              console.log(res);
                                              if(res){
                                                $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : 'Desisti de ir no seu evento, perdão', 
                                                      idevento : $scope.evento.idevento,
                                                      nomeevento : $scope.evento.nomeevento,
                                                      id_user_envia : $scope.aux.iduser,
                                                      username_envia : $scope.aux.username,
                                                      apelido_envia : $scope.aux.apelido,
                                                      tipo : '5', //pessoa desistiu
                                                      id_user_recebe : $scope.criador});
                                                EventoService.getusuario2(noti.recebeusername).then(function(user) {
                                                  $scope.pushnoti.titulo = 'Desisti';
                                                  $scope.pushnoti.msg = $scope.aux.username + ' desistiu de ir no seu evento';
                                                  $scope.pushnoti.token = user.devicetoken;
                                                   EventoService.MandaPushNoti($scope.pushnoti);
                                                });
                                              }
                                              });
                                              $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacaoporids.php", {id_user_recebe : noti.recebe,
                                                                              id_user_envia: noti.envia,
                                                                              nomeevento: noti.nomeevento,
                                                                              tipo : '1'});
                                                       $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/penalidade.php', {iduser : $scope.aux.iduser,
                                                                                                     idevento : $scope.evento.idevento,
                                                                                                     username : $scope.aux.username,
                                                                                                     tipopenalidade : '1'});   // tipo 1 saiu na yellow zone   
                                                      
                                                         $scope.evento.patual = parseInt($scope.evento.patual)-1;
                                                        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/addpessoaevento.php', {idevento : $scope.evento.idevento,
                                                                                          patual : $scope.evento.patual});    
                                                    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser : $scope.aux.iduser,
                                                                                                                        idevento : $scope.evento.idevento});
                                                      $state.go('tabsController.home');
                                                    }
                                                   }
                                                 ]
                                         })

                             }
                           
                         }else{
                             var confirmPopup = $ionicPopup.show({
                                         title: 'ATENÇÃO!!!',
                                         template: 'Você esta preste a desistir de um evento, tens certeza disso?',
                                         buttons: [
                                            { text: 'Não',
                                              type: 'button-assertive'},
                                            {
                                              text: 'Sim',
                                              type: 'button-positive',
                                              onTap: function(e){
                                                noti.recebeusername = $scope.evento.admusername;
                                                noti.recebe =$scope.criador;
                                            noti.envia = $scope.aux.iduser;
                                            noti.tipo = 5;
                                            noti.nomeevento = $scope.evento.nomeevento;
                                            EventoService.VerificaNotificacao(noti).then(function(res) {
                                              console.log(res);
                                              if(res){
                                                $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : 'Desisti de ir no seu evento, perdão', 
                                                      idevento : $scope.evento.idevento,
                                                      nomeevento : $scope.evento.nomeevento,
                                                      id_user_envia : $scope.aux.iduser,
                                                      username_envia : $scope.aux.username,
                                                      apelido_envia : $scope.aux.apelido,
                                                      tipo : '5', //pessoa desistiu
                                                      id_user_recebe : $scope.criador}).then(function (res){
                                                     $scope.response = res.data;
                                                     //console.log($scope.response.msg)
                                                   });
                                                EventoService.getusuario2(noti.recebeusername).then(function(user) {
                                                  $scope.pushnoti.titulo = 'Desisti';
                                                  $scope.pushnoti.msg = $scope.aux.username + ' desistiu de ir no seu evento';
                                                  $scope.pushnoti.token = user.devicetoken;
                                                   EventoService.MandaPushNoti($scope.pushnoti);
                                                });
                                              }
                                            });
                                            $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacaoporids.php", {id_user_recebe : noti.recebe,
                                                                              id_user_envia: noti.envia,
                                                                              nomeevento: noti.nomeevento,
                                                                              tipo : '1'});
                                                       if(meuestado == 2){
                                                         $scope.evento.patual = parseInt($scope.evento.patual)-1;
                                                        }
                                                    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/addpessoaevento.php', {idevento : $scope.evento.idevento,
                                                                                                                    patual : $scope.evento.patual});    
                                                    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser : $scope.aux.iduser,
                                                                                                                        idevento : $scope.evento.idevento});
                                                      $state.go('tabsController.home');
                                                    }
                                                   }
                                                 ]
                                         })
                           }


                }else{
                   var confirmPopup = $ionicPopup.show({
                                         title: 'ATENÇÃO!!!',
                                         template: 'Você esta preste a desistir de um evento, tens certeza disso?',
                                         buttons: [
                                            { text: 'Não',
                                              type: 'button-assertive'},
                                            {
                                              text: 'Sim',
                                              type: 'button-positive',
                                              onTap: function(e){
                                                noti.recebeusername = $scope.evento.username;
                                                noti.recebe =$scope.criador;
                                            noti.envia = $scope.aux.iduser;
                                            noti.tipo = 5;
                                            noti.nomeevento = $scope.evento.nomeevento;
                                            EventoService.VerificaNotificacao(noti).then(function(res) {
                                              console.log(res);
                                              if(res){
                                                $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : 'Desisti de ir no seu evento, perdão', 
                                                      idevento : $scope.evento.idevento,
                                                      nomeevento : $scope.evento.nomeevento,
                                                      id_user_envia : $scope.aux.iduser,
                                                      username_envia : $scope.aux.username,
                                                      apelido_envia : $scope.aux.apelido,
                                                      tipo : '5', //pessoa desistiu
                                                      id_user_recebe : $scope.criador}).then(function (res){
                                                     $scope.response = res.data;
                                                     //console.log($scope.response.msg)
                                                   });
                                                EventoService.getusuario2(noti.recebeusername).then(function(user) {
                                                  $scope.pushnoti.titulo = 'Desisti';
                                                  $scope.pushnoti.msg = $scope.aux.username + ' desistiu de ir no seu evento';
                                                  $scope.pushnoti.token = user.devicetoken;
                                                   EventoService.MandaPushNoti($scope.pushnoti);
                                                });
                                              }
                                            });
                                            $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacaoporids.php", {id_user_recebe : noti.recebe,
                                                                              id_user_envia: noti.envia,
                                                                              nomeevento: noti.nomeevento,
                                                                              tipo : '1'});
                                                       if(meuestado == 2){
                                                         $scope.evento.patual = parseInt($scope.evento.patual)-1;
                                                        }
                                                    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/addpessoaevento.php', {idevento : $scope.evento.idevento,
                                                                                                                    patual : $scope.evento.patual});    
                                                    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser : $scope.aux.iduser,
                                                                                                                        idevento : $scope.evento.idevento});
                                                      $state.go('tabsController.home');
                                                    }
                                                   }
                                                 ]
                                         })
                }



            }           
            $state.reload();
  }
  
}])

    
.controller('eventoPinzadoCtrl', ['$scope', '$stateParams', 'formItem', 'formUser', 'formtelaCriar', 'formOutro', '$http', '$timeout','$ionicPopup', 'EventoService', '$state', 'formEventoAbertosTab',// The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, formItem, formUser, formtelaCriar, formOutro, $http, $timeout, $ionicPopup, EventoService, $state, formEventoAbertosTab) {

  //$scope.evento = formItem.getForm();
  $scope.evento = formEventoAbertosTab.getForm();
  $scope.aux = formUser.getForm();

  $scope.tag = '';
  $scope.nuser = 0;
  var datainvalida = 0;
  $scope.pushnoti = {};
  $scope.borala = true;
  $scope.aviso =false;
  $scope.desistir = false;
  $scope.reserva = false;
  $scope.chathome = false;
  $scope.pinza = false;
  $scope.despinza = false;
  $scope.data = {};
  $scope.auxdata ={};
  $scope.limiteconfirmacao ={};
  $scope.fim = {};
  $scope.dia = {};

  var hj = $scope.evento.diainicio;
  var ano = (hj[0]+hj[1]+hj[2]+hj[3]).valueOf();
  var mes = (hj[5]+hj[6]).valueOf();
  var dia = (hj[8]+hj[9]).valueOf();

  var h = (hj[11]+hj[12]).valueOf();
  var m = (hj[14]+hj[15]).valueOf();

  var currentdate = new Date(); 
  var curr_date = (currentdate.getDate()<10?'0':'') + currentdate.getDate();
  var curr_month = (currentdate.getMonth()<10?'0':'') + (currentdate.getMonth() + 1); 
  var curr_year = currentdate.getFullYear();
  var h2 = (currentdate.getHours()<10?'0':'') + currentdate.getHours();
  var m2 = (currentdate.getMinutes()<10?'0':'') + currentdate.getMinutes();
    
  var  hjl = $scope.evento.dialimiteconfirmacao;
  $scope.dialimiteconfirmacao =  (hjl[8]+hjl[9]).valueOf()+'/'+(hjl[5]+hjl[6]).valueOf()+'/'+(hjl[0]+hjl[1]+hjl[2]+hjl[3])+' '+(hjl[11]+hjl[12]).valueOf()+':'+(hjl[14]+hjl[15]).valueOf();
    
  //$scope.dia = dia+'/'+mes+'/'+ano+' '+h+':'+m;

  var hjf = $scope.evento.diafim;
  $scope.diafim =  (hjf[8]+hjf[9]).valueOf()+'/'+(hjf[5]+hjf[6]).valueOf()+'/'+(hjf[0]+hjf[1]+hjf[2]+hjf[3])+' '+(hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf();
    
  var zone;
  var meuestado;
  var noti = {};
  var confirm = $scope.aux.iduser;

  var ano5 = (hjl[0]+hjl[1]+hjl[2]+hjl[3]).valueOf()-curr_year;
  var mes5 = (hjl[5]+hjl[6]).valueOf()-curr_month;
  var dia5 = (hjl[8]+hjl[9]).valueOf()-curr_date;
  var h5 = (hjl[11]+hjl[12]).valueOf()-h2;
  var m5 = (hjl[14]+hjl[15]).valueOf()-m2;

  var hjd = $scope.evento.duracao;
  var hd = (hjd[0]+hjd[1]).valueOf();
  var md = (hjd[3]+hjd[4]).valueOf();
  $scope.duracao= hd+':'+md;

  var  hjl = $scope.evento.dialimiteconfirmacao;
  $scope.limiteconfirmacao.dia =  (hjl[8]+hjl[9]).valueOf()+'/'+(hjl[5]+hjl[6]).valueOf();
  $scope.limiteconfirmacao.hora =  (hjl[11]+hjl[12]).valueOf()+':'+(hjl[14]+hjl[15]).valueOf();  
  
  

  var hjf = $scope.evento.diafim;
  $scope.fim.dia =  (hjf[8]+hjf[9]).valueOf()+'/'+(hjf[5]+hjf[6]).valueOf()+'/'+(hjf[0]+hjf[1]+hjf[2]+hjf[3]);
  $scope.fim.hora = (hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf();
  $scope.dia.dia = (hj[8]+hj[9]).valueOf()+'/'+(hj[5]+hj[6]).valueOf();
  $scope.dia.hora = (hj[11]+hj[12]).valueOf()+':'+(hj[14]+hj[15]).valueOf() +' - '+(hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf() ;


  

  if(ano5 == 0 && mes5 == 0 && dia5 == 0 && ((h5 == 1 && m5<30 && m5>0)||(h5==0 && m5 > 30)|| (h5==1 && m5>-30))){
    console.log('YELLOWZONE');
    zone = 'yellow';
    $scope.confirmaPessoa =true;
  }
  if(ano5<0 || mes5 < 0 ||(ano5 == 0 && mes5 == 0 && (dia5 < 0 || (dia5==0 && ((h5 == 0 && m5<=0)||(h5 < 0)))))){
    console.log('REDZONE');
    $scope.borala = false;
    $scope.aviso =true;
    zone = 'red';
    $scope.confirmaPessoa =false;
    $scope.deletarPessoa = false;
    $scope.edita = false;
  }else{
    $scope.borala = true;
    $scope.aviso =false;
  }
  if($scope.evento.preco == 0 || $scope.evento.preco =="Gratuito"){
      $scope.evento.preco = "Gratuito";
      $scope.porpessoa = false;
      $scope.porlocal = false;
    }else{
      if($scope.evento.precopor == 1){
        $scope.porpessoa = true;
        $scope.porlocal = false;
      }else{
        $scope.porpessoa = false;
        $scope.porlocal = true;
      }
    }

  if($scope.evento.adm ==  $scope.aux.iduser){
    $scope.deletarPessoa = true;
    $scope.confirmaPessoa =true;
    if(zone == 'red'){
      $scope.edita = false;
      $scope.deletarPessoa = false;
    }else{
      $scope.edita = true;
    }
    
  }
  if($scope.evento.genero == "masc"){
      $scope.masc = true;
      $scope.fem = false;
    }
    if($scope.evento.genero == "fem"){
        $scope.fem = true;
        $scope.masc = false;
    }
    if($scope.evento.genero == "todos"){
        $scope.fem = false;
        $scope.masc = false;
    }
  

  console.log($scope.evento.patual , $scope.evento.pmin)
  if(parseInt($scope.evento.patual) < parseInt($scope.evento.pmin) && zone == 'red'){
    console.log('Evento não acontece por falta de pessoas')
  }
  if(parseInt($scope.evento.patual) < parseInt($scope.evento.pmin) && zone == 'yellow'){
    console.log('Evento esta com poucas pessoas, talvez ele nao aconteça')
  }
  

  $scope.$on("$ionicView.enter", function(event, data){
    $scope.pushnoti = {};
    $scope.tag = '';
    $scope.items = [];
    $scope.pinza = false;
    $scope.despinza = false;
    //$scope.evento = formItem.getForm();
    $scope.evento = formEventoAbertosTab.getForm();
    $scope.aux = formUser.getForm();
    datainvalida = 0;

    $scope.auxdata ={};

            // Ve se eu tenho ou não interesse nesse evento
    $scope.auxpinza ={};
    $scope.auxpinza.iduser = $scope.aux.iduser;
    $scope.auxpinza.idevento = $scope.evento.idevento;

    EventoService.verificahorariopessoaeventoconfirmados($scope.aux).then(function(items) {
      $scope.auxdata = items;
      for(var r = 0;r<$scope.auxdata.length; r++){
        //console.log($scope.auxdata[r].idevento, $scope.auxdata[r].diainicio, $scope.auxdata[r].diafim , we ,$scope.evento.diafim);
        if($scope.evento.idevento!=$scope.auxdata[r].idevento){
          if (($scope.auxdata[r].diainicio < $scope.evento.diainicio && $scope.auxdata[r].diafim > $scope.evento.diainicio) || ($scope.auxdata[r].diainicio<$scope.evento.diafim && $scope.auxdata[r].diafim>$scope.evento.diafim) ||($scope.auxdata[r].diainicio > $scope.evento.diainicio && $scope.auxdata[r].diafim<$scope.evento.diafim) || ($scope.auxdata[r].diainicio < $scope.evento.diainicio && $scope.auxdata[r].diafim>$scope.evento.diafim) ) {
            console.log('horario invalido');
            datainvalida = 1;
          }
        }
      }
    });

    if($scope.aux.iduser != $scope.evento.adm){
       $scope.edita = false;
       console.log($scope.auxpinza.iduser)
      EventoService.Getpinza($scope.auxpinza).then(function(items) {
        //console.log(items.success)
        if(items.success != false){
          if (items[0].estado == 7) {
            $scope.pinza = false;
            $scope.despinza = true;
            console.log('eh favorito')
          }
        }else{
          console.log('N eh')
          $scope.pinza = true;
          $scope.despinza = false;
        } 
      });
    }else{
       if(zone == 'red'){
          $scope.edita = false;
        }else{
          $scope.edita = true;
        }
      $scope.pinza = false;
      $scope.despinza = false;
    }
    
            //Pega tags do evento
    EventoService.Gettags($scope.evento.idevento).then(function(tags) {
      for(var  i =0; i< tags.length;i++){
        $scope.tag = ($scope.tag + ' ' + tags[i].tag);
      } 
    });
            //Capacidade do evento
    if(parseInt($scope.evento.pmax) <= parseInt($scope.evento.patual)){
        console.log('Evento cheio');
        $scope.borala = false;
        $scope.reserva = true;
    }

    EventoService.GetParticipantes($scope.evento.idevento).then(function(parti) {
      //console.log($scope.items[0].idevento);
      $scope.nomeevento = parti[0].nomeevento;
      for (var i = 0; i < parti.length; i++) {
        if ($scope.aux.iduser == parti[i].iduser && parti[i].estado!=7 && parti[i].estado!=8) {
          $scope.nuser++;
          $scope.borala = false;
          $scope.reserva = false;
          $scope.desistir = true;
          $scope.chathome = true;
        }
        if ($scope.aux.iduser == parti[i].iduser) {
          meuestado = parti[i].estado;
        }
        if ($scope.aux.iduser == parti[i].iduser && parti[i].estado == 7) {
          $scope.pinza = false;
          $scope.despinza = true;
        }
        if ($scope.aux.iduser == parti[i].iduser && parti[i].estado == 8) {
          $scope.reserva = false;
          var alertPopup = $ionicPopup.alert({
                          title: 'ლ(*꒪ヮ꒪*)ლ',
                          template: 'Tais na fila da reserva, se vagar t avisaremos'
          });
          console.log('reservado');
        }            
      }
    });
    
    EventoService.GetParticipantesSemFav($scope.evento.idevento).then(function(items) {
      for (var i = 0; i < items.length; i++) {
        if (items[i].estado == 0) {
          items[i].confirmacao = 'Sou o organizador';
          $scope.criador = items[i].iduser;
        }
        if (items[i].estado == 1) {
          items[i].confirmacao = 'Aguardando confirmação';
        }
        if (items[i].estado == 2) {
          items[i].confirmacao = 'Confirmado';
        }
        if(items[i].borda == 0){
            items[i].bb = false;
            items[i].bs = false;
            items[i].bg = false;
          }
          if(items[i].borda == 1){
            items[i].bb = true;
            items[i].bs = false;
            items[i].bg = false;
          }
          if(items[i].borda == 2){
            items[i].bb = false;
            items[i].bs = true;
            items[i].bg = false;
          }
          if(items[i].borda == 3){
            items[i].bb = false;
            items[i].bs = false;
            items[i].bg = true;
          }
          if(items[i].profilepic[8] == 's' && items[i].profilepic[9] == '3'){
             items[i].profilepic=items[i].profilepic+"?{{getTimeStamp()}}";
           }else{
             items[i].profilepic=items[i].profilepic;
           }
      }
      $scope.items = items.concat($scope.items);
    });
  });

  $scope.enterItem =  function(item){
      formOutro.updateForm(item);
      $state.go('tabsController.perfil_outro_eventoabertos');
    }
    

    $scope.Vermapa = function(){
      $state.go('tabsController.ver_onde_mapa_Eventoabertos');
    }

  $scope.editar = function(){
    
    $state.go('tabsController.EditaEEAPart1');
  }

  $scope.aprova = function(item){
    console.log(meuestado)
    if(meuestado == 1 || meuestado == 8 || meuestado == 7 ){
                var alertPopup = $ionicPopup.alert({
                          title: '(°ロ°)☝',
                          template: 'Ainda não foi confirmado para poder aprovar alguem'
                        });
    }else{
      if(item.estado == 1 ){
        if (item.iduser!=$scope.aux.iduser  && confirm!= item.iduser) {
                confirm = item.iduser;
                console.log(item.iduser, $scope.aux.iduser);
                $scope.msgnoti = ('Tu foi aceito no evento: ' + $scope.evento.nomeevento);
                $scope.evento.patual = parseInt($scope.evento.patual)+1;
                $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/addpessoaevento.php', {idevento : $scope.evento.idevento,
                                                                                patual : $scope.evento.patual});
                $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpessoaevento.php' , {iduser : item.iduser,
                                                                                  idevento : $scope.evento.idevento,
                                                                                  confirmacao : 'Confirmação aceita',
                                                                                  estado :2});
                noti.recebeusername = item.username;
                noti.recebe = item.iduser;
                noti.envia = $scope.aux.iduser;
                noti.tipo = 2;
                noti.nomeevento = $scope.evento.nomeevento;
                $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacaoporids.php", {id_user_recebe : $scope.evento.adm,
                                                                              id_user_envia: item.iduser,
                                                                              nomeevento: noti.nomeevento,
                                                                              tipo : '1'});
                EventoService.VerificaNotificacao(noti).then(function(res) {
                  console.log(res);
                  if(res){
                    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : $scope.msgnoti, 
                                          idevento : $scope.evento.idevento,
                                          nomeevento : $scope.evento.nomeevento,
                                          id_user_envia : $scope.aux.iduser,
                                          username_envia : $scope.aux.username,
                                          apelido_envia : $scope.aux.apelido,
                                          tipo : '2',
                                          id_user_recebe : noti.recebe});
                    EventoService.getusuario2(noti.recebeusername).then(function(user) {
                      $scope.pushnoti.titulo =  'Boraaa!!!' ;
                      $scope.pushnoti.msg = $scope.msgnoti;
                      $scope.pushnoti.token = user.devicetoken;
                       EventoService.MandaPushNoti($scope.pushnoti);
                    });
                  }
                });
                 var alertPopup = $ionicPopup.alert({
                          title: '(/^▽^)/',
                          template: 'Vamos avisa-lo que ele foi aprovado, obrigado.'
                        });
                 item.confirmacao = 'Confirmação aprovada';

              
        }else{
          if(confirm ==  item.iduser){
            var alertPopup = $ionicPopup.alert({
                          title: '༼ つ ◕_◕ ༽つ',
                          template: 'Ja esta confirmado nesse evento!!!'
                        });
          }else{
              var alertPopup = $ionicPopup.alert({
                          title: 'ಠ_ಠ',
                          template: 'Seria muito facil tu se aceitar no evento né?'
                        });
          }
        }
      }
      if(item.estado == 2 ){
        var alertPopup = $ionicPopup.alert({
                      title: '༼ つ ◕_◕ ༽つ',
                      template: 'Ja esta confirmado nesse evento!!!'
                    });
        console.log('Ja estou confirmado')
      }
      console.log($scope.evento.diainicio)
      if(item.estado == 8 ){
        if(parseInt($scope.evento.patual)<parseInt($scope.evento.pmax)  && confirm!= item.iduser){
                confirm = item.iduser;
                console.log(item.iduser, $scope.aux.iduser);
                $scope.msgnoti = ('Tu foi aceito no evento: ' + $scope.evento.nomeevento);
                $scope.evento.patual = parseInt($scope.evento.patual)+1;
                $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/addpessoaevento.php', {idevento : $scope.evento.idevento,
                                                                                patual : $scope.evento.patual});
                $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpessoaevento.php' , {iduser : item.iduser,
                                                                                  idevento : $scope.evento.idevento,
                                                                                  confirmacao : 'Confirmação aceita',
                                                                                  estado :2});
                noti.recebeusername = item.username;
                noti.recebe = item.iduser;
                noti.envia = $scope.aux.iduser;
                noti.tipo = 2;
                noti.nomeevento = $scope.evento.nomeevento;
                EventoService.VerificaNotificacao(noti).then(function(res) {
                  console.log(res);
                  if(res){
                $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : $scope.msgnoti, 
                                          idevento : $scope.evento.idevento,
                                          nomeevento : $scope.evento.nomeevento,
                                          id_user_envia : $scope.aux.iduser,
                                          username_envia : $scope.aux.username,
                                          apelido_envia : $scope.aux.apelido,
                                          tipo : '2',
                                          id_user_recebe : noti.recebe});
                 EventoService.getusuario2(noti.recebeusername).then(function(user) {
                    $scope.pushnoti.titulo =  'Boraaa!!!' ;
                    $scope.pushnoti.msg = $scope.msgnoti;
                    $scope.pushnoti.token = user.devicetoken;
                     EventoService.MandaPushNoti($scope.pushnoti);
                  });
                }
              });
                  var alertPopup = $ionicPopup.alert({
                      title: '(°◡°♡).:｡',
                      template: 'Vamos confirmar a presença dele!!'
                    });
                 item.confirmacao = 'Confirmação aprovada';
         
        console.log('Ja estou confirmado')
        }else{
            var alertPopup = $ionicPopup.alert({
                        title: '(◕⌓◕;)',
                        template: 'Evento esta cheio, ou aumenta o numero de vagas ou escolha alguem para excluir do evento'
                      });
          console.log('Esta cheio o evento')
        }
      }
      if (item.estado == 0) {
                var alertPopup = $ionicPopup.alert({
                          title: 'ლ(́◉◞౪◟◉‵ლ)',
                          template: 'Ja sou o organizador, não preciso me confirmar'
                        });
      }
    }
  }

  $scope.onItemDelete = function(item) {
    if (item.iduser == $scope.aux.iduser) {
      var alertPopup = $ionicPopup.alert({
                      title: 'Oi?',
                      template: 'Tu és o organizador, não podes se deletar do seu evento, podes cancelar ele'
      });
    }else{
      var confirmPopup = $ionicPopup.show({
                   title: 'ATENÇÃO!!!',
                   template: 'Você esta preste excluir pessoa do evento, ela não poderá mais entrar neste evento, tens certeza disso?',
                   buttons: [
                      { text: 'Não',
                        type: 'button-assertive'},
                      {
                        text: 'Sim',
                        type: 'button-positive',
                        onTap: function(e){
                        noti.recebeusername = item.username;
                        noti.recebe = item.iduser;
                        noti.envia = $scope.aux.iduser;
                        noti.tipo = 9;
                        noti.nomeevento = $scope.evento.nomeevento;
                        EventoService.VerificaNotificacao(noti).then(function(res) {
                        console.log(res);
                        if(res){
                          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : 'Tu foi retirado do evento', 
                                                                                          idevento : $scope.evento.idevento,
                                                                                          nomeevento : $scope.evento.nomeevento,
                                                                                          id_user_envia : $scope.aux.iduser,
                                                                                          username_envia : $scope.aux.username,
                                                                                          apelido_envia : $scope.aux.apelido,
                                                                                          tipo : '9', //pessoa kickada
                                                                                          id_user_recebe : noti.recebe});
                          EventoService.getusuario2(noti.recebeusername).then(function(user) {
                            $scope.pushnoti.titulo = 'Retirado do evento';
                            $scope.pushnoti.msg = 'Você foi retirado do evento: ' + $scope.evento.nomeevento;
                            $scope.pushnoti.token = user.devicetoken;
                             EventoService.MandaPushNoti($scope.pushnoti);
                          });
                        }
                      });
                          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser :item.iduser,
                                                                                              idevento : $scope.evento.idevento});
                          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletachat.php', {iduser : item.iduser,
                                                                                      idevento : $scope.aux.idevento}); 
                          if(item.estado == 2){
                           $scope.evento.patual = parseInt($scope.evento.patual)-1;
                          }
                          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/addpessoaevento.php', {idevento : $scope.evento.idevento,
                                                                                          patual : $scope.evento.patual});     
                          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/pessoanaoevento.php', {iduser : item.iduser, 
                                                                                          idevento : $scope.evento.idevento,
                                                                                          nomeevento : $scope.evento.nomeevento,
                                                                                          estado : '1'});//foi kickado
                                                                                             

                          $scope.items.splice($scope.items.indexOf(item), 1);      
                              }
                             }
                           ]
                   })


      
    }
  }  

  $scope.confirma = function(){
    if(datainvalida==1){
      var alertPopup = $ionicPopup.alert({
        title: 'ಠ_ಠ',
        template: 'Ja tens um evento marcado nesta data querido'
      });
    }else{
      if ($scope.nuser == 0) {
            if (!$scope.evento.idevento || !$scope.aux.iduser) {
                            var alertPopup = $ionicPopup.alert({
                            title: 'Vish deu ruim',
                            template: 'Favor refaça seu login'
                          });

            }else{
              if(zone == 'yellow'){
                var confirmPopup = $ionicPopup.show({
                     title: 'ZONA AMARELA',
                     template: 'Evento esta na ZONA AMARELA, caso voce desista uma vez que confirmado a presença tu sofrerás um cartão amarelo. Deseja ir mesmo assim?',
                     buttons: [
                        { text: 'Não sei se vou',
                          type: 'button-assertive',
                          onTap: function(e){
                            console.log('nada acontece');
                          }},
                        {
                          text: 'Quero ir',
                          type: 'button-positive',
                          onTap: function(e){
                            $scope.confirmacao = 'aguardando confirmação';
                  $scope.estado = '1';
                  // console.log($scope.evento.idevento);
                  // console.log($scope.aux.iduser);
                  // console.log($scope.confirmacao);
                  // console.log($scope.nomeevento);
                  // console.log($scope.estado);
                  var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/irevento.php';
                  $http.post(link, {idevento : $scope.evento.idevento,
                                  idadm : $scope.evento.adm, 
                                  admusername : $scope.evento.admusername, 
                                  diainicio : $scope.evento.diainicio,
                                  diafim : $scope.evento.diafim,
                                  iduser : $scope.aux.iduser,
                                  username: $scope.aux.username,
                                  profilepic : $scope.aux.profilepic,
                                  devicetoken : $scope.aux.devicetoken,
                                  borda : $scope.aux.borda,
                                  apelido : $scope.aux.apelido,
                                  confirmacao : $scope.confirmacao,
                                  nomeevento :  $scope.nomeevento,
                                  eventopic : $scope.evento.eventopic, 
                                  estado : $scope.estado}).then(function (res){
                    $scope.response = res.data;
                    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser : $scope.aux.iduser,
                                                                                idevento : $scope.evento.idevento,
                                                                                estado: '5'});
                    if ($scope.response.success == true) {
                      $scope.msgnoti = ('To querendo ir no evento: ' + $scope.evento.nomeevento);
                      noti.recebe = $scope.evento.adm;
                      noti.envia = $scope.aux.iduser;
                      noti.tipo = 1;
                      noti.nomeevento = $scope.evento.nomeevento;
                      EventoService.VerificaNotificacao(noti).then(function(res) {
                        console.log(res);
                        if(res){
                          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificacriador.php', {notificacao : $scope.msgnoti, 
                                  idevento : $scope.evento.idevento,
                                  nomeevento : $scope.evento.nomeevento,
                                  id_user_envia : $scope.aux.iduser,
                                  username_envia : $scope.aux.username,
                                  apelido_envia : $scope.aux.apelido,
                                  tipo : '1',
                                  id_user_recebe : $scope.evento.adm});
                           EventoService.getusuario2($scope.evento.admusername).then(function(user) {
                            $scope.pushnoti.titulo = $scope.evento.nomeevento;
                            $scope.pushnoti.msg = $scope.aux.username + " quer participar do evento";
                            $scope.pushnoti.token = user.devicetoken;
                             EventoService.MandaPushNoti($scope.pushnoti);
                          });
                        }
                      });
                      $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacaoporids.php", {id_user_recebe : noti.recebe,
                                                                                id_user_envia: noti.envia,
                                                                                nomeevento: noti.nomeevento,
                                                                                tipo : '5'});
                      var alertPopup = $ionicPopup.alert({
                        title: 'Parabéns',
                        template: $scope.response.msg
                      });
                      alertPopup.then(function(){
                        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser : $scope.aux.iduser,
                                                                                idevento : $scope.evento.idevento,
                                                                                estado: '7'}).then(function (res){
                        $scope.response = res.data;
                        //console.log(i);
                        $scope.fav = false;
                        });
                        $state.go('tabsController.home');
                      });
                      
                    }else{
                      var alertPopup = $ionicPopup.alert({
                        title: 'Ocorreu uma falha',
                        template: $scope.response.msg
                      });
                    }
                    console.log($scope.response.msg);
                });
                          }}]
                   });
              }else{
                  $scope.confirmacao = 'aguardando confirmação';
                  $scope.estado = '1';
                  // console.log($scope.evento.idevento);
                  // console.log($scope.aux.iduser);
                  // console.log($scope.confirmacao);
                  // console.log($scope.nomeevento);
                  // console.log($scope.estado);
                  var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/irevento.php';
                  $http.post(link, {idevento : $scope.evento.idevento,
                                  idadm : $scope.evento.adm, 
                                  admusername : $scope.evento.admusername, 
                                  diainicio : $scope.evento.diainicio,
                                  diafim : $scope.evento.diafim,
                                  iduser : $scope.aux.iduser,
                                  username: $scope.aux.username,
                                  profilepic : $scope.aux.profilepic,
                                  devicetoken : $scope.aux.devicetoken,
                                  borda : $scope.aux.borda,
                                  apelido : $scope.aux.apelido,
                                  confirmacao : $scope.confirmacao,
                                  nomeevento :  $scope.nomeevento,
                                  eventopic : $scope.evento.eventopic, 
                                  estado : $scope.estado}).then(function (res){
                    $scope.response = res.data;
                    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser : $scope.aux.iduser,
                                                                                idevento : $scope.evento.idevento,
                                                                                estado: '5'});
                    if ($scope.response.success == true) {
                      $scope.msgnoti = ('To querendo ir no evento: ' + $scope.evento.nomeevento);
                      noti.recebe = $scope.evento.adm;
                      noti.envia = $scope.aux.iduser;
                      noti.tipo = 1;
                      noti.nomeevento = $scope.evento.nomeevento;
                      EventoService.VerificaNotificacao(noti).then(function(res) {
                        console.log(res);
                        if(res){
                          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificacriador.php', {notificacao : $scope.msgnoti, 
                                  idevento : $scope.evento.idevento,
                                  nomeevento : $scope.evento.nomeevento,
                                  id_user_envia : $scope.aux.iduser,
                                  username_envia : $scope.aux.username,
                                  apelido_envia : $scope.aux.apelido,
                                  tipo : '1',
                                  id_user_recebe : $scope.evento.adm});
                          EventoService.getusuario2($scope.evento.admusername).then(function(user) {
                            $scope.pushnoti.titulo = $scope.evento.nomeevento;
                            $scope.pushnoti.msg = $scope.aux.username + " quer participar do evento";
                            $scope.pushnoti.token = user.devicetoken;
                             EventoService.MandaPushNoti($scope.pushnoti);
                          });
                        }
                      });
                      $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacaoporids.php", {id_user_recebe : noti.recebe,
                                                                                id_user_envia: noti.envia,
                                                                                nomeevento: noti.nomeevento,
                                                                                tipo : '5'});
                      var alertPopup = $ionicPopup.alert({
                        title: 'Parabéns',
                        template: $scope.response.msg
                      });
                      alertPopup.then(function(){
                        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser : $scope.aux.iduser,
                                                                                idevento : $scope.evento.idevento,
                                                                                estado: '7'}).then(function (res){
                        $scope.response = res.data;
                        //console.log(i);
                        $scope.fav = false;
                        });
                        $state.go('tabsController.home');
                      });
                      
                    }else{
                      var alertPopup = $ionicPopup.alert({
                        title: 'Ocorreu uma falha',
                        template: $scope.response.msg
                      });
                    }
                    console.log($scope.response.msg);
                });
              }
            }
      
      }else{
        $scope.borala = false;
        $scope.desistir = true;
      }
      $state.reload();
    }
  }

  $scope.reservar = function(){
    var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/reservar.php';
                  $http.post(link, {idevento : $scope.evento.idevento, 
                                idadm : $scope.evento.adm, 
                                admusername : $scope.evento.admusername, 
                                iduser : $scope.aux.iduser,
                                apelido : $scope.aux.apelido, 
                                diainicio : $scope.evento.diainicio,
                                diafim : $scope.evento.diafim,
                                username: $scope.aux.username,
                                confirmacao : 'na fila',
                                profilepic: $scope.aux.profilepic,
                                devicetoken : $scope.aux.devicetoken,
                                nomeevento :  $scope.nomeevento, 
                                estado : '8'}).then(function (res){
                  $scope.response = res.data;
                  var alertPopup = $ionicPopup.alert({
                      title: 'ヾ(･д･ヾ)',
                      template: 'Vamos avisar que tu ta querendo ir, vai que aumentao o limite máximo ou alguem desiste né? T avisaremos se algo acontecer'
                    });
                    $scope.msgnoti = ('To querendo ir no evento: ' + $scope.evento.nomeevento + ' mas ele esta cheio, da pra fazer algo?');
                    //console.log($scope.msgnoti);
                    noti.recebe = $scope.evento.adm;
                    noti.envia = $scope.aux.iduser;
                    noti.tipo = 8; // solicitando reserva
                    noti.nomeevento = $scope.evento.nomeevento;
                    EventoService.VerificaNotificacao(noti).then(function(res) {
                      console.log(res);
                      if(res){
                        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificacriador.php', {notificacao : $scope.msgnoti, 
                                idevento : $scope.evento.idevento,
                                nomeevento : $scope.evento.nomeevento,
                                id_user_envia : $scope.aux.iduser,
                                username_envia : $scope.aux.username,
                                apelido_envia : $scope.aux.apelido,
                                tipo : '1',
                                id_user_recebe : $scope.evento.adm}).then(function (res){
                               $scope.response = res.data;
                               //console.log($scope.response.msg)
                             });
                        EventoService.getusuario2($scope.evento.admusername).then(function(user) {
                          $scope.pushnoti.titulo = $scope.evento.nomeevento;
                          $scope.pushnoti.msg = $scope.aux.username + " quer participar do evento";
                          $scope.pushnoti.token = user.devicetoken;
                           EventoService.MandaPushNoti($scope.pushnoti);
                        });
                      }
                    });
                    $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacaoporids.php", {id_user_recebe : noti.recebe,
                                                                              id_user_envia: noti.envia,
                                                                              nomeevento: noti.nomeevento,
                                                                              tipo : '5'});
                  $scope.reserva = false;
              });
    $state.reload();
  }

  $scope.desfavorita = function(){
    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser : $scope.aux.iduser,
                                                                        idevento : $scope.evento.idevento,
                                                                        estado: '7'});
    $scope.pinza = true;
    $scope.despinza = false;
  }

  $scope.favorita = function(){
    var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/irevento.php';
    $http.post(link, {idevento : $scope.evento.idevento, 
                              idadm : $scope.evento.adm, 
                              admusername : $scope.evento.admusername, 
                              iduser : $scope.aux.iduser,
                              diainicio : $scope.evento.diainicio,
                              diafim : $scope.evento.diafim,
                              username: $scope.aux.username,
                              profilepic : $scope.aux.profilepic,
                              devicetoken : $scope.aux.devicetoken,
                              borda : $scope.aux.borda,
                              apelido : $scope.aux.apelido,
                              confirmacao : 'interesse',
                              nomeevento :  $scope.nomeevento,
                              eventopic : $scope.evento.eventopic, 
                              estado : '7'});
    $scope.pinza = false;
    $scope.despinza = true;
  }

  $scope.reportar = function(){
    $scope.reportmsg = '';
    //console.log($scope.evento.admusername);
    $scope.report = [
      { text: "Conteúdo impróprio", checked: false },
      { text: "Linguajar inadequado", checked: false },
      { text: "Discurso de ódio", checked: false },
      { text: "Substancias ilicitas ", checked: false }
    ];
    $ionicPopup.confirm({
        title: 'Você quer reportar esse evento pq?',
        content: '<ion-checkbox ng-repeat="item in report" style="color: #FCFCFC;" ng-model="item.checked"  ng-checked="item.checked">{{item.text}}</ion-checkbox>',
        scope: $scope
    }).then(function(res) {
        if(res) {
          for (var h=0;h<3;h++){
            //console.log($scope.report[h].checked , h);
            if($scope.report[h].checked){
              $scope.reportmsg = $scope.reportmsg + $scope.report[h].text + ' ';
              //console.log($scope.reportmsg);
            }
          }
          if(h==3){
            console.log($scope.reportmsg);
            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/reportaevento.php', {namereportado : $scope.evento.admusername,
                                                                            reportadoid : $scope.evento.idevento,
                                                                            iduserreportando : $scope.aux.iduser,
                                                                            usernamereportando : $scope.aux.username,
                                                                            tiporeport : 'evento',
                                                                            motivo : $scope.reportmsg}).then(function (tes){
              $scope.response = tes.data;
              var alertPopup = $ionicPopup.alert({
                                        title: 'Obrigado',
                                        template: 'Este evento esta agora sobre avaliação, obrigado por manter a plataforma organizada'
              });
            });
          }
        }
    });
  }

  $scope.deletar =  function(){
    if ($scope.criador == $scope.aux.iduser) {
      if(zone == 'red' || zone == 'yellow'){
        if(zone == 'red' ){
          var myPopup = $ionicPopup.show({
                template: '<input type="text" placeholder="Escreva aqui pq nao vai rolar" ng-model="data.desculpa">',
                title: 'ATENÇÃO!!!',
                subTitle: 'Você esta preste a cancelar seu evento faltando muito pouco para seu começo, tens certeza disso?. Se tu realmente cancelar estaremos te dando um cartão vermelho. Para saber mais sobre eles va no seu indice de confirmação',
                scope: $scope,
                buttons: [
                  { text: 'Não' },
                  {
                    text: '<b>Sim</b>',
                    type: 'button-positive',
                    onTap: function(e) {
                      // console.log($scope.items.length);
                       var notifica = ("Desisti de fazer o evento, " + $scope.data.desculpa);
                      // console.log(notifica);
                      // console.log($scope.aux.iduser);
                    
                      formtelaCriar.updateForm(1);
                       $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacaoporevento.php' , {idevento : $scope.evento.idevento,
                                                                                    nomeevento : $scope.evento.nomeevento});
                      
                      
                      $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/penalidade.php', {iduser : $scope.aux.iduser,
                                                                                   idevento : $scope.evento.idevento,
                                                                                   username : $scope.aux.username,
                                                                                   tipopenalidade : '2'});     // tipo2 saiu na redzone         
                      EventoService.GetParticipantes($scope.evento.idevento).then(function(ppl) {
                                   for (var i = 0; i < ppl.length; i++) {
                                    if ($scope.aux.iduser != ppl[i].iduser) {
                                          noti.recebeusername = ppl[i].username;
                                          noti.recebe = ppl[i].iduser;
                                          noti.envia = $scope.aux.iduser;
                                          noti.tipo = 4;
                                          noti.nomeevento = $scope.evento.nomeevento;
                                          EventoService.VerificaNotificacao(noti).then(function(res) {
                                            console.log(res);
                                            if(res){
                                              $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : notifica, 
                                                    idevento : $scope.evento.idevento,
                                                    nomeevento : $scope.evento.nomeevento,
                                                    id_user_envia : $scope.aux.iduser,
                                                    username_envia : $scope.aux.username,
                                                    apelido_envia : $scope.aux.apelido,
                                                    tipo : '5',   
                                                    id_user_recebe : noti.recebe}).then(function (res){
                                                   $scope.response = res.data;
                                                   console.log($scope.response.msg)
                                                 });
                                              EventoService.getusuario2(noti.recebeusername).then(function(user) {
                                                $scope.pushnoti.titulo = $scope.evento.nomeevento + ' Cancelado';
                                                $scope.pushnoti.msg = notifica;
                                                $scope.pushnoti.token = user.devicetoken;
                                                 EventoService.MandaPushNoti($scope.pushnoti);
                                              });
                                            }
                                          });
                                        }
                                  }
                                 })
                      for(var i = 0; i< $scope.items.length; i++){
                        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser : $scope.items[i].iduser,
                                                                                           idevento : $scope.evento.idevento});
                      }
                      $scope.evento.estado = "3";                
                      EventoService.atualizarevento($scope.evento);
                      $state.go('tabsController.home');
                    }
                  }
                ]
          });
          console.log('criador do evento cancelando proprio evento');
        }else{
          var myPopup = $ionicPopup.show({
                      template: '<input type="text" placeholder="Escreva aqui pq nao vai rolar" ng-model="data.desculpa">',
                      title: 'ATENÇÃO!!!',
                      subTitle: 'Você esta preste a cancelar seu evento faltando pouco para seu começo, tens certeza disso?. Se tu realmente cancelar estaremos te dando um cartão amarelo. Para saber mais sobre eles va no seu indice de confirmação',
                      scope: $scope,
                      buttons: [
                        { text: 'Não' },
                        {
                          text: '<b>Sim</b>',
                          type: 'button-positive',
                          onTap: function(e) {
                            // console.log($scope.items.length);
                             var notifica = ("Desisti de fazer o evento, " + $scope.data.desculpa);
                            // console.log(notifica);
                            // console.log($scope.aux.iduser);
                          
                            formtelaCriar.updateForm(1);
                             $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacaoporevento.php' , {idevento : $scope.evento.idevento,
                                                                                          nomeevento : $scope.evento.nomeevento});
                            
                            
                            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/penalidade.php', {iduser : $scope.aux.iduser,
                                                                                       idevento : $scope.evento.idevento,
                                                                                       username : $scope.aux.username,
                                                                                       tipopenalidade : '1'});   // tipo 1 saiu na yellow zone               
                            EventoService.GetParticipantes($scope.evento.idevento).then(function(ppl) {
                                   for (var i = 0; i < ppl.length; i++) {
                                    if ($scope.aux.iduser != ppl[i].iduser) {
                                          noti.recebeusername = ppl[i].username;
                                          noti.recebe = ppl[i].iduser;
                                          noti.envia = $scope.aux.iduser;
                                          noti.tipo = 4;
                                          noti.nomeevento = $scope.evento.nomeevento;
                                          EventoService.VerificaNotificacao(noti).then(function(res) {
                                            console.log(res);
                                            if(res){
                                              $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : notifica, 
                                                    idevento : $scope.evento.idevento,
                                                    nomeevento : $scope.evento.nomeevento,
                                                    id_user_envia : $scope.aux.iduser,
                                                    username_envia : $scope.aux.username,
                                                    apelido_envia : $scope.aux.apelido,
                                                    tipo : '5',   
                                                    id_user_recebe : noti.recebe}).then(function (res){
                                                   $scope.response = res.data;
                                                   console.log($scope.response.msg)
                                                 });
                                              EventoService.getusuario2(noti.recebeusername).then(function(user) {
                                                $scope.pushnoti.titulo = $scope.evento.nomeevento + ' Cancelado';
                                                $scope.pushnoti.msg = notifica;
                                                $scope.pushnoti.token = user.devicetoken;
                                                 EventoService.MandaPushNoti($scope.pushnoti);
                                              });
                                            }
                                          });
                                        }
                                  }
                                 })
                            for(var i = 0; i< $scope.items.length; i++){
                              $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser : $scope.items[i].iduser,
                                                                                                 idevento : $scope.evento.idevento});
                            }
                            $scope.evento.estado = "3";                
                            EventoService.atualizarevento($scope.evento);
                            $state.go('tabsController.home');
                          }
                        }
                      ]
          });
          console.log('criador do evento cancelando proprio evento');
        }
      }else{
        var myPopup = $ionicPopup.show({
                  template: '<input type="text" placeholder="Escreva aqui pq nao vai rolar" ng-model="data.desculpa">',
                  title: 'ATENÇÃO!!!',
                  subTitle: 'Você esta preste a deletar seu evento, tens certeza disso?',
                  scope: $scope,
                  buttons: [
                    { text: 'Não' },
                    {
                      text: '<b>Sim</b>',
                      type: 'button-positive',
                      onTap: function(e) {
                        // console.log($scope.items.length);
                         var notifica = ("Desisti de fazer o evento, " + $scope.data.desculpa);
                        // console.log(notifica);
                        // console.log($scope.aux.iduser);
                      
                        formtelaCriar.updateForm(1);
                         $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacaoporevento.php' , {idevento : $scope.evento.idevento,
                                                                                                    nomeevento : $scope.evento.nomeevento});
                                     
                        
                        EventoService.GetParticipantes($scope.evento.idevento).then(function(ppl) {
                                   for (var i = 0; i < ppl.length; i++) {
                                    if ($scope.aux.iduser != ppl[i].iduser) {
                                          noti.recebeusername = ppl[i].username;
                                          noti.recebe = ppl[i].iduser;
                                          noti.envia = $scope.aux.iduser;
                                          noti.tipo = 4;
                                          noti.nomeevento = $scope.evento.nomeevento;
                                          EventoService.VerificaNotificacao(noti).then(function(res) {
                                            console.log(res);
                                            if(res){
                                            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : notifica, 
                                                    idevento : $scope.evento.idevento,
                                                    nomeevento : $scope.evento.nomeevento,
                                                    id_user_envia : $scope.aux.iduser,
                                                    username_envia : $scope.aux.username,
                                                    apelido_envia : $scope.aux.apelido,
                                                    tipo : '5',   
                                                    id_user_recebe : noti.recebe}).then(function (res){
                                                   $scope.response = res.data;
                                                   console.log($scope.response.msg)
                                                 });
                                              EventoService.getusuario2(noti.recebeusername).then(function(user) {
                                                $scope.pushnoti.titulo = $scope.evento.nomeevento + ' Cancelado';
                                                $scope.pushnoti.msg = notifica;
                                                $scope.pushnoti.token = user.devicetoken;
                                                 EventoService.MandaPushNoti($scope.pushnoti);
                                              });
                                            }
                                          });
                                        }
                                  }
                                 })
                        for(var i = 0; i< $scope.items.length; i++){
    
                          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser : $scope.items[i].iduser,
                                                                                             idevento : $scope.evento.idevento});
                        }                
                        $scope.evento.estado = "3";                
                       EventoService.atualizarevento($scope.evento);
                                            $state.go('tabsController.home');
                                            }
                    }]
                   });

                        console.log('criador do evento cancelando proprio evento');
        }
              
      }else{
        if (meuestado!=1) {


         if(zone == 'red' || zone == 'yellow'){
                          if(zone == 'red' ){

                               var confirmPopup = $ionicPopup.show({
                                         title: 'ATENÇÃO!!!',
                                         template: 'Você esta preste a desistir de um evento faltando muito pouco tempo para seu começo, tens certeza disso? Se tu realmente cancelar estaremos te dando um cartão vermelho. Para saber mais sobre eles va no seu indice de confirmação ',
                                         buttons: [
                                            { text: 'Não',
                                              type: 'button-assertive'},
                                            {
                                              text: 'Sim',
                                              type: 'button-positive',
                                              onTap: function(e){
                                                noti.recebeusername = $scope.evento.admusername
                                                noti.recebe = $scope.criador;
                                            noti.envia = $scope.aux.iduser;
                                            noti.tipo = 5;
                                            noti.nomeevento = $scope.evento.nomeevento;
                                            EventoService.VerificaNotificacao(noti).then(function(res) {
                                              console.log(res);
                                              if(res){
                                                $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : 'Desisti de ir no seu evento, perdão', 
                                                      idevento : $scope.evento.idevento,
                                                      nomeevento : $scope.evento.nomeevento,
                                                      id_user_envia : $scope.aux.iduser,
                                                      username_envia : $scope.aux.username,
                                                      apelido_envia : $scope.aux.apelido,
                                                      tipo : '5', //pessoa desistiu
                                                      id_user_recebe : $scope.criador});
                                                EventoService.getusuario2(noti.recebeusername).then(function(user) {
                                                  $scope.pushnoti.titulo = 'Desisti';
                                                  $scope.pushnoti.msg = 'Desisti de ir no seu evento: ' + $scope.evento.nomeevento;;
                                                  $scope.pushnoti.token = user.devicetoken;
                                                   EventoService.MandaPushNoti($scope.pushnoti);
                                                });
                                              }
                                            });
                                            $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacaoporids.php", {id_user_recebe : noti.recebe,
                                                                              id_user_envia: noti.envia,
                                                                              nomeevento: noti.nomeevento,
                                                                              tipo : '1'});
                                            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/penalidade.php', {iduser : $scope.aux.iduser,
                                                                                           idevento : $scope.evento.idevento,
                                                                                           username : $scope.aux.username,
                                                                                           tipopenalidade : '2'});     // tipo2 saiu na redzone  
                                            if(meuestado == 2){
                                               $scope.evento.patual = parseInt($scope.evento.patual)-1;
                                            }
                                            if(parseInt($scope.evento.patual)<parseInt($scope.evento.pmin)){
                                              $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/mudaestadoevento.php', {idevento : $scope.evento.idevento,
                                                                                                            estado : '2'});
                                              $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : 'ATENÇÃO!! Numero de pessoas agora nao bate o mínimo.', 
                                                          idevento : $scope.evento.idevento,
                                                          nomeevento : $scope.evento.nomeevento,
                                                          id_user_envia : $scope.aux.iduser,
                                                          username_envia : $scope.aux.username,
                                                          apelido_envia : $scope.aux.apelido,
                                                          tipo : '12', //pessoa desistiu com menos pessoas para acontecer ou nao um evento
                                                          id_user_recebe : $scope.criador});
                                            }
                                            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/addpessoaevento.php', {idevento : $scope.evento.idevento,
                                                                                                            patual : $scope.evento.patual});    
                                            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser : $scope.aux.iduser,
                                                                                                              idevento : $scope.evento.idevento});
                                            $state.go('tabsController.home');
                                                    }
                                                   }
                                                 ]
                                         })
                             }else{
                                 var confirmPopup = $ionicPopup.show({
                                         title: 'ATENÇÃO!!!',
                                         template: 'Você esta preste a desistir de um evento faltando pouco tempo para seu começo, tens certeza disso? Se tu realmente cancelar estaremos te dando um cartão amarelo. Para saber mais sobre eles va no seu indice de confirmação',
                                         buttons: [
                                            { text: 'Não',
                                              type: 'button-assertive'},
                                            {
                                              text: 'Sim',
                                              type: 'button-positive',
                                              onTap: function(e){
                                                noti.recebeusername = $scope.evento.admusername;
                                                noti.recebe = $scope.criador;
                                            noti.envia = $scope.aux.iduser;
                                            noti.tipo = 5;
                                            noti.nomeevento = $scope.evento.nomeevento;
                                              EventoService.VerificaNotificacao(noti).then(function(res) {
                                              console.log(res);
                                              if(res){
                                                $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : 'Desisti de ir no seu evento, perdão', 
                                                      idevento : $scope.evento.idevento,
                                                      nomeevento : $scope.evento.nomeevento,
                                                      id_user_envia : $scope.aux.iduser,
                                                      username_envia : $scope.aux.username,
                                                      apelido_envia : $scope.aux.apelido,
                                                      tipo : '5', //pessoa desistiu
                                                      id_user_recebe : $scope.criador});
                                                EventoService.getusuario2(noti.recebeusername).then(function(user) {
                                                  $scope.pushnoti.titulo = 'Desisti';
                                                  $scope.pushnoti.msg = 'Desisti de ir no seu evento: ' + $scope.evento.nomeevento;;
                                                  $scope.pushnoti.token = user.devicetoken;
                                                   EventoService.MandaPushNoti($scope.pushnoti);
                                                });
                                              }
                                              });
                                              $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacaoporids.php", {id_user_recebe : noti.recebe,
                                                                              id_user_envia: noti.envia,
                                                                              nomeevento: noti.nomeevento,
                                                                              tipo : '1'});
                                                       $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/penalidade.php', {iduser : $scope.aux.iduser,
                                                                                                     idevento : $scope.evento.idevento,
                                                                                                     username : $scope.aux.username,
                                                                                                     tipopenalidade : '1'});   // tipo 1 saiu na yellow zone   
                                                      
                                                         $scope.evento.patual = parseInt($scope.evento.patual)-1;
                                                        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/addpessoaevento.php', {idevento : $scope.evento.idevento,
                                                                                          patual : $scope.evento.patual});    
                                                    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser : $scope.aux.iduser,
                                                                                                                        idevento : $scope.evento.idevento});
                                                      $state.go('tabsController.home');
                                                    }
                                                   }
                                                 ]
                                         })

                             }
                           
                         }else{
                             var confirmPopup = $ionicPopup.show({
                                         title: 'ATENÇÃO!!!',
                                         template: 'Você esta preste a desistir de um evento, tens certeza disso?',
                                         buttons: [
                                            { text: 'Não',
                                              type: 'button-assertive'},
                                            {
                                              text: 'Sim',
                                              type: 'button-positive',
                                              onTap: function(e){
                                                noti.recebeusername = $scope.evento.admusername;
                                                noti.recebe =$scope.criador;
                                            noti.envia = $scope.aux.iduser;
                                            noti.tipo = 5;
                                            noti.nomeevento = $scope.evento.nomeevento;
                                            EventoService.VerificaNotificacao(noti).then(function(res) {
                                              console.log(res);
                                              if(res){
                                                $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : 'Desisti de ir no seu evento, perdão', 
                                                      idevento : $scope.evento.idevento,
                                                      nomeevento : $scope.evento.nomeevento,
                                                      id_user_envia : $scope.aux.iduser,
                                                      username_envia : $scope.aux.username,
                                                      apelido_envia : $scope.aux.apelido,
                                                      tipo : '5', //pessoa desistiu
                                                      id_user_recebe : $scope.criador}).then(function (res){
                                                     $scope.response = res.data;
                                                     //console.log($scope.response.msg)
                                                   });
                                                EventoService.getusuario2(noti.recebeusername).then(function(user) {
                                                  $scope.pushnoti.titulo = 'Desisti';
                                                  $scope.pushnoti.msg = 'Desisti de ir no seu evento: ' + $scope.evento.nomeevento;;
                                                  $scope.pushnoti.token = user.devicetoken;
                                                   EventoService.MandaPushNoti($scope.pushnoti);
                                                });
                                                    }
                                                  });
                                            $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacaoporids.php", {id_user_recebe : noti.recebe,
                                                                              id_user_envia: noti.envia,
                                                                              nomeevento: noti.nomeevento,
                                                                              tipo : '1'});
                                                       if(meuestado == 2){
                                                         $scope.evento.patual = parseInt($scope.evento.patual)-1;
                                                        }
                                                    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/addpessoaevento.php', {idevento : $scope.evento.idevento,
                                                                                                                    patual : $scope.evento.patual});    
                                                    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser : $scope.aux.iduser,
                                                                                                                        idevento : $scope.evento.idevento});
                                                      $state.go('tabsController.home');
                                                    }
                                                   }
                                                 ]
                                         })
                           }


                }else{
                   var confirmPopup = $ionicPopup.show({
                                         title: 'ATENÇÃO!!!',
                                         template: 'Você esta preste a desistir de um evento, tens certeza disso?',
                                         buttons: [
                                            { text: 'Não',
                                              type: 'button-assertive'},
                                            {
                                              text: 'Sim',
                                              type: 'button-positive',
                                              onTap: function(e){
                                                noti.recebeusername = $scope.evento.admusername;
                                                noti.recebe =$scope.criador;
                                            noti.envia = $scope.aux.iduser;
                                            noti.tipo = 5;
                                            noti.nomeevento = $scope.evento.nomeevento;
                                            EventoService.VerificaNotificacao(noti).then(function(res) {
                                              console.log(res);
                                              if(res){
                                                $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : 'Desisti de ir no seu evento, perdão', 
                                                      idevento : $scope.evento.idevento,
                                                      nomeevento : $scope.evento.nomeevento,
                                                      id_user_envia : $scope.aux.iduser,
                                                      username_envia : $scope.aux.username,
                                                      apelido_envia : $scope.aux.apelido,
                                                      tipo : '5', //pessoa desistiu
                                                      id_user_recebe : $scope.criador}).then(function (res){
                                                     $scope.response = res.data;
                                                     //console.log($scope.response.msg)
                                                   });
                                                      EventoService.getusuario2(noti.recebeusername).then(function(user) {
                                                  $scope.pushnoti.titulo = 'Desisti';
                                                  $scope.pushnoti.msg = 'Desisti de ir no seu evento: ' + $scope.evento.nomeevento;;
                                                  $scope.pushnoti.token = user.devicetoken;
                                                   EventoService.MandaPushNoti($scope.pushnoti);
                                                });
                                                    }
                                                  });
                                            $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacaoporids.php", {id_user_recebe : noti.recebe,
                                                                              id_user_envia: noti.envia,
                                                                              nomeevento: noti.nomeevento,
                                                                              tipo : '1'});
                                                       if(meuestado == 2){
                                                         $scope.evento.patual = parseInt($scope.evento.patual)-1;
                                                        }
                                                    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/addpessoaevento.php', {idevento : $scope.evento.idevento,
                                                                                                                    patual : $scope.evento.patual});    
                                                    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletapessoaevento.php', {iduser : $scope.aux.iduser,
                                                                                                                        idevento : $scope.evento.idevento});
                                                      $state.go('tabsController.home');
                                                    }
                                                   }
                                                 ]
                                         })
                }



            }           
            $state.reload();
  }
   

}])

.controller('eventofiltroEncerradoCtrl', ['$scope', '$stateParams', 'formItem', 'formUser', 'formtelaCriar', 'formOutro', '$http', '$timeout','$ionicPopup', 'EventoService', '$state', 'formvimdofiltro', 'formvimdofiltroperfil',// The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, formItem, formUser, formtelaCriar, formOutro, $http, $timeout, $ionicPopup, EventoService, $state,formvimdofiltro, formvimdofiltroperfil) {

  $scope.evento = formItem.getForm();
  $scope.aux = formUser.getForm();
  $scope.diaf = {};
  $scope.tag = '';
  $scope.items = [];
  $scope.coments = {};
  $scope.ncomen = 0;
  console.log($scope.evento.idevento)
  var hj = $scope.evento.diainicio;
  var ano = (hj[0]+hj[1]+hj[2]+hj[3]).valueOf();
  var mes = (hj[5]+hj[6]).valueOf();
  var dia = (hj[8]+hj[9]).valueOf();
  var h = (hj[11]+hj[12]).valueOf();
  var m = (hj[14]+hj[15]).valueOf();
  $scope.dia = dia+'/'+mes+'/'+ano+' '+h+':'+m;
  
  var  hjl = $scope.evento.dialimiteconfirmacao;
  $scope.dialimiteconfirmacao =  (hjl[8]+hjl[9]).valueOf()+'/'+(hjl[5]+hjl[6]).valueOf()+'/'+(hjl[0]+hjl[1]+hjl[2]+hjl[3])+' '+(hjl[11]+hjl[12]).valueOf()+':'+(hjl[14]+hjl[15]).valueOf();
    
  var hjf = $scope.evento.diafim;
  $scope.diafim =  (hjf[8]+hjf[9]).valueOf()+'/'+(hjf[5]+hjf[6]).valueOf()+'/'+(hjf[0]+hjf[1]+hjf[2]+hjf[3])+' '+(hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf();
    
  $scope.diaf.dia = (hj[8]+hj[9]).valueOf()+'/'+(hj[5]+hj[6]).valueOf();
  $scope.diaf.hora = (hj[11]+hj[12]).valueOf()+':'+(hj[14]+hj[15]).valueOf() +' - '+(hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf() ;

    if($scope.evento.genero == "masc"){
      $scope.masc = true;
      $scope.fem = false;
    }
    if($scope.evento.genero == "fem"){
        $scope.fem = true;
        $scope.masc = false;
    }
    if($scope.evento.genero == "todos"){
        $scope.fem = false;
        $scope.masc = false;
    }   
    if($scope.evento.preco == 0 || $scope.evento.preco =="Gratuito"){
      $scope.evento.preco = "Gratuito";
      $scope.porpessoa = false;
      $scope.porlocal = false;
    }else{
      if($scope.evento.precopor == 1){
        $scope.porpessoa = true;
        $scope.porlocal = false;
      }else{
        $scope.porpessoa = false;
        $scope.porlocal = true;
      }
    }
  $scope.$on("$ionicView.enter", function(event, data){

    $scope.tag = '';
    $scope.items = [];
    $scope.nota = 0;
    $scope.coments = {};
    $scope.ncomen = 0;
    //$scope.evento = formItem.getForm();
    $scope.aux = formUser.getForm();


     
    EventoService.GetComentariosevento($scope.evento).then(function(coments) {
      if(coments=='Error'){
        $scope.nota = '';
      }else{
        for (var i = 0; i < coments.length; i++) {
          $scope.nota = parseFloat(coments[i].nota) + $scope.nota ;
        }
        $scope.nota = ($scope.nota/coments.length).toFixed(1);
        $scope.coments = coments;
        $scope.ncomen = $scope.coments.length;
      }     
    });
    
            //Pega tags do evento
    EventoService.Gettags($scope.evento.idevento).then(function(tags) {
      for(var  i =0; i< tags.length;i++){
        $scope.tag = ($scope.tag + ' ' + tags[i].tag);
      } 
    });
    console.log($scope.evento.idevento)
    EventoService.GetParticipantesSemFav($scope.evento.idevento).then(function(items) {
      for (var i = 0; i < items.length; i++) {
        if(items[i].borda == 0){
            items[i].bb = false;
            items[i].bs = false;
            items[i].bg = false;
          }
          if(items[i].borda == 1){
            items[i].bb = true;
            items[i].bs = false;
            items[i].bg = false;
          }
          if(items[i].borda == 2){
            items[i].bb = false;
            items[i].bs = true;
            items[i].bg = false;
          }
          if(items[i].borda == 3){
            items[i].bb = false;
            items[i].bs = false;
            items[i].bg = true;
          }
          if(items[i].profilepic[8] == 's' && items[i].profilepic[9] == '3'){
             items[i].profilepic=items[i].profilepic+"?{{getTimeStamp()}}";
           }else{
             items[i].profilepic=items[i].profilepic;
           }
      }
      $scope.items = items;
    });
  });

  $scope.enterItem =  function(item){
    formOutro.updateForm(item);
    //console.log(item.iduser);
    formvimdofiltroperfil.updateForm(false);
    $state.go('tabsController.perfilOutro');
  }

  $scope.Vermapa = function(){
    $state.go('tabsController.ver_onde_mapa');
  }

  $scope.reportar = function(){
    $scope.reportmsg = '';
    //console.log($scope.evento.admusername);
    $scope.report = [
      { text: "Conteúdo impróprio", checked: false },
      { text: "Linguajar inadequado", checked: false },
      { text: "Discurso de ódio", checked: false },
      { text: "Substancias ilicitas ", checked: false }
    ];
    $ionicPopup.confirm({
        title: 'Você quer reportar esse evento pq?',
        content: '<ion-checkbox ng-repeat="item in report" style="color: #FCFCFC;" ng-model="item.checked"  ng-checked="item.checked">{{item.text}}</ion-checkbox>',
        scope: $scope
    }).then(function(res) {
        if(res) {
          for (var h=0;h<3;h++){
            //console.log($scope.report[h].checked , h);
            if($scope.report[h].checked){
              $scope.reportmsg = $scope.reportmsg + $scope.report[h].text + ' ';
              //console.log($scope.reportmsg);
            }
          }
          if(h==3){
            console.log($scope.reportmsg);
            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/reportaevento.php', {namereportado : $scope.evento.admusername,
                                                                            reportadoid : $scope.evento.idevento,
                                                                            iduserreportando : $scope.aux.iduser,
                                                                            usernamereportando : $scope.aux.username,
                                                                            tiporeport : 'evento',
                                                                            motivo : $scope.reportmsg}).then(function (tes){
              $scope.response = tes.data;
              var alertPopup = $ionicPopup.alert({
                                        title: 'Obrigado',
                                        template: 'Este evento esta agora sobre avaliação, obrigado por manter a plataforma organizada'
              });
            });
          }
        }
    });
  }

  $scope.entrar = function(){
    if($scope.ncomen>0){
      $state.go('tabsController.comentariosEFE');
    }else{
      var alertPopup = $ionicPopup.alert({title: '٩꒰´·⌢•｀꒱۶⁼³₌₃ﾟ',
                                        template: 'Ninguem comentou sobre este evento ainda'
      });
    }
  }


}])

.controller('ver_onde_mapaCtrl', ['$scope', '$stateParams', '$cordovaGeolocation', '$state', '$ionicLoading', 'formItem',  // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $cordovaGeolocation, $state, $ionicLoading, formItem) {
 $scope.evento = formItem.getForm();
 //$scope.coord = {};
  console.log($scope.evento.lat);
  console.log($scope.evento.lng);
        
        var latlng = {lat: parseFloat($scope.evento.lat), lng: parseFloat($scope.evento.lng)};


        var mapOptions = {
                center: latlng,
                zoom: 16,
                mapTypeId: google.maps.MapTypeId.ROADMAP
            };          
             

        var map = new google.maps.Map(document.getElementById("map_canvas2"), mapOptions); 
        var geocoder = new google.maps.Geocoder;
        var infowindow = new google.maps.InfoWindow({
                                                      maxWidth: 200
                                                    });

        geocoder.geocode({'location': latlng}, function(results, status) {
          if (status === 'OK') {
            if (results[1]) {
              var marker = new google.maps.Marker({
                position: latlng,
                map: map,
                title: "Borai",
                icon: 'http://maps.google.com/mapfiles/ms/icons/green-dot.png',
                animation: google.maps.Animation.DROP 
              });
              infowindow.setContent(results[0].formatted_address);
              infowindow.open(map, marker);
            } else {
              window.alert('No results found');
            }
          } else {
            window.alert('Geocoder failed due to: ' + status);
          }
        });

        $scope.map = map;  
             
}])

.controller('comentariosEFECtrl', ['$scope', '$stateParams', 'formItem', 'EventoService', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, formItem, EventoService) {
  $scope.evento = formItem.getForm();
  $scope.nota = 0;
  $scope.items ={};
   
  EventoService.GetComentariosevento($scope.evento).then(function(items) {
    console.log(items)
    if(items=='Error'){
      $scope.nota = 0;
      $scope.items ={};
    }else{
      console.log('Tem comentarios')
      $scope.items = items;
      for (var i = 0; i < items.length; i++) {
        $scope.nota = parseFloat(items[i].nota) + $scope.nota ;
        if(items[i].profilepic[8] == 's' && items[i].profilepic[9] == '3'){
             $scope.items[i].profilepic=items[i].profilepic+"?{{getTimeStamp()}}";
           }else{
             $scope.items[i].profilepic=items[i].profilepic;
           }
        //$scope.items[i].profilepic = items[i].profilepic+"?{{getTimeStamp()}}";;
      }
      $scope.nota = ($scope.nota/items.length).toFixed(1);
      
    }     
  });

}])
  
.controller('editarPerfilCtrl', ['$scope', '$stateParams', 'formUser', 'EventoService','$ionicPopup', '$timeout','$state', '$cordovaCamera', '$cordovaFile', '$cordovaFileTransfer', '$ionicLoading', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, formUser, EventoService, $ionicPopup, $timeout, $state, $cordovaCamera, $cordovaFile, $cordovaFileTransfer, $ionicLoading) {

  $scope.user = formUser.getForm();
  $scope.cidade ={};
  $scope.auxusername = $scope.user.username;
  if(!$scope.imgURI){
    $scope.imgURI = $scope.user.profilepic;
    if($scope.user.profilepic[8] == 's' && $scope.user.profilepic[9] == '3'){
             document.getElementById("imageidEditar").src=$scope.user.profilepic+"?{{getTimeStamp()}}";
           }else{
             document.getElementById("imageidEditar").src=$scope.user.profilepic;
           }
    //document.getElementById("imageidEditar").src=$scope.user.profilepic+"?{{getTimeStamp()}}";
  }

  var mudoufoto = false;
      var options = {
        types: ['(cities)'],
        componentRestrictions: {
          country: "br"
        }
      };
      //document.getElementById('pac-searchTextField')[0].setAttribute('data-tap-disabled', true);
       $scope.disableTap = function(){
     container = document.getElementsByClassName('pac-container');
     // disable ionic data tab
     angular.element(container).attr('data-tap-disabled', 'true');
     // leave input field if google-address-entry is selected
     angular.element(container).on("click", function(){
                                   document.getElementById('searchTextField').blur();
                                   });
     };
      var input = document.getElementById('searchTextField');
      var autocomplete = new google.maps.places.Autocomplete(input, options);
     
      $scope.cidade = autocomplete.getPlace();

    $scope.$on("$ionicView.enter", function(event, data){
      $scope.user = formUser.getForm();
      $scope.cidade ={};
      $scope.auxusername = $scope.user.username;
      if(!$scope.imgURI){
        $scope.imgURI = $scope.user.profilepic;
        if($scope.user.profilepic[8] == 's' && $scope.user.profilepic[9] == '3'){
           document.getElementById("imageidEditar").src=$scope.user.profilepic+"?{{getTimeStamp()}}";
         }else{
           document.getElementById("imageidEditar").src=$scope.user.profilepic;
         }
      }
    });

    $scope.takePicture = function() {
      var optionsCamera = {
          quality : 100,
          destinationType : Camera.DestinationType.FILE_URL,
          sourceType : Camera.PictureSourceType.CAMERA,
          allowEdit : true,
          encodingType: Camera.EncodingType.JPEG,
          targetWidth: 640,
          targetHeight: 640,
          popoverOptions: CameraPopoverOptions,
          saveToPhotoAlbum: true
      };

      $cordovaCamera.getPicture(optionsCamera).then(function(imageData) {
          $scope.imgURI2 = imageData;
          $scope.imgURI = $scope.imgURI2;
          var mystring = String($scope.user.email);
          mystring = mystring.replace(/[^a-zA-Z0-9]/g, '');
          $scope.user.profilepic = 'https://s3.amazonaws.com/diwoappprofilepics/profilepicsdiwo/' + mystring + '.jpg';
          mudoufoto =true;
          document.getElementById("imageidEditar").src=imageData;
          
      }, function(err) {
          // An error occured. Show a message to the user
      });
    }
    $scope.getPicture = function (optionsCamera) {
      var optionsCamera = {
            quality : 100,
            sourceType : 0,
            allowEdit : true,
            targetWidth: 640,
            targetHeight: 640
      };
      $cordovaCamera.getPicture(optionsCamera).then(function(imageData) {
        $scope.imgURI2 = imageData;
        $scope.imgURI = $scope.imgURI2;
        document.getElementById("imageidEditar").src=imageData;
        var mystring = String($scope.user.email);
        mystring = mystring.replace(/[^a-zA-Z0-9]/g, '');
        $scope.user.profilepic = 'https://s3.amazonaws.com/diwoappprofilepics/profilepicsdiwo/' + mystring + '.jpg';
         
        mudoufoto =true;
      }, function(err) {
        console.log(err);
      });
    };
    $scope.cidade = autocomplete.getPlace();
        if($scope.cidade){
          for(var i = 0;i<$scope.cidade.address_components.length;i++){
            if($scope.cidade.address_components[i].types[0] == "administrative_area_level_2"){
              $scope.user.cidade = $scope.cidade.address_components[i].long_name;
             
            }
          }
        }

  $scope.verifica = function(){
    if($scope.auxusername.toLowerCase() == $scope.user.username.toLowerCase()){
      var alertPopup = $ionicPopup.alert({
              title: 'ԅ( ˘ω˘ ԅ)',
              template: 'Teu username ja é demaix'
        });
      $scope.usernexite = false;
      $scope.userexiste = false;
    }else{
      EventoService.verificanome($scope.user.username).then(function(success){
        console.log(success, "'dasd",$scope.user.email, $scope.user.genero )                         
        if(!success){
          $scope.usernexite = true;
          $scope.userexiste = false;
        }else{
          $scope.userexiste = true;
          $scope.usernexite = false;
        }
      }); 
    }
    
  };

  //$scope.cidade = autocomplete.getPlace();  
  $scope.mudar = function(){
    $scope.cidade = autocomplete.getPlace();
        if($scope.cidade){
          for(var i = 0;i<$scope.cidade.address_components.length;i++){
            if($scope.cidade.address_components[i].types[0] == "administrative_area_level_2"){
              $scope.user.cidade = $scope.cidade.address_components[i].long_name;
             
            }
          }
        }
     var palavrasnaousar = ["ALIAMBA", "ANUS", "BAGULIO"
      , "BANZA", "BARRUFO", "BECK", "BEQUE", "BOCETA"
      , "BOLAGATO", "BOQUETE", "BOLCAT", "BOSSETA", "BOSTANA", "BREXA", "BRIOCO", "BRONHA", "BUCA", "BUCETA"
      , "BUSSETA", "CANABIS", "CANNABIS", "CARALHO"
      , "CASSETA", "CASSETE", "CHECHECA", "CHERECA", "CHIBUMBA", "CHIBUMBO", "CHOTA", "CHOCHOTA", "CHUPADA", "CHUPADO", "CLITORIS"
      , "COCAINA", "C+"
      , "C*", "CURALHO", "CUZAO", "CUZUDA", "CUZUDO", "CUZÃO", "ESPORRADA", "ESPORRADO", "ESPORRO", "estupro"
      , "FELACAO", "FELACÃO", "FODA", "FODAO", "FODÃO", "FODAUM", "FODE", "FODIDA", "FODIDO", "FORNICA", "FUDENDO", "FUDECÃO", "FUDECAO"
      , "FUDIDA", "FUDIDO", "GRELINHO", "GRELO", "ISCROTA", "ISCROTO", "MACONHA", "MASTURBA", "MASTURBAÇÃO", "MASTURBACÃO", "MASTURBACAO"
      , "PENIS", "PEN1S", "PENES", "PENIZ", "PICA", "PIROCA", "PIRU", "PORRA", "POURRA", "PROSTIBULO", "PUTA", "PUNHETA", "PUTO"
      , "RABAO", "TESTUDA", "TESTUDO", "VAGABUNDA", "VAGINA", "VIADO", "VIADAO", "VIADÃO", "XAVASCA", "XERERECA", "XEXECA", "XOTA"
      , "XOCHOTA", "XOXOTA", "XANA", "XANINHA", "MDMA", "VSF", "TNC", "FDP", "CRACK"];
      var error = 0;
      var error1 = 0;  
      for (var i = 0; i < palavrasnaousar.length; i++) {
        var res2 = $scope.user.apelido.split("_") ;
        if(res2.length>1){
          for(var w = 0; w < res2.length; w++){
            var val = palavrasnaousar[i].toLowerCase();
            if ((res2[w].toLowerCase()).indexOf(val.toString()) > -1) {  
              error = error + 1;  
            }
          }
        }else{
          var val = palavrasnaousar[i].toLowerCase();  
          if (($scope.user.apelido.toLowerCase()).indexOf(val.toString()) > -1) {  
            error = error + 1;  
          }
        }
        var res3 = $scope.user.apelido.split(" ") ;
        if(res3.length>1){
          for(var w = 0; w < res3.length; w++){
            var val = palavrasnaousar[i].toLowerCase();
            if ((res3[w].toLowerCase()).indexOf(val.toString()) > -1) {  
              error = error + 1;  
            }
          }
        }else{
          var val = palavrasnaousar[i].toLowerCase();  
          if (($scope.user.apelido.toLowerCase()).indexOf(val.toString()) > -1) {  
            error = error + 1;  
          }
        }
              // PARA A DESCRICAO
        if($scope.user.descricao){
          var res2 = $scope.user.descricao.split("_") ;
          if(res2.length>1){
            for(var w = 0; w < res2.length; w++){
              var val = palavrasnaousar[i].toLowerCase();
              if ((res2[w].toLowerCase()).indexOf(val.toString()) > -1) {  
                error1 = error1 + 1;  
              }
            }
          }else{
            var val = palavrasnaousar[i].toLowerCase();  
            if (($scope.user.descricao.toLowerCase()).indexOf(val.toString()) > -1) {  
              error1 = error1 + 1;  
            }
          }
          var res3 = $scope.user.descricao.split(" ") ;
          if(res3.length>1){
            for(var w = 0; w < res3.length; w++){
              var val = palavrasnaousar[i].toLowerCase();
              if ((res3[w].toLowerCase()).indexOf(val.toString()) > -1) {  
                error1 = error1 + 1;  
              }
            }
          }else{
            var val = palavrasnaousar[i].toLowerCase();  
            if (($scope.user.descricao.toLowerCase()).indexOf(val.toString()) > -1) {  
              error1 = error1 + 1;  
            }
          }   
        }else{
          $scope.user.descricao = "";
        }
         
      } 
      if (error > 0) {  
          var alertPopup = $ionicPopup.alert({
                title: '（・о・；）',
                template: 'Que boquinha suja eim, usaste uma palavra inapropriada no seu apelido'
              }); 
      }else{
        if (error1 > 0) {  
          var alertPopup = $ionicPopup.alert({
                title: '（・о・；）',
                template: 'Que boquinha suja eim, usaste uma palavra inapropriada na sua BIO'
              }); 
        }else{ 
        $scope.cidade = autocomplete.getPlace();
        // if($scope.cidade){
        //   for(var i = 0;i<$scope.cidade.address_components.length;i++){
        //     if($scope.cidade.address_components[i].types[0] == "administrative_area_level_2"){
        //       $scope.user.cidade = $scope.cidade.address_components[i].long_name;
             
        //     }
        //   }
        // }
          EventoService.atualizarperfil($scope.user).then(function(msg){
            if(mudoufoto == true){
              var url = "http://ec2-3-84-65-68.compute-1.amazonaws.com/upload.php";
                                          // File for Upload
              var targetPath2 = $scope.imgURI2;
              var mystring = String($scope.user.email);
              mystring = mystring.replace(/[^a-zA-Z0-9]/g, '');
              // File name only
              //var name = $scope.imgURI.substr(imageData.lastIndexOf('/') + 1);
              var filename = mystring + '.jpg';

              // NO CASO SERIA O NOME DO USUARIO.jpg O fileName
              var options = {
                fileKey: "file",
                fileName: filename,
                chunkedMode: false,
                mimeType: "multipart/form-data"
              };
              $cordovaFileTransfer.upload(url, targetPath2, options).then(function(result) {
                
                var alertPopup = $ionicPopup.alert({
                  title: 'Perfil Atualizado, obrigado',
                  template: msg
                });
                alertPopup.then(function(){
                  window.localStorage.setItem( 'user', JSON.stringify($scope.user));
                  formUser.updateForm($scope.user);
                  $state.go('tabsController.perfil');
                });
                
                $ionicLoading.hide();
              }, function(err) {
                $ionicPopup.alert({
                  title: 'Sorry!',
                  template: 'Aconteceu um probleminha, tente de novo'
                });
                $ionicLoading.hide();
              }, function (progress) {
                $ionicLoading.show({
                  title: '┗(＾0＾)┓',
                  template: 'Atualizando o perfil'
                });
              });
            }else{
              var alertPopup = $ionicPopup.alert({
                            title: 'Perfil Atualizado, obrigado',
                            template: msg
              });
              alertPopup.then(function(){
                window.localStorage.setItem( 'user', JSON.stringify($scope.user));
                formUser.updateForm($scope.user);
                $state.go('tabsController.perfil');
              }) 
            }
          }, function(errMsg) {
            var alertPopup = $ionicPopup.alert({
              title: 'Register failed!',
              template: errMsg
            });
            alertPopup.then(function(){
                      $state.go('logando');
            })
          })
        }
      }
    }

}])

.controller('criandoEventoPart1Ctrl', ['$scope', '$stateParams', 'formEventoCriar', '$state','$ionicPopup', '$timeout', 'formtela2', 'formUser', 'EventoService',  // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, formEventoCriar, $state, $ionicPopup, $timeout, formtela2, formUser, EventoService) {
  $scope.evento = {};
  $scope.evento.nomeevento = '';
  $scope.evento.duracao = '';
  $scope.evento.diainicio = '';
  $scope.evento.diafim = '';
  $scope.evento.dialimiteconfirmacao = '';
  $scope.evento.pmin  = 2;
  $scope.evento.patual = 0;
  $scope.evento.pmax = 16;
  $scope.evento.preco = '';
  $scope.evento.nomelocal = '';
  $scope.evento.endereco = '';
  $scope.evento.cidade = '';
  $scope.evento.lat = -26.9829029;
  $scope.evento.lng = -48.6340998;
  $scope.evento.dificuldade="Qual a dificuldade do evento?";
  $scope.evento.genero = "todos";
  $scope.evento.descricao = '';
  $scope.evento.tags = '';
  $scope.evento.addtag = '';
  $scope.auxdata = {};
  $scope.evento.dificuldaden = 1;
  $scope.evento.semana = 0;
  $scope.evento.precopor = 1; 
    $scope.evento.auxtag1 = '';
    $scope.evento.auxtag2 = '';
    $scope.evento.auxtag3 = '';
    $scope.evento.auxtagbutton1 = false;
    $scope.evento.auxtagbutton2 = false;
    $scope.evento.auxtagbutton3 = false;
    $scope.evento.auxtag4 = '';
    $scope.evento.auxtag5 = '';
    $scope.evento.auxtag6 = '';
    $scope.evento.auxtagbutton4 = false;
    $scope.evento.auxtagbutton5 = false;
    $scope.evento.auxtagbutton6 = false;
    $scope.evento.auxtag7 = '';
    $scope.evento.auxtag8 = '';
    $scope.evento.auxtag9 = '';
    $scope.evento.auxtagbutton7 = false;
    $scope.evento.auxtagbutton8 = false;
    $scope.evento.auxtagbutton9 = false;
  var somatag = 0;

  $scope.user = formUser.getForm();
  if($scope.user.genero == "fem"){
    $scope.femin = true;
  }else{
    $scope.femin = false;
  }

  $scope.$on("$ionicView.enter", function(event, data){
    $scope.evento = {};
    $scope.evento.dificuldaden = 1;
    $scope.evento.nomeevento = '';
    $scope.evento.duracao = '';
    $scope.evento.diainicio = '';
    $scope.evento.diafim = '';
    $scope.evento.dialimiteconfirmacao = '';
    $scope.evento.pmin  = 0;
    $scope.evento.patual = 0;
    $scope.evento.pmax = 0;
    $scope.evento.preco = '';
    $scope.evento.nomelocal = '';
    $scope.evento.endereco = '';
    $scope.evento.cidade = '';
    $scope.evento.lat = -26.9829029;
    $scope.evento.lng = -48.6340998;
    $scope.evento.genero = "todos";
    $scope.evento.descricao = '';
    $scope.evento.redzone = "1";
    $scope.evento.addtag = '';
    $scope.evento.precopor = 1;
    $scope.evento.auxtag1 = '';
    $scope.evento.auxtag2 = '';
    $scope.evento.auxtag3 = '';
    $scope.evento.auxtagbutton1 = false;
    $scope.evento.auxtagbutton2 = false;
    $scope.evento.auxtagbutton3 = false;
    $scope.evento.auxtag4 = '';
    $scope.evento.auxtag5 = '';
    $scope.evento.auxtag6 = '';
    $scope.evento.auxtagbutton4 = false;
    $scope.evento.auxtagbutton5 = false;
    $scope.evento.auxtagbutton6 = false;
    $scope.evento.auxtag7 = '';
    $scope.evento.auxtag8 = '';
    $scope.evento.auxtag9 = '';
    $scope.evento.auxtagbutton7 = false;
    $scope.evento.auxtagbutton8 = false;
    $scope.evento.auxtagbutton9 = false;
    var somatag = 0;
    formtela2.updateForm(0);
    $scope.evento.dificuldade="Qual a dificuldade do evento?";
    EventoService.verificahorariopessoaevento($scope.user).then(function(items) {
      $scope.auxdata = items;
    }); 

  });

  var header = document.getElementById("barpor");
  var btns = header.getElementsByClassName("btnpor");
  for (var i = 0; i < btns.length; i++) {
    btns[i].addEventListener("click", function() {
      var current = document.getElementsByClassName("actr");
      current[0].className = current[0].className.replace(" actr", "");
      this.className += " actr";
    });
  }

  $scope.pessoa = function() {$scope.evento.precopor = 1;};
  $scope.hora = function() {$scope.evento.precopor = 2;};

  $scope.duvida = function() {var alertPopup = $ionicPopup.alert({
                      title: 'Para ver se vai rolar ou não',
                      template: 'Uma vez que chega na data limite de confirmação, caso o evento não atinja o número mínimo de pessoas, o evento será cancelado automaticamente.'
                    });};
  $scope.duvida2 = function() {var alertPopup = $ionicPopup.alert({
                      title: 'Cobrar como?',
                      template: 'Em alguns casos como quadras é cobrado por hora e em outros é cobrado por pessoa, então é melhor deixar avisado certinho né.'
                    });};
  $scope.duvida3= function() {var alertPopup = $ionicPopup.alert({
                      title: 'Respeito ao gênero',
                      template: 'O evento não aparecerá para pessoas que não forem do gênero selecionado'
                    });};
   $scope.duvida4= function() {var alertPopup = $ionicPopup.alert({
                      title: 'Pra que serve essas hashtags?',
                      template: 'Fica mais fácil para outras pessoas acharem seu evento pelas tags.'
                    });};

  var currentdate = new Date(); 
  var curr_date2 = (currentdate.getDate()<10?'0':'') + currentdate.getDate();
  var curr_month2 = (currentdate.getMonth()<10?'0':'') + (currentdate.getMonth() + 1); //Months are zero based
  var curr_year2 = currentdate.getFullYear();
  var h22 = (currentdate.getHours()<10?'0':'') + currentdate.getHours();
  var m22 = (currentdate.getMinutes()<10?'0':'') + currentdate.getMinutes();

  var curr_date
  var h2
  var m2 
  var curr_month
  var s2
  var curr_year
  var datainvalida = 0;

  var curr_date4;
  var curr_date5;
  var h4
  var m4 
  var curr_month4;
  var curr_month5;
  var s4
  var curr_year4
  var curr_year5;

  var ano;
  var mes ;
  var dia;
  var h;
  var m;
  var diainiciodoevento = new Date();

  $scope.evento.genero = "todos";
  $scope.evento.redzone = "1";

  $scope.ch = function(){
    if($scope.evento.dificuldaden == 1){
      $scope.evento.dificuldade = "Não importa";
    }
    if($scope.evento.dificuldaden == 2){
      $scope.evento.dificuldade = "Fácil";
    }
    if($scope.evento.dificuldaden == 3){
      $scope.evento.dificuldade = "Moderado";
    }
    if($scope.evento.dificuldaden == 4){
      $scope.evento.dificuldade = "Difícil";
    }
  }

  $scope.muda = function(){

            curr_date = ($scope.evento.date.getDate()<10?'0':'') + $scope.evento.date.getDate();
            curr_month = ($scope.evento.date.getMonth()<9?'0':'') + ($scope.evento.date.getMonth() + 1); //Months are zero based
            curr_year = $scope.evento.date.getFullYear();
            h2 = ($scope.evento.date.getHours()<10?'0':'') + $scope.evento.date.getHours();
            m2 = ($scope.evento.date.getMinutes()<10?'0':'') + $scope.evento.date.getMinutes();
            s2 = ($scope.evento.date.getSeconds()<10?'0':'') + $scope.evento.date.getSeconds();
            $scope.evento.semana = $scope.evento.date.getDay();
            var j = curr_year + "-" + curr_month + "-" + curr_date+ ' '+h2 + ':' + m2 + ':' + s2;
            
            $scope.evento.diainicio = j;
            diainiciodoevento = $scope.evento.date;
          //console.log($scope.evento.diainicio);
          datainvalida = 0;
          ano = curr_year-curr_year2;
          mes = curr_month-curr_month2;
          dia = curr_date-curr_date2;
          h = h2-h22;
          m = m2-m22;
          
              if(ano<0){
                 var alertPopup = $ionicPopup.alert({
                    title: 'Falha na data!!',
                    template: 'Coloque uma data valida s`il vous plait'
                  });
                console.log('data invalida');
              }else{
                if (ano == 0) {
                  if(mes<0){
                    var alertPopup = $ionicPopup.alert({
                      title: 'Falha na data!!',
                      template: 'Coloque uma data valida s`il vous plait'
                    });
                    console.log('data invalida');
                  }else{
                    if (mes==0) {
                      if(dia<0){
                        var alertPopup = $ionicPopup.alert({
                        title: 'Falha na data!!',
                        template: 'Coloque uma data valida s`il vous plait'
                      });
                        console.log('data invalida');
                      }else{
                        if (dia==0 && h<3){
                          var alertPopup = $ionicPopup.alert({
                            title: 'ヽ ( ꒪д꒪ )ﾉ',
                            template: 'Muito em cima da hora para criar um evento, no mínimo umas 3 horas de antecedência'
                          });
                          console.log('data invalida');
                        }else{
                          $scope.evento.date = $scope.evento.date.toLocaleString();

                        }
                      }
                    }
                  }
                }
              }
  }

  $scope.red = function(){
    if(ano==0 && mes == 0 && (dia == 0 && $scope.evento.redzone >= h) || (dia == 1 && $scope.evento.redzone >= h+24)){
      console.log($scope.evento.redzone)
      var alertPopup = $ionicPopup.alert({
        title: 'ლ(ﾟдﾟლ)',
        template: 'A hora limite para confirmação ja passou de agora, ninguem vai conseguir confirmar ida. Selecione um horario válido'
      });
      $scope.evento.redzone = "1";
    }
  }
 
  // $scope.adicionatag = function(){
  //   $scope.evento.auxtagbutton1 = true;
  //   if($scope.evento.tags){
      
  //     if($scope.evento.auxtagbutton1 == true && $scope.evento.auxtagbutton2 == true){
  //       $scope.evento.auxtagbutton3 = true;
  //       $scope.evento.auxtag3 = ' #' +$scope.evento.addtag;
  //     } 
  //     if($scope.evento.auxtagbutton1 == true && $scope.evento.auxtagbutton2 == false){
  //       $scope.evento.auxtagbutton2 = true;
  //       $scope.evento.auxtag2 = ' #' +$scope.evento.addtag;
  //     }
  //     $scope.evento.tags = $scope.evento.tags + ' #' + $scope.evento.addtag; 
  //   }else{
  //     $scope.evento.auxtag1 = '#' +$scope.evento.addtag;
      
  //     $scope.evento.tags = '#' + $scope.evento.addtag; 
  //   }
  //   $scope.evento.addtag = '';
  // }
  var auxauxtagbut = false;
  $scope.adicionatag = function(){
    if($scope.evento.addtag!=''){
      var res2 = $scope.evento.addtag.split(" ") ;
        if(res2.length>1){
          for(var w = 0; w < res2.length; w++){
            var t = res2[w].toLowerCase();
           console.log(t)
          }
          $scope.evento.addtag = res2[0];
        }
      if(!auxauxtagbut){
        auxauxtagbut = true;
        if($scope.evento.auxtagbutton1 == false && auxauxtagbut){
          $scope.evento.auxtag1 = '#' +$scope.evento.addtag;
          $scope.evento.auxtagbutton1 = true;
          auxauxtagbut = false;
        }
        if($scope.evento.auxtagbutton2 == false && auxauxtagbut){
          $scope.evento.auxtag2 = '#' +$scope.evento.addtag;
          $scope.evento.auxtagbutton2 = true;
          auxauxtagbut = false;
        }
        if($scope.evento.auxtagbutton3 == false && auxauxtagbut){
          $scope.evento.auxtag3 = '#' +$scope.evento.addtag;
          $scope.evento.auxtagbutton3 = true;
          auxauxtagbut = false;
        }
        if($scope.evento.auxtagbutton4 == false && auxauxtagbut){
          $scope.evento.auxtag4 = '#' +$scope.evento.addtag;
          $scope.evento.auxtagbutton4 = true;
          auxauxtagbut = false;
        }
        if($scope.evento.auxtagbutton5 == false && auxauxtagbut){
          $scope.evento.auxtag5 = '#' +$scope.evento.addtag;
          $scope.evento.auxtagbutton5 = true;
          auxauxtagbut = false;
        }
        if($scope.evento.auxtagbutton6 == false && auxauxtagbut){
          $scope.evento.auxtag6 = '#' +$scope.evento.addtag;
          $scope.evento.auxtagbutton6 = true;
          auxauxtagbut = false;
        }
        if($scope.evento.auxtagbutton7 == false && auxauxtagbut){
          $scope.evento.auxtag7 = '#' +$scope.evento.addtag;
          $scope.evento.auxtagbutton7 = true;
          auxauxtagbut = false;
        }
        if($scope.evento.auxtagbutton8 == false && auxauxtagbut){
          $scope.evento.auxtag8 = '#' +$scope.evento.addtag;
          $scope.evento.auxtagbutton8 = true;
          auxauxtagbut = false;
        }
        if($scope.evento.auxtagbutton9 == false && auxauxtagbut){
          $scope.evento.auxtag9 = '#' +$scope.evento.addtag;
          $scope.evento.auxtagbutton9 = true;
          auxauxtagbut = false;
        }
      }
    }
    $scope.evento.addtag = '';
  }

  $scope.tiratag1 = function(){
      $scope.evento.auxtagbutton1 = false;
      $scope.evento.auxtag1 = '';
  }
  $scope.tiratag2 = function(){
      $scope.evento.auxtagbutton2 = false;
      $scope.evento.auxtag2 = '';
  }
  $scope.tiratag3 = function(){
      $scope.evento.auxtagbutton3 = false;
      $scope.evento.auxtag3 = '';
  }
  $scope.tiratag4 = function(){
      $scope.evento.auxtagbutton4 = false;
      $scope.evento.auxtag4 = '';
  }
  $scope.tiratag5 = function(){
      $scope.evento.auxtagbutton5 = false;
      $scope.evento.auxtag5 = '';
  }
  $scope.tiratag6 = function(){
      $scope.evento.auxtagbutton6 = false;
      $scope.evento.auxtag6 = '';
  }
  $scope.tiratag7 = function(){
      $scope.evento.auxtagbutton7 = false;
      $scope.evento.auxtag7 = '';
  }
  $scope.tiratag8 = function(){
      $scope.evento.auxtagbutton8 = false;
      $scope.evento.auxtag8 = '';
  }
  $scope.tiratag9 = function(){
      $scope.evento.auxtagbutton9 = false;
      $scope.evento.auxtag9 = '';
  }
  
  $scope.getCriar = function(evento) {
     if($scope.evento.auxtagbutton1 == true){
        if ($scope.evento.tags == undefined) {
          $scope.evento.tags = $scope.evento.auxtag1;
        }else{
          $scope.evento.tags = $scope.evento.tags + ' ' +$scope.evento.auxtag1;
        }
      }
      if($scope.evento.auxtagbutton2 == true){
        if ($scope.evento.tags == undefined) {
          $scope.evento.tags = $scope.evento.auxtag2;
        }else{
          $scope.evento.tags = $scope.evento.tags + ' ' +$scope.evento.auxtag2;
        }
      }
      if($scope.evento.auxtagbutton3 == true){
        if ($scope.evento.tags == undefined) {
          $scope.evento.tags = $scope.evento.auxtag3;
        }else{
        $scope.evento.tags = $scope.evento.tags + ' ' +$scope.evento.auxtag3;
        }
      }
      if($scope.evento.auxtagbutton4 == true){
        if ($scope.evento.tags == undefined) {
          $scope.evento.tags = $scope.evento.auxtag4;
        }else{
          $scope.evento.tags = $scope.evento.tags + ' ' +$scope.evento.auxtag4;
        }
      }
      if($scope.evento.auxtagbutton5 == true){
        if ($scope.evento.tags == undefined) {
          $scope.evento.tags = $scope.evento.auxtag5;
        }else{
          $scope.evento.tags = $scope.evento.tags + ' ' +$scope.evento.auxtag5;
        }
      }
      if($scope.evento.auxtagbutton6 == true){
        if ($scope.evento.tags == undefined) {
          $scope.evento.tags = $scope.evento.auxtag6;
        }else{
          $scope.evento.tags = $scope.evento.tags + ' ' +$scope.evento.auxtag6;
        }
      }
      if($scope.evento.auxtagbutton7 == true){
        if ($scope.evento.tags == undefined) {
          $scope.evento.tags = $scope.evento.auxtag7;
        }else{
          $scope.evento.tags = $scope.evento.tags + ' ' +$scope.evento.auxtag7;
        }
      }
      if($scope.evento.auxtagbutton8 == true){
        if ($scope.evento.tags == undefined) {
          $scope.evento.tags = $scope.evento.auxtauxtag8ag2;
        }else{
          $scope.evento.tags = $scope.evento.tags + ' ' +$scope.evento.auxtag8;
        }
      }
      if($scope.evento.auxtagbutton9 == true ){
        if ($scope.evento.tags == undefined) {
          $scope.evento.tags = $scope.evento.auxtag9;
        }else{
          $scope.evento.tags = $scope.evento.tags + ' ' +$scope.evento.auxtag9;
        }
      }

    if (!$scope.evento.tags) {
      var alertPopup = $ionicPopup.alert({
        title: '(⊙﹏⊙✿)',
        template: 'Coloque pelo menos uma tag para facilitar a procura do seu evento'
      });
    }else{
      $scope.test = formtela2.getForm();
    //console.log($scope.evento.duracao res);
    //$scope.evento.duracao= $scope.evento.duracao.toLocaleString().replace(/:\d+ /, ' ');
    //console.log($scope.evento.duracao);
    // console.log($scope.evento.data);
    // console.log($scope.evento.duracao);
    // console.log($scope.evento.horas);
      if (!$scope.evento.preco) {$scope.evento.preco=0}
      if($scope.evento.dificuldaden == 1){
        $scope.evento.dificuldade = "Não importa";
      }
      if (!$scope.evento.duracao || !$scope.evento.date ) {
        var alertPopup = $ionicPopup.alert({
          title: '( ͒ ́ඉ .̫ ඉ ̀ ͒)',
          template: 'Preciso saber a data e/ou duração do evento'
        });

         }else{
              if($scope.evento.semana == 0){
                $scope.evento.semana = "Domingo";
              }
              if($scope.evento.semana == 1){
                $scope.evento.semana = "Segunda-feira";
              }
              if($scope.evento.semana == 2){
                $scope.evento.semana = "Terça-feira";
              }
              if($scope.evento.semana == 3){
                $scope.evento.semana = "Quarta-feira";
              }
              if($scope.evento.semana == 4){
                $scope.evento.semana = "Quinta-feira";
              }
              if($scope.evento.semana == 5){
                $scope.evento.semana = "Sexta-feira";
              }
              if($scope.evento.semana == 6){
                $scope.evento.semana = "Sábado";
              }

              var h = ($scope.evento.duracao.getHours()<10?'0':'') + $scope.evento.duracao.getHours();
              var m = ($scope.evento.duracao.getMinutes()<10?'0':'') + $scope.evento.duracao.getMinutes();
              var i = h + ':' + m;
              var diafimeventodate; 
              var diafimeventomonth;
              var diafimeventoyear;
              var fimfim;
              $scope.evento.duracao = i;
              var horapositiva = parseFloat(h)-parseFloat(h2);
              var minutopositiva = parseFloat(m)-parseFloat(m2);
              if(horapositiva<0){
                var diafimevento = new Date();
                diafimevento.setDate(diainiciodoevento.getDate() + 1);
                diafimeventodate = (diafimevento.getDate()<10?'0':'') + diafimevento.getDate();
                diafimeventomonth = (diafimevento.getMonth()<10?'0':'') + (diafimevento.getMonth() + 1); //Months are zero based
                diafimeventoyear = diafimevento.getFullYear();
                fimfim = diafimeventoyear + "-" + diafimeventomonth + "-" + diafimeventodate+ ' '+h + ':' + m;
                $scope.evento.diafim = fimfim;
              }else{
                if(horapositiva == 0 && minutopositiva<0 ){
                  var diafimevento = new Date();
                  diafimevento.setDate(diainiciodoevento.getDate() + 1);
                  diafimeventodate = (diafimevento.getDate()<10?'0':'') + diafimevento.getDate();
                  diafimeventomonth = (diafimevento.getMonth()<10?'0':'') + (diafimevento.getMonth() + 1); //Months are zero based
                  diafimeventoyear = diafimevento.getFullYear();
                  fimfim = diafimeventoyear + "-" + diafimeventomonth + "-" + diafimeventodate+ ' '+h + ':' + m;
                  $scope.evento.diafim = fimfim;
                }else{
                  $scope.evento.diafim = curr_year + "-" + curr_month + "-" + curr_date+ ' '+h + ':' + m;
                }
              }
              var we = curr_year + "-" + curr_month + "-" + curr_date+ ' '+h2 + ':' + m2 + ':' + s2;


            curr_year5 = curr_year;
            curr_date5 = curr_date;
            curr_month5 = curr_month;
            h4 = parseFloat(h2)-parseFloat($scope.evento.redzone);
            //console.log(h4)
            if(h4<0){
              h4 = h4.valueOf()+24;
              curr_date5 = parseFloat(curr_date)-1;
              if(curr_date5<1){
                curr_month5 = parseFloat(curr_month)-1;
                if(curr_month5==1||curr_month5==3||curr_month5==5||curr_month5==7||curr_month5==8||curr_month5==10||curr_month5==12){
                  curr_date5 = curr_date5.valueOf()+31;
                }
                if(curr_month5==4||curr_month5==6||curr_month5==9||curr_month5==11){
                  curr_date5 = curr_date5.valueOf()+30;
                }
                if(curr_month5==2){
                  curr_date5 = curr_date5.valueOf()+28;
                }
                if(curr_month5<1){
                  curr_year5 = parseFloat(curr_year)-1;
                }
              }
            }
            h4 = (h4<10?'0':'')+h4;
            curr_date5 = (curr_date5<10?'0':'')+curr_date5;
            curr_month5 = (curr_month5<9?'0':'')+curr_month5;
            var j = curr_year5 + "-" + curr_month5 + "-" + curr_date5+ ' '+h4 + ':' + m2 + ':' + s2;
            
            $scope.evento.dialimiteconfirmacao = j;
            console.log($scope.evento.diafim ,  $scope.evento.dialimiteconfirmacao);
              
              for(var r = 0;r<$scope.auxdata.length; r++){
                console.log($scope.auxdata[r].idevento, $scope.auxdata[r].diainicio, $scope.auxdata[r].diafim , we ,$scope.evento.diafim);
                if (($scope.auxdata[r].diainicio < we && $scope.auxdata[r].diafim > we) || ($scope.auxdata[r].diainicio<$scope.evento.diafim && $scope.auxdata[r].diafim>$scope.evento.diafim) ||($scope.auxdata[r].diainicio > we && $scope.auxdata[r].diafim<$scope.evento.diafim) || ($scope.auxdata[r].diainicio < we && $scope.auxdata[r].diafim>$scope.evento.diafim) ) {
                  console.log('horario invalido');
                  datainvalida = 1;
                }
              }
             //console.log (datainvalida , r)
              ///        ╭∩╮(︶‿︶)╭∩╮
            if(datainvalida == 0 && r==$scope.auxdata.length){
              // $scope.evento.date = $scope.evento.date.toDateString("yyyy-MM-dd HH:mm");
              // $scope.evento.diafim = $scope.evento.diafim.toDateString("yyyy-MM-dd HH:mm");
               formEventoCriar.updateForm($scope.evento);
               //console.log($scope.evento.duracao);
              // console.log($scope.evento.date);
               $state.go('tabsController.criandoEventoPart2');
            }
            if(datainvalida ==1){
              var alertPopup = $ionicPopup.alert({
                    title: 'Oww!!',
                    template: 'Tu ja tem um evento marcado nesse horário :/'
                  });
            }
          

          }
        }
    }

}])
     
.controller('criandoEventoPart2Ctrl', ['$scope', '$stateParams', '$cordovaGeolocation', '$state', '$ionicLoading', 'formEventoCriar',  // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $cordovaGeolocation, $state, $ionicLoading, formEventoCriar) {
  $scope.evento = formEventoCriar.getForm();
  $scope.evento.nomelocal = 'Casa do Igor';
  $scope.evento.endereco = 'Secreto';
  $scope.evento.cidade = 'Balneário Camboriú';
  $scope.evento.lat = -26.9829029;
  $scope.evento.lng = -48.6340998;
  $scope.disableTap = function(){
     container = document.getElementsByClassName('pac-container');
     // disable ionic data tab
     angular.element(container).attr('data-tap-disabled', 'true');
     // leave input field if google-address-entry is selected
     angular.element(container).on("click", function(){
                                   document.getElementById('pac-input').blur();
                                   });
     };

  $scope.$on("$ionicView.enter", function(event, data){
    $scope.evento = formEventoCriar.getForm();
    navigator.geolocation.getCurrentPosition(function(position){
            var lat  = position.coords.latitude;
            var long = position.coords.longitude;
            var myLatlng = new google.maps.LatLng(lat, long);
            var mapOptions = {
                center: myLatlng,
                zoom: 16,
                mapTypeId: google.maps.MapTypeId.ROADMAP
            };          
            var map = new google.maps.Map(document.getElementById("map_canvas"), mapOptions); 
            var marker = new google.maps.Marker({
                      position: new google.maps.LatLng(position.coords.latitude, position.coords.longitude),
                      map: map,
                      title: "Borai",
                      draggable: true,
                      icon: 'http://maps.google.com/mapfiles/ms/icons/green-dot.png',
                      animation: google.maps.Animation.DROP 
                  })

            var geocoder = new google.maps.Geocoder;
            var infowindow = new google.maps.InfoWindow({maxWidth: 200});

            geocoder.geocode({'location': myLatlng}, function(results, status) {
                  if (status === 'OK') {
                    if (results[1]) {
                      $scope.evento.nomelocal = results[0].address_components[0].long_name;
                      $scope.evento.endereco = results[0].formatted_address;
                      for(var i = 0;i<results[0].address_components.length;i++){
                        if(results[0].address_components[i].types[0] == "administrative_area_level_2"){
                          $scope.evento.cidade = results[0].address_components[i].long_name;
                          console.log($scope.evento.cidade)
                        }
                      }
                      //$scope.evento.cidade = results[0].address_components[4].long_name;
                      $scope.evento.lat = position.coords.latitude;
                      $scope.evento.lng = position.coords.longitude;
                      infowindow.setContent(results[0].formatted_address);
                      console.log($scope.evento.endereco);
                      console.log($scope.evento.cidade);
                      console.log($scope.evento.lng);
                      console.log($scope.evento.lat);
                      //infowindow.setContent(results[0].address_components[2].long_name);
                      infowindow.open(map, marker);
                      setTimeout(function () { infowindow.close(); }, 5000);
                    } else {
                      window.alert('No results found');
                    }
                  } else {
                    window.alert('Geocoder failed due to: ' + status);
                  }
                });


            google.maps.event.addListener(marker, "dragstart", function (event) {
               marker.setAnimation(3); // raise
            });

            google.maps.event.addListener(marker, "dragend", function (event) {
               marker.setAnimation(4); // raise
            });

            marker.addListener('dragend', handleEvent);

            google.maps.event.addListener(map, 'click', function(e) {
                
                markers.forEach(function(marker) {
                marker.setMap(null);
                });
                markers = [];

                placeMarker(e.latLng, map, marker);

            });

            function placeMarker(latlng, map, marker) {
                marker.setPosition(latlng);
                marker.setMap(map);
                map.panTo(latlng);
                $scope.evento.lat = latlng.lat();
                $scope.evento.lng = latlng.lng();
                geocoder.geocode({'location': latlng}, function(results, status) {
                  if (status === 'OK') {
                    if (results[1]) {
                      $scope.evento.nomelocal = results[0].address_components[0].long_name;
                      for(var i = 0;i<results[0].address_components.length;i++){
                        if(results[0].address_components[i].types[0] == "administrative_area_level_2"){
                          $scope.evento.cidade = results[0].address_components[i].long_name;
                          console.log($scope.evento.cidade)
                        }
                      }
                      //$scope.evento.cidade = results[0].address_components[4].long_name;
                      $scope.evento.endereco = results[0].formatted_address;
                      console.log($scope.evento.endereco);
                      console.log($scope.evento.cidade);
                      console.log($scope.evento.lng);
                      console.log($scope.evento.lat);
                      infowindow.setContent(results[0].formatted_address);
                     
                      infowindow.open(map, marker);
                      setTimeout(function () { infowindow.close(); }, 5000);
                    } else {
                      window.alert('No results found');
                    }
                  } else {
                    window.alert('Geocoder failed due to: ' + status);
                  }
                });
            };        

            function handleEvent(event) {
                $scope.evento.lat = event.latLng.lat();
                $scope.evento.lng = event.latLng.lng();

                              // GEOCODER INVERSO

                var geocoder = new google.maps.Geocoder;
                var infowindow = new google.maps.InfoWindow({
                                                              maxWidth: 200
                                                            });;    
            
                geocoder.geocode({'location': event.latLng}, function(results, status) {
                  if (status === 'OK') {
                    if (results[1]) {
                      $scope.evento.nomelocal = results[0].address_components[0].long_name;
                      for(var i = 0;i<results[0].address_components.length;i++){
                        if(results[0].address_components[i].types[0] == "administrative_area_level_2"){
                          $scope.evento.cidade = results[0].address_components[i].long_name;
                          console.log($scope.evento.cidade)
                        }
                      }
                      //$scope.evento.cidade = results[0].address_components[4].long_name;
                      $scope.evento.endereco = results[0].formatted_address;
                      // console.log($scope.evento.endereco);
                      // console.log($scope.evento.cidade);
                      console.log($scope.evento.lng);
                      console.log($scope.evento.lat);
                      infowindow.setContent(results[0].formatted_address);
                     
                      infowindow.open(map, marker);
                      setTimeout(function () { infowindow.close(); }, 5000);
                    } else {
                      window.alert('No results found');
                    }
                  } else {
                    window.alert('Geocoder failed due to: ' + status);
                  }
                });
            }
            var input = document.getElementById('pac-input');
            var searchBox = new google.maps.places.SearchBox(input);
            map.addListener('bounds_changed', function() {
                searchBox.setBounds(map.getBounds());
            });
            var markers = [];
            searchBox.addListener('places_changed', function() {
                var places = searchBox.getPlaces();

                if (places.length == 0) {
                  return;
                }

                // Clear out the old markers.
                markers.forEach(function(marker) {
                  marker.setMap(null);
                });
                markers = [];

                // For each place, get the icon, name and location.
                var bounds = new google.maps.LatLngBounds();
                places.forEach(function(place) {
                  if (!place.geometry) {
                    console.log("Returned place contains no geometry");
                    return;
                  }
                  // var icon = {
                  //   url: place.icon,
                  //   size: new google.maps.Size(71, 71),
                  //   origin: new google.maps.Point(0, 0),
                  //   anchor: new google.maps.Point(17, 34),
                  //   scaledSize: new google.maps.Size(25, 25)
                  // };

                  // Create a marker for each place.
                  markers.push(new google.maps.Marker({
                    map: map,
                    // icon: icon,
                    title: place.name,
                    position: place.geometry.location
                  }));

                  $scope.evento.nomelocal = place.name;
                  $scope.evento.endereco = place.formatted_address;
             
                  for(var i = 0;i<place.address_components.length;i++){
                    //console.log(place.address_components[i].types[0])
                    if(place.address_components[i].types[0] == "administrative_area_level_2"){
                      $scope.evento.cidade = place.address_components[i].long_name;
                      console.log($scope.evento.cidade)
                    }
                  }
                 
                  $scope.evento.lat = place.geometry.location.lat();
                  $scope.evento.lng = place.geometry.location.lng();

                  console.log($scope.evento.lng, $scope.evento.lat, "lssdd", $scope.evento.nomelocal, $scope.evento.endereco);

                  if (place.geometry.viewport) {
                    // Only geocodes have viewport.
                    bounds.union(place.geometry.viewport);
                  } else {
                    bounds.extend(place.geometry.location);
                  }
                });
                map.fitBounds(bounds);
            });

            $scope.map = map;  
             
        }, function(err) {
            console.log(err.code);
            console.log(err.message);
        });

  })

  var posOptions = {
      enableHighAccuracy: true,
      timeout: 200000,
      maximumAge: 0
  };

    navigator.geolocation.getCurrentPosition(function(position){
          
            var lat  = position.coords.latitude;
            var long = position.coords.longitude;
             

            var myLatlng = new google.maps.LatLng(lat, long);
             
            var mapOptions = {
                center: myLatlng,
                zoom: 16,
                mapTypeId: google.maps.MapTypeId.ROADMAP
            };          
             
            var map = new google.maps.Map(document.getElementById("map_canvas"), mapOptions); 


            var marker = new google.maps.Marker({
                      position: new google.maps.LatLng(position.coords.latitude, position.coords.longitude),
                      map: map,
                      title: "Borai",
                      draggable: true,
                      icon: 'http://maps.google.com/mapfiles/ms/icons/green-dot.png',
                      animation: google.maps.Animation.DROP 
                  })

            var geocoder = new google.maps.Geocoder;
            var infowindow = new google.maps.InfoWindow({maxWidth: 200});

            geocoder.geocode({'location': myLatlng}, function(results, status) {
                  if (status === 'OK') {
                    if (results[1]) {
                      $scope.evento.nomelocal = results[0].address_components[0].long_name;
                      $scope.evento.endereco = results[0].formatted_address;
                      for(var i = 0;i<results[0].address_components.length;i++){
                        if(results[0].address_components[i].types[0] == "administrative_area_level_2"){
                          $scope.evento.cidade = results[0].address_components[i].long_name;
                          console.log($scope.evento.cidade)
                        }
                      }
                      //$scope.evento.cidade = results[0].address_components[4].long_name;
                      $scope.evento.lat = position.coords.latitude;
                      $scope.evento.lng = position.coords.longitude;
                      infowindow.setContent(results[0].formatted_address);
                      console.log($scope.evento.endereco);
                      console.log($scope.evento.cidade);
                      console.log($scope.evento.lng);
                      console.log($scope.evento.lat);
                      //infowindow.setContent(results[0].address_components[2].long_name);
                      infowindow.open(map, marker);
                      setTimeout(function () { infowindow.close(); }, 5000);
                    } else {
                      window.alert('No results found');
                    }
                  } else {
                    window.alert('Geocoder failed due to: ' + status);
                  }
                });


            google.maps.event.addListener(marker, "dragstart", function (event) {
               marker.setAnimation(3); // raise
            });

            google.maps.event.addListener(marker, "dragend", function (event) {
               marker.setAnimation(4); // raise
            });

            marker.addListener('dragend', handleEvent);

            google.maps.event.addListener(map, 'click', function(e) {
              
                markers.forEach(function(marker) {
                marker.setMap(null);
                });
                markers = [];

                placeMarker(e.latLng, map, marker);

            });

            function placeMarker(latlng, map, marker) {
                marker.setPosition(latlng);
                marker.setMap(map);
                map.panTo(latlng);
                $scope.evento.lat = latlng.lat();
                $scope.evento.lng = latlng.lng();
                geocoder.geocode({'location': latlng}, function(results, status) {
                  if (status === 'OK') {
                    if (results[1]) {
                      $scope.evento.nomelocal = results[0].address_components[0].long_name;
                      for(var i = 0;i<results[0].address_components.length;i++){
                        if(results[0].address_components[i].types[0] == "administrative_area_level_2"){
                          $scope.evento.cidade = results[0].address_components[i].long_name;
                          console.log($scope.evento.cidade)
                        }
                      }
                      //$scope.evento.cidade = results[0].address_components[4].long_name;
                      $scope.evento.endereco = results[0].formatted_address;
                      console.log($scope.evento.endereco);
                      console.log($scope.evento.cidade);
                      console.log($scope.evento.lng);
                      console.log($scope.evento.lat);
                      infowindow.setContent(results[0].formatted_address);
                     
                      infowindow.open(map, marker);
                      setTimeout(function () { infowindow.close(); }, 5000);
                    } else {
                      window.alert('No results found');
                    }
                  } else {
                    window.alert('Geocoder failed due to: ' + status);
                  }
                });
            };        

            function handleEvent(event) {
                $scope.evento.lat = event.latLng.lat();
                $scope.evento.lng = event.latLng.lng();

                              // GEOCODER INVERSO

                var geocoder = new google.maps.Geocoder;
                var infowindow = new google.maps.InfoWindow({
                                                              maxWidth: 200
                                                            });;    
            
                geocoder.geocode({'location': event.latLng}, function(results, status) {
                  if (status === 'OK') {
                    if (results[1]) {
                      $scope.evento.nomelocal = results[0].address_components[0].long_name;
                      for(var i = 0;i<results[0].address_components.length;i++){
                        if(results[0].address_components[i].types[0] == "administrative_area_level_2"){
                          $scope.evento.cidade = results[0].address_components[i].long_name;
                          console.log($scope.evento.cidade)
                        }
                      }
                      //$scope.evento.cidade = results[0].address_components[4].long_name;
                      $scope.evento.endereco = results[0].formatted_address;
                      // console.log($scope.evento.endereco);
                      // console.log($scope.evento.cidade);
                      console.log($scope.evento.lng);
                      console.log($scope.evento.lat);
                      infowindow.setContent(results[0].formatted_address);
                     
                      infowindow.open(map, marker);
                      setTimeout(function () { infowindow.close(); }, 5000);
                    } else {
                      window.alert('No results found');
                    }
                  } else {
                    window.alert('Geocoder failed due to: ' + status);
                  }
                });
            }

                              // GEOCODER INVERSO

                

                
            
                    //        SEARCHBOX

            var input = document.getElementById('pac-input');
            var searchBox = new google.maps.places.SearchBox(input);
          //map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);

        // Bias the SearchBox results towards current map's viewport.
            map.addListener('bounds_changed', function() {
                searchBox.setBounds(map.getBounds());
            });

            var markers = [];
        // Listen for the event fired when the user selects a prediction and retrieve
        // more details for that place.
            searchBox.addListener('places_changed', function() {
                var places = searchBox.getPlaces();

                if (places.length == 0) {
                  return;
                }

                // Clear out the old markers.
                markers.forEach(function(marker) {
                  marker.setMap(null);
                });
                markers = [];

                // For each place, get the icon, name and location.
                var bounds = new google.maps.LatLngBounds();
                places.forEach(function(place) {
                  if (!place.geometry) {
                    console.log("Returned place contains no geometry");
                    return;
                  }
                  // var icon = {
                  //   url: place.icon,
                  //   size: new google.maps.Size(71, 71),
                  //   origin: new google.maps.Point(0, 0),
                  //   anchor: new google.maps.Point(17, 34),
                  //   scaledSize: new google.maps.Size(25, 25)
                  // };

                  // Create a marker for each place.
                  markers.push(new google.maps.Marker({
                    map: map,
                    // icon: icon,
                    title: place.name,
                    position: place.geometry.location
                  }));

                  $scope.evento.nomelocal = place.name;
                  $scope.evento.endereco = place.formatted_address;
                  for(var i = 0;i<place.address_components.length;i++){
                    //console.log(place.address_components[i].types[0])
                    if(place.address_components[i].types[0] == "administrative_area_level_2"){
                      $scope.evento.cidade = place.address_components[i].long_name;
                      console.log($scope.evento.cidade)
                    }
                  }
                 
                  $scope.evento.lat = place.geometry.location.lat();
                  $scope.evento.lng = place.geometry.location.lng();

                  // console.log($scope.coord.endereco);
                  // console.log($scope.coord.long);
                  // console.log($scope.coord.lat);

                  if (place.geometry.viewport) {
                    // Only geocodes have viewport.
                    bounds.union(place.geometry.viewport);
                  } else {
                    bounds.extend(place.geometry.location);
                  }
                });
                map.fitBounds(bounds);
            });

            $scope.map = map;  
             
        }, function(err) {
            console.log(err.code);
            console.log(err.message);
        });


        $scope.getCriar = function(evento) {
          formEventoCriar.updateForm($scope.evento);
          $state.go('tabsController.criandoEventoPart3');
        }

}])

.controller('criandoEventoPart3Ctrl', ['$scope', '$stateParams', '$state', 'formEventoCriar', '$ionicPopup', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $state, formEventoCriar, $ionicPopup) {
  $scope.evento = formEventoCriar.getForm();
  $scope.$on("$ionicView.enter", function(event, data){
    $scope.evento = formEventoCriar.getForm();
  })
     $scope.getCriar = function(evento) {
      var palavrasnaousar = ["ALIAMBA", "ANUS", "BAGULIO"
      , "BANZA", "BARRUFO", "BECK", "BEQUE", "BOCETA"
      , "BOLAGATO", "BOQUETE", "BOLCAT", "BOSSETA", "BOSTANA", "BREXA", "BRIOCO", "BRONHA", "BUCA", "BUCETA"
      , "BUSSETA", "CANABIS", "CANNABIS", "CARALHO"
      , "CASSETA", "CASSETE", "CHECHECA", "CHERECA", "CHIBUMBA", "CHIBUMBO", "CHOTA", "CHOCHOTA", "CHUPADA", "CHUPADO", "CLITORIS"
      , "COCAINA","C+"
      , "C*", "CURALHO", "CUZAO", "CUZUDA", "CUZUDO", "CUZÃO", "ESPORRADA", "ESPORRADO", "ESPORRO", "estupro"
      , "FELACAO", "FELACÃO", "FODA", "FODAO", "FODÃO", "FODAUM", "FODE", "FODIDA", "FODIDO", "FORNICA", "FUDENDO", "FUDECÃO", "FUDECAO"
      , "FUDIDA", "FUDIDO", "GRELINHO", "GRELO", "ISCROTA", "ISCROTO", "MACONHA", "MASTURBA", "MASTURBAÇÃO", "MASTURBACÃO", "MASTURBACAO"
      , "PENIS", "PEN1S", "PENES", "PENIZ", "PICA", "PIROCA", "PIRU", "PORRA", "POURRA", "PROSTIBULO", "PUTA", "PUNHETA", "PUTO"
      , "RABAO", "TESTUDA", "TESTUDO", "VAGABUNDA", "VAGINA", "VIADO", "VIADAO", "VIADÃO", "XAVASCA", "XERERECA", "XEXECA", "XOTA"
      , "XOCHOTA", "XOXOTA", "XANA", "XANINHA", "MDMA", "VSF", "TNC", "FDP", "CRACK"];
      var error = 0; 
      for (var i = 0; i < palavrasnaousar.length; i++) {
        var res2 = $scope.evento.descricao.split("_") ;
        if(res2.length>1){
          for(var w = 0; w < res2.length; w++){
            var val = palavrasnaousar[i].toLowerCase();
            if ((res2[w].toLowerCase()).indexOf(val.toString()) > -1) {  
              error = error + 1;  
            }
          }
        }else{
          var val = palavrasnaousar[i].toLowerCase();  
          if (($scope.evento.descricao.toLowerCase()).indexOf(val.toString()) > -1) {  
            error = error + 1;  
          }
        }
        var res3 = $scope.evento.descricao.split(" ") ;
        if(res3.length>1){
          for(var w = 0; w < res3.length; w++){
            var val = palavrasnaousar[i].toLowerCase();
            if ((res3[w].toLowerCase()).indexOf(val.toString()) > -1) {  
              error = error + 1;  
            }
          }
        }else{
          var val = palavrasnaousar[i].toLowerCase();  
          if (($scope.evento.descricao.toLowerCase()).indexOf(val.toString()) > -1) {  
            error = error + 1;  
          }
        }   
      } 
      if (error > 0) {  
          var alertPopup = $ionicPopup.alert({
                title: '（・о・；）',
                template: 'Que boquinha suja eim, usaste uma palavra inapropriada né'
              }); 
      }else{   
        if(evento.descricao){
          formEventoCriar.updateForm($scope.evento);
          $state.go('tabsController.criandoEventoPart4');
        }else{
          var alertPopup = $ionicPopup.alert({
                title: '( ꒪Д꒪)ノ',
                template: 'Escreva algo na descrição do evento para ajudar as pessoas a entenderem o que será feito'
              }); 
        }
        
      }

 }

}])
   
.controller('criandoEventoPart4Ctrl', ['$scope', '$stateParams', '$state', 'formEventoCriar', 'formUser','$ionicPopup', '$http', 'formtela2', 'formtelaCriar', 'EventoService', '$cordovaCamera', '$cordovaFile', '$cordovaFileTransfer', '$cordovaDevice',  '$ionicLoading',// The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $state, formEventoCriar, formUser, $ionicPopup, $http, formtela2, formtelaCriar, EventoService, $cordovaCamera, $cordovaFile, $cordovaFileTransfer, $cordovaDevice,  $ionicLoading) {
  $scope.evento = formEventoCriar.getForm();
  $scope.user = formUser.getForm();
  $scope.auxtela = formtela2.getForm();
  var noti = {};
  $scope.imgURI = "img/ev.png"
  $scope.pushnoti ={};
  $scope.auxfoto = '';
  $scope.confirmacao = 'aprovado';
  $scope.estado = '0';
  $scope.ic = {};
  var evpic ='';
  EventoService.getIC($scope.user).then(function(ic) {
    if(ic){
     $scope.ic = ic;
   }
  });
  
  document.getElementById("imageidEvento").src="img/ev.png";
    $scope.getPicture = function (optionsCamera) {
      var optionsCamera = {
            quality : 100,
            sourceType : 0,
            allowEdit : true,
            targetWidth: 720,
            targetHeight: 400
      };
      $cordovaCamera.getPicture(optionsCamera).then(function(imageData) {
        $scope.imgURI = imageData;
        document.getElementById("imageidEvento").src=imageData;
      }, function(err) {
        console.log(err);
      });
    };


     $scope.$on("$ionicView.enter", function(event, data){
      $scope.auxtela = formtela2.getForm();
      $scope.evento = formEventoCriar.getForm();

      if ($scope.auxtela == 1) {
        $state.go('tabsController.criandoEventoPart1');
      }
     });

     $scope.getCriar = function(evento) {
      if (!$scope.evento.pmax || !$scope.evento.pmin) {
                    var alertPopup = $ionicPopup.alert({
                    title: '( ͒•·̫|',
                    template: 'Favor preencher todos os campos'
                  });

         }else{
          if (parseInt($scope.evento.pmin)<=1) {
            var alertPopup = $ionicPopup.alert({
                    title: '=/',
                    template: 'Não da pra fazer um evento só com você né'
                  });
          }else{
            if (parseInt($scope.evento.pmax) <= parseInt($scope.evento.pmin)) {
              var alertPopup = $ionicPopup.alert({
                      title: 'Matematimatematica',
                      template: 'Mínimo de pessoas nao pode ser maior ou igual ao máximo xD'
                    });
            }else{
              if (parseInt($scope.evento.pmax) >= 50) {
                var alertPopup = $ionicPopup.alert({
                        title: 'Muuuuita gente',
                        template: 'Limite máximo de pessoas para um evento é 50 personas'
                      });
              }else{



                $ionicPopup.prompt({
                    title: 'Qual nome devo dar?',
                    template: 'Não vamos esquecer de dar nomes aos bois',
                   inputType: 'text',
                   inputPlaceholder: ' Nome legal'
                 }).then(function(nomeevento) {
                  if (nomeevento && nomeevento !='' && nomeevento !=' ') {

                    var palavrasnaousar = ["ALIAMBA", "ANUS", "BAGULIO"
      , "BANZA", "BARRUFO", "BECK", "BEQUE", "BOCETA"
      , "BOLAGATO", "BOQUETE", "BOLCAT", "BOSSETA", "BOSTANA", "BREXA", "BRIOCO", "BRONHA", "BUCA", "BUCETA"
      , "BUSSETA", "CANABIS", "CANNABIS", "CARALHO"
      , "CASSETA", "CASSETE", "CHECHECA", "CHERECA", "CHIBUMBA", "CHIBUMBO", "CHOTA", "CHOCHOTA", "CHUPADA", "CHUPADO", "CLITORIS"
      , "COCAINA", "C+"
      , "C*", "CURALHO", "CUZAO", "CUZUDA", "CUZUDO", "CUZÃO", "ESPORRADA", "ESPORRADO", "ESPORRO", "estupro"
      , "FELACAO", "FELACÃO", "FODA", "FODAO", "FODÃO", "FODAUM", "FODE", "FODIDA", "FODIDO", "FORNICA", "FUDENDO", "FUDECÃO", "FUDECAO"
      , "FUDIDA", "FUDIDO", "GRELINHO", "GRELO", "ISCROTA", "ISCROTO", "MACONHA", "MASTURBA", "MASTURBAÇÃO", "MASTURBACÃO", "MASTURBACAO"
      , "PENIS", "PEN1S", "PENES", "PENIZ", "PICA", "PIROCA", "PIRU", "PORRA", "POURRA", "PROSTIBULO", "PUTA", "PUNHETA", "PUTO"
      , "RABAO", "TESTUDA", "TESTUDO", "VAGABUNDA", "VAGINA", "VIADO", "VIADAO", "VIADÃO", "XAVASCA", "XERERECA", "XEXECA", "XOTA"
      , "XOCHOTA", "XOXOTA", "XANA", "XANINHA", "MDMA",  "VSF", "TNC", "FDP", "CRACK"];
      var error = 0; 
      for (var i = 0; i < palavrasnaousar.length; i++) {
        var res2 = nomeevento.split("_") ;
        if(res2.length>1){
          for(var w = 0; w < res2.length; w++){
            var val = palavrasnaousar[i].toLowerCase();
            if ((res2[w].toLowerCase()).indexOf(val.toString()) > -1) {  
              error = error + 1;  
            }
          }
        }else{
          var val = palavrasnaousar[i].toLowerCase();  
          if ((nomeevento.toLowerCase()).indexOf(val.toString()) > -1) {  
            error = error + 1;  
          }
        }
        var res3 = nomeevento.split(" ");
        if(res3.length>1){
          for(var w = 0; w < res3.length; w++){
            var val = palavrasnaousar[i].toLowerCase();
            if ((res3[w].toLowerCase()).indexOf(val.toString()) > -1) {  
              error = error + 1;  
            }
          }
        }else{
          var val = palavrasnaousar[i].toLowerCase();  
          if ((nomeevento.toLowerCase()).indexOf(val.toString()) > -1) {  
            error = error + 1;  
          }
        }   
      } 
      if (error > 0) {  
          var alertPopup = $ionicPopup.alert({
                title: '（・о・；）',
                template: 'Que boquinha suja eim, usaste uma palavra inapropriada né'
              }); 
      }else{ 
        console.log($scope.imgURI)
        if($scope.imgURI != "img/ev.png"){ 
          $scope.auxfoto = nomeevento + $scope.evento.diainicio;
          var mystring = String($scope.auxfoto);
          mystring = mystring.replace(/[^a-zA-Z0-9]/g, '');
          evpic = 'https://s3.amazonaws.com/diwoappprofilepics/eventopicsdiwo/' + mystring + '.jpg';
        }else{
          evpic = "img/ev.png";
        } 
                  
                    $scope.evento.nomeevento = nomeevento;
                    var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criarevento.php';
                    $http.post(link, {nomeevento : $scope.evento.nomeevento, 
                                  duracao : $scope.evento.duracao,
                                  diainicio : $scope.evento.diainicio,
                                  semana : $scope.evento.semana,
                                  diafim : $scope.evento.diafim,
                                  dialimiteconfirmacao: $scope.evento.dialimiteconfirmacao,
                                  pmin : $scope.evento.pmin, 
                                  patual : 1, 
                                  pmax : $scope.evento.pmax,
                                  adm : $scope.user.iduser,
                                  admusername : $scope.user.username,
                                  admapelido : $scope.user.apelido,
                                  preco : $scope.evento.preco,
                                  precopor : $scope.evento.precopor,  
                                  nomelocal : $scope.evento.nomelocal,
                                  endereco : $scope.evento.endereco,
                                  cidade : $scope.evento.cidade,
                                  lat : $scope.evento.lat,
                                  lng : $scope.evento.lng,
                                  dificuldade :$scope.evento.dificuldade,
                                  genero : $scope.evento.genero,
                                  eventopic : evpic,
                                  descricao : $scope.evento.descricao}).then(function (res){
                    $scope.responsecriado = res.data;
                    console.log(res.data.success, "criou");
                  if ($scope.responsecriado.success == true) {
                    if($scope.imgURI != "img/ev.png"){
                      $scope.auxfoto = $scope.evento.nomeevento + $scope.evento.diainicio;
                      var mystring = String($scope.auxfoto);
                      mystring = mystring.replace(/[^a-zA-Z0-9]/g, '');
                      var url = "http://ec2-3-84-65-68.compute-1.amazonaws.com/uploadfotoevento.php";
                                              // File for Upload
                      var targetPath = $scope.imgURI;
                     
                      // File name only
                      //var name = $scope.imgURI.substr(imageData.lastIndexOf('/') + 1);
                      var filename = mystring + '.jpg';
                      // NO CASO SERIA O NOME DO USUARIO.jpg O fileName
                      var options = {
                        fileKey: "file",
                        fileName: filename,
                        chunkedMode: false,
                        mimeType: "multipart/form-data"
                      };
                      $cordovaFileTransfer.upload(url, targetPath, options).then(function(result) {
                         $ionicLoading.hide();
                         var alertPopup = $ionicPopup.alert({
                          title: 'Parabéns',
                          template: $scope.responsecriado.msg
                        }); 
                        alertPopup.then(function(){
                          $ionicLoading.hide();
                          formtelaCriar.updateForm(1);
                          formtela2.updateForm(1);
                          $scope.evento = {};
                          $state.go('tabsController.home');
                       })
                      }, function(err) {
                        $ionicPopup.alert({
                          title: 'Sorry!',
                          template: 'Aconteceu um probleminha, tente de novo'
                        });
                        $ionicLoading.hide();
                      }, function (progress) {
                        $ionicLoading.show({
                          title: '┗(＾0＾)┓',
                          template: '┗(＾0＾)┓'
                        });
                      });
                    }
                          // CRIO TAG
              var res = $scope.evento.tags.split(" ") ;
              for (var i = 0; i<res.length;i++){
                if(res[i][0]!='#'){
                  res[i]= '#' + res[i];
                }
                console.log(res[i], "tags")
                var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criartag.php';
                  $http.post(link, {idevento : $scope.responsecriado.last, 
                                    tag : res[i]}).then(function (res){console.log(res.success, "criou tag")});
              }
              var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/irevento.php';
                  $http.post(link, {idevento : $scope.responsecriado.last, 
                                    iduser : $scope.user.iduser,
                                    idadm : $scope.user.iduser,
                                    admusername : $scope.user.username,  
                                    diainicio : $scope.evento.diainicio,
                                    diafim : $scope.evento.diafim,
                                    username : $scope.user.username,
                                    borda : $scope.user.borda,
                                    apelido : $scope.user.apelido,
                                    profilepic : $scope.user.profilepic,
                                    devicetoken : $scope.user.devicetoken,
                                    confirmacao : $scope.confirmacao,
                                    nomeevento :  $scope.evento.nomeevento,
                                    eventopic : evpic, 
                                    estado : $scope.estado}).then(function (res){
                  $scope.response = res.data;
                  console.log($scope.response);
                  $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/getstalkers.php", {iduser : $scope.user.iduser}).then(function(response) {
                    console.log(response.data[0])
                    if(response.data[0] != 'E'){
                      $scope.auxresp = response.data[0]; 
                      for(var  i = 0 ; i<response.data[0].length;i++){
                        $scope.pushnoti.titulo =$scope.user.apelido + " criou um evento novo";
                        $scope.pushnoti.msg = $scope.user.apelido + " criou um evento novo: " +$scope.evento.nomeevento;
                        $scope.pushnoti.token = $scope.auxresp[i].devicetokenseguidor;
                        EventoService.MandaPushNoti($scope.pushnoti);
                      }
                     }
                  });
                    if ($scope.response.success == true) {
                       
                    }else{
                        var alertPopup = $ionicPopup.alert({
                          title: 'Ocorreu uma falha',
                          template: $scope.responsecriado.msg
                        });
                        alertPopup.then(function(){
                          $ionicLoading.hide();
                          $scope.evento = {};
                          formEventoCriar.updateForm($scope.evento);
                          //formtelaCriar.updateForm(1); // 1 quer dizer que foi criado um evento;
                          $state.go('tabsController.home');
                       })
                      }
                    })
                  }

            });
                                } /// do palavrao
          }else{
            console.log('adsidisa')
          }
            });
          }
         }
         }}
     }

}])

.controller('eventoFechadoCtrl', ['$scope', '$stateParams', 'formItem', 'formUser', 'formOutro', '$http', '$timeout','$ionicPopup', 'EventoService', '$state', 'formpontos' ,'formtelaStalkear', 'formEventoPerfil',// The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, formItem, formUser, formOutro, $http, $timeout, $ionicPopup, EventoService, $state, formpontos, formtelaStalkear, formEventoPerfil) {

    //$scope.evento = formItem.getForm();
    $scope.evento = formEventoPerfil.getForm();
    
    $scope.nota = $scope.evento.nota;
    $scope.dia = {};
    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/geteventoporid.php', {idevento : $scope.evento.idevento}).then(function (result){
    $scope.evento = result.data[0];
      var hj = new Date();
      hj = $scope.evento.diainicio;
      $scope.dia.dia = (hj[8]+hj[9]).valueOf()+'/'+(hj[5]+hj[6]).valueOf();
      $scope.dia.hora = (hj[11]+hj[12]).valueOf()+':'+(hj[14]+hj[15]).valueOf() ;

      //$scope.dia = (hj[8]+hj[9]).valueOf()+'/'+(hj[5]+hj[6]).valueOf()+'/'+(hj[0]+hj[1]+hj[2]+hj[3])+' '+(hj[11]+hj[12]).valueOf()+':'+(hj[14]+hj[15]).valueOf();
      var hjf = $scope.evento.diafim;
      $scope.diafim =  (hjf[8]+hjf[9]).valueOf()+'/'+(hjf[5]+hjf[6]).valueOf()+'/'+(hjf[0]+hjf[1]+hjf[2]+hjf[3])+' '+(hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf();
      
    });



    $scope.aux = formUser.getForm();

    $scope.comentariovalido = {};
    var aux1 = 0;
    var aux2 = 0;
    var aux3 = 0;
    var k = 0;
    var bool = false;
    $scope.validacriador = {};
    $scope.participantes ={};
    $scope.atualiza= {};

    $scope.nuser = 0;
    if($scope.evento.genero == "masc"){
      $scope.masc = true;
      $scope.fem = false;
    }
    if($scope.evento.genero == "fem"){
        $scope.fem = true;
        $scope.masc = false;
    }
    if($scope.evento.genero == "todos"){
        $scope.fem = false;
        $scope.masc = false;
    }
    if($scope.evento.preco == 0 || $scope.evento.preco =="Gratuito"){
      $scope.evento.preco = "Gratuito";
      $scope.porpessoa = false;
      $scope.porlocal = false;
    }else{
      if($scope.evento.precopor == 1){
        $scope.porpessoa = true;
        $scope.porlocal = false;
      }else{
        $scope.porpessoa = false;
        $scope.porlocal = true;
      }
    }

    $scope.$on("$ionicView.enter", function(event, data){
      //$scope.evento = formItem.getForm();
      $scope.evento = formEventoPerfil.getForm();
      
      $scope.nota = $scope.evento.nota;
      $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/geteventoporid.php', {idevento : $scope.evento.idevento}).then(function (result){
        $scope.evento = result.data[0];
        var hj = new Date();
        hj = $scope.evento.diainicio;
        //$scope.dia = (hj[8]+hj[9]).valueOf()+'/'+(hj[5]+hj[6]).valueOf()+'/'+(hj[0]+hj[1]+hj[2]+hj[3])+' '+(hj[11]+hj[12]).valueOf()+':'+(hj[14]+hj[15]).valueOf();
        $scope.dia.dia = (hj[8]+hj[9]).valueOf()+'/'+(hj[5]+hj[6]).valueOf();
        $scope.dia.hora = (hj[11]+hj[12]).valueOf()+':'+(hj[14]+hj[15]).valueOf() ;

        var hjf = $scope.evento.diafim;
        $scope.diafim =  (hjf[8]+hjf[9]).valueOf()+'/'+(hjf[5]+hjf[6]).valueOf()+'/'+(hjf[0]+hjf[1]+hjf[2]+hjf[3])+' '+(hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf();
      });

        
      $scope.items = [];
      var k2 = 0;
      $scope.pessoaduvida ={};
      EventoService.GetParticipantes($scope.evento.idevento).then(function(items) {
        aux3 = items.length;
        $scope.participantes = items;
        for(var  i = 0 ; i<items.length;i++){
          if(items[i].iduser == $scope.aux.iduser){
            if(items[i].estado =='9'){
              $scope.ocultabotao = false;
            }else{
              $scope.ocultabotao = true;
            }
          }
          if(items[i].borda == 0){
            items[i].bb = false;
            items[i].bs = false;
            items[i].bg = false;
          }
          if(items[i].borda == 1){
            items[i].bb = true;
            items[i].bs = false;
            items[i].bg = false;
          }
          if(items[i].borda == 2){
            items[i].bb = false;
            items[i].bs = true;
            items[i].bg = false;
          }
          if(items[i].borda == 3){
            items[i].bb = false;
            items[i].bs = false;
            items[i].bg = true;
          } 
          if(items[i].confirmacao == 'Organizador não lembra dele no evento, avalie-o se vc se lembra dele'){
            $scope.pessoaduvida[k2] = items[i]; 
            k2++;
          }
          if(items[i].profilepic[8] == 's' && items[i].profilepic[9] == '3'){
             items[i].profilepic=items[i].profilepic+"?{{getTimeStamp()}}";
           }else{
             items[i].profilepic=items[i].profilepic;
           }
          //items[i].profilepic = items[i].profilepic+"?{{getTimeStamp()}}";
        }
        if(i==items.length){
          $scope.nomeevento = items[0].nomeevento;
          $scope.items = items;
        }
        
      });

      EventoService.GetComentariosfeitos($scope.aux).then(function(coments) { //
        aux1 = coments.length;
        $scope.feitos = coments;
      }); 
      $scope.validacriador.iduser =  $scope.evento.idevento; 
      $scope.validacriador.username =  $scope.evento.nomeevento; 
      EventoService.GetComentarios($scope.validacriador).then(function(recebido) {
        for(var  v = 0 ; v<recebido.length;v++){
            if(recebido[v].presenca == true){
               bool = true;
            }
          }
          console.log(aux3);
          if (!bool && recebido.length == aux3-1) {
            console.log('Organizador não foi');
          }
      });
    });

    $scope.Ocultar =  function(evento){
      $scope.ocultabotao = false;
      $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/ocultarpessoaevento.php", {idevento : evento.idevento,
                                                                          iduser: $scope.aux.iduser,
                                                                          estado : 9});
    }
    $scope.DESOcultar =  function(evento){
      $scope.ocultabotao = true;
      $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/ocultarpessoaevento.php", {idevento : evento.idevento,
                                                                          iduser: $scope.aux.iduser,
                                                                          estado : 3});
    }
    $scope.enterItem =  function(item){
      formOutro.updateForm(item);
      console.log(item.iduser);
      aux2 = 0;
      console.log(aux2);
      if (item.iduser == $scope.aux.iduser) {
        
          var alertPopup = $ionicPopup.alert({
                      title: 'Oxi',
                      template: 'Não podes se avaliar né quiridu'
                    }); 

      }else{
        $scope.auxcomente={};
        $scope.auxcomente.iduser = item.iduser;
        $scope.auxcomente.username = item.username;
        $scope.auxcomente.idevento = $scope.evento.idevento;
        $scope.auxcomente.stakeriduser = $scope.aux.iduser;
        console.log("iduser" ,$scope.auxcomente.stakeriduser,"idevento", $scope.auxcomente.idevento,"nomepessoaavaliada", $scope.auxcomente.username ,"idpessoaavaliada", $scope.auxcomente.iduser)
        EventoService.GetComentariosDesseEventoPessoaAvaliou($scope.auxcomente).then(function(items) {
          if(items != "Error" ){
            formOutro.updateForm(item);
            $state.go('tabsController.perfil_outro_evento_criados');
          }else{
            $state.go('tabsController.avaliaODoUsuario');
          }
        });


        //   for (var i = 0 ; i<aux1 ; i++){
        //     console.log($scope.feitos[i].idevento, item.idevento , item.iduser, $scope.feitos[i].idpessoaavaliada)
        //     if ($scope.feitos[i].idevento == item.idevento && item.iduser == $scope.feitos[i].idpessoaavaliada) {
        //       aux2=1;
        //     }
        //   }
        //   console.log(aux2, "aux2")
        // if (aux2==1) {
        //   formOutro.updateForm(item);
        //   $state.go('tabsController.perfil_outro_evento_criados');
        // }else{
        //   $state.go('tabsController.avaliaODoUsuario');
        // }
      }
    }
    $scope.chatrou = function(){
      $state.go('tabsController.chatfechado');
    }

    $scope.entrar = function(){
      $state.go('tabsController.comentRiosEvento');
    }

}])

.controller('chatfechadoCtrl', ['$scope', '$stateParams', '$timeout', '$ionicScrollDelegate', 'formUser', '$http', 'formItem', '$interval', 'EventoService', 'formEventoPerfil',  // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $timeout, $ionicScrollDelegate, formUser, $http, formItem, $interval, EventoService, formEventoPerfil) {
  $scope.user = formUser.getForm();
  $scope.evento = formEventoPerfil.getForm();
  $scope.messages = [];

  var isIOS = ionic.Platform.isWebView() && ionic.Platform.isIOS();
  EventoService.Getmsg($scope.evento.idevento).then(function(result) {
    if (result.success != false) {
      $scope.messages =result;
      //$scope.messages = result.concat($scope.messages);
      $timeout(function() {
        $ionicScrollDelegate.scrollBottom(true);
      }, 300);
    }
  });


  $scope.$on("$ionicView.enter", function(event, data){
    $scope.user = formUser.getForm();
    $scope.evento = formEventoPerfil.getForm();
    $scope.data = {};
    $scope.messages = {
      mensagem: '',
      tempo: '',
      idevento : '', 
      iduser : '', 
      username : '',
      apelido : ''
    };
    var isIOS = ionic.Platform.isWebView() && ionic.Platform.isIOS();
    //$scope.messages = [];
    EventoService.Getmsg($scope.evento.idevento).then(function(result) {
      if (result.success != false) {
        $scope.messages =result;
        //$scope.messages = result.concat($scope.messages);
        $timeout(function() {
        $ionicScrollDelegate.scrollBottom(true);
      }, 300);
      }
    });
  });

   $interval( function() {
      EventoService.Getmsg($scope.evento.idevento).then(function(result) {
        if (result.success != false) {
          $scope.messages =result;
        }
      });
    }, 5000);


}])

.controller('chathomeCtrl', ['$scope', '$stateParams', '$timeout', '$ionicScrollDelegate', 'formUser', '$http', 'formItem', '$interval', 'EventoService','$state', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $timeout, $ionicScrollDelegate, formUser, $http, formItem, $interval, EventoService, $state) {
  $scope.user = formUser.getForm();
  $scope.evento = formItem.getForm();
  $scope.data = {};

    $scope.messages = {
      mensagem: '',
      tempo: '',
      idevento : '', 
      iduser : '', 
      username : '',
      apelido : ''
    };
    $scope.pushnoti = {};
  // $scope.hideTime = true;
  //console.log( $scope.user.username);
  var isIOS = ionic.Platform.isWebView() && ionic.Platform.isIOS();
  EventoService.Getmsg($scope.evento.idevento).then(function(result) {
    if (result.success != false) {
      $scope.messages =result;
      //$scope.messages = result.concat($scope.messages);
      $timeout(function() {
        $ionicScrollDelegate.scrollBottom(true);
      }, 300);
    }
  });
  $scope.nomeevento = '';
 

  $scope.$on("$ionicView.enter", function(event, data){
    $scope.user = formUser.getForm();
    $scope.evento = formItem.getForm();
    $scope.data = {};
    $scope.messages = {
      mensagem: '',
      tempo: '',
      idevento : '', 
      iduser : '', 
      username : '',
      apelido : ''
    };
    var isIOS = ionic.Platform.isWebView() && ionic.Platform.isIOS();
    //$scope.messages = [];
    EventoService.Getmsg($scope.evento.idevento).then(function(result) {
      if (result.success != false) {
        $scope.messages =result;
        //$scope.messages = result.concat($scope.messages);
        $timeout(function() {
        $ionicScrollDelegate.scrollBottom(true);
      }, 300);
      }
    });
  });

   $interval( function() {
      EventoService.Getmsg($scope.evento.idevento).then(function(result) {
        if (result.success != false) {
          $scope.messages =result;
        }
      });
    }, 5000);

   $scope.volta =  function(){
    $state.go('tabsController.eventoAberto');
  }
  $scope.auxev = {};
  $scope.auxev.iduser = $scope.user.iduser;
  $scope.auxev.idevento = $scope.evento.idevento;
  EventoService.GetNotiOn($scope.auxev).then(function(notion) {
    $scope.notion = notion;
  });
  $scope.ativanoti = function(){
    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/mudanotievento.php', {idevento : $scope.auxev.idevento, iduser : $scope.auxev.iduser, chatnotion : 0});
    $scope.notion = true;
  }
  $scope.desativanoti = function(){
    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/mudanotievento.php', {idevento : $scope.auxev.idevento, iduser : $scope.auxev.iduser, chatnotion : 1});
    $scope.notion = false;
  }


  $scope.sendMessage = function() {
    var d = new Date();
    console.log(d);
    d = d.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
    d = d.replace(/:\d+ /, ' ');
    var data = new Date();
    var dataFormatada = ("0" + data.getDate()).substr(-2) + "/" 
        + ("0" + (data.getMonth() + 1)).substr(-2) + "/" + data.getFullYear();

     // var dataFormatada2 =  (data.getFullYear() + "-" + ("0" + (data.getMonth() + 1)).substr(-2) + "-" + ("0" + data.getDate()).substr(-2) );


        dataFormatada = (d + ' '+dataFormatada);
        console.log(dataFormatada);
     if(!$scope.data.message){
      console.log(  "mensagem "+$scope.data.message);
     }else{
      console.log($scope.data.message,  $scope.messages,  $scope.messages[0]);
    
      if($scope.messages[0]){
        $scope.messages.push({
          username: $scope.user.username,
          mensagem: $scope.data.message,
          tempo: dataFormatada,
          idevento : $scope.evento.idevento, 
          iduser : $scope.user.iduser, 
          apelido : $scope.user.apelido
        });
      }else{
        $scope.messages[0] = {
          username: $scope.user.username,
          mensagem: $scope.data.message,
          tempo: dataFormatada,
          idevento : $scope.evento.idevento, 
          iduser : $scope.user.iduser, 
          apelido : $scope.user.apelido
        };
      }
      if($scope.data.message != '' || $scope.data.message){
        var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criarmsg.php';
                      $http.post(link, {idevento : $scope.evento.idevento, 
                                        mensagem :  $scope.data.message,
                                        iduser : $scope.user.iduser, 
                                        username : $scope.user.username,
                                        apelido : $scope.user.apelido,
                                        tempo : dataFormatada}).then(function (res){
                    $scope.response = res.data;
                    console.log($scope.response.msg);
                  });
        EventoService.GetParticipantesNotifica($scope.evento.idevento).then(function(parti) {
          $scope.nomeevento = parti[0].nomeevento;
          for (var i = 0; i < parti.length; i++) {
            if (parti[i].estado!=7 && parti[i].estado!=8 && parti[i].iduser != $scope.user.iduser) {
              $scope.pushnoti.titulo = "Nova mensagem";
              $scope.pushnoti.msg = 'Chat do '+$scope.evento.nomeevento + ' tem mensagem nova' ;
              $scope.pushnoti.token = parti[i].devicetoken;
              EventoService.MandaPushNoti($scope.pushnoti);
            }          
          }     
        });
      }
      delete $scope.data.message;
      $ionicScrollDelegate.scrollBottom(true);
     }
      
  };


  $scope.inputUp = function() {
    if (isIOS) $scope.data.keyboardHeight = 216;
    $ionicScrollDelegate.resize();
    $timeout(function() {
      $ionicScrollDelegate.scrollBottom(true);
    }, 300);

  };

  $scope.inputDown = function() {
    if (isIOS) $scope.data.keyboardHeight = 0;
    $ionicScrollDelegate.resize();
  };

  $scope.closeKeyboard = function() {
     cordova.plugins.Keyboard.close();
  };

}])

.controller('comentRiosEventoCtrl', ['$scope', '$stateParams', 'formItem', 'EventoService', '$ionicPopup', '$http', 'formEventoPerfil', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, formItem, EventoService, $ionicPopup, $http,formEventoPerfil ) {
  $scope.evento = formEventoPerfil.getForm();
  $scope.nota = 0;
  $scope.items ={};

  EventoService.GetComentariosevento($scope.evento).then(function(items) {
    console.log(items)
    if(items=='Error'){
      $scope.nota = 0;
      $scope.items ={};
    }else{
      console.log('Tem comentarios')
      $scope.items = items;
      for (var i = 0; i < items.length; i++) {
        $scope.nota = parseFloat(items[i].nota) + $scope.nota ;
        if(items[i].profilepic[8] == 's' && items[i].profilepic[9] == '3'){
             $scope.items[i].profilepic=items[i].profilepic+"?{{getTimeStamp()}}";
           }else{
             $scope.items[i].profilepic=items[i].profilepic;
           }
        //$scope.items[i].profilepic = items[i].profilepic+"?{{getTimeStamp()}}";;
      }
      $scope.nota = ($scope.nota/items.length).toFixed(1);
    }     
  });
  $scope.reportcoment = function(item){
      $ionicPopup.prompt({
                    title: 'Você quer reportar essa comentário pq?',
                    template: 'Não me venha reportando só pq tu quer, não me venha dar trabalho!!!!',
                   inputType: 'text',
                   inputPlaceholder: ' Linguajar ofensivo ou inapropriado'
                 }).then(function(texto) {
                  if(texto){
                    $scope.reportmsg = item.idavaliacao + ' (idavaliação) '+texto;
                    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/reportaevento.php', {namereportado : item.nomeavaliador,
                                                                              reportadoid : item.iduser,
                                                                              iduserreportando : $scope.user.iduser,
                                                                              usernamereportando : $scope.user.username,
                                                                              tiporeport : 'comentario',
                                                                              motivo : $scope.reportmsg}).then(function (tes){
                                 $scope.response = tes.data;
                                  var alertPopup = $ionicPopup.alert({
                                                          title: 'Obrigado',
                                                          template: 'Esta pessoa esta agora sobre investigação, obrigado por manter a plataforma segura'
                                                        });

                               });
                  }
                 });
  }

}])

.controller('sigoCtrl', ['$scope', '$stateParams', 'formUser', '$http', 'formOutro', '$state', 'formtelaStalkear',  '$ionicPopup','EventoService',   // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, formUser, $http, formOutro, $state, formtelaStalkear,  $ionicPopup, EventoService) {
  $scope.user = formUser.getForm();
  $scope.items = {};
  $scope.estadobutton = 0; 
  $scope.seguindo = true;
  $scope.seguido = false; 
  $scope.desbloque = false; 
  $scope.bloqueado = false;
  $scope.dessegue = true; 

  $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/getamigos.php", {iduser : $scope.user.iduser}).then(function(response) {
          if(response.data[0] != 'E'){
            for(var  i = 0 ; i<response.data[0].length;i++){
    
              if(response.data[0][i].profilepicseguindo[8] == 's' && response.data[0][i].profilepicseguindo[9] == '3'){
                 response.data[0][i].profilepic=response.data[0][i].profilepicseguindo+"?{{getTimeStamp()}}";
               }else{
                 response.data[0][i].profilepic=response.data[0][i].profilepicseguindo;
               }
            }
            if(i==response.data[0].length){
              $scope.items = response.data[0];
            }  
          }else{
              $scope.items = {};
          }
        });

  var header = document.getElementById("barrr");
    var btns = header.getElementsByClassName("btneva2");
    for (var i = 0; i < btns.length; i++) {
      btns[i].addEventListener("click", function() {
        var current = document.getElementsByClassName("actis");
        current[0].className = current[0].className.replace(" actis", "");
        this.className += " actis";
      });
    }

    $scope.duvida4= function() {var alertPopup = $ionicPopup.alert({
                      title: '|_・)',
                      template: 'Ao seguir uma pessoa, você poderá ver os eventos nos quais ela está confirmada. Mas atenção, ela saberá que você está stalkeando-a. Ao bloquear uma pessoa que te segue, ela não conseguirá mais ver os eventos que você marcou de ir (arraste para o lado para bloquear).'
                    });};

  $scope.sigo = function(){
    $scope.items = {};
    $scope.estadobutton = 0;
    $scope.seguindo = true;
    $scope.seguido = false;
    $scope.desbloque = false; 
    $scope.bloqueado = false;
    $scope.dessegue = true; 
    $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/getamigos.php", {iduser : $scope.user.iduser}).then(function(response) {
          if(response.data[0] != 'E'){
            for(var  i = 0 ; i<response.data[0].length;i++){
    
              if(response.data[0][i].profilepicseguindo[8] == 's' && response.data[0][i].profilepicseguindo[9] == '3'){
                 response.data[0][i].profilepic=response.data[0][i].profilepicseguindo+"?{{getTimeStamp()}}";
               }else{
                 response.data[0][i].profilepic=response.data[0][i].profilepicseguindo;
               }
            }
            if(i==response.data[0].length){
              $scope.items = response.data[0];
            }  
          }else{
              $scope.items = {};
          }
        });
  }
  $scope.seguem = function(){
    $scope.items = {};
    $scope.estadobutton = 1;
    $scope.seguindo = false;
    $scope.desbloque = false; 
    $scope.seguido = true;
    $scope.bloqueado = false;
    $scope.dessegue = false; 
    $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/getstalkers.php", {iduser : $scope.user.iduser}).then(function(response) {
          if(response.data[0] != 'E'){
            for(var  i = 0 ; i<response.data[0].length;i++){
              if(response.data[0][i].profilepicseguidor[8] == 's' && response.data[0][i].profilepicseguidor[9] == '3'){
                 response.data[0][i].profilepic=response.data[0][i].profilepicseguidor+"?{{getTimeStamp()}}";
               }else{
                 response.data[0][i].profilepic=response.data[0][i].profilepicseguidor;
               }
               //console.log("das",response.data[0][i].profilepicseguidor);
            }

            if(i==response.data[0].length){
              $scope.items = response.data[0];
            }  
          }else{
              $scope.items = {};
          }
        });
    }
   $scope.bloqueados = function(){
    $scope.items = {};
    $scope.desbloque = true; 
    $scope.estadobutton = 2;
    $scope.seguindo = false;
    $scope.seguido = false;
    $scope.bloqueado = true;
    $scope.dessegue = false; 
    $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/getbloqueados.php", {iduser : $scope.user.iduser}).then(function(response) {
          if(response.data[0] != 'E'){
            for(var  i = 0 ; i<response.data[0].length;i++){
    
              if(response.data[0][i].profilepicseguidor[8] == 's' && response.data[0][i].profilepicseguidor[9] == '3'){
                 response.data[0][i].profilepic=response.data[0][i].profilepicseguidor+"?{{getTimeStamp()}}";
               }else{
                 response.data[0][i].profilepic=response.data[0][i].profilepicseguidor;
               }
            }
            if(i==response.data[0].length){
              $scope.items = response.data[0];
            }  
          }else{
              $scope.items = {};
          }
        });
  }

  //// BLOQUEAR PESSOA

  $scope.bloquear = function(item) {
    var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/bloquear.php'; // estado "Bloqueado"  = 1;
            $http.post(link, {iduserseguindo : item.iduserseguindo, 
                              iduserseguidor : item.iduserseguidor}).then(function(res) {
                            
                                var alertPopup = $ionicPopup.alert({
                                                            title: '( ง ᵒ̌皿ᵒ̌)ง⁼³₌₃',
                                                            template: 'Pessoa não poderá mais te seguir'
                                                          }); 
                            $scope.items.splice($scope.items.indexOf(item), 1);  
                          });
  }
  $scope.desbloquear = function(item) {
    console.log(item.iduserseguindo , item.iduserseguidor)
    var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/desbloquear.php'; // estado "desBloqueado"  = 0;
            $http.post(link, {iduserseguindo : item.iduserseguindo, 
                              iduserseguidor : item.iduserseguidor}).then(function(res) {
                            
                                var alertPopup = $ionicPopup.alert({
                                                            title: 's2',
                                                            template: 'Pessoa desbloqueada'
                                                          });  
                                $scope.items.splice($scope.items.indexOf(item), 1);  
                          });
  }
  $scope.desseguir = function(item) {
    console.log(item.iduserseguindo , item.iduserseguidor)
    var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/desfollow.php'; // estado "Bloqueado"  = 2;
            $http.post(link, {iduserseguindo : item.iduserseguindo, 
                          iduserseguidor : item.iduserseguidor}).then(function(res) {
                            
                                var alertPopup = $ionicPopup.alert({
                                                            title: '(*꒦ິ⌓꒦ີ)',
                                                            template: 'Não segues mais esta pessoa'
                                                          }); 
                                $scope.items.splice($scope.items.indexOf(item), 1);  
                            
                          });
  }



          //// ARRUMAR PARA NÃO IR NA TAB DE EVENTOS ABERTOS

  $scope.enterItem = function(item){
    console.log(item.iduserseguidor,"entrando no bloqueado")
      if($scope.estadobutton  == 0 ){
          $scope.stalkeada={};
          $scope.stalkeada.iduser = item.iduserseguindo;
          $scope.stalkeada.username = item.usernameseguindo;
          formOutro.updateForm($scope.stalkeada);
          formtelaStalkear.updateForm(1);
          $state.go('tabsController.perfilFollow');
      }
      if($scope.estadobutton  == 1 ){
        $scope.stalkeada={};
        $scope.stalkeada.iduser = item.iduserseguidor;
        $scope.stalkeada.username = item.usernameseguidor;
        formOutro.updateForm($scope.stalkeada);
        formtelaStalkear.updateForm(1);
        $state.go('tabsController.perfilFollow');
      }
      if($scope.estadobutton  == 2 ){
        $scope.stalkeada={};
        $scope.stalkeada.iduser = item.iduserseguidor;
        $scope.stalkeada.username = item.usernameseguidor;
        formOutro.updateForm($scope.stalkeada);
        formtelaStalkear.updateForm(1);
        $state.go('tabsController.perfilFollow');
      }
      
 
    
  }

}])
   
.controller('qmFoiMesmoCtrl', ['$scope', '$stateParams', 'EventoService', '$state', 'formAux', 'formUser', 'formItem', 'formpontos','$http', '$ionicPopup', 'formtelanoti','formEventoPerfil',  // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, EventoService, $state, formAux, formUser, formItem, formpontos, $http, $ionicPopup, formtelanoti,formEventoPerfil) {

  $scope.evento = formAux.getAux();

  $scope.aux = formUser.getForm();
  $scope.items = {};
  $scope.pessoaevento = {};
  $scope.p = 0;
  $scope.atualiza={};
  var idnoti = $scope.evento.idnotificacao;

  $scope.telano = formtelanoti.getForm();

  EventoService.GetParticipantes($scope.evento.idevento).then(function(items) {
              items.shift();
              $scope.items = items;
              for (var i = 0; i < items.length; i++) {
                if(items[i].profilepic[8] == 's' && items[i].profilepic[9] == '3'){
                   $scope.items[i].profilepic=items[i].profilepic+"?{{getTimeStamp()}}";
                 }else{
                   $scope.items[i].profilepic=items[i].profilepic;
                 }
                //$scope.items[i].profilepic = items[i].profilepic+"?{{getTimeStamp()}}";;
              }

  });

  $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/getpessoaeventopontos.php", {iduser : $scope.aux.iduser,
                                                                   estado : '3'}).then(function(response) {
    ajuda = response.data[0];
      for(var i=0;i<ajuda.length;i++){
        if (ajuda[i].idevento == $scope.evento.idevento){
           $scope.p += parseFloat(ajuda[i].pontos);
        }
      }
  });

  $scope.$on("$ionicView.enter", function(event, data){
    $scope.evento = formAux.getAux();
    $scope.aux = formUser.getForm();
    idnoti = $scope.evento.idnotificacao;
    $scope.items = {};
    $scope.pessoaevento = {};
    $scope.p = 0;
    //console.log($scope.telano,"TEalaaa")
    
    EventoService.GetParticipantes($scope.evento.idevento).then(function(items) {
              items.shift();
              $scope.items = items;
              for (var i = 0; i < items.length; i++) {
                if(items[i].profilepic[8] == 's' && items[i].profilepic[9] == '3'){
                   $scope.items[i].profilepic=items[i].profilepic+"?{{getTimeStamp()}}";
                 }else{
                   $scope.items[i].profilepic=items[i].profilepic;
                 }
                //$scope.items[i].profilepic = items[i].profilepic+"?{{getTimeStamp()}}";;
              }
    });

    $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/getpessoaeventopontos.php", {iduser : $scope.aux.iduser,
                                                                    estado : '3'}).then(function(response) {
      ajuda = response.data[0];
      for(var i=0;i<ajuda.length;i++){
        if (ajuda[i].idevento == $scope.evento.idevento){
           $scope.p += parseFloat(ajuda[i].pontos);
        }
      }
    });
  });
  $scope.myToggle = { checked: true }


  $scope.onClickAdd = function(item){
    //console.log(item.added);
    if (!item.added){
      console.log(item.username);
      item.foi = "não fui"
    }else{
      item.foi = "fui"
      console.log('add');
    } 
    item.added = !item.added;
  };  

  $scope.confirma = function(items){
    console.log(items.length);
    for(var i = 0; i<items.length;i++){ 
      if (items[i].added) {
        console.log(items[i].iduser);
        $scope.pessoaevento.id_user_envia = items[i].iduser;
        $scope.pessoaevento.idevento = $scope.evento.idevento;
        $scope.pessoaevento.confirmacao = 'Organizador não lembra dele no evento, avalie-o se vc se lembra dele'; //estado significa que o usuário não foi ao evento de acordo com o criador
        $scope.pessoaevento.aceito = '3';
        $scope.pessoaevento.pontos = 0; 
        EventoService.atualizarpessoaevento($scope.pessoaevento).then(function(msg){
        });
      }
    }
           ///PONTOS PARA CRIADOR DO EVENTO POR CONFIRMAR A PRESENÇA DOS USUÁRIOS +4
    $scope.atualiza.idevento = $scope.evento.idevento;
    $scope.atualiza.id_user_envia = $scope.aux.iduser;  
    $scope.atualiza.pontos =  $scope.p+4;
    $scope.atualiza.auxpontos = 0;
    EventoService.pontospessoaevento($scope.atualiza);
    EventoService.ncriadoscriador($scope.aux.iduser);
    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacao.php', {idnotificacao : idnoti});

    formItem.updateForm($scope.evento);
    var alertPopup = $ionicPopup.alert({
        title: '¡¡¡( •̀ ᴗ •́ )و!!!',
        template: 'Veja nos seus eventos finalizados e avalie os participantes'
    });
    formEventoPerfil.updateForm($scope.evento);
    if($scope.telano == 1){
      $state.go('geral'); ///teste
    }else{
      $state.go('tabsController.notificaEs'); ///teste
    } 
    
  }

}])


.controller('avaliaODoUsuarioCtrl', ['$scope', '$stateParams', '$state', 'formOutro', 'EventoService','formItem', 'formUser', '$http','$timeout','$ionicPopup','formpontos', 'formEventoPerfil', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $state, formOutro, EventoService, formItem, formUser, $http, $timeout, $ionicPopup,formpontos, formEventoPerfil) {
  
  $scope.teste = formOutro.getForm();
  //$scope.evento = formItem.getForm();
  $scope.evento = formEventoPerfil.getForm();
  
  $scope.aux = formUser.getForm();
  $scope.cars = 0;
  $scope.pessoa = {};
  $scope.atualiza ={};
  $scope.pontos = {};
  $scope.pushnoti = {};
  $scope.p = 0;
  $scope.stalkeada = {};
  $scope.notificaapelido = "";
  $scope.notificafoto = "";
  $scope.pessoa.nota = 8;
  var aux = 0;
  var noti = {};
  $scope.comentbem = true;
  $scope.pushnoti = {};

    var btns = document.getElementsByClassName("btnavaliauser");
    for (var i = 0; i < btns.length; i++) {
      btns[i].addEventListener("click", function() {
        var current = document.getElementsByClassName("actauser");
        current[0].className = current[0].className.replace(" actauser", "");
        this.className += " actauser";
      });
    }

 

  EventoService.GetStalkear($scope.teste.iduser).then(function(items) {
    $scope.stalkeada = items;
    //console.log($scope.stalkeada, 'depois de stalkear');
    if($scope.stalkeada.profilepic[8] == 's' && $scope.stalkeada.profilepic[9] == '3'){
            document.getElementById("imageidavaliaODoUsuario").src=$scope.stalkeada.profilepic+"?{{getTimeStamp()}}";
           }else{
             document.getElementById("imageidavaliaODoUsuario").src=$scope.stalkeada.profilepic;
           }
    //document.getElementById("imageidavaliaODoUsuario").src=$scope.stalkeada.profilepic+"?{{getTimeStamp()}}";
  });

  $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/getpessoaeventopontos.php", {iduser : $scope.aux.iduser,
                                                                  estado : '3'}).then(function(response) {
    $scope.pontos = response.data[0];
      for(var i=0;i<$scope.pontos.length;i++){
        if ($scope.pontos[i].idevento == $scope.evento.idevento) {
          console.log('alouuu');
          $scope.p += parseFloat($scope.pontos[i].pontos);
        }
      }
    console.log($scope.p);
  });

  var Areatxt = document.getElementById("Areatxt");

  Areatxt.addEventListener("keydown",function(){
    var characters = Areatxt.value.split('');
    $scope.cars= characters.length+1;
    console.log($scope.cars)
    if(characters.length > 300){
      Areatxt.value = Areatxt.value.substring(0,300);
    }
  });
  
  $scope.Extrovertido = function() {$scope.pessoa.nota = 1;$scope.comentbem = true;}
  $scope.Introvertido = function() {$scope.pessoa.nota = 2;$scope.comentbem = true;}
  $scope.Realista = function() {$scope.pessoa.nota = 3;$scope.comentbem = true;}
  $scope.Curioso = function() {$scope.pessoa.nota = 4;$scope.comentbem = true;}
  $scope.Solidario = function() {$scope.pessoa.nota = 5;$scope.comentbem = true;}
  $scope.Racional = function() {$scope.pessoa.nota = 6;$scope.comentbem = true;}
  $scope.Organizado = function() {$scope.pessoa.nota = 7;$scope.comentbem = true;}
  $scope.Criativo = function() {$scope.pessoa.nota = 8;$scope.comentbem = true;}
  $scope.mal = function(){$scope.pessoa.nota = 9;$scope.comentbem = false;}

  $scope.auxcomente={};
 // $scope.testee = function(){
    $scope.auxcomente.iduser = $scope.aux.iduser;
    $scope.auxcomente.username = $scope.aux.username;
    $scope.auxcomente.idevento = $scope.evento.idevento;
    $scope.auxcomente.stakeriduser = $scope.teste.iduser;
    //console.log("iduser" ,$scope.auxcomente.stakeriduser,"idevento", $scope.auxcomente.idevento,"nomepessoaavaliada", $scope.auxcomente.username ,"idpessoaavaliada", $scope.auxcomente.iduser)
    EventoService.GetComentariosDesseEventoPessoaAvaliou($scope.auxcomente).then(function(items) {
      if(items != "Error" ){
        $scope.auxcomente.estado = 1;
        console.log("Essa pessoa te avaliou ja")
      }else{
        $scope.auxcomente.estado = 0;
        console.log("Não foi avaliado por essa pessoa")
      }
    });
  //}

  



    $scope.reportar = function(){
    $scope.reportmsg = '';
    console.log($scope.stalkeada.username);
    $scope.report = [
    { text: "Nome impróprio", checked: false },
    { text: "Comportamento inadequado", checked: false },
    { text: "Foto inapropriada", checked: false },
    { text: "É um impostor", checked: false }
    ];
    $ionicPopup.confirm({
      title: 'Você quer reportar essa pessoa pq?',
      content: '<ion-checkbox ng-repeat="item in report" style="color: #FCFCFC;" ng-model="item.checked"  ng-checked="item.checked">{{item.text}}</ion-checkbox>',
      scope: $scope
    }).then(function(res) {
      if(res) {
        for (var h=0;h<3;h++){
          //console.log($scope.report[h].checked , h);
          if($scope.report[h].checked){
            $scope.reportmsg = $scope.reportmsg + $scope.report[h].text + ' ';
            //console.log($scope.reportmsg);
          }
        }
        if(h==3){
          console.log($scope.reportmsg);
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/reportaevento.php', {namereportado : $scope.stalkeada.username,
                                                                          reportadoid : $scope.stalkeada.iduser,
                                                                          iduserreportando : $scope.user.iduser,
                                                                          usernamereportando : $scope.user.username,
                                                                          tiporeport : 'usuario',
                                                                          motivo : $scope.reportmsg}).then(function (tes){
            $scope.response = tes.data;
            var alertPopup = $ionicPopup.alert({
              title: 'Obrigado',
              template: 'Esta pessoa esta agora sobre investigação, obrigado por manter a plataforma segura'
            });
          });
        }
      }
    });
  }


  $scope.pushNotificationChange = function() {
    console.log('Push Notification Change', $scope.pushNotification.checked);
  };
  $scope.pushNotification = { checked: false };

  $scope.pronto = function(){
    if($scope.pushNotification.checked){
      $scope.notificaapelido = "Anônimo";
      $scope.notificafoto = "img/anonimo.jpg";
      $scope.msg = "Você foi avaliado";
    }else{
      $scope.notificaapelido =  $scope.aux.apelido;
      $scope.msg = $scope.aux.username + " te avaliou";
      $scope.notificafoto = $scope.aux.profilepic;
    }
    console.log($scope.pessoa.comentario)
    if($scope.pessoa.comentario == '' || !$scope.pessoa.comentario){
      var alertPopup = $ionicPopup.alert({
        title: 'Bleeee',
        template: 'Escreva algo!!!!'
      });
    
    }else{
      $scope.atualiza.confirmacao = 'Avaliado';
      $scope.atualiza.aceito = '3';
      $scope.atualiza.idevento = $scope.evento.idevento;
      $scope.atualiza.id_user_envia = $scope.stalkeada.iduser;
      $scope.atualiza.pontos = 3;     // Confirma que a pessoa esteve presente no evento
      EventoService.atualizarpessoaevento($scope.atualiza);
      for(var i = 0; i<$scope.pontos.length;i++){
        if ($scope.pontos[i].idevento==$scope.evento.idevento && $scope.pontos[i].auxpontos==1) {
          aux = 1;
        }
      }
      if (aux != 1){
        $scope.atualiza.idevento = $scope.evento.idevento;
        $scope.atualiza.id_user_envia = $scope.aux.iduser;  
        $scope.atualiza.pontos =  parseFloat($scope.p)+3;
        $scope.atualiza.auxpontos = 1;
        EventoService.pontospessoaevento($scope.atualiza);
      }
      if($scope.auxcomente.estado ==  1){
        EventoService.AtualizaComentariosDesseEventoPessoaAvaliou($scope.auxcomente)
      }
      $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/avaliar.php', {idevento : $scope.evento.idevento,
                                                                iduser : $scope.aux.iduser,
                                                                 nomeavaliador : $scope.aux.username,
                                                                 apelidoavaliador : $scope.notificaapelido,
                                                                 profilepic :$scope.notificafoto,
                                                                idpessoaavaliada : $scope.stalkeada.iduser,
                                                                nomepessoaavaliada: $scope.stalkeada.username,
                                                                estado :  $scope.auxcomente.estado,    //pessoa avaliou pessoa
                                                                nota : $scope.pessoa.nota,
                                                                comentario: $scope.pessoa.comentario,
                                                                presenca: true}).then(function (res){
        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarauxfrase.php' , {iduser :$scope.aux.iduser}).then(function (resp){console.log(resp.data.success)});;
        var alertPopup = $ionicPopup.alert({
          title: 'Obrigado',
          template: 'Por favor avalie as outras pessoas que compareceram ao evento'
        });
        alertPopup.then(function(){
          noti.recebe = $scope.stalkeada.iduser;
          noti.envia = $scope.aux.iduser;
          noti.tipo = 7;
          noti.nomeevento = $scope.evento.nomeevento;
          EventoService.VerificaNotificacao(noti).then(function(res) {
            console.log(res);
            if(res){
              if(!$scope.pushNotification.checked){
                $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : $scope.msg, 
                                                                              idevento : $scope.evento.idevento,
                                                                              nomeevento : $scope.evento.nomeevento,
                                                                              id_user_envia : $scope.aux.iduser,
                                                                              username_envia : $scope.aux.username,
                                                                              apelido_envia : $scope.aux.apelido,
                                                                              tipo : '7', 
                                                                              id_user_recebe : $scope.stalkeada.iduser});
              
                $scope.pushnoti.titulo = "Você foi avaliado";
                $scope.pushnoti.msg = $scope.aux.username + ' te avaliou sobre o evento:' + $scope.evento.nomeevento;
                $scope.pushnoti.token = $scope.stalkeada.devicetoken;
                EventoService.MandaPushNoti($scope.pushnoti);
              }
            }
          });
          $scope.aux = formUser.getForm();
          $state.go('tabsController.eventoFechado');
        })
      });
    }
  }

  $scope.enterItem =  function(){
    formOutro.updateForm($scope.stalkeada);
    $state.go('tabsController.perfil_outro_evento_criados');
  }


}])
   
.controller('avaliaODoEventoCtrl', ['$scope', '$stateParams', '$state', 'formAux', 'formItem', '$http', '$timeout','$ionicPopup', 'formtela', 'formUser', 'formEventoPerfil', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $state, formAux, formItem, $http, $timeout, $ionicPopup, formtela, formUser, formEventoPerfil) {

  $scope.evento = {};
  $scope.infoevento = {};
  $scope.noti = {};
  $scope.presente=true;
  $scope.evento.nota = '5';
  $scope.cars = 0;

    $scope.ratingsObject = {
        iconOn : 'ion-ios-star',
        iconOff : 'ion-ios-star-outline',
        iconOnColor: '#60FFBD',
        iconOffColor:  '#60FFBD',
        rating:  4,
        minRating:1,
        callback: function(rating) {
          $scope.ratingsCallback(rating);
        }
      };
  
      $scope.ratingsCallback = function(rating) {
        console.log('Selected rating is : ', rating);
        $scope.evento.nota = rating;
      };


  $scope.user = formUser.getForm();
  $scope.infoevento = formItem.getForm();
  $scope.noti = formAux.getAux();          /// itens da notificação

  formtela.updateForm(1);

  $scope.$on("$ionicView.enter", function(event, data){
    $scope.evento = {};
    $scope.infoevento = {};
    $scope.evento.nota = '5';

    $scope.tela = formtela.getForm();
    $scope.noti = formAux.getAux();
    $scope.user = formUser.getForm();
    $scope.infoevento = formItem.getForm();
    
    if ($scope.tela==0) {
      formEventoPerfil.updateForm($scope.infoevento);
      $state.go('tabsController.perfil');
    }
  });

  var Areatxt = document.getElementById("Areatxt");

  Areatxt.addEventListener("keyup",function(){
    var characters = Areatxt.value.split('');
    $scope.cars= characters.length+1;
    console.log($scope.cars)
    if(characters.length > 300){
      Areatxt.value = Areatxt.value.substring(0,300);
    }
  });

  $scope.change = function(){
    $scope.presente = !$scope.presente;
  }
  $scope.reportcoment = function(item){
      $ionicPopup.prompt({
                    title: 'Você quer reportar esse evento pq?',
                    template: 'Não me venha reportando só pq tu quer, não me venha dar trabalho!!!!',
                   inputType: 'text',
                   inputPlaceholder: ' Não foi o que era para ter sido'
                 }).then(function(texto) {
        if(texto){
          $scope.reportmsg = item.idavaliacao + ' (idavaliação) '+texto;
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/reportaevento.php', {namereportado : item.nomeevento,
                                                                    reportadoid : item.idevento,
                                                                    iduserreportando : $scope.user.iduser,
                                                                    usernamereportando : $scope.user.username,
                                                                    tiporeport : 'comentario',
                                                                    motivo : $scope.reportmsg}).then(function (tes){
            $scope.response = tes.data;
            var alertPopup = $ionicPopup.alert({
                                      title: 'Obrigado',
                                      template: 'Este evento esta agora sobre investigação'
                                    });
          });
        }
      });
    }

  $scope.pronto = function(){
    console.log($scope.evento.comentario)
    if($scope.evento.comentario == '' || !$scope.evento.comentario){
      var alertPopup = $ionicPopup.alert({
        title: '(๑•̆૩•̆)',
        template: 'Escreva algo!!!!'
      });
    
    }else{
      console.log($scope.presente, $scope.evento.nota);
      $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacao.php', {idnotificacao : $scope.noti.idnotificacao});
      $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/avaliar.php', {idevento : $scope.noti.idevento,
                                                                iduser : $scope.noti.id_user_envia,
                                                                nomeavaliador : $scope.user.username,
                                                                apelidoavaliador : $scope.user.apelido,
                                                                profilepic : $scope.user.profilepic,
                                                                idpessoaavaliada : $scope.noti.idevento,
                                                                nomepessoaavaliada : $scope.noti.nomeevento,
                                                                estado : '0',    //pessoa avaliou
                                                                nota : $scope.evento.nota,
                                                                comentario: $scope.evento.comentario,
                                                                presenca: $scope.presente}).then(function (res){
        var alertPopup = $ionicPopup.alert({
          title: 'Obrigado',
          template: 'Por favor avalie as outras pessoas que compareceram ao evento'
        });
        alertPopup.then(function(){
          formEventoPerfil.updateForm($scope.infoevento);
          $state.go('tabsController.perfil');
        })
      });
    }
  }

}])

.controller('repeteEventoPart1Ctrl', ['$scope', '$stateParams', 'formEvento', '$state','$ionicPopup', '$timeout', '$http', 'formItem', 'EventoService', 'formUser', 'formEventoEditaperfil', 'formEventoPerfil', '$cordovaCamera', '$cordovaFile', '$cordovaFileTransfer', '$cordovaDevice',  '$ionicLoading', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, formEvento, $state, $ionicPopup, $timeout, $http, formItem, EventoService, formUser, formEventoEditaperfil, formEventoPerfil,$cordovaCamera, $cordovaFile, $cordovaFileTransfer, $cordovaDevice,  $ionicLoading) {
  $scope.evento = {};
  $scope.evento = formEventoEditaperfil.getForm();

  $scope.user = formUser.getForm();
   $scope.auxfoto = '';
  var noti = {};
  $scope.pushnoti = {};

  $scope.limiteconfirmacao ={};
  $scope.fim = {};
  $scope.inicio = {};
  var mudoufoto = false;
  var auxdiainicio = $scope.evento.diainicio;

  $scope.evento.dateconfirma = $scope.evento.dialimiteconfirmacao.toLocaleString();
  $scope.evento.dateinicio = $scope.evento.diainicio;
  $scope.evento.datefim = $scope.evento.diafim;
  
  var currentdate = new Date(); 
  var curr_date = (currentdate.getDate()<10?'0':'') + currentdate.getDate();
  var curr_month = (currentdate.getMonth()<9?'0':'') + (currentdate.getMonth() + 1); //Months are zero based
  var curr_year = currentdate.getFullYear();
  var curr_h = (currentdate.getHours()<10?'0':'') + currentdate.getHours();
  var curr_m = (currentdate.getMinutes()<10?'0':'') + currentdate.getMinutes();
  var curr_j = curr_year + "-" + curr_month + "-" + curr_date+ ' '+curr_h + ':' + curr_m + ':' + '00';
  
  EventoService.verificahorariopessoaevento($scope.user).then(function(items) {
    if (items!="Error") {
      $scope.auxdata = items;
    }
  });

   $scope.mudafotoevento = function (optionsCamera) {
    var optionsCamera = {
          quality : 100,
          sourceType : 0,
          allowEdit : true,
          targetWidth: 720,
          targetHeight: 400
    };
    $cordovaCamera.getPicture(optionsCamera).then(function(imageData) {
      $scope.imgURI = imageData;
      mudoufoto = true;
      document.getElementById("imageidEventoRPT").src=imageData;
    }, function(err) {
      console.log(err);
    });
    
  }

  $scope.mudaconfirma = function(){
    novaconfirma_date = ($scope.evento.dateconfirma.getDate()<10?'0':'') + $scope.evento.dateconfirma.getDate();
    novaconfirma_month = ($scope.evento.dateconfirma.getMonth()<9?'0':'') + ($scope.evento.dateconfirma.getMonth() + 1); //Months are zero based
    novaconfirma_year = $scope.evento.dateconfirma.getFullYear();
    novaconfirma_h = ($scope.evento.dateconfirma.getHours()<10?'0':'') + $scope.evento.dateconfirma.getHours();
    novaconfirma_m = ($scope.evento.dateconfirma.getMinutes()<10?'0':'') + $scope.evento.dateconfirma.getMinutes();
    novaconfirma_s = ($scope.evento.dateconfirma.getSeconds()<10?'0':'') + $scope.evento.dateconfirma.getSeconds();
    var novaconfirmaj = novaconfirma_year + "-" + novaconfirma_month + "-" + novaconfirma_date+ ' '+novaconfirma_h + ':' + novaconfirma_m + ':' + novaconfirma_s;
    

    if(curr_j>novaconfirmaj){
      var alertPopup = $ionicPopup.alert({
                  title: '(*ﾉ´□`)ﾉ~',
                  template: 'Muito em cima da hora para mudar pra ontem'
                });
      
    }else{
      if(novaconfirmaj>$scope.evento.diainicio){
        var alertPopup = $ionicPopup.alert({
                  title: 'ヽ ( ꒪д꒪ )ﾉ',
                  template: 'Evento nao pode começar depois da data limite de confirmação'
                });
      }else{
        $scope.limiteconfirmacao.dia =  novaconfirma_date +'/'+ novaconfirma_month;
        $scope.limiteconfirmacao.hora =  novaconfirma_h+':'+novaconfirma_m;  
        $scope.evento.dialimiteconfirmacao = novaconfirmaj;
        $scope.evento.dateconfirma = $scope.evento.dateconfirma.toLocaleString();
      }
    }
  }
  
  $scope.mudainicio = function(){
    var datainvalida = 0;
    
    novadateinicio_date = ($scope.evento.dateinicio.getDate()<10?'0':'') + $scope.evento.dateinicio.getDate();
    novadateinicio_month = ($scope.evento.dateinicio.getMonth()<9?'0':'') + ($scope.evento.dateinicio.getMonth() + 1); //Months are zero based
    novadateinicio_year = $scope.evento.dateinicio.getFullYear();
    novadateinicio_h = ($scope.evento.dateinicio.getHours()<10?'0':'') + $scope.evento.dateinicio.getHours();
    novadateinicio_m = ($scope.evento.dateinicio.getMinutes()<10?'0':'') + $scope.evento.dateinicio.getMinutes();
    novadateinicio_s = ($scope.evento.dateinicio.getSeconds()<10?'0':'') + $scope.evento.dateinicio.getSeconds();
    $scope.evento.semana = $scope.evento.dateinicio.getDay();
    var novadateinicioj = novadateinicio_year + "-" + novadateinicio_month + "-" + novadateinicio_date+ ' '+novadateinicio_h + ':' + novadateinicio_m + ':' + novadateinicio_s;
    
    if(curr_j>novadateinicioj){
      var alertPopup = $ionicPopup.alert({
                  title: '(*ﾉ´□`)ﾉ~',
                  template: 'Muito em cima da hora para mudar pra ontem'
                });
      
    }else{
      if($scope.evento.dialimiteconfirmacao>novadateinicioj){
        var alertPopup = $ionicPopup.alert({
                    title: '(*ﾉ´□`)ﾉ~',
                    template: 'Data de inicio não pode ser antes que a data limite de confirmação'
                  });
        
      }else{
        for(var r = 0;r<$scope.auxdata.length; r++){
          //console.log($scope.auxdata[r].idevento, $scope.auxdata[r].diainicio, $scope.auxdata[r].diafim , we ,$scope.evento.diafim);
          if($scope.evento.idevento!=$scope.auxdata[r].idevento){
            if (($scope.auxdata[r].diainicio <= novadateinicioj && $scope.auxdata[r].diafim >= novadateinicioj)  ) {
              datainvalida = 1;
            }
          }
        }
        if(r==$scope.auxdata.length && datainvalida == 1){
          var alertPopup = $ionicPopup.alert({
            title: 'Oww!!',
            template: 'Tu ja tem um evento marcado nesse horário :/'
          });
        }
        if(novadateinicioj>$scope.evento.datefim){
          console.log("to aquiwenqieni")
          $scope.fim.dia =  '??'+'/'+'??';
          $scope.fim.hora = '??'+':'+'??';
        }
        if(r==$scope.auxdata.length && datainvalida == 0){
          if($scope.evento.semana == 0){
            $scope.evento.semana = "Domingo";
          }
          if($scope.evento.semana == 1){
            $scope.evento.semana = "Segunda-feira";
          }
          if($scope.evento.semana == 2){
            $scope.evento.semana = "Terça-feira";
          }
          if($scope.evento.semana == 3){
            $scope.evento.semana = "Quarta-feira";
          }
          if($scope.evento.semana == 4){
            $scope.evento.semana = "Quinta-feira";
          }
          if($scope.evento.semana == 5){
            $scope.evento.semana = "Sexta-feira";
          }
          if($scope.evento.semana == 6){
            $scope.evento.semana = "Sábado";
          }
          $scope.inicio.dia =  novadateinicio_date +'/'+ novadateinicio_month;
          $scope.inicio.hora =  novadateinicio_h+':'+novadateinicio_m;  
          $scope.evento.diainicio = novadateinicioj;
          $scope.evento.dateinicio = $scope.evento.dateinicio.toLocaleString();
        }
      }
    }
  }

  $scope.mudafim = function(){
    var datainvalida = 0;
    
    novadatefim_date = ($scope.evento.datefim.getDate()<10?'0':'') + $scope.evento.datefim.getDate();
    novadatefim_month = ($scope.evento.datefim.getMonth()<9?'0':'') + ($scope.evento.datefim.getMonth() + 1); //Months are zero based
    novadatefim_year = $scope.evento.datefim.getFullYear();
    novadatefim_h = ($scope.evento.datefim.getHours()<10?'0':'') + $scope.evento.datefim.getHours();
    novadatefim_m = ($scope.evento.datefim.getMinutes()<10?'0':'') + $scope.evento.datefim.getMinutes();
    novadatefim_s = ($scope.evento.datefim.getSeconds()<10?'0':'') + $scope.evento.datefim.getSeconds();
    var novadatedatefimj = novadatefim_year + "-" + novadatefim_month + "-" + novadatefim_date+ ' '+novadatefim_h + ':' + novadatefim_m + ':' + novadatefim_s;
    
    if(curr_j>novadatedatefimj){
      var alertPopup = $ionicPopup.alert({
                  title: '(*ﾉ´□`)ﾉ~',
                  template: 'Muito em cima da hora para mudar pra ontem'
                });
      
    }else{
      if($scope.evento.dialimiteconfirmacao>novadatedatefimj){
        var alertPopup = $ionicPopup.alert({
                    title: '(*ﾉ´□`)ﾉ~',
                    template: 'Data de fim não pode ser antes que a data limite de confirmação'
                  });
        
      }else{
        if($scope.evento.diainicio>=novadatedatefimj){
        var alertPopup = $ionicPopup.alert({
                    title: '(*ﾉ´□`)ﾉ~',
                    template: 'Data de fim não pode ser antes que a data de início'
                  });
        }else{
          for(var r = 0;r<$scope.auxdata.length; r++){
            if($scope.evento.idevento!=$scope.auxdata[r].idevento){
              if (($scope.auxdata[r].diainicio <= novadatedatefimj && $scope.auxdata[r].diafim >= novadatedatefimj)  ) {
                datainvalida = 1;
              }
            }
          }
          if(r==$scope.auxdata.length && datainvalida == 1){
            var alertPopup = $ionicPopup.alert({
              title: 'Oww!!',
              template: 'Tu ja tem um evento marcado nesse horário :/'
            });
          }
          if(r==$scope.auxdata.length && datainvalida == 0){
            $scope.fim.dia =  novadatefim_date +'/'+ novadatefim_month;
            $scope.fim.hora =  novadatefim_h+':'+novadatefim_m;  
            $scope.evento.diafim = novadatedatefimj;
            $scope.evento.datefim = $scope.evento.datefim.toLocaleString();
          }
        }
      }
    }
  }
  
  var hjf = $scope.evento.diafim;
  $scope.fim.dia =  (hjf[8]+hjf[9]).valueOf()+'/'+(hjf[5]+hjf[6]).valueOf();
  $scope.fim.hora = (hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf();
  
  var hj = $scope.evento.diainicio;
  $scope.inicio.dia = (hj[8]+hj[9]).valueOf()+'/'+(hj[5]+hj[6]).valueOf();
  $scope.inicio.hora = (hj[11]+hj[12]).valueOf()+':'+(hj[14]+hj[15]).valueOf();


  var  hjl = $scope.evento.dialimiteconfirmacao;
  $scope.limiteconfirmacao.dia =  (hjl[8]+hjl[9]).valueOf()+'/'+(hjl[5]+hjl[6]).valueOf();
  $scope.limiteconfirmacao.hora =  (hjl[11]+hjl[12]).valueOf()+':'+(hjl[14]+hjl[15]).valueOf();  
  
    $scope.evento.auxtag1 = '';
    $scope.evento.auxtag2 = '';
    $scope.evento.auxtag3 = '';
    $scope.evento.auxtagbutton1 = false;
    $scope.evento.auxtagbutton2 = false;
    $scope.evento.auxtagbutton3 = false;
    $scope.evento.auxtag4 = '';
    $scope.evento.auxtag5 = '';
    $scope.evento.auxtag6 = '';
    $scope.evento.auxtagbutton4 = false;
    $scope.evento.auxtagbutton5 = false;
    $scope.evento.auxtagbutton6 = false;
    $scope.evento.auxtag7 = '';
    $scope.evento.auxtag8 = '';
    $scope.evento.auxtag9 = '';
    $scope.evento.auxtagbutton7 = false;
    $scope.evento.auxtagbutton8 = false;
    $scope.evento.auxtagbutton9 = false;


    $scope.auxtags = {};
    EventoService.Gettags($scope.evento.idevento).then(function(tags) {
      var auxauxtagbut = true;
      $scope.auxtags = tags;
      for(var  i =0; i< tags.length;i++){
         if($scope.evento.auxtagbutton1 == false && auxauxtagbut){
            $scope.evento.auxtag1 = tags[i].tag;
            $scope.evento.auxtagbutton1 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton2 == false && auxauxtagbut){
            console.log($scope.evento.auxtagbutton2)
            $scope.evento.auxtag2 = tags[i].tag;
            $scope.evento.auxtagbutton2 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton3 == false && auxauxtagbut){
            $scope.evento.auxtag3 = tags[i].tag;
            $scope.evento.auxtagbutton3 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton4 == false && auxauxtagbut){
            $scope.evento.auxtag4 = tags[i].tag;
            $scope.evento.auxtagbutton4 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton5 == false && auxauxtagbut){
            $scope.evento.auxtag5 = tags[i].tag;
            $scope.evento.auxtagbutton5 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton6 == false && auxauxtagbut){
            $scope.evento.auxtag6 = tags[i].tag;
            $scope.evento.auxtagbutton6 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton7 == false && auxauxtagbut){
            $scope.evento.auxtag7 = tags[i].tag;
            $scope.evento.auxtagbutton7 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton8 == false && auxauxtagbut){
            $scope.evento.auxtag8 = tags[i].tag;
            $scope.evento.auxtagbutton8 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton9 == false && auxauxtagbut){
            $scope.evento.auxtag9 = tags[i].tag;
            $scope.evento.auxtagbutton9 = true;
            auxauxtagbut = false;
          }
          auxauxtagbut = true;
      } 
    });

    var auxauxtagbut = false;
    $scope.adicionatag = function(){
      if($scope.evento.addtag!=''){
        var res2 = $scope.evento.addtag.split(" ") ;
          if(res2.length>1){
            for(var w = 0; w < res2.length; w++){
              var t = res2[w].toLowerCase();
             console.log(t)
            }
            $scope.evento.addtag = res2[0];
          }
        if(!auxauxtagbut){
          auxauxtagbut = true;
          if($scope.evento.auxtagbutton1 == false && auxauxtagbut){
            $scope.evento.auxtag1 = '#' +$scope.evento.addtag;
            $scope.evento.auxtagbutton1 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton2 == false && auxauxtagbut){
            $scope.evento.auxtag2 = '#' +$scope.evento.addtag;
            $scope.evento.auxtagbutton2 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton3 == false && auxauxtagbut){
            $scope.evento.auxtag3 = '#' +$scope.evento.addtag;
            $scope.evento.auxtagbutton3 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton4 == false && auxauxtagbut){
            $scope.evento.auxtag4 = '#' +$scope.evento.addtag;
            $scope.evento.auxtagbutton4 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton5 == false && auxauxtagbut){
            $scope.evento.auxtag5 = '#' +$scope.evento.addtag;
            $scope.evento.auxtagbutton5 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton6 == false && auxauxtagbut){
            $scope.evento.auxtag6 = '#' +$scope.evento.addtag;
            $scope.evento.auxtagbutton6 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton7 == false && auxauxtagbut){
            $scope.evento.auxtag7 = '#' +$scope.evento.addtag;
            $scope.evento.auxtagbutton7 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton8 == false && auxauxtagbut){
            $scope.evento.auxtag8 = '#' +$scope.evento.addtag;
            $scope.evento.auxtagbutton8 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton9 == false && auxauxtagbut){
            $scope.evento.auxtag9 = '#' +$scope.evento.addtag;
            $scope.evento.auxtagbutton9 = true;
            auxauxtagbut = false;
          }
        }
      }
      $scope.evento.addtag = '';
    }

    $scope.tiratag1 = function(){
        $scope.evento.auxtagbutton1 = false;
        $scope.evento.auxtag1 = '';
    }
    $scope.tiratag2 = function(){
        $scope.evento.auxtagbutton2 = false;
        $scope.evento.auxtag2 = '';
    }
    $scope.tiratag3 = function(){
        $scope.evento.auxtagbutton3 = false;
        $scope.evento.auxtag3 = '';
    }
    $scope.tiratag4 = function(){
        $scope.evento.auxtagbutton4 = false;
        $scope.evento.auxtag4 = '';
    }
    $scope.tiratag5 = function(){
        $scope.evento.auxtagbutton5 = false;
        $scope.evento.auxtag5 = '';
    }
    $scope.tiratag6 = function(){
        $scope.evento.auxtagbutton6 = false;
        $scope.evento.auxtag6 = '';
    }
    $scope.tiratag7 = function(){
        $scope.evento.auxtagbutton7 = false;
        $scope.evento.auxtag7 = '';
    }
    $scope.tiratag8 = function(){
        $scope.evento.auxtagbutton8 = false;
        $scope.evento.auxtag8 = '';
    }
    $scope.tiratag9 = function(){
        $scope.evento.auxtagbutton9 = false;
        $scope.evento.auxtag9 = '';
    }

    $scope.mudaloc = function(){
      formEventoEditahome.updateForm($scope.evento);
      $state.go('tabsController.repeteEventoPart2')
    }

    $scope.mudamais = function(){
      formEventoEditahome.updateForm($scope.evento);
      $state.go('tabsController.repeteEventoPart3')
    }

    $scope.salvar = function(evento){
      if ($scope.evento.nomeevento == '') {
        var alertPopup = $ionicPopup.alert({
          title: 'ʕ•ᴥ•ʔ',
          template: 'Coloque um titulo válido'
        });
      }else{
        if($scope.evento.diafim <$scope.evento.diainicio){
          var alertPopup = $ionicPopup.alert({
            title: 'ʕ•ᴥ•ʔ',
            template: 'Data de termino eh antes do dia de inicio!! Assim não da'
          });
        }else{
          var existe = 0;
          var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/deletatag.php';
          $http.post(link, {idevento : $scope.evento.idevento}).then(function(items) {
            if($scope.evento.auxtagbutton1 == true){
              existe = 0;
              var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criartag.php';
              $http.post(link, {idevento : $scope.evento.idevento, 
                                      tag : $scope.evento.auxtag1});
            }
            if($scope.evento.auxtagbutton2 == true){
              existe = 0;
              var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criartag.php';
              $http.post(link, {idevento : $scope.evento.idevento, 
                                      tag : $scope.evento.auxtag2});
            }
            if($scope.evento.auxtagbutton3 == true){
              existe = 0;
              var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criartag.php';
              $http.post(link, {idevento : $scope.evento.idevento, 
                                      tag : $scope.evento.auxtag3});
            }
            if($scope.evento.auxtagbutton4 == true){
              existe = 0;
              var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criartag.php';
              $http.post(link, {idevento : $scope.evento.idevento, 
                                      tag : $scope.evento.auxtag4});
            }
            if($scope.evento.auxtagbutton5 == true){
              existe = 0;
              var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criartag.php';
              $http.post(link, {idevento : $scope.evento.idevento, 
                                      tag : $scope.evento.auxtag5});
            }
            if($scope.evento.auxtagbutton6 == true){
              existe = 0;
              var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criartag.php';
              $http.post(link, {idevento : $scope.evento.idevento, 
                                      tag : $scope.evento.auxtag6});
            }
            if($scope.evento.auxtagbutton7 == true){
              existe = 0;
              var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criartag.php';
              $http.post(link, {idevento : $scope.evento.idevento, 
                                      tag : $scope.evento.auxtag7});
            }
            if($scope.evento.auxtagbutton8 == true){
              existe = 0;
              var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criartag.php';
              $http.post(link, {idevento : $scope.evento.idevento, 
                                      tag : $scope.evento.auxtag8});
            }
            if($scope.evento.auxtagbutton9 == true){
              existe = 0;
              var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criartag.php';
              $http.post(link, {idevento : $scope.evento.idevento, 
                                      tag : $scope.evento.auxtag9});
            }
          });

          console.log($scope.imgURI)
          if($scope.imgURI != "img/ev.png"){ 
            $scope.auxfoto = $scope.evento.nomeevento + $scope.evento.diainicio;
            var mystring = String($scope.auxfoto);
            mystring = mystring.replace(/[^a-zA-Z0-9]/g, '');
            $scope.evento.eventopic = 'https://s3.amazonaws.com/diwoappprofilepics/eventopicsdiwo/' + mystring + '.jpg';
          }else{
             $scope.evento.eventopic = "img/ev.png";
          }
            if(mudoufoto == true){
              var url = "http://ec2-3-84-65-68.compute-1.amazonaws.com/uploadfotoevento.php";
                                      // File for Upload
              var targetPath = $scope.imgURI;
             
              // File name only
              //var name = $scope.imgURI.substr(imageData.lastIndexOf('/') + 1);
              var filename = mystring + '.jpg';
              // NO CASO SERIA O NOME DO USUARIO.jpg O fileName
              var options = {
                fileKey: "file",
                fileName: filename,
                chunkedMode: false,
                mimeType: "multipart/form-data"
              };
              $cordovaFileTransfer.upload(url, targetPath, options).then(function(result) {
               EventoService.atualizarevento($scope.evento).then(function(msg){
                $ionicLoading.hide();
        var alertPopup = $ionicPopup.alert({
                title: 'ʕ•ᴥ•ʔ',
                template: msg
              });
        alertPopup.then(function(){
          EventoService.GetParticipantes($scope.evento.idevento).then(function(items) {
            $scope.msgnoti = 'O evento: '+$scope.evento.nomeevento +' foi mudado'
            for (var i = 0; i < items.length; i++) {
              if ($scope.user.iduser != items[i].iduser) {
                noti.recebeusername = items[i].username;
                noti.recebe = items[i].iduser;
                noti.envia = $scope.user.iduser;
                noti.tipo = 4;
                noti.nomeevento = $scope.evento.nomeevento;
                EventoService.VerificaNotificacao(noti).then(function(res) {
                  console.log(res);
                  if(res){
                    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : $scope.msgnoti, 
                          idevento : $scope.evento.idevento,
                          nomeevento : $scope.evento.nomeevento,
                          id_user_envia : $scope.user.iduser,
                          username_envia : $scope.user.username,
                          apelido_envia : $scope.user.apelido,
                          tipo : '4',    //update no evento
                          id_user_recebe : noti.recebe}).then(function (res){
                         $scope.response = res.data;
                         console.log($scope.response.msg)
                    });
                    EventoService.getusuario2(noti.recebeusername).then(function(user) {
                      $scope.pushnoti.titulo =  'Mudanças!' ;
                      $scope.pushnoti.msg = $scope.msgnoti;
                      $scope.pushnoti.token = user.devicetoken;
                      EventoService.MandaPushNoti($scope.pushnoti);
                    });
                  }
                });
              }
            }
          })
          formEventoPerfil.updateForm($scope.evento);
          $state.go('tabsController.eventoCriado');
        })
        }, function(errMsg) {
          var alertPopup = $ionicPopup.alert({
            title: 'Register failed!',
            template: errMsg
          });
        })
              }, function(err) {
                $ionicPopup.alert({
                  title: 'Sorry!',
                  template: 'Aconteceu um probleminha, tente de novo'
                });
                $ionicLoading.hide();
              }, function (progress) {
                $ionicLoading.show({
                  title: '┗(＾0＾)┓',
                  template: '┗(＾0＾)┓'
                });
              });
            }
          
       
      }
    }
    }


}])
     
.controller('repeteEventoPart2Ctrl', ['$scope', '$stateParams', '$cordovaGeolocation', '$state', '$ionicLoading', 'formEventoEditaperfil', 'formItem',  // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $cordovaGeolocation, $state, $ionicLoading, formEventoEditaperfil, formItem) {
  $scope.evento = {};
  $scope.evento = formEventoEditaperfil.getForm();
 //$scope.coord = {};
  var lat;
  var long;
  var map;
  var myLatlng;
  var mapOptions;
  var marker;
  var geocoder;
  var infowindow;
  $scope.disableTap = function(){
     container = document.getElementsByClassName('pac-container');
     // disable ionic data tab
     angular.element(container).attr('data-tap-disabled', 'true');
     // leave input field if google-address-entry is selected
     angular.element(container).on("click", function(){
                                   document.getElementById('pac-input').blur();
                                   });
     };
  $scope.$on("$ionicView.enter", function(event, data){
    $scope.evento = {};
    $scope.evento = formEventoEditaperfil.getForm();
    lat  = $scope.evento.lat;
    long = $scope.evento.lng;     
    myLatlng = new google.maps.LatLng(lat, long);
    mapOptions = {
          center: myLatlng,
          zoom: 16,
          mapTypeId: google.maps.MapTypeId.ROADMAP
      };          
             
       map = new google.maps.Map(document.getElementById("map_canvas"), mapOptions); 
       marker = new google.maps.Marker({
                position: new google.maps.LatLng(lat, long),
                map: map,
                title: "Borai",
                draggable: true,
                icon: 'http://maps.google.com/mapfiles/ms/icons/green-dot.png',
                animation: google.maps.Animation.DROP 
            })
       geocoder = new google.maps.Geocoder;
       infowindow = new google.maps.InfoWindow({maxWidth: 200});

      geocoder.geocode({'location': myLatlng}, function(results, status) {
        if (status === 'OK') {
          if (results[1]) {
            $scope.evento.nomelocal = results[0].address_components[0].long_name;
            $scope.evento.endereco = results[0].formatted_address;
            for(var i = 0;i<results[0].address_components.length;i++){
              if(results[0].address_components[i].types[0] == "administrative_area_level_2"){
                $scope.evento.cidade = results[0].address_components[i].long_name;
                console.log($scope.evento.cidade)
              }
            }
            $scope.evento.lat = lat;
            $scope.evento.lng = long;
            infowindow.setContent(results[0].formatted_address);
            // console.log($scope.evento.endereco);
            // console.log($scope.evento.cidade);
            // console.log($scope.evento.lng);
            // console.log($scope.evento.lat);
            infowindow.open(map, marker);
            setTimeout(function () { infowindow.close(); }, 5000);
          } else {
            window.alert('Resultado não encontrado');
          }
        } else {
          window.alert('Ocorreu uma falha doida :' + status);
        }
      });
  });
  
     var posOptions = {
            enableHighAccuracy: true,
            timeout: 200000,
            maximumAge: 0
        };

    navigator.geolocation.getCurrentPosition(function(position){
          
            lat  = $scope.evento.lat;
            long = $scope.evento.lng;
             

            myLatlng = new google.maps.LatLng(lat, long);
             
            mapOptions = {
                center: myLatlng,
                zoom: 16,
                mapTypeId: google.maps.MapTypeId.ROADMAP
            };          
             
            map = new google.maps.Map(document.getElementById("map_canvas"), mapOptions); 


            marker = new google.maps.Marker({
                      position: new google.maps.LatLng(lat, long),
                      map: map,
                      title: "Borai",
                      draggable: true,
                      icon: 'http://maps.google.com/mapfiles/ms/icons/green-dot.png',
                      animation: google.maps.Animation.DROP 
                  })

            geocoder = new google.maps.Geocoder;
            infowindow = new google.maps.InfoWindow({
                                                              maxWidth: 200
                                                            });

            geocoder.geocode({'location': myLatlng}, function(results, status) {
                  if (status === 'OK') {
                    if (results[1]) {
                      $scope.evento.nomelocal = results[0].address_components[0].long_name;
                      $scope.evento.endereco = results[0].formatted_address;
                      for(var i = 0;i<results[0].address_components.length;i++){
                        if(results[0].address_components[i].types[0] == "administrative_area_level_2"){
                          $scope.evento.cidade = results[0].address_components[i].long_name;
                          console.log($scope.evento.cidade)
                        }
                      }
                      $scope.evento.lat = lat;
                      $scope.evento.lng = long;
                      // $scope.evento.lat = position.coords.latitude;
                      // $scope.evento.lng = position.coords.longitude;
                      infowindow.setContent(results[0].formatted_address);
                      console.log($scope.evento.endereco);
                      console.log($scope.evento.cidade);
                      console.log($scope.evento.lng);
                      console.log($scope.evento.lat);
                      //infowindow.setContent(results[0].address_components[2].long_name);
                      infowindow.open(map, marker);
                      setTimeout(function () { infowindow.close(); }, 5000);
                    } else {
                      window.alert('Resultado não encontrado');
                    }
                  } else {
                    window.alert('Ocorreu uma falha doida :' + status);
                  }
                });


            google.maps.event.addListener(marker, "dragstart", function (event) {
               marker.setAnimation(3); // raise
            });

            google.maps.event.addListener(marker, "dragend", function (event) {
               marker.setAnimation(4); // raise
            });

            marker.addListener('dragend', handleEvent);
            google.maps.event.addListener(map, 'click', function(e) {
              
                markers.forEach(function(marker) {
                  marker.setMap(null);
                });
                markers = [];

                placeMarker(e.latLng, map, marker);

            });

            function placeMarker(latlng, map, marker) {
                marker.setPosition(latlng);
                marker.setMap(map);
                map.panTo(latlng);
                $scope.evento.lat = latlng.lat();
                $scope.evento.lng = latlng.lng();
                geocoder.geocode({'location': latlng}, function(results, status) {
                  if (status === 'OK') {
                    if (results[1]) {
                      $scope.evento.nomelocal = results[0].address_components[0].long_name;
                      for(var i = 0;i<results[0].address_components.length;i++){
                        if(results[0].address_components[i].types[0] == "administrative_area_level_2"){
                          $scope.evento.cidade = results[0].address_components[i].long_name;
                          console.log($scope.evento.cidade)
                        }
                      }
                      $scope.evento.endereco = results[0].formatted_address;
                      console.log($scope.evento.endereco);
                      console.log($scope.evento.cidade);
                      console.log($scope.evento.lng);
                      console.log($scope.evento.lat);
                      infowindow.setContent(results[0].formatted_address);
                     
                      infowindow.open(map, marker);
                      setTimeout(function () { infowindow.close(); }, 5000);
                    } else {
                      window.alert('Resultado não encontrado');
                    }
                  } else {
                    window.alert('Ocorreu uma falha doida :' + status);
                  }
                });
            };        

            function handleEvent(event) {
                $scope.evento.lat = event.latLng.lat();
                $scope.evento.lng = event.latLng.lng();

                              // GEOCODER INVERSO

                var geocoder = new google.maps.Geocoder;
                var infowindow = new google.maps.InfoWindow({
                                                              maxWidth: 200
                                                            });;    
            
                geocoder.geocode({'location': event.latLng}, function(results, status) {
                  if (status === 'OK') {
                    if (results[1]) {
                      $scope.evento.nomelocal = results[0].address_components[0].long_name;
                      for(var i = 0;i<results[0].address_components.length;i++){
                        if(results[0].address_components[i].types[0] == "administrative_area_level_2"){
                          $scope.evento.cidade = results[0].address_components[i].long_name;
                          console.log($scope.evento.cidade)
                        }
                      }
                      $scope.evento.endereco = results[0].formatted_address;
                      // console.log($scope.evento.endereco);
                      // console.log($scope.evento.cidade);
                      // console.log($scope.evento.lng);
                      // console.log($scope.evento.lat);
                      infowindow.setContent(results[0].formatted_address);
                     
                      infowindow.open(map, marker);
                      setTimeout(function () { infowindow.close(); }, 5000);
                    } else {
                      window.alert('Resultado não encontrado');
          }
        } else {
          window.alert('Ocorreu uma falha doida :' + status); 
                  }
                });
            }

                              // GEOCODER INVERSO

                

                
            
                    //        SEARCHBOX

            var input = document.getElementById('pac-input');
            var searchBox = new google.maps.places.SearchBox(input);
        //map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);

        // Bias the SearchBox results towards current map's viewport.
            map.addListener('bounds_changed', function() {
                searchBox.setBounds(map.getBounds());
            });

            var markers = [];
        // Listen for the event fired when the user selects a prediction and retrieve
        // more details for that place.
            searchBox.addListener('places_changed', function() {
                var places = searchBox.getPlaces();

                if (places.length == 0) {
                  return;
                }

                // Clear out the old markers.
                markers.forEach(function(marker) {
                  marker.setMap(null);
                });
                markers = [];

                // For each place, get the icon, name and location.
                var bounds = new google.maps.LatLngBounds();
                places.forEach(function(place) {
                  if (!place.geometry) {
                    console.log("Returned place contains no geometry");
                    return;
                  }
                  // var icon = {
                  //   url: place.icon,
                  //   size: new google.maps.Size(71, 71),
                  //   origin: new google.maps.Point(0, 0),
                  //   anchor: new google.maps.Point(17, 34),
                  //   scaledSize: new google.maps.Size(25, 25)
                  // };

                  // Create a marker for each place.
                  markers.push(new google.maps.Marker({
                    map: map,
                    // icon: icon,
                    title: place.name,
                    position: place.geometry.location
                  }));

                  $scope.evento.nomelocal = place.name;
                  $scope.evento.endereco = place.formatted_address;
                  for(var i = 0;i<place.address_components.length;i++){
                    //console.log(place.address_components[i].types[0])
                    if(place.address_components[i].types[0] == "administrative_area_level_2"){
                      $scope.evento.cidade = place.address_components[i].long_name;
                      console.log($scope.evento.cidade)
                    }
                  }
                  $scope.evento.lat = place.geometry.location.lat();
                  $scope.evento.lng = place.geometry.location.lng();

                  // console.log($scope.coord.endereco);
                  // console.log($scope.coord.long);
                  // console.log($scope.coord.lat);

                  if (place.geometry.viewport) {
                    // Only geocodes have viewport.
                    bounds.union(place.geometry.viewport);
                  } else {
                    bounds.extend(place.geometry.location);
                  }
                });
                map.fitBounds(bounds);
            });
            $scope.map = map;  
             
        }, function(err) {
            console.log(err.code);
            console.log(err.message);
        });


        $scope.getCriar = function(evento) {
          formEventoEditaperfil.updateForm($scope.evento);
          $state.go('tabsController.repeteEventoPart1');
        }

}])

.controller('repeteEventoPart3Ctrl', ['$scope', '$stateParams', '$state', 'formEventoEditaperfil', 'formItem', '$ionicPopup','formUser', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $state, formEventoEditaperfil, formItem, $ionicPopup, formUser) {
  $scope.evento = {};
  $scope.evento = formEventoEditaperfil.getForm();
  //$scope.eventorepete = formEvento.getForm().comentario;
  $scope.user = formUser.getForm();
  
  if($scope.user.genero == "fem"){
    $scope.femin = true;
  }else{
    $scope.femin = false;
  }


  if($scope.evento.dificuldade == "Não importa"){
    $scope.evento.dificuldaden = 1;
  }
  if($scope.evento.dificuldade == "Fácil"){
    $scope.evento.dificuldaden = 2;
  }
  if($scope.evento.dificuldade == "Moderado"){
    $scope.evento.dificuldaden = 3;
  }
  if($scope.evento.dificuldade == "Difícil"){
    $scope.evento.dificuldaden = 4;
  }

  $scope.ch = function(){
    if($scope.evento.dificuldaden == 1){
      $scope.evento.dificuldade = "Não importa";
    }
    if($scope.evento.dificuldaden == 2){
      $scope.evento.dificuldade = "Fácil";
    }
    if($scope.evento.dificuldaden == 3){
      $scope.evento.dificuldade = "Moderado";
    }
    if($scope.evento.dificuldaden == 4){
      $scope.evento.dificuldade = "Difícil";
    }
  }

  var header = document.getElementById("barpor");
  var btns = header.getElementsByClassName("btnpor");
  for (var i = 0; i < btns.length; i++) {
    btns[i].addEventListener("click", function() {
      var current = document.getElementsByClassName("actr");
      current[0].className = current[0].className.replace(" actr", "");
      this.className += " actr";
    });
  }
  // $scope.evento.auxpmax = $scope.evento.pmax;
  // $scope.mudamax = function() {
  //   if (!$scope.evento.pmax) {
  //     var alertPopup = $ionicPopup.alert({
  //     title: 'Register failed!',
  //     template: 'Favor preencher todos os campos'
  //   });
  //   }else{    
  //     if (parseInt($scope.evento.pmax) < parseInt($scope.evento.pmin)) {
  //       var alertPopup = $ionicPopup.alert({
  //               title: 'Matematimatematica',
  //               template: 'Máximo de pessoas nao pode ser maior que mínino xD'
  //             });
  //     }else{
  //       if (parseInt($scope.evento.pmax) >= 50) {
  //         var alertPopup = $ionicPopup.alert({
  //                 title: 'Muuuuita gente',
  //                 template: 'Limite máximo de pessoas para um evento é 50 personas'
  //               });
  //       }else{
  //         $scope.evento.pmax = $scope.evento.auxpmax;
  //       }
  //     }
  //   }
  // };
  // $scope.evento.auxpmin = $scope.evento.pmin;
  // $scope.mudamin = function() {
  //   if (!$scope.evento.pmin) {
  //     var alertPopup = $ionicPopup.alert({
  //     title: 'Register failed!',
  //     template: 'Favor preencher todos os campos'
  //   });
  //   }else{    
  //     if (parseInt($scope.evento.pmin)<=1) {
  //       var alertPopup = $ionicPopup.alert({
  //               title: '=/',
  //               template: 'Não da pra fazer um evento só com você né'
  //             });
  //     }else{
  //       $scope.evento.pmin = $scope.evento.auxpmin;
  //     }
  //   }
  // };

  $scope.pessoa = function() {$scope.evento.precopor = 1;};
  $scope.hora = function() {$scope.evento.precopor = 2;};

  $scope.getCriar = function(evento) {
  var palavrasnaousar = ["ALIAMBA", "ANUS", "BAGULIO"
      , "BANZA", "BARRUFO", "BECK", "BEQUE", "BOCETA"
      , "BOLAGATO", "BOQUETE", "BOLCAT", "BOSSETA", "BOSTANA", "BREXA", "BRIOCO", "BRONHA", "BUCA", "BUCETA"
      , "BUSSETA", "CANABIS", "CANNABIS", "CARALHO"
      , "CASSETA", "CASSETE", "CHECHECA", "CHERECA", "CHIBUMBA", "CHIBUMBO", "CHOTA", "CHOCHOTA", "CHUPADA", "CHUPADO", "CLITORIS"
      , "COCAINA", "C+"
      , "C*", "CURALHO", "CUZAO", "CUZUDA", "CUZUDO", "CUZÃO", "ESPORRADA", "ESPORRADO", "ESPORRO", "estupro"
      , "FELACAO", "FELACÃO", "FODA", "FODAO", "FODÃO", "FODAUM", "FODE", "FODIDA", "FODIDO", "FORNICA", "FUDENDO", "FUDECÃO", "FUDECAO"
      , "FUDIDA", "FUDIDO", "GRELINHO", "GRELO", "ISCROTA", "ISCROTO", "MACONHA", "MASTURBA", "MASTURBAÇÃO", "MASTURBACÃO", "MASTURBACAO"
      , "PENIS", "PEN1S", "PENES", "PENIZ", "PICA", "PIROCA", "PIRU", "PORRA", "POURRA", "PROSTIBULO", "PUTA", "PUNHETA", "PUTO"
      , "RABAO", "TESTUDA", "TESTUDO", "VAGABUNDA", "VAGINA", "VIADO", "VIADAO", "VIADÃO", "XAVASCA", "XERERECA", "XEXECA", "XOTA"
      , "XOCHOTA", "XOXOTA", "XANA", "XANINHA", "MDMA", "VSF", "TNC", "FDP", "CRACK"];
      var error = 0; 
      for (var i = 0; i < palavrasnaousar.length; i++) {
        var res2 = $scope.evento.descricao.split("_") ;
        if(res2.length>1){
          for(var w = 0; w < res2.length; w++){
            var val = palavrasnaousar[i].toLowerCase();
            if ((res2[w].toLowerCase()).indexOf(val.toString()) > -1) {  
              error = error + 1;  
            }
          }
        }else{
          var val = palavrasnaousar[i].toLowerCase();  
          if (($scope.evento.descricao.toLowerCase()).indexOf(val.toString()) > -1) {  
            error = error + 1;  
          }
        }
        var res3 = $scope.evento.descricao.split(" ") ;
        if(res3.length>1){
          for(var w = 0; w < res3.length; w++){
            var val = palavrasnaousar[i].toLowerCase();
            if ((res3[w].toLowerCase()).indexOf(val.toString()) > -1) {  
              error = error + 1;  
            }
          }
        }else{
          var val = palavrasnaousar[i].toLowerCase();  
          if (($scope.evento.descricao.toLowerCase()).indexOf(val.toString()) > -1) {  
            error = error + 1;  
          }
        }   
      } 
      if (error > 0) {  
          var alertPopup = $ionicPopup.alert({
                title: '（・о・；）',
                template: 'Que boquinha suja eim, usaste uma palavra inapropriada né'
              }); 
      }else{
        if (!$scope.evento.pmax || !$scope.evento.pmin) {
                    var alertPopup = $ionicPopup.alert({
                    title: 'Register failed!',
                    template: 'Favor preencher todos os campos'
                  });

        }else{
          if (parseInt($scope.evento.pmin)<=1) {
            var alertPopup = $ionicPopup.alert({
                    title: '=/',
                    template: 'Não da pra fazer um evento só com você né'
                  });
          }else{
            if (parseInt($scope.evento.pmax) <= parseInt($scope.evento.pmin)) {
              var alertPopup = $ionicPopup.alert({
                      title: 'Matematimatematica',
                      template: 'Mínimo de pessoas nao pode ser maior que máximo xD'
                    });
            }else{
              if (parseInt($scope.evento.pmax) >= 50) {
                var alertPopup = $ionicPopup.alert({
                        title: 'Muuuuita gente',
                        template: 'Limite máximo de pessoas para um evento é 50 personas'
                      });
              }else{
        if(evento.descricao){
          formEventoEditaperfil.updateForm($scope.evento);
          $state.go('tabsController.repeteEventoPart1');
        }else{
          var alertPopup = $ionicPopup.alert({
                title: '( ꒪Д꒪)ノ',
                template: 'Escreva algo na descrição do evento para ajudar as pessoas a entenderem o que será feito'
              }); 
        }   
              }
            }
          }
        }
        
      }
  }

}])
   
.controller('repeteEventoPart4Ctrl', ['$scope', '$stateParams', '$state', 'formEvento', 'formUser','$ionicPopup', '$http', 'formtela2','formEditar', 'EventoService', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $state, formEvento, formUser, $ionicPopup, $http, formtela2, formEditar, EventoService) {
 $scope.evento = formEvento.getForm();
 $scope.telaeditar = formEditar.getForm();

 $scope.confirmacao = 'aprovado';
  $scope.estado = '0';
  $scope.auxtela = formtela2.getForm();
  var res2 = [];
  var noti = {};
  console.log($scope.auxtela);
  EventoService.Gettags($scope.evento.idevento).then(function(tags) {
    for(var  i =0; i< tags.length;i++){
         res2[i] =  tags[i].tag;
        } 
  });
  $scope.mudanome = false;
  $scope.pushnoti = {};
   $scope.user = formUser.getForm(); /// mudar aqui o Formuser
    //console.log($scope.user.iduser);
  $scope.$on("$ionicView.enter", function(event, data){
    $scope.evento = {};
    $scope.evento = formEvento.getForm();
    $scope.telaeditar = 1;
    $scope.pushnoti = {};
    $scope.confirmacao = 'aprovado';
    $scope.estado = '0';
    $scope.auxtela = formtela2.getForm();
    var res2 = [];
    var noti = {};
    console.log($scope.auxtela);
    EventoService.Gettags($scope.evento.idevento).then(function(tags) {
      for(var  i =0; i< tags.length;i++){
           res2[i] =  tags[i].tag;
          } 
    });
    $scope.mudanome = false;
    $scope.user = formUser.getForm();
    if ($scope.telaeditar == 1) {
      $scope.mudanome = true;
     }
    $scope.auxtela = formtela2.getForm();
    if ($scope.auxtela == 1) {
      $state.go('tabsController.EditaEEAPart1');
    }
  });
  
  $scope.getCriar = function(evento) {
      if (!$scope.evento.pmax || !$scope.evento.pmin) {
                    var alertPopup = $ionicPopup.alert({
                    title: 'Register failed!',
                    template: 'Favor preencher todos os campos'
                  });

         }else{
          if (parseInt($scope.evento.pmin)<=1) {
            var alertPopup = $ionicPopup.alert({
                    title: '=/',
                    template: 'Não da pra fazer um evento só com você né'
                  });
          }else{
            if (parseInt($scope.evento.pmax) < parseInt($scope.evento.pmin)) {
              var alertPopup = $ionicPopup.alert({
                      title: 'Matematimatematica',
                      template: 'Mínimo de pessoas nao pode ser maior que máximo xD'
                    });
            }else{
          if (parseInt($scope.evento.pmax) >= 50) {
                var alertPopup = $ionicPopup.alert({
                        title: 'Muuuuita gente',
                        template: 'Limite máximo de pessoas para um evento é 50 personas'
                      });
              }else{
            if ($scope.telaeditar == 1) {
              console.log('oi');
             EventoService.atualizarevento($scope.evento).then(function(msg){
             var alertPopup = $ionicPopup.alert({
                      title: 'ʕ•ᴥ•ʔ',
                      template: msg
                    });
                       alertPopup.then(function(){
                        EventoService.GetParticipantes($scope.evento.idevento).then(function(items) {
                        $scope.msgnoti = 'O evento: '+$scope.evento.nomeevento +' foi mudado'
                           for (var i = 0; i < items.length; i++) {
                            if ($scope.user.iduser != items[i].iduser) {
                                  noti.recebeusername = items[i].username;
                                  noti.recebe = items[i].iduser;
                                  noti.envia = $scope.user.iduser;
                                  noti.tipo = 4;
                                  noti.nomeevento = $scope.evento.nomeevento;
                                  EventoService.VerificaNotificacao(noti).then(function(res) {
                                    console.log(res);
                                    if(res){
                                      $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : $scope.msgnoti, 
                                            idevento : $scope.evento.idevento,
                                            nomeevento : $scope.evento.nomeevento,
                                            id_user_envia : $scope.user.iduser,
                                            username_envia : $scope.user.username,
                                            apelido_envia : $scope.aux.apelido,
                                            tipo : '4',    //update no evento
                                            id_user_recebe : noti.recebe}).then(function (res){
                                           $scope.response = res.data;
                                           console.log($scope.response.msg)
                                         });
                                      EventoService.getusuario2(noti.recebeusername).then(function(user) {
                                        $scope.pushnoti.titulo =  'Mudanças!' ;
                                        $scope.pushnoti.msg = $scope.msgnoti;
                                        $scope.pushnoti.token = user.devicetoken;
                                         EventoService.MandaPushNoti($scope.pushnoti);
                                      } );
                                    }
                                  });
                                }
                          }
                         })
                             $state.go('tabsController.perfil');
                        })
                  }, function(errMsg) {
                    var alertPopup = $ionicPopup.alert({
                      title: 'Register failed!',
                      template: errMsg
                    });
                  })
                            /// AQUI TEMOS QUE COMPARAR SE HOUVE INCLUSAO DE UMA TAG NOVA
                  if( $scope.evento.tags!=''){
                    console.log("com tag adicionada");
                    var res = $scope.evento.tags.split(" ") ;
                    var array3 = res.filter(function(obj) { return res2.indexOf(obj) == -1; });
                    for (var i = 0; i<array3.length;i++){
                      if(array3[i][0]!='#'){
                        array3[i]= '#' + array3[i];
                      }
                      var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criartag.php';
                        $http.post(link, {idevento : $scope.evento.idevento, 
                                          tag : array3[i]});
                      }
                  }
                  
            }else{
                $ionicPopup.prompt({
                    title: 'Qual nome devo dar?',
                    template: 'Não vamos esquecer de dar nomes aos bois',
                   inputType: 'text',
                   inputPlaceholder: ' Nome legal'
                 }).then(function(nomeevento) {
                  $scope.evento.nomeevento = nomeevento;
                    console.log('Nome do evento é', nomeevento);
                 
           if (nomeevento && nomeevento !='' && nomeevento !=' ') {
            console.log($scope.evento.dialimiteconfirmacao)
            var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criarevento.php';
            $http.post(link, {nomeevento : $scope.evento.nomeevento, 
                          duracao : $scope.evento.duracao,
                          diainicio : $scope.evento.diainicio,
                          semana : $scope.evento.semana,
                          diafim : $scope.evento.diafim,
                          dialimiteconfirmacao: $scope.evento.dialimiteconfirmacao,
                          pmin : $scope.evento.pmin, 
                          pmax : $scope.evento.pmax,
                          patual : 1, 
                          adm : $scope.user.iduser,
                          admusername : $scope.user.username,
                          admapelido : $scope.user.apelido,
                          preco : $scope.evento.preco,
                          precopor : $scope.evento.precopor, 
                          nomelocal : $scope.evento.nomelocal,
                          endereco : $scope.evento.endereco,
                          estado : '0',
                          cidade : $scope.evento.cidade,
                          lat : $scope.evento.lat,
                          lng : $scope.evento.lng,
                          dificuldade :$scope.evento.dificuldade,
                          genero : $scope.evento.genero,
                          descricao : $scope.evento.descricao}).then(function (res){
            $scope.responsecriado = res.data;
            

            if ($scope.responsecriado.success == true) {
                // console.log($scope.responsecriado.last);
                // console.log($scope.user.iduser);
                // console.log($scope.evento.nomeevento);
                // console.log($scope.confirmacao);
                // console.log($scope.evento.estado);
                if( $scope.evento.tags!=''){
                  console.log("com tag adicionada");
                  var res = $scope.evento.tags.split(" ") ;
                  var array3 = res.filter(function(obj) { return res2.indexOf(obj) == -1; });
                  for (var i = 0; i<array3.length;i++){
                    var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criartag.php';
                    $http.post(link, {idevento : $scope.responsecriado.last, 
                                      tag : array3[i]});
                   }
                 }

              var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/irevento.php';
                  $http.post(link, {idevento : $scope.responsecriado.last, 
                                    iduser : $scope.user.iduser,
                                    idadm : $scope.user.iduser, 
                                    admusername : $scope.user.username,
                                    borda : $scope.user.borda,
                                    username : $scope.user.username,
                                    apelido : $scope.user.apelido,
                                    borda : $scope.user.borda,
                                    profilepic : $scope.user.profilepic,
                                    devicetoken : $scope.user.devicetoken,
                                    diainicio : $scope.evento.diainicio,
                                    confirmacao : $scope.confirmacao,
                                    nomeevento :  $scope.evento.nomeevento,
                                    //eventopic : $scope.evento.eventopic, 
                                    estado : $scope.estado}).then(function (res){
                  $scope.response = res.data;
                  console.log($scope.response);
                    if ($scope.response.success == true) {
                        var alertPopup = $ionicPopup.alert({
                      title: 'Parabéns',
                      template: $scope.responsecriado.msg
                    }); 
                        alertPopup.then(function(){
                        formtela2.updateForm(1);
                        $scope.evento = {};
                        formEvento.updateForm($scope.evento);
                         $state.go('tabsController.home');
                       })
                      }else{
                        var alertPopup = $ionicPopup.alert({
                      title: 'Ocorreu uma falha',
                      template: $scope.responsecriado.msg
                    });
                        alertPopup.then(function(){
                        $state.go('tabsController.home');
                       })
                      }
                    })
                  }
            });

           }else{console.log('dasd');}
        });
            }
  }
         
          }}

         }
  }

}])

.controller('EditaEventoPart1Ctrl', ['$scope', '$stateParams', 'formEvento', '$state','$ionicPopup', '$timeout', 'formtela2', 'formItem', 'EventoService', 'formUser', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, formEvento, $state, $ionicPopup, $timeout, formtela2, formItem, EventoService, formUser) {
  $scope.evento = {};
  $scope.evento = formItem.getForm();
  $scope.user = formUser.getForm();
   $scope.auxfoto = '';
  $scope.auxdata = {};
  $scope.evento.date = $scope.evento.diainicio;
  $scope.evento.tags = '';
  $scope.evento.tagsvelhos = '';
  var auxh;
  var h2;
  var auxdiainicio
  EventoService.Gettags($scope.evento.idevento).then(function(tags) {
        for(var  i =0; i< tags.length;i++){
          if(i == 0){
            $scope.evento.tagsvelhos = tags[i].tag;
          }else{
            $scope.evento.tagsvelhos = ($scope.evento.tagsvelhos + ' ' + tags[i].tag);
          } 
        } 
      });
  var currentdate = new Date(); 
  var curr_date2 = (currentdate.getDate()<10?'0':'') + currentdate.getDate();
  var curr_month2 = (currentdate.getMonth()<9?'0':'') + (currentdate.getMonth() + 1); //Months are zero based
  var curr_year2 = currentdate.getFullYear();
  var h22 = (currentdate.getHours()<10?'0':'') + currentdate.getHours();
  var m22 = (currentdate.getMinutes()<10?'0':'') + currentdate.getMinutes();

  var curr_date = ($scope.evento.diainicio[8]+$scope.evento.diainicio[9]).valueOf();
  h2 = ($scope.evento.diainicio[11]+$scope.evento.diainicio[12]).valueOf();
  var m2 = ($scope.evento.diainicio[14]+$scope.evento.diainicio[15]).valueOf();
  var curr_month = ($scope.evento.diainicio[5]+$scope.evento.diainicio[6]).valueOf();
  var s2 = ($scope.evento.diainicio[17]+$scope.evento.diainicio[18]).valueOf();
  var curr_year = ($scope.evento.diainicio[0]+$scope.evento.diainicio[1]+$scope.evento.diainicio[2]+$scope.evento.diainicio[3]).valueOf();
  var datainvalida = 0;
  var h = ($scope.evento.duracao[0]+$scope.evento.duracao[1]).valueOf();
  var m  = ($scope.evento.duracao[3]+$scope.evento.duracao[4]).valueOf(); 
  var ano = curr_year-curr_year2;
  var mes = curr_month-curr_month2;
  var dia = curr_date-curr_date2;
  var he = h2-h22;             
  var me = m2-m22;

  var header = document.getElementById("barpor");
  var btns = header.getElementsByClassName("btnpor");
  for (var i = 0; i < btns.length; i++) {
    btns[i].addEventListener("click", function() {
      var current = document.getElementsByClassName("actr");
      current[0].className = current[0].className.replace(" actr", "");
      this.className += " actr";
    });
  }
  $scope.pessoa = function() {$scope.evento.precopor = 1;};
  $scope.hora = function() {$scope.evento.precopor = 2;};

  $scope.duvida = function() {var alertPopup = $ionicPopup.alert({
                      title: 'Para ver se vai rolar ou não',
                      template: 'Uma vez que chega na data limite de confirmação, caso o evento não atinja o número mínimo de pessoas, o evento será cancelado automaticamente.'
                    });};
  $scope.duvida2 = function() {var alertPopup = $ionicPopup.alert({
                      title: 'Cobrar como?',
                      template: 'Em alguns casos como quadras é cobrado por hora e em outros é cobrado por pessoa, então é melhor deixar avisado certinho né.'
                    });};
  $scope.duvida3= function() {var alertPopup = $ionicPopup.alert({
                      title: 'Respeito ao gênero',
                      template: 'O evento não aparecerá para pessoas que não forem do gênero selecionado'
                    });};
   $scope.duvida4= function() {var alertPopup = $ionicPopup.alert({
                      title: 'Pra que serve essas hashtags?',
                      template: 'Fica mais fácil para outras pessoas acharem seu evento pelas tags.'
                    });};
  $scope.user = formUser.getForm();
  if($scope.user.genero == "fem"){
    $scope.femin = true;
  }else{
    $scope.femin = false;
  }
  $scope.$on("$ionicView.enter", function(event, data){
    formtela2.updateForm(0);
    $scope.evento = {};
    $scope.evento = formItem.getForm();
    $scope.evento.tags = '';
    $scope.evento.tagsvelhos = '';
    $scope.evento.date = $scope.evento.diainicio;
    auxdiainicio = $scope.evento.diainicio;
    h2 = ($scope.evento.diainicio[11]+$scope.evento.diainicio[12]).valueOf();
    auxh = ($scope.evento.dialimiteconfirmacao[11]+$scope.evento.dialimiteconfirmacao[12]).valueOf();
    if(0>=(h2 - auxh)){
      $scope.evento.redzone = (h2 - auxh +24).toString();
    }else{
      $scope.evento.redzone = (h2 - auxh).toString();
    }
    console.log($scope.evento.redzone, auxh , h2)
    EventoService.Gettags($scope.evento.idevento).then(function(tags) {
        for(var  i =0; i< tags.length;i++){
          if(i == 0){
            $scope.evento.tagsvelhos = tags[i].tag;
          }else{
            $scope.evento.tagsvelhos = ($scope.evento.tagsvelhos + ' ' + tags[i].tag);
          } 
        } 
      });
    EventoService.verificahorariopessoaevento($scope.user).then(function(items) {
      $scope.auxdata = items;
    });
     currentdate = new Date(); 
     curr_date2 = (currentdate.getDate()<10?'0':'') + currentdate.getDate();
     curr_month2 = (currentdate.getMonth()<9?'0':'') + (currentdate.getMonth() + 1); //Months are zero based
     curr_year2 = currentdate.getFullYear();
     h22 = (currentdate.getHours()<10?'0':'') + currentdate.getHours();
     m22 = (currentdate.getMinutes()<10?'0':'') + currentdate.getMinutes();

     curr_date = ($scope.evento.diainicio[8]+$scope.evento.diainicio[9]).valueOf();
     h2 = ($scope.evento.diainicio[11]+$scope.evento.diainicio[12]).valueOf();
     m2 = ($scope.evento.diainicio[14]+$scope.evento.diainicio[15]).valueOf();
     curr_month = ($scope.evento.diainicio[5]+$scope.evento.diainicio[6]).valueOf();
     s2 = ($scope.evento.diainicio[17]+$scope.evento.diainicio[18]).valueOf();
     curr_year = ($scope.evento.diainicio[0]+$scope.evento.diainicio[1]+$scope.evento.diainicio[2]+$scope.evento.diainicio[3]).valueOf();
     datainvalida = 0;
     h = ($scope.evento.duracao[0]+$scope.evento.duracao[1]).valueOf();
     m  = ($scope.evento.duracao[3]+$scope.evento.duracao[4]).valueOf();
     ano = curr_year-curr_year2;
      mes = curr_month-curr_month2;
      dia = curr_date-curr_date2;
      he = h2-h22;             
      me = m2-m22;
     auxh = ($scope.evento.dialimiteconfirmacao[11]+$scope.evento.dialimiteconfirmacao[12]).valueOf();
    if(0>=(h2 - auxh)){
      $scope.evento.redzone = (h2 - auxh +24).toString();
    }else{
      $scope.evento.redzone = (h2 - auxh).toString();
    } 

    if($scope.evento.dificuldade == "Não importa"){
      $scope.evento.dificuldaden = 1;
    }
    if($scope.evento.dificuldade == "Fácil"){
      $scope.evento.dificuldaden = 2;
    }
    if($scope.evento.dificuldade == "Moderado"){
      $scope.evento.dificuldaden = 3;
    }
    if($scope.evento.dificuldade == "Difícil"){
      $scope.evento.dificuldaden = 4;
    }
    
  });

  
  console.log(curr_date);

  auxh = ($scope.evento.dialimiteconfirmacao[11]+$scope.evento.dialimiteconfirmacao[12]).valueOf();

  
  if(0>=(h2 - auxh)){
    $scope.evento.redzone = (h2 - auxh +24).toString();
  }else{
    $scope.evento.redzone = (h2 - auxh).toString();
  }
  console.log($scope.evento.redzone, auxh , h2)

  var curr_date4;
  var curr_date5;
  var h4
  var m4 
  var curr_month4;
  var curr_month5;
  var s4
  var curr_year4
  var curr_year5;
  var i;

  $scope.ch = function(){
    if($scope.evento.dificuldaden == 1){
      $scope.evento.dificuldade = "Não importa";
    }
    if($scope.evento.dificuldaden == 2){
      $scope.evento.dificuldade = "Fácil";
    }
    if($scope.evento.dificuldaden == 3){
      $scope.evento.dificuldade = "Moderado";
    }
    if($scope.evento.dificuldaden == 4){
      $scope.evento.dificuldade = "Difícil";
    }
  }

  $scope.muda = function(){
    curr_date = ($scope.evento.date.getDate()<10?'0':'') + $scope.evento.date.getDate();
    curr_month = ($scope.evento.date.getMonth()<9?'0':'') + ($scope.evento.date.getMonth() + 1); //Months are zero based
    curr_year = $scope.evento.date.getFullYear();
    h2 = ($scope.evento.date.getHours()<10?'0':'') + $scope.evento.date.getHours();
    m2 = ($scope.evento.date.getMinutes()<10?'0':'') + $scope.evento.date.getMinutes();
    s2 = ($scope.evento.date.getSeconds()<10?'0':'') + $scope.evento.date.getSeconds();
    $scope.evento.semana = $scope.evento.date.getDay();
    var j = curr_year + "-" + curr_month + "-" + curr_date+ ' '+h2 + ':' + m2 + ':' + s2;
            //$scope.evento.date = $scope.evento.date.toLocaleString();
    $scope.evento.diainicio = j;

    datainvalida = 0;
    ano = curr_year-curr_year2;
    mes = curr_month-curr_month2;
    dia = curr_date-curr_date2;
    he = h2-h22;             
    me = m2-m22;

    if(ano<0){
     var alertPopup = $ionicPopup.alert({
        title: 'Falha na data!!',
        template: 'Coloque uma data valida s`il vous plait'
      });
      console.log('data invalida');
    }else{
      if (ano == 0) {
        if(mes<0){
          var alertPopup = $ionicPopup.alert({
            title: 'Falha na data!!',
            template: 'Coloque uma data valida s`il vous plait'
          });
          console.log('data invalida');
        }else{
          if (mes==0) {
            if(dia<0){
              var alertPopup = $ionicPopup.alert({
                title: 'Falha na data!!',
                template: 'Coloque uma data valida s`il vous plait'
              });
              console.log('data invalida');
            }else{
              if((dia==1 && j<auxdiainicio && he <=0)||(dia==0 && j<auxdiainicio)){
                var alertPopup = $ionicPopup.alert({
                  title: '(*ﾉ´□`)ﾉ~',
                  template: 'Muito em cima da hora para mudar a data do evento para mais cedo!!'
                });
                $scope.evento.diainicio = auxdiainicio;
                console.log('data invalida');
              }
              if (dia==0 && he<3){
              var alertPopup = $ionicPopup.alert({
                title: 'ヽ ( ꒪д꒪ )ﾉ',
                template: 'Muito em cima da hora para mudar um evento, no mínimo umas 3 horas de antecedência'
              });
              console.log('data invalida');
              }else{
                $scope.evento.date = $scope.evento.date.toLocaleString();
              }
            }
          }
        }
      }
    }
  }


  $scope.red = function(){
    if(ano==0 && mes == 0 && (dia == 0 && $scope.evento.redzone >= h) || (dia == 1 && $scope.evento.redzone >= h+24)){
      console.log($scope.evento.redzone)
      var alertPopup = $ionicPopup.alert({
        title: 'ლ(ﾟдﾟლ)',
        template: 'A hora limite para confirmação ja passou de agora, ninguem vai conseguir confirmar ida. Selecione um horario válido'
      });
      $scope.evento.redzone = "1";
    }
  }

  $scope.muda2 = function(){
    h = ($scope.evento.duracao.getHours()<10?'0':'') + $scope.evento.duracao.getHours();
    m = ($scope.evento.duracao.getMinutes()<10?'0':'') + $scope.evento.duracao.getMinutes();
    i = h + ':' + m;
    $scope.evento.duracao = i;
  }

  $scope.getCriar = function(evento) {
    
      var res = $scope.evento.tags.split(/[ #]+/) ;
      $scope.test = formtela2.getForm();
      if (!$scope.evento.preco) {$scope.preco=0}
      if (!$scope.evento.duracao || !$scope.evento.date ) {
        var alertPopup = $ionicPopup.alert({
          title: 'Falha no engano!!',
          template: 'Preciso saber a data e ou duração do evento'
        });
      }else{
        i = h + ':' + m;
        $scope.evento.duracao = i;
        console.log($scope.evento.duracao)
              var h3 = parseFloat(h2)+parseFloat(h);
              var m3 = parseFloat(m2) +parseFloat(m);

              var diafimeventodate; 
              var diafimeventomonth;
              var diafimeventoyear;
              var fimfim;
              $scope.evento.duracao = i;
              var horapositiva = parseFloat(h)-parseFloat(h2);
              var minutopositiva = parseFloat(m)-parseFloat(m2);
              if(horapositiva<0){
                var diafimevento = new Date();
                diafimevento.setDate(diainiciodoevento.getDate() + 1);
                diafimeventodate = (diafimevento.getDate()<10?'0':'') + diafimevento.getDate();
                diafimeventomonth = (diafimevento.getMonth()<10?'0':'') + (diafimevento.getMonth() + 1); //Months are zero based
                diafimeventoyear = diafimevento.getFullYear();
                fimfim = diafimeventoyear + "-" + diafimeventomonth + "-" + diafimeventodate+ ' '+h + ':' + m;
                $scope.evento.diafim = fimfim;
              }else{
                if(horapositiva == 0 && minutopositiva<0 ){
                  var diafimevento = new Date();
                  diafimevento.setDate(diainiciodoevento.getDate() + 1);
                  diafimeventodate = (diafimevento.getDate()<10?'0':'') + diafimevento.getDate();
                  diafimeventomonth = (diafimevento.getMonth()<10?'0':'') + (diafimevento.getMonth() + 1); //Months are zero based
                  diafimeventoyear = diafimevento.getFullYear();
                  fimfim = diafimeventoyear + "-" + diafimeventomonth + "-" + diafimeventodate+ ' '+h + ':' + m;
                  $scope.evento.diafim = fimfim;
                }else{
                  $scope.evento.diafim = curr_year + "-" + curr_month + "-" + curr_date+ ' '+h + ':' + m;
                }
              }
              var we = curr_year + "-" + curr_month + "-" + curr_date+ ' '+h2 + ':' + m2 + ':' + s2;
              // var we = curr_year + "-" + curr_month + "-" + curr_date+ ' '+h2 + ':' + m2 + ':' + s2;
              // if(m3>59){
              //   m3 = m3.valueOf()-60;
              //   h3 = h3.valueOf()+1;
              // }
              // curr_year4 = curr_year;
              // curr_month4 = curr_month;
              // curr_date4 = curr_date;
              // if(h3.valueOf()>23){
              //   h3 = h3.valueOf()-24;
              //   curr_date4 = parseFloat(curr_date)+1;
              //     if(curr_date4<1){
              //       curr_month4 = parseFloat(curr_month)-1;
              //       if(curr_month4==1||curr_month4==3||curr_month4==5||curr_month4==7||curr_month4==8||curr_month4==10||curr_month4==12){
              //         curr_date4 = curr_date4.valueOf()+31;
              //       }
              //       if(curr_month4==4||curr_month4==6||curr_month4==9||curr_month4==11){
              //         curr_date4 = curr_date4.valueOf()+30;
              //       }
              //       if(curr_month4==2){
              //         curr_date4 = curr_date4.valueOf()+28;
              //       }
              //       if(curr_month4<1){
              //         curr_year4 = parseFloat(curr_year)-1;
              //       }
              //     }
              // }

              // h3 = (h3<10?'0':'')+h3;
              // m3 = (m3<10?'0':'')+m3;
              // curr_date4 = (curr_date4<10?'0':'')+curr_date4;
              // $scope.evento.diafim = curr_year4 + "-" + curr_month4 + "-" + curr_date4+ ' '+h3 + ':' + m3 + ':' + s2;
              //console.log(h2 ,$scope.evento.redzone );

            curr_year5 = curr_year;
            curr_date5 = curr_date;
            curr_month5 = curr_month;
            h4 = parseFloat(h2)-parseFloat($scope.evento.redzone);
            //console.log(h4)
            if(h4<0){
              h4 = h4.valueOf()+24;
              curr_date5 = parseFloat(curr_date)-1;
              if(curr_date5<1){
                curr_month5 = parseFloat(curr_month)-1;
                if(curr_month5==1||curr_month5==3||curr_month5==5||curr_month5==7||curr_month5==8||curr_month5==10||curr_month5==12){
                  curr_date5 = curr_date5.valueOf()+31;
                }
                if(curr_month5==4||curr_month5==6||curr_month5==9||curr_month5==11){
                  curr_date5 = curr_date5.valueOf()+30;
                }
                if(curr_month5==2){
                  curr_date5 = curr_date5.valueOf()+28;
                }
                if(curr_month5<1){
                  curr_year5 = parseFloat(curr_year)-1;
                }
              }
            }
            h4 = (h4<10?'0':'')+h4;
            curr_date5 = (curr_date5<10?'0':'')+curr_date5;
            curr_month5 = (curr_month5<9?'0':'')+curr_month5;
            var j = curr_year5 + "-" + curr_month5 + "-" + curr_date5+ ' '+h4 + ':' + m2 + ':' + s2;
            
            $scope.evento.dialimiteconfirmacao = j;
            console.log($scope.evento.diafim ,  $scope.evento.dialimiteconfirmacao);
              if($scope.evento.semana == 0){
                $scope.evento.semana = "Domingo";
              }
              if($scope.evento.semana == 1){
                $scope.evento.semana = "Segunda-feira";
              }
              if($scope.evento.semana == 2){
                $scope.evento.semana = "Terça-feira";
              }
              if($scope.evento.semana == 3){
                $scope.evento.semana = "Quarta-feira";
              }
              if($scope.evento.semana == 4){
                $scope.evento.semana = "Quinta-feira";
              }
              if($scope.evento.semana == 5){
                $scope.evento.semana = "Sexta-feira";
              }
              if($scope.evento.semana == 6){
                $scope.evento.semana = "Sábado";
              }
               for(var r = 0;r<$scope.auxdata.length; r++){
                //console.log($scope.auxdata[r].idevento, $scope.auxdata[r].diainicio, $scope.auxdata[r].diafim , we ,$scope.evento.diafim);
                if($scope.evento.idevento!=$scope.auxdata[r].idevento){
                  if (($scope.auxdata[r].diainicio < we && $scope.auxdata[r].diafim > we) || ($scope.auxdata[r].diainicio<$scope.evento.diafim && $scope.auxdata[r].diafim>$scope.evento.diafim) ||($scope.auxdata[r].diainicio > we && $scope.auxdata[r].diafim<$scope.evento.diafim) || ($scope.auxdata[r].diainicio < we && $scope.auxdata[r].diafim>$scope.evento.diafim) ) {
                    console.log('horario invalido');
                    datainvalida = 1;
                  }
                }
              }
             //console.log (datainvalida , r)
              ///        ╭∩╮(︶‿︶)╭∩╮
            if(datainvalida == 0 && r==$scope.auxdata.length){
              // $scope.evento.date = $scope.evento.date.toDateString("yyyy-MM-dd HH:mm");
              // $scope.evento.diafim = $scope.evento.diafim.toDateString("yyyy-MM-dd HH:mm");
               formEvento.updateForm($scope.evento);
               //console.log($scope.evento.duracao);
              // console.log($scope.evento.date);
               $state.go('tabsController.EditaEventoPart2');
            }
            if(datainvalida ==1){
              var alertPopup = $ionicPopup.alert({
                    title: 'Oww!!',
                    template: 'Tu ja tem um evento marcado nesse horário :/'
                  });
            }
          

          }
        
    }


}])
     
.controller('EditaEventoPart2Ctrl', ['$scope', '$stateParams', '$cordovaGeolocation', '$state', '$ionicLoading', 'formEventoEdita', 'formItem',  // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $cordovaGeolocation, $state, $ionicLoading, formEventoEdita, formItem) {
  $scope.evento = {};
  $scope.evento = formEventoEdita.getForm();

  var lat;
  var long;
  var map;
  var myLatlng;
  var mapOptions;
  var marker;
  var geocoder;
  var infowindow;
  $scope.disableTap = function(){
     container = document.getElementsByClassName('pac-container');
     // disable ionic data tab
     angular.element(container).attr('data-tap-disabled', 'true');
     // leave input field if google-address-entry is selected
     angular.element(container).on("click", function(){
                                   document.getElementById('pac-input').blur();
                                   });
     };
    
    lat  = $scope.evento.lat;
    long = $scope.evento.lng;     
    myLatlng = new google.maps.LatLng(lat, long);
    mapOptions = {
          center: myLatlng,
          zoom: 16,
          mapTypeId: google.maps.MapTypeId.ROADMAP
      };          
             
       map = new google.maps.Map(document.getElementById("map_canvas"), mapOptions); 
       marker = new google.maps.Marker({
                position: new google.maps.LatLng(lat, long),
                map: map,
                title: "Borai",
                draggable: true,
                icon: 'http://maps.google.com/mapfiles/ms/icons/green-dot.png',
                animation: google.maps.Animation.DROP 
            })
       geocoder = new google.maps.Geocoder;
       infowindow = new google.maps.InfoWindow({maxWidth: 200});

      geocoder.geocode({'location': myLatlng}, function(results, status) {
        if (status === 'OK') {
          if (results[1]) {
            $scope.evento.nomelocal = results[0].address_components[0].long_name;
            $scope.evento.endereco = results[0].formatted_address;
            for(var i = 0;i<results[0].address_components.length;i++){
              if(results[0].address_components[i].types[0] == "administrative_area_level_2"){
                $scope.evento.cidade = results[0].address_components[i].long_name;
                console.log($scope.evento.cidade)
              }
            }
            $scope.evento.lat = lat;
            $scope.evento.lng = long;
            infowindow.setContent(results[0].formatted_address);
            infowindow.open(map, marker);
            setTimeout(function () { infowindow.close(); }, 5000);
          } else {
            window.alert('Resultado não encontrado');
          }
        } else {
          window.alert('Ocorreu uma falha doida :' + status);
        }
      });

  $scope.$on("$ionicView.enter", function(event, data){
    $scope.evento = {};
    $scope.evento = formEventoEdita.getForm();
    var posOptions = {
            enableHighAccuracy: true,
            timeout: 200000,
            maximumAge: 0
        };

    navigator.geolocation.getCurrentPosition(function(position){
          
            lat  = $scope.evento.lat;
            long = $scope.evento.lng;
             

            myLatlng = new google.maps.LatLng(lat, long);
             
            mapOptions = {
                center: myLatlng,
                zoom: 16,
                mapTypeId: google.maps.MapTypeId.ROADMAP
            };          
             
            map = new google.maps.Map(document.getElementById("map_canvas"), mapOptions); 


            marker = new google.maps.Marker({
                      position: new google.maps.LatLng(lat, long),
                      map: map,
                      title: "Borai",
                      draggable: true,
                      icon: 'http://maps.google.com/mapfiles/ms/icons/green-dot.png',
                      animation: google.maps.Animation.DROP 
                  })

            geocoder = new google.maps.Geocoder;
            infowindow = new google.maps.InfoWindow({
                                                              maxWidth: 200
                                                            });

            geocoder.geocode({'location': myLatlng}, function(results, status) {
                  if (status === 'OK') {
                    if (results[1]) {
                      $scope.evento.nomelocal = results[0].address_components[0].long_name;
                      $scope.evento.endereco = results[0].formatted_address;
                      for(var i = 0;i<results[0].address_components.length;i++){
                        if(results[0].address_components[i].types[0] == "administrative_area_level_2"){
                          $scope.evento.cidade = results[0].address_components[i].long_name;
                          console.log($scope.evento.cidade)
                        }
                      }
                      $scope.evento.lat = lat;
                      $scope.evento.lng = long;
                      // $scope.evento.lat = position.coords.latitude;
                      // $scope.evento.lng = position.coords.longitude;
                      infowindow.setContent(results[0].formatted_address);
                      console.log($scope.evento.endereco);
                      console.log($scope.evento.cidade);
                      console.log($scope.evento.lng);
                      console.log($scope.evento.lat);
                      //infowindow.setContent(results[0].address_components[2].long_name);
                      infowindow.open(map, marker);
                      setTimeout(function () { infowindow.close(); }, 5000);
                    } else {
                      window.alert('Resultado não encontrado');
          }
        } else {
          window.alert('Ocorreu uma falha doida :' + status);
                  }
                });


            google.maps.event.addListener(marker, "dragstart", function (event) {
               marker.setAnimation(3); // raise
            });

            google.maps.event.addListener(marker, "dragend", function (event) {
               marker.setAnimation(4); // raise
            });

            marker.addListener('dragend', handleEvent);
            google.maps.event.addListener(map, 'click', function(e) {
              
                markers.forEach(function(marker) {
                  marker.setMap(null);
                });
                markers = [];

                placeMarker(e.latLng, map, marker);

            });

            function placeMarker(latlng, map, marker) {
                marker.setPosition(latlng);
                marker.setMap(map);
                map.panTo(latlng);
                $scope.evento.lat = latlng.lat();
                $scope.evento.lng = latlng.lng();
                geocoder.geocode({'location': latlng}, function(results, status) {
                  if (status === 'OK') {
                    if (results[1]) {
                      $scope.evento.nomelocal = results[0].address_components[0].long_name;
                      for(var i = 0;i<results[0].address_components.length;i++){
                        if(results[0].address_components[i].types[0] == "administrative_area_level_2"){
                          $scope.evento.cidade = results[0].address_components[i].long_name;
                          console.log($scope.evento.cidade)
                        }
                      }
                      $scope.evento.endereco = results[0].formatted_address;
                      infowindow.setContent(results[0].formatted_address);
                     
                      infowindow.open(map, marker);
                      setTimeout(function () { infowindow.close(); }, 5000);
                    } else {
                      window.alert('Resultado não encontrado');
          }
        } else {
          window.alert('Ocorreu uma falha doida :' + status);
                  }
                });
            };        

            function handleEvent(event) {
                $scope.evento.lat = event.latLng.lat();
                $scope.evento.lng = event.latLng.lng();

                              // GEOCODER INVERSO

                var geocoder = new google.maps.Geocoder;
                var infowindow = new google.maps.InfoWindow({
                                                              maxWidth: 200
                                                            });;    
            
                geocoder.geocode({'location': event.latLng}, function(results, status) {
                  if (status === 'OK') {
                    if (results[1]) {
                      $scope.evento.nomelocal = results[0].address_components[0].long_name;
                      for(var i = 0;i<results[0].address_components.length;i++){
                        if(results[0].address_components[i].types[0] == "administrative_area_level_2"){
                          $scope.evento.cidade = results[0].address_components[i].long_name;
                          console.log($scope.evento.cidade)
                        }
                      }
                      $scope.evento.endereco = results[0].formatted_address;
                      // console.log($scope.evento.endereco);
                      // console.log($scope.evento.cidade);
                      // console.log($scope.evento.lng);
                      // console.log($scope.evento.lat);
                      infowindow.setContent(results[0].formatted_address);
                     
                      infowindow.open(map, marker);
                      setTimeout(function () { infowindow.close(); }, 5000);
                    } else {
                      window.alert('Resultado não encontrado');
          }
        } else {
          window.alert('Ocorreu uma falha doida :' + status);
                  }
                });
            }

                              // GEOCODER INVERSO

                

                
            
                    //        SEARCHBOX

            var input = document.getElementById('pac-input');
            var searchBox = new google.maps.places.SearchBox(input);
        //map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);

        // Bias the SearchBox results towards current map's viewport.
            map.addListener('bounds_changed', function() {
                searchBox.setBounds(map.getBounds());
            });

            var markers = [];
        // Listen for the event fired when the user selects a prediction and retrieve
        // more details for that place.
            searchBox.addListener('places_changed', function() {
                var places = searchBox.getPlaces();

                if (places.length == 0) {
                  return;
                }

                // Clear out the old markers.
                markers.forEach(function(marker) {
                  marker.setMap(null);
                });
                markers = [];

                // For each place, get the icon, name and location.
                var bounds = new google.maps.LatLngBounds();
                places.forEach(function(place) {
                  if (!place.geometry) {
                    console.log("Returned place contains no geometry");
                    return;
                  }
                  markers.push(new google.maps.Marker({
                    map: map,
                    // icon: icon,
                    title: place.name,
                    position: place.geometry.location
                  }));

                  $scope.evento.nomelocal = place.name;
                  $scope.evento.endereco = place.formatted_address;
                  for(var i = 0;i<place.address_components.length;i++){
                    //console.log(place.address_components[i].types[0])
                    if(place.address_components[i].types[0] == "administrative_area_level_2"){
                      $scope.evento.cidade = place.address_components[i].long_name;
                      console.log($scope.evento.cidade)
                    }
                  }
                  $scope.evento.lat = place.geometry.location.lat();
                  $scope.evento.lng = place.geometry.location.lng();
                  if (place.geometry.viewport) {
                    // Only geocodes have viewport.
                    bounds.union(place.geometry.viewport);
                  } else {
                    bounds.extend(place.geometry.location);
                  }
                });
                map.fitBounds(bounds);
            });
            $scope.map = map;  
             
        }, function(err) {
            console.log(err.code);
            console.log(err.message);
        });




  });
  
     


        $scope.getCriar = function(evento) {
          formEventoEdita.updateForm($scope.evento);
          $state.go('tabsController.EditEv');
        }

}])

.controller('EditaEventoPart3Ctrl', ['$scope', '$stateParams', '$state', 'formEvento', 'formItem', '$ionicPopup', 'formEventoEdita', 'formUser', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $state, formEvento, formItem, $ionicPopup,formEventoEdita, formUser) {
  $scope.evento = {};
  $scope.evento = formEventoEdita.getForm();

  $scope.user = formUser.getForm();
  
  if($scope.user.genero == "fem"){
    $scope.femin = true;
  }else{
    $scope.femin = false;
  }


  if($scope.evento.dificuldade == "Não importa"){
    $scope.evento.dificuldaden = 1;
  }
  if($scope.evento.dificuldade == "Fácil"){
    $scope.evento.dificuldaden = 2;
  }
  if($scope.evento.dificuldade == "Moderado"){
    $scope.evento.dificuldaden = 3;
  }
  if($scope.evento.dificuldade == "Difícil"){
    $scope.evento.dificuldaden = 4;
  }

  $scope.ch = function(){
    if($scope.evento.dificuldaden == 1){
      $scope.evento.dificuldade = "Não importa";
    }
    if($scope.evento.dificuldaden == 2){
      $scope.evento.dificuldade = "Fácil";
    }
    if($scope.evento.dificuldaden == 3){
      $scope.evento.dificuldade = "Moderado";
    }
    if($scope.evento.dificuldaden == 4){
      $scope.evento.dificuldade = "Difícil";
    }
  }

  var header = document.getElementById("barpor");
  var btns = header.getElementsByClassName("btnpor");
  for (var i = 0; i < btns.length; i++) {
    btns[i].addEventListener("click", function() {
      var current = document.getElementsByClassName("actr");
      current[0].className = current[0].className.replace(" actr", "");
      this.className += " actr";
    });
  }
  // $scope.evento.auxpmax = $scope.evento.pmax;
  // $scope.mudamax = function() {
  //   if (!$scope.evento.pmax) {
  //     var alertPopup = $ionicPopup.alert({
  //     title: 'Register failed!',
  //     template: 'Favor preencher todos os campos'
  //   });
  //   }else{    
  //     if (parseInt($scope.evento.pmax) < parseInt($scope.evento.pmin)) {
  //       var alertPopup = $ionicPopup.alert({
  //               title: 'Matematimatematica',
  //               template: 'Máximo de pessoas nao pode ser maior que mínino xD'
  //             });
  //     }else{
  //       if (parseInt($scope.evento.pmax) >= 50) {
  //         var alertPopup = $ionicPopup.alert({
  //                 title: 'Muuuuita gente',
  //                 template: 'Limite máximo de pessoas para um evento é 50 personas'
  //               });
  //       }else{
  //         $scope.evento.pmax = $scope.evento.auxpmax;
  //       }
  //     }
  //   }
  // };
  // $scope.evento.auxpmin = $scope.evento.pmin;
  // $scope.mudamin = function() {
  //   if (!$scope.evento.pmin) {
  //     var alertPopup = $ionicPopup.alert({
  //     title: 'Register failed!',
  //     template: 'Favor preencher todos os campos'
  //   });
  //   }else{    
  //     if (parseInt($scope.evento.pmin)<=1) {
  //       var alertPopup = $ionicPopup.alert({
  //               title: '=/',
  //               template: 'Não da pra fazer um evento só com você né'
  //             });
  //     }else{
  //       $scope.evento.pmin = $scope.evento.auxpmin;
  //     }
  //   }
  // };

  $scope.pessoa = function() {$scope.evento.precopor = 1;};
  $scope.hora = function() {$scope.evento.precopor = 2;};

  $scope.getCriar = function(evento) {
  var palavrasnaousar = ["ALIAMBA", "ANUS", "BAGULIO"
      , "BANZA", "BARRUFO", "BECK", "BEQUE", "BOCETA"
      , "BOLAGATO", "BOQUETE", "BOLCAT", "BOSSETA", "BOSTANA", "BREXA", "BRIOCO", "BRONHA", "BUCA", "BUCETA"
      , "BUSSETA", "CANABIS", "CANNABIS", "CARALHO"
      , "CASSETA", "CASSETE", "CHECHECA", "CHERECA", "CHIBUMBA", "CHIBUMBO", "CHOTA", "CHOCHOTA", "CHUPADA", "CHUPADO", "CLITORIS"
      , "COCAINA","C+"
      , "C*", "CURALHO", "CUZAO", "CUZUDA", "CUZUDO", "CUZÃO", "ESPORRADA", "ESPORRADO", "ESPORRO", "estupro"
      , "FELACAO", "FELACÃO", "FODA", "FODAO", "FODÃO", "FODAUM", "FODE", "FODIDA", "FODIDO", "FORNICA", "FUDENDO", "FUDECÃO", "FUDECAO"
      , "FUDIDA", "FUDIDO", "GRELINHO", "GRELO", "ISCROTA", "ISCROTO", "MACONHA", "MASTURBA", "MASTURBAÇÃO", "MASTURBACÃO", "MASTURBACAO"
      , "PENIS", "PEN1S", "PENES", "PENIZ", "PICA", "PIROCA", "PIRU", "PORRA", "POURRA", "PROSTIBULO", "PUTA", "PUNHETA", "PUTO"
      , "RABAO", "TESTUDA", "TESTUDO", "VAGABUNDA", "VAGINA", "VIADO", "VIADAO", "VIADÃO", "XAVASCA", "XERERECA", "XEXECA", "XOTA"
      , "XOCHOTA", "XOXOTA", "XANA", "XANINHA", "MDMA",  "VSF", "TNC", "FDP", "CRACK"];
      var error = 0; 
      for (var i = 0; i < palavrasnaousar.length; i++) {
        var res2 = $scope.evento.descricao.split("_") ;
        if(res2.length>1){
          for(var w = 0; w < res2.length; w++){
            var val = palavrasnaousar[i].toLowerCase();
            if ((res2[w].toLowerCase()).indexOf(val.toString()) > -1) {  
              error = error + 1;  
            }
          }
        }else{
          var val = palavrasnaousar[i].toLowerCase();  
          if (($scope.evento.descricao.toLowerCase()).indexOf(val.toString()) > -1) {  
            error = error + 1;  
          }
        }
        var res3 = $scope.evento.descricao.split(" ") ;
        if(res3.length>1){
          for(var w = 0; w < res3.length; w++){
            var val = palavrasnaousar[i].toLowerCase();
            if ((res3[w].toLowerCase()).indexOf(val.toString()) > -1) {  
              error = error + 1;  
            }
          }
        }else{
          var val = palavrasnaousar[i].toLowerCase();  
          if (($scope.evento.descricao.toLowerCase()).indexOf(val.toString()) > -1) {  
            error = error + 1;  
          }
        }   
      } 
      if (error > 0) {  
          var alertPopup = $ionicPopup.alert({
                title: '（・о・；）',
                template: 'Que boquinha suja eim, usaste uma palavra inapropriada né'
              }); 
      }else{
        if (!$scope.evento.pmax || !$scope.evento.pmin) {
                    var alertPopup = $ionicPopup.alert({
                    title: 'Register failed!',
                    template: 'Favor preencher todos os campos'
                  });

        }else{
          if (parseInt($scope.evento.pmin)<=1) {
            var alertPopup = $ionicPopup.alert({
                    title: '=/',
                    template: 'Não da pra fazer um evento só com você né'
                  });
          }else{
            if (parseInt($scope.evento.pmax) <= parseInt($scope.evento.pmin)) {
              var alertPopup = $ionicPopup.alert({
                      title: 'Matematimatematica',
                      template: 'Mínimo de pessoas nao pode ser maior que máximo xD'
                    });
            }else{
              if (parseInt($scope.evento.pmax) >= 50) {
                var alertPopup = $ionicPopup.alert({
                        title: 'Muuuuita gente',
                        template: 'Limite máximo de pessoas para um evento é 50 personas'
                      });
              }else{
        if(evento.descricao){
          formEventoEdita.updateForm($scope.evento);
          $state.go('tabsController.EditEv');
        }else{
          var alertPopup = $ionicPopup.alert({
                title: '( ꒪Д꒪)ノ',
                template: 'Escreva algo na descrição do evento para ajudar as pessoas a entenderem o que será feito'
              }); 
        }   
            }
          }
        }
      }
      }
  }

}])
   
.controller('EditaEventoPart4Ctrl', ['$scope', '$stateParams', '$state', 'formEvento', 'formUser','$ionicPopup', '$http', 'formtela2','formEditar', 'EventoService', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $state, formEvento, formUser, $ionicPopup, $http, formtela2, formEditar, EventoService) {
  
  $scope.evento = formEvento.getForm();
  $scope.telaeditar = 1;
  $scope.pushnoti = {};
  $scope.confirmacao = 'aprovado';
  $scope.estado = '0';
  $scope.auxtela = formtela2.getForm();
  var res2 = [];
  var noti = {};
  console.log($scope.auxtela);
  EventoService.Gettags($scope.evento.idevento).then(function(tags) {
    for(var  i =0; i < tags.length;i++){
         res2[i] =  tags[i].tag;
        } 
  });
  $scope.mudanome = false;
  
   $scope.user = formUser.getForm(); /// mudar aqui o Formuser
    //console.log($scope.user.iduser);
  $scope.$on("$ionicView.enter", function(event, data){
    $scope.evento = {};
    $scope.evento = formEvento.getForm();
    $scope.telaeditar = 1;
    $scope.pushnoti = {};
    $scope.confirmacao = 'aprovado';
    $scope.estado = '0';
    $scope.auxtela = formtela2.getForm();
    var res2 = [];
    var noti = {};
    console.log($scope.auxtela);
    EventoService.Gettags($scope.evento.idevento).then(function(tags) {
      for(var  i =0; i< tags.length;i++){
           res2[i] =  tags[i].tag;
          } 
    });
    $scope.mudanome = false;
    $scope.user = formUser.getForm();
    if ($scope.telaeditar == 1) {
      $scope.mudanome = true;
     }
    $scope.auxtela = formtela2.getForm();
    if ($scope.auxtela == 1) {
      $state.go('tabsController.EditaEEAPart1');
    }
  });
  
  $scope.getCriar = function(evento) {
      if (!$scope.evento.pmax || !$scope.evento.pmin) {
                    var alertPopup = $ionicPopup.alert({
                    title: 'Register failed!',
                    template: 'Favor preencher todos os campos'
                  });

         }else{
          if (parseInt($scope.evento.pmin)<=1) {
            var alertPopup = $ionicPopup.alert({
                    title: '=/',
                    template: 'Não da pra fazer um evento só com você né'
                  });
          }else{
            if (parseInt($scope.evento.pmax) < parseInt($scope.evento.pmin)) {
              var alertPopup = $ionicPopup.alert({
                      title: 'Matematimatematica',
                      template: 'Mínimo de pessoas nao pode ser maior que máximo xD'
                    });
            }else{
          if (parseInt($scope.evento.pmax) >= 50) {
                var alertPopup = $ionicPopup.alert({
                        title: 'Muuuuita gente',
                        template: 'Limite máximo de pessoas para um evento é 50 personas'
                      });
              }else{
            if ($scope.telaeditar == 1) {
              console.log('oi');
              EventoService.atualizarevento($scope.evento).then(function(msg){
              var alertPopup = $ionicPopup.alert({
                      title: 'ʕ•ᴥ•ʔ',
                      template: msg
                    });
                       alertPopup.then(function(){
                EventoService.GetParticipantes($scope.evento.idevento).then(function(items) {
                  $scope.msgnoti = 'O evento: '+$scope.evento.nomeevento +' foi mudado'
                           for (var i = 0; i < items.length; i++) {
                            if ($scope.user.iduser != items[i].iduser) {
                              noti.recebeusername = items[i].username;
                              noti.recebe = items[i].iduser;
                              noti.envia = $scope.user.iduser;
                              noti.tipo = 4;
                              noti.nomeevento = $scope.evento.nomeevento;
                              EventoService.VerificaNotificacao(noti).then(function(res) {
                                console.log(res);
                                if(res){
                                  $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : $scope.msgnoti, 
                                        idevento : $scope.evento.idevento,
                                        nomeevento : $scope.evento.nomeevento,
                                        id_user_envia : $scope.user.iduser,
                                        username_envia : $scope.user.username,
                                        apelido_envia : $scope.aux.apelido,
                                        tipo : '4',    //update no evento
                                        id_user_recebe : noti.recebe}).then(function (res){
                                       $scope.response = res.data;
                                       console.log($scope.response.msg)
                                     });
                                  EventoService.getusuario2(noti.recebeusername).then(function(user) {
                                    $scope.pushnoti.titulo =  'Mudanças!' ;
                                    $scope.pushnoti.msg = $scope.msgnoti;
                                    $scope.pushnoti.token = user.devicetoken;
                                     EventoService.MandaPushNoti($scope.pushnoti);
                                  } );
                                }
                              });
                            }
                          }
                         })

                             $state.go('tabsController.home');
                        })
                  }, function(errMsg) {
                    var alertPopup = $ionicPopup.alert({
                      title: 'Register failed!',
                      template: errMsg
                    });
                  })
                            /// AQUI TEMOS QUE COMPARAR SE HOUVE INCLUSAO DE UMA TAG NOVA
                if( $scope.evento.tags!=''){
                  var res = $scope.evento.tags.split(" ") ;
                  var array3 = res.filter(function(obj) { return res2.indexOf(obj) == -1; });
                    for (var i = 0; i<array3.length;i++){
                      if(array3[i][0]!='#'){
                        array3[i]= '#' + array3[i];
                      }
                      var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criartag.php';
                        $http.post(link, {idevento : $scope.evento.idevento, 
                                          tag : array3[i]});
                      }
                }
            }else{
                $ionicPopup.prompt({
                    title: 'Qual nome devo dar?',
                    template: 'Não vamos esquecer de dar nomes aos bois',
                   inputType: 'text',
                   inputPlaceholder: ' Nome legal'
                 }).then(function(nomeevento) {
                  $scope.evento.nomeevento = nomeevento;
                    console.log('Nome do evento é', nomeevento);
                 
           if (nomeevento && nomeevento !='' && nomeevento !=' ') {
            var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarevento.php';
            $http.post(link, {nomeevento : $scope.evento.nomeevento, 
                          duracao : $scope.evento.duracao,
                          diainicio : $scope.evento.diainicio,
                          diafim : $scope.evento.diafim,
                          dialimiteconfirmacao: $scope.evento.dialimiteconfirmacao,
                          pmin : $scope.evento.pmin, 
                          pmax : $scope.evento.pmax,
                          patual : $scope.evento.patual,  
                          adm : $scope.user.iduser,
                          admusername : $scope.user.username,
                          admapelido : $scope.user.apelido,
                          preco : $scope.evento.preco,
                          precopor : $scope.evento.precopor, 
                          nomelocal : $scope.evento.nomelocal,
                          endereco : $scope.evento.endereco,
                          estado : '0',
                          cidade : $scope.evento.cidade,
                          lat : $scope.evento.lat,
                          lng : $scope.evento.lng,
                          dificuldade :$scope.evento.dificuldade,
                          genero : $scope.evento.genero,
                          descricao : $scope.evento.descricao}).then(function (res){
            $scope.responsecriado = res.data;

            if ($scope.responsecriado.success == true) {
                if( $scope.evento.tags!=''){
              var res = $scope.evento.tags.split(" ") ;
               var array3 = res.filter(function(obj) { return res2.indexOf(obj) == -1; });
                for (var i = 0; i<array3.length;i++){
                  var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criartag.php';
                    $http.post(link, {idevento : $scope.responsecriado.last, 
                                      tag : array3[i]})
                   }
                 }
              var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/irevento.php';
                  $http.post(link, {idevento : $scope.responsecriado.last, 
                                    iduser : $scope.user.iduser,
                                    idadm : $scope.user.iduser, 
                                    admusername : $scope.user.username,
                                    username : $scope.user.username,
                                    apelido : $scope.user.apelido,
                                    borda : $scope.user.borda,
                                    profilepic : $scope.user.profilepic,
                                    devicetoken : $scope.user.devicetoken,
                                    diainicio : $scope.evento.diainicio,
                                    confirmacao : $scope.confirmacao,
                                    nomeevento :  $scope.evento.nomeevento,
                                    //eventopic : $scope.evento.eventopic,
                                    estado : $scope.estado}).then(function (res){
                  $scope.response = res.data;
                  console.log($scope.response);
                    if ($scope.response.success == true) {
                        var alertPopup = $ionicPopup.alert({
                      title: 'Parabéns',
                      template: $scope.responsecriado.msg
                    }); 
                        alertPopup.then(function(){
                        formtela2.updateForm(1);
                        $scope.evento = {};
                        formEvento.updateForm($scope.evento);
                         $state.go('tabsController.home');
                       })
                      }else{
                        var alertPopup = $ionicPopup.alert({
                      title: 'Ocorreu uma falha',
                      template: $scope.responsecriado.msg
                    });
                        alertPopup.then(function(){
                        $state.go('tabsController.home');
                       })
                      }
                    })
                  }
            });

           }else{console.log('dasd');}
        });
            }

         }
          }}

         }
  }

}])

.controller('EditaEEAPart1Ctrl', ['$scope', '$stateParams', 'formEvento', '$state','$ionicPopup', '$timeout', 'formtela2', 'formItem', 'EventoService', 'formUser', 'formEventoEditahome','$http', '$cordovaCamera', '$cordovaFile', '$cordovaFileTransfer', '$cordovaDevice',  '$ionicLoading', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, formEvento, $state, $ionicPopup, $timeout, formtela2, formItem, EventoService, formUser, formEventoEditahome, $http, $cordovaCamera, $cordovaFile, $cordovaFileTransfer, $cordovaDevice,  $ionicLoading) {
  $scope.evento = {};
  $scope.evento = formEventoEditahome.getForm();

  $scope.user = formUser.getForm();

  var noti = {};
  $scope.pushnoti = {};
   $scope.auxfoto = '';
  $scope.limiteconfirmacao ={};
  $scope.fim = {};
  $scope.inicio = {};
  var mudoufoto = false;
  var auxdiainicio = $scope.evento.diainicio;

  $scope.evento.dateconfirma = $scope.evento.dialimiteconfirmacao.toLocaleString();
  $scope.evento.dateinicio = $scope.evento.diainicio;
  $scope.evento.datefim = $scope.evento.diafim;
  
  var currentdate = new Date(); 
  var curr_date = (currentdate.getDate()<10?'0':'') + currentdate.getDate();
  var curr_month = (currentdate.getMonth()<9?'0':'') + (currentdate.getMonth() + 1); //Months are zero based
  var curr_year = currentdate.getFullYear();
  var curr_h = (currentdate.getHours()<10?'0':'') + currentdate.getHours();
  var curr_m = (currentdate.getMinutes()<10?'0':'') + currentdate.getMinutes();
  var curr_j = curr_year + "-" + curr_month + "-" + curr_date+ ' '+curr_h + ':' + curr_m + ':' + '00';
  
  EventoService.verificahorariopessoaevento($scope.user).then(function(items) {
    if (items!="Error") {
      $scope.auxdata = items;
    }
  });
  if(!$scope.evento.eventopic){
    $scope.imgURI ="img/ev.png"; 
    document.getElementById("imageidEventoEEA").src="img/ev.png";
  }else{
    $scope.imgURI =$scope.evento.eventopic;
    document.getElementById("imageidEventoEEA").src=$scope.evento.eventopic;
  }
  
  $scope.mudafotoevento = function (optionsCamera) {
    var optionsCamera = {
          quality : 100,
          sourceType : 0,
          allowEdit : true,
          targetWidth: 720,
          targetHeight: 400
    };
    $cordovaCamera.getPicture(optionsCamera).then(function(imageData) {
      $scope.imgURI = imageData;
      mudoufoto = true;
      document.getElementById("imageidEventoEEA").src=imageData;
    }, function(err) {
      console.log(err);
    });
    
  }

  $scope.mudaconfirma = function(){
    novaconfirma_date = ($scope.evento.dateconfirma.getDate()<10?'0':'') + $scope.evento.dateconfirma.getDate();
    novaconfirma_month = ($scope.evento.dateconfirma.getMonth()<9?'0':'') + ($scope.evento.dateconfirma.getMonth() + 1); //Months are zero based
    novaconfirma_year = $scope.evento.dateconfirma.getFullYear();
    novaconfirma_h = ($scope.evento.dateconfirma.getHours()<10?'0':'') + $scope.evento.dateconfirma.getHours();
    novaconfirma_m = ($scope.evento.dateconfirma.getMinutes()<10?'0':'') + $scope.evento.dateconfirma.getMinutes();
    novaconfirma_s = ($scope.evento.dateconfirma.getSeconds()<10?'0':'') + $scope.evento.dateconfirma.getSeconds();
    var novaconfirmaj = novaconfirma_year + "-" + novaconfirma_month + "-" + novaconfirma_date+ ' '+novaconfirma_h + ':' + novaconfirma_m + ':' + novaconfirma_s;
    

    if(curr_j>novaconfirmaj){
      var alertPopup = $ionicPopup.alert({
                  title: '(*ﾉ´□`)ﾉ~',
                  template: 'Muito em cima da hora para mudar pra ontem'
                });
      
    }else{
      if(novaconfirmaj>$scope.evento.diainicio){
        var alertPopup = $ionicPopup.alert({
                  title: 'ヽ ( ꒪д꒪ )ﾉ',
                  template: 'Evento nao pode começar depois da data limite de confirmação'
                });
      }else{
        $scope.limiteconfirmacao.dia =  novaconfirma_date +'/'+ novaconfirma_month;
        $scope.limiteconfirmacao.hora =  novaconfirma_h+':'+novaconfirma_m;  
        $scope.evento.dialimiteconfirmacao = novaconfirmaj;
        $scope.evento.dateconfirma = $scope.evento.dateconfirma.toLocaleString();
      }
    }
  }
  
  $scope.mudainicio = function(){
    var datainvalida = 0;
    
    novadateinicio_date = ($scope.evento.dateinicio.getDate()<10?'0':'') + $scope.evento.dateinicio.getDate();
    novadateinicio_month = ($scope.evento.dateinicio.getMonth()<9?'0':'') + ($scope.evento.dateinicio.getMonth() + 1); //Months are zero based
    novadateinicio_year = $scope.evento.dateinicio.getFullYear();
    novadateinicio_h = ($scope.evento.dateinicio.getHours()<10?'0':'') + $scope.evento.dateinicio.getHours();
    novadateinicio_m = ($scope.evento.dateinicio.getMinutes()<10?'0':'') + $scope.evento.dateinicio.getMinutes();
    novadateinicio_s = ($scope.evento.dateinicio.getSeconds()<10?'0':'') + $scope.evento.dateinicio.getSeconds();
    $scope.evento.semana = $scope.evento.dateinicio.getDay();
    var novadateinicioj = novadateinicio_year + "-" + novadateinicio_month + "-" + novadateinicio_date+ ' '+novadateinicio_h + ':' + novadateinicio_m + ':' + novadateinicio_s;
    
    if(curr_j>novadateinicioj){
      var alertPopup = $ionicPopup.alert({
                  title: '(*ﾉ´□`)ﾉ~',
                  template: 'Muito em cima da hora para mudar pra ontem'
                });
      
    }else{
      if($scope.evento.dialimiteconfirmacao>novadateinicioj){
        var alertPopup = $ionicPopup.alert({
                    title: '(*ﾉ´□`)ﾉ~',
                    template: 'Data de inicio não pode ser antes que a data limite de confirmação'
                  });
        
      }else{
        for(var r = 0;r<$scope.auxdata.length; r++){
          //console.log($scope.auxdata[r].idevento, $scope.auxdata[r].diainicio, $scope.auxdata[r].diafim , we ,$scope.evento.diafim);
          if($scope.evento.idevento!=$scope.auxdata[r].idevento){
            if (($scope.auxdata[r].diainicio <= novadateinicioj && $scope.auxdata[r].diafim >= novadateinicioj)  ) {
              datainvalida = 1;
            }
          }
        }
        if(r==$scope.auxdata.length && datainvalida == 1){
          var alertPopup = $ionicPopup.alert({
            title: 'Oww!!',
            template: 'Tu ja tem um evento marcado nesse horário :/'
          });
        }
        if(novadateinicioj>$scope.evento.datefim){
          console.log("to aquiwenqieni")
          $scope.fim.dia =  '??'+'/'+'??';
          $scope.fim.hora = '??'+':'+'??';
        }
        if(r==$scope.auxdata.length && datainvalida == 0){
          if($scope.evento.semana == 0){
            $scope.evento.semana = "Domingo";
          }
          if($scope.evento.semana == 1){
            $scope.evento.semana = "Segunda-feira";
          }
          if($scope.evento.semana == 2){
            $scope.evento.semana = "Terça-feira";
          }
          if($scope.evento.semana == 3){
            $scope.evento.semana = "Quarta-feira";
          }
          if($scope.evento.semana == 4){
            $scope.evento.semana = "Quinta-feira";
          }
          if($scope.evento.semana == 5){
            $scope.evento.semana = "Sexta-feira";
          }
          if($scope.evento.semana == 6){
            $scope.evento.semana = "Sábado";
          }
          $scope.inicio.dia =  novadateinicio_date +'/'+ novadateinicio_month;
          $scope.inicio.hora =  novadateinicio_h+':'+novadateinicio_m;  
          $scope.evento.diainicio = novadateinicioj;
          $scope.evento.dateinicio = $scope.evento.dateinicio.toLocaleString();
        }
      }
    }
  }

  $scope.mudafim = function(){
    var datainvalida = 0;
    
    novadatefim_date = ($scope.evento.datefim.getDate()<10?'0':'') + $scope.evento.datefim.getDate();
    novadatefim_month = ($scope.evento.datefim.getMonth()<9?'0':'') + ($scope.evento.datefim.getMonth() + 1); //Months are zero based
    novadatefim_year = $scope.evento.datefim.getFullYear();
    novadatefim_h = ($scope.evento.datefim.getHours()<10?'0':'') + $scope.evento.datefim.getHours();
    novadatefim_m = ($scope.evento.datefim.getMinutes()<10?'0':'') + $scope.evento.datefim.getMinutes();
    novadatefim_s = ($scope.evento.datefim.getSeconds()<10?'0':'') + $scope.evento.datefim.getSeconds();
    var novadatedatefimj = novadatefim_year + "-" + novadatefim_month + "-" + novadatefim_date+ ' '+novadatefim_h + ':' + novadatefim_m + ':' + novadatefim_s;
    
    if(curr_j>novadatedatefimj){
      var alertPopup = $ionicPopup.alert({
                  title: '(*ﾉ´□`)ﾉ~',
                  template: 'Muito em cima da hora para mudar pra ontem'
                });
      
    }else{
      if($scope.evento.dialimiteconfirmacao>novadatedatefimj){
        var alertPopup = $ionicPopup.alert({
                    title: '(*ﾉ´□`)ﾉ~',
                    template: 'Data de fim não pode ser antes que a data limite de confirmação'
                  });
        
      }else{
        if($scope.evento.diainicio>=novadatedatefimj){
        var alertPopup = $ionicPopup.alert({
                    title: '(*ﾉ´□`)ﾉ~',
                    template: 'Data de fim não pode ser antes que a data de início'
                  });
        }else{
          for(var r = 0;r<$scope.auxdata.length; r++){
            if($scope.evento.idevento!=$scope.auxdata[r].idevento){
              if (($scope.auxdata[r].diainicio <= novadatedatefimj && $scope.auxdata[r].diafim >= novadatedatefimj)  ) {
                datainvalida = 1;
              }
            }
          }
          if(r==$scope.auxdata.length && datainvalida == 1){
            var alertPopup = $ionicPopup.alert({
              title: 'Oww!!',
              template: 'Tu ja tem um evento marcado nesse horário :/'
            });
          }
          if(r==$scope.auxdata.length && datainvalida == 0){
            $scope.fim.dia =  novadatefim_date +'/'+ novadatefim_month;
            $scope.fim.hora =  novadatefim_h+':'+novadatefim_m;  
            $scope.evento.diafim = novadatedatefimj;
            $scope.evento.datefim = $scope.evento.datefim.toLocaleString();
          }
        }
      }
    }
  }
  
  var hjf = $scope.evento.diafim;
  $scope.fim.dia =  (hjf[8]+hjf[9]).valueOf()+'/'+(hjf[5]+hjf[6]).valueOf();
  $scope.fim.hora = (hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf();
  
  var hj = $scope.evento.diainicio;
  $scope.inicio.dia = (hj[8]+hj[9]).valueOf()+'/'+(hj[5]+hj[6]).valueOf();
  $scope.inicio.hora = (hj[11]+hj[12]).valueOf()+':'+(hj[14]+hj[15]).valueOf();


  var  hjl = $scope.evento.dialimiteconfirmacao;
  $scope.limiteconfirmacao.dia =  (hjl[8]+hjl[9]).valueOf()+'/'+(hjl[5]+hjl[6]).valueOf();
  $scope.limiteconfirmacao.hora =  (hjl[11]+hjl[12]).valueOf()+':'+(hjl[14]+hjl[15]).valueOf();  
  
    $scope.evento.auxtag1 = '';
    $scope.evento.auxtag2 = '';
    $scope.evento.auxtag3 = '';
    $scope.evento.auxtagbutton1 = false;
    $scope.evento.auxtagbutton2 = false;
    $scope.evento.auxtagbutton3 = false;
    $scope.evento.auxtag4 = '';
    $scope.evento.auxtag5 = '';
    $scope.evento.auxtag6 = '';
    $scope.evento.auxtagbutton4 = false;
    $scope.evento.auxtagbutton5 = false;
    $scope.evento.auxtagbutton6 = false;
    $scope.evento.auxtag7 = '';
    $scope.evento.auxtag8 = '';
    $scope.evento.auxtag9 = '';
    $scope.evento.auxtagbutton7 = false;
    $scope.evento.auxtagbutton8 = false;
    $scope.evento.auxtagbutton9 = false;


    $scope.auxtags = {};
    EventoService.Gettags($scope.evento.idevento).then(function(tags) {
      var auxauxtagbut = true;
      $scope.auxtags = tags;
      for(var  i =0; i< tags.length;i++){
         if($scope.evento.auxtagbutton1 == false && auxauxtagbut){
            $scope.evento.auxtag1 = tags[i].tag;
            $scope.evento.auxtagbutton1 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton2 == false && auxauxtagbut){
            console.log($scope.evento.auxtagbutton2)
            $scope.evento.auxtag2 = tags[i].tag;
            $scope.evento.auxtagbutton2 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton3 == false && auxauxtagbut){
            $scope.evento.auxtag3 = tags[i].tag;
            $scope.evento.auxtagbutton3 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton4 == false && auxauxtagbut){
            $scope.evento.auxtag4 = tags[i].tag;
            $scope.evento.auxtagbutton4 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton5 == false && auxauxtagbut){
            $scope.evento.auxtag5 = tags[i].tag;
            $scope.evento.auxtagbutton5 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton6 == false && auxauxtagbut){
            $scope.evento.auxtag6 = tags[i].tag;
            $scope.evento.auxtagbutton6 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton7 == false && auxauxtagbut){
            $scope.evento.auxtag7 = tags[i].tag;
            $scope.evento.auxtagbutton7 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton8 == false && auxauxtagbut){
            $scope.evento.auxtag8 = tags[i].tag;
            $scope.evento.auxtagbutton8 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton9 == false && auxauxtagbut){
            $scope.evento.auxtag9 = tags[i].tag;
            $scope.evento.auxtagbutton9 = true;
            auxauxtagbut = false;
          }
          auxauxtagbut = true;
      } 
    });

    var auxauxtagbut = false;
    $scope.adicionatag = function(){
      if($scope.evento.addtag!=''){
        var res2 = $scope.evento.addtag.split(" ") ;
          if(res2.length>1){
            for(var w = 0; w < res2.length; w++){
              var t = res2[w].toLowerCase();
             console.log(t)
            }
            $scope.evento.addtag = res2[0];
          }
        if(!auxauxtagbut){
          auxauxtagbut = true;
          if($scope.evento.auxtagbutton1 == false && auxauxtagbut){
            $scope.evento.auxtag1 = '#' +$scope.evento.addtag;
            $scope.evento.auxtagbutton1 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton2 == false && auxauxtagbut){
            $scope.evento.auxtag2 = '#' +$scope.evento.addtag;
            $scope.evento.auxtagbutton2 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton3 == false && auxauxtagbut){
            $scope.evento.auxtag3 = '#' +$scope.evento.addtag;
            $scope.evento.auxtagbutton3 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton4 == false && auxauxtagbut){
            $scope.evento.auxtag4 = '#' +$scope.evento.addtag;
            $scope.evento.auxtagbutton4 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton5 == false && auxauxtagbut){
            $scope.evento.auxtag5 = '#' +$scope.evento.addtag;
            $scope.evento.auxtagbutton5 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton6 == false && auxauxtagbut){
            $scope.evento.auxtag6 = '#' +$scope.evento.addtag;
            $scope.evento.auxtagbutton6 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton7 == false && auxauxtagbut){
            $scope.evento.auxtag7 = '#' +$scope.evento.addtag;
            $scope.evento.auxtagbutton7 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton8 == false && auxauxtagbut){
            $scope.evento.auxtag8 = '#' +$scope.evento.addtag;
            $scope.evento.auxtagbutton8 = true;
            auxauxtagbut = false;
          }
          if($scope.evento.auxtagbutton9 == false && auxauxtagbut){
            $scope.evento.auxtag9 = '#' +$scope.evento.addtag;
            $scope.evento.auxtagbutton9 = true;
            auxauxtagbut = false;
          }
        }
      }
      $scope.evento.addtag = '';
    }

    $scope.tiratag1 = function(){
        $scope.evento.auxtagbutton1 = false;
        $scope.evento.auxtag1 = '';
    }
    $scope.tiratag2 = function(){
        $scope.evento.auxtagbutton2 = false;
        $scope.evento.auxtag2 = '';
    }
    $scope.tiratag3 = function(){
        $scope.evento.auxtagbutton3 = false;
        $scope.evento.auxtag3 = '';
    }
    $scope.tiratag4 = function(){
        $scope.evento.auxtagbutton4 = false;
        $scope.evento.auxtag4 = '';
    }
    $scope.tiratag5 = function(){
        $scope.evento.auxtagbutton5 = false;
        $scope.evento.auxtag5 = '';
    }
    $scope.tiratag6 = function(){
        $scope.evento.auxtagbutton6 = false;
        $scope.evento.auxtag6 = '';
    }
    $scope.tiratag7 = function(){
        $scope.evento.auxtagbutton7 = false;
        $scope.evento.auxtag7 = '';
    }
    $scope.tiratag8 = function(){
        $scope.evento.auxtagbutton8 = false;
        $scope.evento.auxtag8 = '';
    }
    $scope.tiratag9 = function(){
        $scope.evento.auxtagbutton9 = false;
        $scope.evento.auxtag9 = '';
    }

    $scope.mudaloc = function(){
      formEventoEditahome.updateForm($scope.evento);
      $state.go('tabsController.EditaEEAPart2')
    }

    $scope.mudamais = function(){
      formEventoEditahome.updateForm($scope.evento);
      $state.go('tabsController.EditaEEAPart3')
    }

    $scope.teste = function(evento){
      console.log(evento.diafim)
    }

    $scope.salvar = function(evento){
      if ($scope.evento.nomeevento == '') {
        var alertPopup = $ionicPopup.alert({
          title: 'ʕ•ᴥ•ʔ',
          template: 'Coloque um titulo válido'
        });
      }else{
        if($scope.evento.diafim <$scope.evento.diainicio){
          var alertPopup = $ionicPopup.alert({
            title: 'ʕ•ᴥ•ʔ',
            template: 'Data de termino eh antes do dia de inicio!! Assim não da'
          });
        }else{
          var existe = 0;
          var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/deletatag.php';
          $http.post(link, {idevento : $scope.evento.idevento}).then(function(items) {
            if($scope.evento.auxtagbutton1 == true){
              existe = 0;
              var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criartag.php';
              $http.post(link, {idevento : $scope.evento.idevento, 
                                      tag : $scope.evento.auxtag1});
            }
            if($scope.evento.auxtagbutton2 == true){
              existe = 0;
              var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criartag.php';
              $http.post(link, {idevento : $scope.evento.idevento, 
                                      tag : $scope.evento.auxtag2});
            }
            if($scope.evento.auxtagbutton3 == true){
              existe = 0;
              var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criartag.php';
              $http.post(link, {idevento : $scope.evento.idevento, 
                                      tag : $scope.evento.auxtag3});
            }
            if($scope.evento.auxtagbutton4 == true){
              existe = 0;
              var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criartag.php';
              $http.post(link, {idevento : $scope.evento.idevento, 
                                      tag : $scope.evento.auxtag4});
            }
            if($scope.evento.auxtagbutton5 == true){
              existe = 0;
              var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criartag.php';
              $http.post(link, {idevento : $scope.evento.idevento, 
                                      tag : $scope.evento.auxtag5});
            }
            if($scope.evento.auxtagbutton6 == true){
              existe = 0;
              var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criartag.php';
              $http.post(link, {idevento : $scope.evento.idevento, 
                                      tag : $scope.evento.auxtag6});
            }
            if($scope.evento.auxtagbutton7 == true){
              existe = 0;
              var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criartag.php';
              $http.post(link, {idevento : $scope.evento.idevento, 
                                      tag : $scope.evento.auxtag7});
            }
            if($scope.evento.auxtagbutton8 == true){
              existe = 0;
              var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criartag.php';
              $http.post(link, {idevento : $scope.evento.idevento, 
                                      tag : $scope.evento.auxtag8});
            }
            if($scope.evento.auxtagbutton9 == true){
              existe = 0;
              var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criartag.php';
              $http.post(link, {idevento : $scope.evento.idevento, 
                                      tag : $scope.evento.auxtag9});
            }
          });

          console.log($scope.imgURI)
          if($scope.imgURI != "img/ev.png"){ 
            $scope.auxfoto = $scope.evento.nomeevento + $scope.evento.diainicio;
            var mystring = String($scope.auxfoto);
            mystring = mystring.replace(/[^a-zA-Z0-9]/g, '');
            $scope.evento.eventopic = 'https://s3.amazonaws.com/diwoappprofilepics/eventopicsdiwo/' + mystring + '.jpg';
          }else{
             $scope.evento.eventopic = "img/ev.png";
          }
            if(mudoufoto == true){
              var url = "http://ec2-3-84-65-68.compute-1.amazonaws.com/uploadfotoevento.php";
                                      // File for Upload
              var targetPath = $scope.imgURI;
             
              // File name only
              //var name = $scope.imgURI.substr(imageData.lastIndexOf('/') + 1);
              var filename = mystring + '.jpg';
              // NO CASO SERIA O NOME DO USUARIO.jpg O fileName
              var options = {
                fileKey: "file",
                fileName: filename,
                chunkedMode: false,
                mimeType: "multipart/form-data"
              };
              $cordovaFileTransfer.upload(url, targetPath, options).then(function(result) {
              EventoService.atualizarevento($scope.evento).then(function(msg){
          var alertPopup = $ionicPopup.alert({
                  title: 'ʕ•ᴥ•ʔ',
                  template: msg
                });
          $ionicLoading.hide();
          alertPopup.then(function(){
            EventoService.GetParticipantes($scope.evento.idevento).then(function(items) {
              $scope.msgnoti = 'O evento: '+$scope.evento.nomeevento +' foi mudado'
              for (var i = 0; i < items.length; i++) {
                if ($scope.user.iduser != items[i].iduser) {
                  noti.recebeusername = items[i].username;
                  noti.recebe = items[i].iduser;
                  noti.envia = $scope.user.iduser;
                  noti.tipo = 4;
                  noti.nomeevento = $scope.evento.nomeevento;
                  EventoService.VerificaNotificacao(noti).then(function(res) {
                    console.log(res);
                    if(res){
                      $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : $scope.msgnoti, 
                            idevento : $scope.evento.idevento,
                            nomeevento : $scope.evento.nomeevento,
                            id_user_envia : $scope.user.iduser,
                            username_envia : $scope.user.username,
                            apelido_envia : $scope.user.apelido,
                            tipo : '4',    //update no evento
                            id_user_recebe : noti.recebe}).then(function (res){
                           $scope.response = res.data;
                           console.log($scope.response.msg)
                      });
                      EventoService.getusuario2(noti.recebeusername).then(function(user) {
                        $scope.pushnoti.titulo =  'Mudanças!' ;
                        $scope.pushnoti.msg = $scope.msgnoti;
                        $scope.pushnoti.token = user.devicetoken;
                        EventoService.MandaPushNoti($scope.pushnoti);
                      });
                    }
                  });
                }
              }
            })
            formItem.updateForm($scope.evento);
            $state.go('tabsController.eventoAberto');
          })
          }, function(errMsg) {
            var alertPopup = $ionicPopup.alert({
              title: 'Register failed!',
              template: errMsg
            });
          })

              }, function(err) {
                $ionicPopup.alert({
                  title: 'Sorry!',
                  template: 'Aconteceu um probleminha, tente de novo'
                });
                $ionicLoading.hide();
              }, function (progress) {
                $ionicLoading.show({
                  title: '┗(＾0＾)┓',
                  template: 'DANCE, DANCE, DANCE!!'
                });
              });
            }
            
         
        }  
      }
    }
  

}])
     
.controller('EditaEEAPart2Ctrl', ['$scope', '$stateParams', '$cordovaGeolocation', '$state', '$ionicLoading', 'formEventoEditahome', 'formItem',  // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $cordovaGeolocation, $state, $ionicLoading, formEventoEditahome, formItem) {
  $scope.evento = {};
  $scope.evento = formEventoEditahome.getForm();

 var lat;
  var long;
  var map;
  var myLatlng;
  var mapOptions;
  var marker;
  var geocoder;
  var infowindow;
  $scope.disableTap = function(){
     container = document.getElementsByClassName('pac-container');
     // disable ionic data tab
     angular.element(container).attr('data-tap-disabled', 'true');
     // leave input field if google-address-entry is selected
     angular.element(container).on("click", function(){
                                   document.getElementById('pac-input').blur();
                                   });
     };
    
    lat  = $scope.evento.lat;
    long = $scope.evento.lng;     
    myLatlng = new google.maps.LatLng(lat, long);
    mapOptions = {
          center: myLatlng,
          zoom: 16,
          mapTypeId: google.maps.MapTypeId.ROADMAP
      };          
             
       map = new google.maps.Map(document.getElementById("map_canvas"), mapOptions); 
       marker = new google.maps.Marker({
                position: new google.maps.LatLng(lat, long),
                map: map,
                title: "Borai",
                draggable: true,
                icon: 'http://maps.google.com/mapfiles/ms/icons/green-dot.png',
                animation: google.maps.Animation.DROP 
            })
       geocoder = new google.maps.Geocoder;
       infowindow = new google.maps.InfoWindow({maxWidth: 200});

      geocoder.geocode({'location': myLatlng}, function(results, status) {
        if (status === 'OK') {
          if (results[1]) {
            $scope.evento.nomelocal = results[0].address_components[0].long_name;
            $scope.evento.endereco = results[0].formatted_address;
            for(var i = 0;i<results[0].address_components.length;i++){
              if(results[0].address_components[i].types[0] == "administrative_area_level_2"){
                $scope.evento.cidade = results[0].address_components[i].long_name;
                console.log($scope.evento.cidade)
              }
            }
            $scope.evento.lat = lat;
            $scope.evento.lng = long;
            infowindow.setContent(results[0].formatted_address);
            infowindow.open(map, marker);
            setTimeout(function () { infowindow.close(); }, 5000);
          } else {
            window.alert('Resultado não encontrado');
          }
        } else {
          window.alert('Ocorreu uma falha doida :' + status);
        }
      });

  $scope.$on("$ionicView.enter", function(event, data){
    $scope.evento = {};
    $scope.evento = formEventoEditahome.getForm();
    var posOptions = {
            enableHighAccuracy: true,
            timeout: 200000,
            maximumAge: 0
        };

    navigator.geolocation.getCurrentPosition(function(position){
          
            lat  = $scope.evento.lat;
            long = $scope.evento.lng;
             

            myLatlng = new google.maps.LatLng(lat, long);
             
            mapOptions = {
                center: myLatlng,
                zoom: 16,
                mapTypeId: google.maps.MapTypeId.ROADMAP
            };          
             
            map = new google.maps.Map(document.getElementById("map_canvas"), mapOptions); 


            marker = new google.maps.Marker({
                      position: new google.maps.LatLng(lat, long),
                      map: map,
                      title: "Borai",
                      draggable: true,
                      icon: 'http://maps.google.com/mapfiles/ms/icons/green-dot.png',
                      animation: google.maps.Animation.DROP 
                  })

            geocoder = new google.maps.Geocoder;
            infowindow = new google.maps.InfoWindow({
                                                              maxWidth: 200
                                                            });

            geocoder.geocode({'location': myLatlng}, function(results, status) {
                  if (status === 'OK') {
                    if (results[1]) {
                      $scope.evento.nomelocal = results[0].address_components[0].long_name;
                      $scope.evento.endereco = results[0].formatted_address;
                      for(var i = 0;i<results[0].address_components.length;i++){
                        if(results[0].address_components[i].types[0] == "administrative_area_level_2"){
                          $scope.evento.cidade = results[0].address_components[i].long_name;
                          console.log($scope.evento.cidade)
                        }
                      }
                      $scope.evento.lat = lat;
                      $scope.evento.lng = long;
                      // $scope.evento.lat = position.coords.latitude;
                      // $scope.evento.lng = position.coords.longitude;
                      infowindow.setContent(results[0].formatted_address);
                      console.log($scope.evento.endereco);
                      console.log($scope.evento.cidade);
                      console.log($scope.evento.lng);
                      console.log($scope.evento.lat);
                      //infowindow.setContent(results[0].address_components[2].long_name);
                      infowindow.open(map, marker);
                      setTimeout(function () { infowindow.close(); }, 5000);
                    } else {
                      window.alert('Resultado não encontrado');
          }
        } else {
          window.alert('Ocorreu uma falha doida :' + status);
                  }
                });


            google.maps.event.addListener(marker, "dragstart", function (event) {
               marker.setAnimation(3); // raise
            });

            google.maps.event.addListener(marker, "dragend", function (event) {
               marker.setAnimation(4); // raise
            });

            marker.addListener('dragend', handleEvent);
            google.maps.event.addListener(map, 'click', function(e) {
              
                markers.forEach(function(marker) {
                  marker.setMap(null);
                });
                markers = [];

                placeMarker(e.latLng, map, marker);

            });

            function placeMarker(latlng, map, marker) {
                marker.setPosition(latlng);
                marker.setMap(map);
                map.panTo(latlng);
                $scope.evento.lat = latlng.lat();
                $scope.evento.lng = latlng.lng();
                geocoder.geocode({'location': latlng}, function(results, status) {
                  if (status === 'OK') {
                    if (results[1]) {
                      $scope.evento.nomelocal = results[0].address_components[0].long_name;
                      for(var i = 0;i<results[0].address_components.length;i++){
                        if(results[0].address_components[i].types[0] == "administrative_area_level_2"){
                          $scope.evento.cidade = results[0].address_components[i].long_name;
                          console.log($scope.evento.cidade)
                        }
                      }
                      $scope.evento.endereco = results[0].formatted_address;
                      infowindow.setContent(results[0].formatted_address);
                     
                      infowindow.open(map, marker);
                      setTimeout(function () { infowindow.close(); }, 5000);
                    } else {
                      window.alert('Resultado não encontrado');
          }
        } else {
          window.alert('Ocorreu uma falha doida :' + status);
                  }
                });
            };        

            function handleEvent(event) {
                $scope.evento.lat = event.latLng.lat();
                $scope.evento.lng = event.latLng.lng();

                              // GEOCODER INVERSO

                var geocoder = new google.maps.Geocoder;
                var infowindow = new google.maps.InfoWindow({
                                                              maxWidth: 200
                                                            });;    
            
                geocoder.geocode({'location': event.latLng}, function(results, status) {
                  if (status === 'OK') {
                    if (results[1]) {
                      $scope.evento.nomelocal = results[0].address_components[0].long_name;
                      for(var i = 0;i<results[0].address_components.length;i++){
                        if(results[0].address_components[i].types[0] == "administrative_area_level_2"){
                          $scope.evento.cidade = results[0].address_components[i].long_name;
                          console.log($scope.evento.cidade)
                        }
                      }
                      $scope.evento.endereco = results[0].formatted_address;
                      // console.log($scope.evento.endereco);
                      // console.log($scope.evento.cidade);
                      // console.log($scope.evento.lng);
                      // console.log($scope.evento.lat);
                      infowindow.setContent(results[0].formatted_address);
                     
                      infowindow.open(map, marker);
                      setTimeout(function () { infowindow.close(); }, 5000);
                    } else {
                      window.alert('Resultado não encontrado');
          }
        } else {
          window.alert('Ocorreu uma falha doida :' + status);
                  }
                });
            }

                              // GEOCODER INVERSO

                

                
            
                    //        SEARCHBOX

            var input = document.getElementById('pac-input');
            var searchBox = new google.maps.places.SearchBox(input);
        //map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);

        // Bias the SearchBox results towards current map's viewport.
            map.addListener('bounds_changed', function() {
                searchBox.setBounds(map.getBounds());
            });

            var markers = [];
        // Listen for the event fired when the user selects a prediction and retrieve
        // more details for that place.
            searchBox.addListener('places_changed', function() {
                var places = searchBox.getPlaces();

                if (places.length == 0) {
                  return;
                }

                // Clear out the old markers.
                markers.forEach(function(marker) {
                  marker.setMap(null);
                });
                markers = [];

                // For each place, get the icon, name and location.
                var bounds = new google.maps.LatLngBounds();
                places.forEach(function(place) {
                  if (!place.geometry) {
                    console.log("Returned place contains no geometry");
                    return;
                  }
                  markers.push(new google.maps.Marker({
                    map: map,
                    // icon: icon,
                    title: place.name,
                    position: place.geometry.location
                  }));

                  $scope.evento.nomelocal = place.name;
                  $scope.evento.endereco = place.formatted_address;
                  for(var i = 0;i<place.address_components.length;i++){
                    //console.log(place.address_components[i].types[0])
                    if(place.address_components[i].types[0] == "administrative_area_level_2"){
                      $scope.evento.cidade = place.address_components[i].long_name;
                      console.log($scope.evento.cidade)
                    }
                  }
                  $scope.evento.lat = place.geometry.location.lat();
                  $scope.evento.lng = place.geometry.location.lng();
                  if (place.geometry.viewport) {
                    // Only geocodes have viewport.
                    bounds.union(place.geometry.viewport);
                  } else {
                    bounds.extend(place.geometry.location);
                  }
                });
                map.fitBounds(bounds);
            });
            $scope.map = map;  
             
        }, function(err) {
            console.log(err.code);
            console.log(err.message);
        });




  });


    $scope.getCriar = function(evento) {
      formEventoEditahome.updateForm($scope.evento);
      $state.go('tabsController.EditaEEAPart1');
    }

}])

.controller('EditaEEAPart3Ctrl', ['$scope', '$stateParams', '$state', 'formEventoEditahome', 'formItem', '$ionicPopup', 'formUser', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $state, formEventoEditahome, formItem, $ionicPopup, formUser) {
  $scope.evento = {};
  $scope.evento = formEventoEditahome.getForm();
  //$scope.eventorepete = formEvento.getForm().comentario;
  $scope.user = formUser.getForm();
  
  if($scope.user.genero == "fem"){
    $scope.femin = true;
  }else{
    $scope.femin = false;
  }


  if($scope.evento.dificuldade == "Não importa"){
    $scope.evento.dificuldaden = 1;
  }
  if($scope.evento.dificuldade == "Fácil"){
    $scope.evento.dificuldaden = 2;
  }
  if($scope.evento.dificuldade == "Moderado"){
    $scope.evento.dificuldaden = 3;
  }
  if($scope.evento.dificuldade == "Difícil"){
    $scope.evento.dificuldaden = 4;
  }

  $scope.ch = function(){
    if($scope.evento.dificuldaden == 1){
      $scope.evento.dificuldade = "Não importa";
    }
    if($scope.evento.dificuldaden == 2){
      $scope.evento.dificuldade = "Fácil";
    }
    if($scope.evento.dificuldaden == 3){
      $scope.evento.dificuldade = "Moderado";
    }
    if($scope.evento.dificuldaden == 4){
      $scope.evento.dificuldade = "Difícil";
    }
  }

  var header = document.getElementById("barpor");
  var btns = header.getElementsByClassName("btnpor");
  for (var i = 0; i < btns.length; i++) {
    btns[i].addEventListener("click", function() {
      var current = document.getElementsByClassName("actr");
      current[0].className = current[0].className.replace(" actr", "");
      this.className += " actr";
    });
  }
  // $scope.evento.auxpmax = $scope.evento.pmax;
  // $scope.mudamax = function() {
  //   if (!$scope.evento.pmax) {
  //     var alertPopup = $ionicPopup.alert({
  //     title: 'Register failed!',
  //     template: 'Favor preencher todos os campos'
  //   });
  //   }else{    
  //     if (parseInt($scope.evento.pmax) < parseInt($scope.evento.pmin)) {
  //       var alertPopup = $ionicPopup.alert({
  //               title: 'Matematimatematica',
  //               template: 'Máximo de pessoas nao pode ser maior que mínino xD'
  //             });
  //     }else{
  //       if (parseInt($scope.evento.pmax) >= 50) {
  //         var alertPopup = $ionicPopup.alert({
  //                 title: 'Muuuuita gente',
  //                 template: 'Limite máximo de pessoas para um evento é 50 personas'
  //               });
  //       }else{
  //         $scope.evento.pmax = $scope.evento.auxpmax;
  //       }
  //     }
  //   }
  // };
  // $scope.evento.auxpmin = $scope.evento.pmin;
  // $scope.mudamin = function() {
  //   if (!$scope.evento.pmin) {
  //     var alertPopup = $ionicPopup.alert({
  //     title: 'Register failed!',
  //     template: 'Favor preencher todos os campos'
  //   });
  //   }else{    
  //     if (parseInt($scope.evento.pmin)<=1) {
  //       var alertPopup = $ionicPopup.alert({
  //               title: '=/',
  //               template: 'Não da pra fazer um evento só com você né'
  //             });
  //     }else{
  //       $scope.evento.pmin = $scope.evento.auxpmin;
  //     }
  //   }
  // };

  $scope.pessoa = function() {$scope.evento.precopor = 1;};
  $scope.hora = function() {$scope.evento.precopor = 2;};

  $scope.getCriar = function(evento) {
  var palavrasnaousar = ["ALIAMBA", "ANUS", "BAGULIO"
      , "BANZA", "BARRUFO", "BECK", "BEQUE", "BOCETA"
      , "BOLAGATO", "BOQUETE", "BOLCAT", "BOSSETA", "BOSTANA", "BREXA", "BRIOCO", "BRONHA", "BUCA", "BUCETA"
      , "BUSSETA", "CANABIS", "CANNABIS", "CARALHO"
      , "CASSETA", "CASSETE", "CHECHECA", "CHERECA", "CHIBUMBA", "CHIBUMBO", "CHOTA", "CHOCHOTA", "CHUPADA", "CHUPADO", "CLITORIS"
      , "COCAINA", "C+"
      , "C*", "CURALHO", "CUZAO", "CUZUDA", "CUZUDO", "CUZÃO", "ESPORRADA", "ESPORRADO", "ESPORRO", "estupro"
      , "FELACAO", "FELACÃO", "FODA", "FODAO", "FODÃO", "FODAUM", "FODE", "FODIDA", "FODIDO", "FORNICA", "FUDENDO", "FUDECÃO", "FUDECAO"
      , "FUDIDA", "FUDIDO", "GRELINHO", "GRELO", "ISCROTA", "ISCROTO", "MACONHA", "MASTURBA", "MASTURBAÇÃO", "MASTURBACÃO", "MASTURBACAO"
      , "PENIS", "PEN1S", "PENES", "PENIZ", "PICA", "PIROCA", "PIRU", "PORRA", "POURRA", "PROSTIBULO", "PUTA", "PUNHETA", "PUTO"
      , "RABAO", "TESTUDA", "TESTUDO", "VAGABUNDA", "VAGINA", "VIADO", "VIADAO", "VIADÃO", "XAVASCA", "XERERECA", "XEXECA", "XOTA"
      , "XOCHOTA", "XOXOTA", "XANA", "XANINHA", "MDMA", "VSF", "TNC", "FDP", "CRACK"];
      var error = 0; 
      for (var i = 0; i < palavrasnaousar.length; i++) {
        var res2 = $scope.evento.descricao.split("_") ;
        if(res2.length>1){
          for(var w = 0; w < res2.length; w++){
            var val = palavrasnaousar[i].toLowerCase();
            if ((res2[w].toLowerCase()).indexOf(val.toString()) > -1) {  
              error = error + 1;  
            }
          }
        }else{
          var val = palavrasnaousar[i].toLowerCase();  
          if (($scope.evento.descricao.toLowerCase()).indexOf(val.toString()) > -1) {  
            error = error + 1;  
          }
        }
        var res3 = $scope.evento.descricao.split(" ") ;
        if(res3.length>1){
          for(var w = 0; w < res3.length; w++){
            var val = palavrasnaousar[i].toLowerCase();
            if ((res3[w].toLowerCase()).indexOf(val.toString()) > -1) {  
              error = error + 1;  
            }
          }
        }else{
          var val = palavrasnaousar[i].toLowerCase();  
          if (($scope.evento.descricao.toLowerCase()).indexOf(val.toString()) > -1) {  
            error = error + 1;  
          }
        }   
      } 
      if (error > 0) {  
          var alertPopup = $ionicPopup.alert({
                title: '（・о・；）',
                template: 'Que boquinha suja eim, usaste uma palavra inapropriada né'
              }); 
      }else{
        if (!$scope.evento.pmax || !$scope.evento.pmin) {
                    var alertPopup = $ionicPopup.alert({
                    title: 'Register failed!',
                    template: 'Favor preencher todos os campos'
                  });

        }else{
          if (parseInt($scope.evento.pmin)<=1) {
            var alertPopup = $ionicPopup.alert({
                    title: '=/',
                    template: 'Não da pra fazer um evento só com você né'
                  });
          }else{
            if (parseInt($scope.evento.pmax) <= parseInt($scope.evento.pmin)) {
              var alertPopup = $ionicPopup.alert({
                      title: 'Matematimatematica',
                      template: 'Mínimo de pessoas nao pode ser maior que máximo xD'
                    });
            }else{
              if (parseInt($scope.evento.pmax) >= 50) {
                var alertPopup = $ionicPopup.alert({
                        title: 'Muuuuita gente',
                        template: 'Limite máximo de pessoas para um evento é 50 personas'
                      });
              }else{
                if(evento.descricao){
                  formEventoEditahome.updateForm($scope.evento);
                  $state.go('tabsController.EditaEEAPart1');
                }else{
                  var alertPopup = $ionicPopup.alert({
                        title: '( ꒪Д꒪)ノ',
                        template: 'Escreva algo na descrição do evento para ajudar as pessoas a entenderem o que será feito'
                      }); 
                } 
              }
            }
          }
        }  
      }
  }


}])
   
.controller('EditaEEAPart4Ctrl', ['$scope', '$stateParams', '$state', 'formEvento', 'formUser','$ionicPopup', '$http', 'formtela2','formEditar', 'EventoService', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $state, formEvento, formUser, $ionicPopup, $http, formtela2, formEditar, EventoService) {
  $scope.evento = {};
  $scope.evento = formEvento.getForm();
  $scope.telaeditar = 1;
  $scope.pushnoti = {};
  $scope.confirmacao = 'aprovado';
  $scope.estado = '0';
  $scope.auxtela = formtela2.getForm();
  var res2 = [];
  var noti = {};
  console.log($scope.auxtela);
  EventoService.Gettags($scope.evento.idevento).then(function(tags) {
    for(var  i =0; i< tags.length;i++){
         res2[i] =  tags[i].tag;
        } 
  });

  $scope.mudanome = false;
  $scope.user = formUser.getForm();

  $scope.$on("$ionicView.enter", function(event, data){
    $scope.evento = {};
    $scope.evento = formEvento.getForm();
    $scope.telaeditar = 1;
    $scope.pushnoti = {};
    $scope.confirmacao = 'aprovado';
    $scope.estado = '0';
    $scope.auxtela = formtela2.getForm();
    var res2 = [];
    var noti = {};
    console.log($scope.auxtela);
    EventoService.Gettags($scope.evento.idevento).then(function(tags) {
      for(var  i =0; i< tags.length;i++){
           res2[i] =  tags[i].tag;
          } 
    });
    $scope.mudanome = false;
    $scope.user = formUser.getForm();
    if ($scope.telaeditar == 1) {
      $scope.mudanome = true;
     }
    $scope.auxtela = formtela2.getForm();
    if ($scope.auxtela == 1) {
      $state.go('tabsController.EditaEEAPart1');
    }
  });

  $scope.getCriar = function(evento) {
    if (!$scope.evento.pmax || !$scope.evento.pmin) {
                  var alertPopup = $ionicPopup.alert({
                  title: 'Register failed!',
                  template: 'Favor preencher todos os campos'
                });

       }else{
        if (parseInt($scope.evento.pmin)<=1) {
          var alertPopup = $ionicPopup.alert({
                  title: '=/',
                  template: 'Não da pra fazer um evento só com você né'
                });
        }else{
          if (parseInt($scope.evento.pmax) < parseInt($scope.evento.pmin)) {
            var alertPopup = $ionicPopup.alert({
                    title: 'Matematimatematica',
                    template: 'Mínimo de pessoas nao pode ser maior que máximo xD'
                  });
          }else{
        if (parseInt($scope.evento.pmax) >= 50) {
                var alertPopup = $ionicPopup.alert({
                        title: 'Muuuuita gente',
                        template: 'Limite máximo de pessoas para um evento é 50 personas'
                      });
              }else{
          if ($scope.telaeditar == 1) {
            console.log('oi');
           EventoService.atualizarevento($scope.evento).then(function(msg){
           var alertPopup = $ionicPopup.alert({
                    title: 'ʕ•ᴥ•ʔ',
                    template: msg
                  });
                     alertPopup.then(function(){
                      EventoService.GetParticipantes($scope.evento.idevento).then(function(items) {
                  $scope.msgnoti = 'O evento: '+$scope.evento.nomeevento +' foi mudado'
                           for (var i = 0; i < items.length; i++) {
                            if ($scope.user.iduser != items[i].iduser) {
                                  noti.recebeusername = items[i].username;
                                  noti.recebe = items[i].iduser;
                                  noti.envia = $scope.user.iduser;
                                  noti.tipo = 4;
                                  noti.nomeevento = $scope.evento.nomeevento;
                                  EventoService.VerificaNotificacao(noti).then(function(res) {
                                    console.log(res);
                                    if(res){
                                      $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : $scope.msgnoti, 
                                            idevento : $scope.evento.idevento,
                                            nomeevento : $scope.evento.nomeevento,
                                            id_user_envia : $scope.user.iduser,
                                            username_envia : $scope.user.username,
                                            apelido_envia : $scope.aux.apelido,
                                            tipo : '4',    //update no evento
                                            id_user_recebe : noti.recebe}).then(function (res){
                                           $scope.response = res.data;
                                           console.log($scope.response.msg)
                                      });
                                      EventoService.getusuario2(noti.recebeusername).then(function(user) {
                                        $scope.pushnoti.titulo =  'Mudanças!' ;
                                        $scope.pushnoti.msg = $scope.msgnoti;
                                        $scope.pushnoti.token = user.devicetoken;
                                          EventoService.MandaPushNoti($scope.pushnoti);
                                      } );
                                    }
                                  });
                                }
                          }
                         })
                           $state.go('tabsController.eventosAbertos');
                      })
                }, function(errMsg) {
                  var alertPopup = $ionicPopup.alert({
                    title: 'Register failed!',
                    template: errMsg
                  });
                })


       
                          /// AQUI TEMOS QUE COMPARAR SE HOUVE INCLUSAO DE UMA TAG NOVA
          if( $scope.evento.tags!=''){
                var res = $scope.evento.tags.split(" ") ;
                var array3 = res.filter(function(obj) { return res2.indexOf(obj) == -1; });
                  for (var i = 0; i<array3.length;i++){
                    if(array3[i][0]!='#'){
                      array3[i]= '#' + array3[i];
                    }
                    var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criartag.php';
                    $http.post(link, {idevento : $scope.evento.idevento, 
                                      tag : array3[i]});
                    }
                  }
          }else{
              $ionicPopup.prompt({
                  title: 'Qual nome devo dar?',
                  template: 'Não vamos esquecer de dar nomes aos bois',
                 inputType: 'text',
                 inputPlaceholder: ' Nome legal'
               }).then(function(nomeevento) {
                $scope.evento.nomeevento = nomeevento;
                  console.log('Nome do evento é', nomeevento);
               
         if (nomeevento && nomeevento !='' && nomeevento !=' ') {
          var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarevento.php';
          $http.post(link, {nomeevento : $scope.evento.nomeevento, 
                        duracao : $scope.evento.duracao,
                        diainicio : $scope.evento.diainicio,
                        semana : $scope.evento.semana,
                        diafim : $scope.evento.diafim,
                        dialimiteconfirmacao: $scope.evento.dialimiteconfirmacao,
                        pmin : $scope.evento.pmin, 
                        pmax : $scope.evento.pmax,
                        patual : $scope.evento.patual, 
                        adm : $scope.user.iduser,
                        admusername : $scope.user.username,
                        admapelido : $scope.user.apelido,
                        preco : $scope.evento.preco,
                        precopor : $scope.evento.precopor, 
                        nomelocal : $scope.evento.nomelocal,
                        endereco : $scope.evento.endereco,
                        estado : '0',
                        cidade : $scope.evento.cidade,
                        lat : $scope.evento.lat,
                        lng : $scope.evento.lng,
                        dificuldade :$scope.evento.dificuldade,
                        genero : $scope.evento.genero,
                        descricao : $scope.evento.descricao}).then(function (res){
          $scope.responsecriado = res.data;
          
                /// FAÇO O UPDATE DAS PENALIDADES QUE ME FODEM MATANDO A PENALIDADE RED 

          // if($scope.ic.red >=3){
          //   $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpenalidades.php", {idpenalidade : $scope.ic.idred[0]});
          //   $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpenalidades.php", {idpenalidade : $scope.ic.idred[1]});
          //   $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpenalidades.php", {idpenalidade : $scope.ic.idred[2]});
          //   console.log('Matei a penalidade RED');
          // }
          //     /// FAÇO O UPDATE DAS PENALIDADES QUE ME FODEM E CRIO ANTI RED DE CRIAÇÃO (TIPOPENALIDADE = 5)

          // if($scope.ic.black >=3){
          //     /// FAÇO O UPDATE DAS PENALIDADES QUE ME FODEM MATANDO A PENALIDADE BLACK    
          //   if($scope.ic.antiblack >= 3){
          //     $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpenalidades.php", {idpenalidade : $scope.ic.idblack[0]});
          //     $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpenalidades.php", {idpenalidade : $scope.ic.idblack[1]});
          //     $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpenalidades.php", {idpenalidade : $scope.ic.idblack[2]});
          //     $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpenalidades.php", {idpenalidade : $scope.ic.idantiblack[0]});
          //     $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpenalidades.php", {idpenalidade : $scope.ic.idantiblack[1]});
          //     $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpenalidades.php", {idpenalidade : $scope.ic.idantiblack[2]});
          //     console.log('Matei a penalidade BLACK');
          //   }else{
          //     /// CRIO O ANTIRED (TIPOPENALIDADE = 5)
          //     $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/penalidade.php' , {iduser : $scope.user.iduser,
          //                                                                 idevento : '42',
          //                                                                 username : $scope.user.username,
          //                                                                 tipopenalidade : '5'});
          //     console.log('Criou antiRED do BLACK');
          //   }

          // }

          if ($scope.responsecriado.success == true) {
              // console.log($scope.responsecriado.last);
              // console.log($scope.user.iduser);
              // console.log($scope.evento.nomeevento);
              // console.log($scope.confirmacao);
              // console.log($scope.evento.estado);
              if( $scope.evento.tags!=''){
            var res = $scope.evento.tags.split(" ") ;
             var array3 = res.filter(function(obj) { return res2.indexOf(obj) == -1; });
              for (var i = 0; i<array3.length;i++){
                var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/criartag.php';
                  $http.post(link, {idevento : $scope.responsecriado.last, 
                                    tag : array3[i]})
                 }
               }

            var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/irevento.php';
                $http.post(link, {idevento : $scope.responsecriado.last, 
                                  iduser : $scope.user.iduser,
                                  idadm : $scope.user.iduser, 
                                  admusername : $scope.user.username,
                                  username : $scope.user.username,
                                  borda : $scope.user.borda,
                                  apelido : $scope.user.apelido,
                                  profilepic : $scope.user.profilepic,
                                  devicetoken : $scope.user.devicetoken,
                                  diainicio : $scope.evento.diainicio,
                                  confirmacao : $scope.confirmacao,
                                  nomeevento :  $scope.evento.nomeevento,
                                  //eventopic : $scope.evento.eventopic, 
                                  estado : $scope.estado}).then(function (res){
                $scope.response = res.data;
                console.log($scope.response);
                  if ($scope.response.success == true) {
                      var alertPopup = $ionicPopup.alert({
                    title: 'Parabéns',
                    template: $scope.responsecriado.msg
                  }); 
                      alertPopup.then(function(){
                      formtela2.updateForm(1);
                      $scope.evento = {};
                      formEvento.updateForm($scope.evento);
                       $state.go('tabsConteroller.eventosAbertos');
                     })
                    }else{
                      var alertPopup = $ionicPopup.alert({
                    title: 'Ocorreu uma falha',
                    template: $scope.responsecriado.msg
                  });
                      alertPopup.then(function(){
                      $state.go('tabsController.eventosAbertos');
                     })
                    }
                  })
                }
          });

         }else{console.log('dasd');}
      });
          }
 }
       
        }}

       }
  }

}])

 