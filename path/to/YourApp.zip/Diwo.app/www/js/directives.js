angular.module('app.directives', [])

.directive('backImg', function($timeout){
  return function(scope, element, attrs){

    $timeout(function () {
      var url = attrs.backImg;
      var content = element.find('a');
      content.css({
        'background-image': 'img/starsilver.png',
        'background-size' : 'cover'
      });

    });

  };
});

