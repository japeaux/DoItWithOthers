angular.module('app.services', [])

.service('formItem', function() {
 return {
   item: {},
   getForm: function() {
     return this.item;
   },
   updateForm: function(item) {
     this.item = item;
   }
 }
})

.service('formCodigo', function() {
 return {
   item: {},
   getForm: function() {
     return this.item;
   },
   updateForm: function(item) {
     this.item = item;
   }
 }
})

.service('formvimdofiltro', function() {
 return {
   item: {},
   getForm: function() {
     return this.item;
   },
   updateForm: function(item) {
     this.item = item;
   }
 }
})

.service('formvimdofiltroperfil', function() {
 return {
   item: {},
   getForm: function() {
     return this.item;
   },
   updateForm: function(item) {
     this.item = item;
   }
 }
})

.service('formpontos', function() {
 return {
   pontos: {},
   getPontos: function() {
     return this.pontos;
   },
   updatePontos: function(pontos) {
     this.pontos = pontos;
   }
 }
})

.service('formEditar', function() {
 return {
   editar: {},
   getForm: function() {
     return this.editar;
   },
   updateForm: function(editar) {
     this.editar = editar;
   }
 }
})

.service('formtela', function() {
 return {
   tela: {},
   getForm: function() {
     return this.tela;
   },
   updateForm: function(tela) {
     this.tela = tela;
   }
 }
})

.service('formtelaStalkear', function() {
 return {
   tela: {},
   getForm: function() {
     return this.tela;
   },
   updateForm: function(tela) {
     this.tela = tela;
   }
 }
})


.service('formtelaCriar', function() {
 return {
   tela: {},
   getForm: function() {
     return this.tela;
   },
   updateForm: function(tela) {
     this.tela = tela;
   }
 }
})

.service('formtela2', function() {
 return {
   tela: {},
   getForm: function() {
     return this.tela;
   },
   updateForm: function(tela) {
     this.tela = tela;
   }
 }
})

.service('formtelanoti', function() {
 return {
   tela: {},
   getForm: function() {
     return this.tela;
   },
   updateForm: function(tela) {
     this.tela = tela;
   }
 }
})

.service('formtipologin', function() {
 return {
   tela: {},
   getForm: function() {
     return this.tela;
   },
   updateForm: function(tela) {
     this.tela = tela;
   }
 }
})

.service('formEvento', function() {
 return {
   evento: {},
   getForm: function() {
     return this.evento;
   },
   updateForm: function(evento) {
     this.evento = evento;
   }
 }
})

.service('formEventoPerfil', function() {
 return {
   evento: {},
   getForm: function() {
     return this.evento;
   },
   updateForm: function(evento) {
     this.evento = evento;
   }
 }
})

.service('formEventoEdita', function() {
 return {
   evento: {},
   getForm: function() {
     return this.evento;
   },
   updateForm: function(evento) {
     this.evento = evento;
   }
 }
})

.service('formEventoEditahome', function() {
 return {
   evento: {},
   getForm: function() {
     return this.evento;
   },
   updateForm: function(evento) {
     this.evento = evento;
   }
 }
})

.service('formEventoEditaperfil', function() {
 return {
   evento: {},
   getForm: function() {
     return this.evento;
   },
   updateForm: function(evento) {
     this.evento = evento;
   }
 }
})

.service('formEventoAbertosTab', function() {
 return {
   evento: {},
   getForm: function() {
     return this.evento;
   },
   updateForm: function(evento) {
     this.evento = evento;
   }
 }
})

.service('formEventoCriar', function() {
 return {
   evento: {},
   getForm: function() {
     return this.evento;
   },
   updateForm: function(evento) {
     this.evento = evento;
   }
 }
})

.service('formOutro', function() {
 return {
   outro: {},
   getForm: function() {
     return this.outro;
   },
   updateForm: function(outro) {
     this.outro = outro;
   }
 }
})

.service('formOutroPerfilFinal', function() {
 return {
   outro: {},
   getForm: function() {
     return this.outro;
   },
   updateForm: function(outro) {
     this.outro = outro;
   }
 }
})


.service('formStalker', function() {
 return {
   outro: {},
   getForm: function() {
     return this.outro;
   },
   updateForm: function(outro) {
     this.outro = outro;
   }
 }
})

.service('formUser', function() {
 return {
   user: {},
   getForm: function() {
     return this.user;
   },
   updateForm: function(user) {
     this.user = user;
   }
 }
})

.service('formLoc', function() {
 return {
   loc: {},
   getForm: function() {
     return this.loc;
   },
   updateForm: function(loc) {
     this.loc = loc;
   }
 }
})

.service('formAux', function() {
 return {
   aux: {},
   getAux: function() {
     return this.aux;
   },
   updateAux: function(aux) {
     this.aux = aux;
   }
 }
})
// .service('UserService', function() {
//   // For the purpose of this example I will store user data on ionic local storage but you should save it on a database
//   var setUser = function(user_data) {
//     window.localStorage.starter_facebook_user = JSON.stringify(user_data);
//   };
//   var getUser = function(){
//     return JSON.parse(window.localStorage.starter_facebook_user || '{}');
//   };
//   return {
//     getUser: getUser,
//     setUser: setUser
//   };
// })


.factory('EventoService', function($http, $q) {
    var BASE_URL = "http://ec2-3-84-65-68.compute-1.amazonaws.com/feed.php";
    var items = [];
    var nextUrl = 0;   
    var NewInsta = 0;
    var nextUrlCriados = 0;   
    var NewInstaCriados = 0;  
    var link = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/api2.php';
    var link2 = 'http://ec2-3-84-65-68.compute-1.amazonaws.com/api.php';
    var uemail = '' ;
    var ft2 = 0;
    var ic = {};
    var finalizadocomnota = {};
    var ux1 = 0;
    var ux2 = 0;
    var comments = {};
    var k = 0;  
    var p =0;
    var iduser;
    var idevento;
    var username;
    var black = 0;
    var yellow = 0;
    var red = 0;
    var followbutton;
    var aux2eventos = 0;
    var volta = [];
    var evts={};
    var people = {};
    var fefe ;
    var dist ={};
    var nota = [];
    var nomeevento = [];


    return {
      GetFeed: function(user) {
        var hjdate = new Date(); 
        var hjdate_date = (hjdate.getDate()<10?'0':'') + hjdate.getDate();
        var hjdate_month = (hjdate.getMonth()<10?'0':'') + (hjdate.getMonth() + 1); 
        var hjdate_year = hjdate.getFullYear();
        var hjdateh2 = (hjdate.getHours()<10?'0':'') + hjdate.getHours();
        var hjdatem2 = (hjdate.getMinutes()<10?'0':'') + hjdate.getMinutes();
        var hj = hjdate_year + "-" + hjdate_month + "-" + hjdate_date+ ' '+hjdateh2 + ':' + hjdatem2 + ':00';
        hj = hj.toLocaleString();
        return $http.post(BASE_URL, {vezes : 0,
                                     hj : hj, 
                                     iduser :user.iduser,
                                     genero : user.genero,
                                     northlat : user.northlat,
                                     southlat : user.southlat,
                                     eastlng : user.eastlng,
                                     westlng : user.westlng}).then(function(response) {
          items = response.data[0];
          console.log('Aqui' ,user.northlat ,user.southlat  ,  user.eastlng,user.westlng);
          //console.log(response.data[0].idevento);
          nextUrl = response.data[0][items.length-1].diainicio;
          NewInsta = response.data[0][0].diainicio;
         // console.log(nextUrl, NewInsta);
          var hj = new Date();
          var hjl = new Date();
          var currentdate = new Date(); 
          var curr_date = (currentdate.getDate()<10?'0':'') + currentdate.getDate();
          var curr_month = (currentdate.getMonth()<10?'0':'') + (currentdate.getMonth() + 1); //Months are zero based
          var curr_year = currentdate.getFullYear();
          var h2 = (currentdate.getHours()<10?'0':'') + currentdate.getHours();
          var m2 = (currentdate.getMinutes()<10?'0':'') + currentdate.getMinutes();

          var zone = [];
          var faltatempo = [];
          var ft = 0;
          if(items!='E'){
            for(var i = 0 ; i<items.length ; i++){
              hj = items[i].diainicio.valueOf();
              var ano = (hj[0]+hj[1]+hj[2]+hj[3]).valueOf()-curr_year;
              var mes = (hj[5]+hj[6]).valueOf()-curr_month;
              var dia = (hj[8]+hj[9]).valueOf()-curr_date;
              var h = (hj[11]+hj[12]).valueOf()-h2;
              var m = (hj[14]+hj[15]).valueOf()-m2;
              

              var hjf =items[i].diafim.valueOf();
              items[i].dia =  (hj[8]+hj[9]).valueOf()+'/'+(hj[5]+hj[6]).valueOf()+'       ';
              items[i].hora = (hj[11]+hj[12]).valueOf()+':'+(hj[14]+hj[15]).valueOf() +'-'+(hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf() ;


              hjl = items[i].dialimiteconfirmacao.valueOf();
              var ano5 = (hjl[0]+hjl[1]+hjl[2]+hjl[3]).valueOf()-curr_year;
              var mes5 = (hjl[5]+hjl[6]).valueOf()-curr_month;
              var dia5 = (hjl[8]+hjl[9]).valueOf()-curr_date;
              var h5 = (hjl[11]+hjl[12]).valueOf()-h2;
              var m5 = (hjl[14]+hjl[15]).valueOf()-m2;


              zone[i] = 'green';
              if(ano5 == 0 && mes5 == 0 && dia5 == 0 && ((h5 == 1 && m5<30 && m5>0)||(h5==0 && m5 > 30)|| (h5==1 && m5>-30))){
                zone[i] = 'yellow';
              }
              if(ano5 == 0 && mes5 == 0 && (dia5 < 0 || (dia5==0 && h5 <= 0 && m5<=0))){
                zone[i] = 'red';
              }

              var radlat1 = Math.PI * user.lat/180
              var radlat2 = Math.PI * items[i].lat.valueOf()/180
              var theta = user.long-items[i].lng.valueOf()
              var radtheta = Math.PI * theta/180
              dist[i] = Math.sin(radlat1) * Math.sin(radlat2) + Math.cos(radlat1) * Math.cos(radlat2) * Math.cos(radtheta);
              if (dist[i] > 1) {
                dist[i] = 1;
              }
              dist[i] = Math.acos(dist[i])
              dist[i] = dist[i] * 180/Math.PI
              dist[i] = dist[i] * 60 * 1.1515
              dist[i] = dist[i] * 1.609344;

            items[i].dist = dist[i].toFixed(1);
            items[i].faltatempo = faltatempo[i];
            items[i].zone = zone[i];
            //console.log(ano, mes, dia , h, m, zone[i]);
            }
          }
          return items;

        });
      },

      GetFeedSemLogin: function(user) {
        //console.log(user.northlat, "to aqui", user.southlat, user.eastlng,user.westlng)
        return $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/feedsemlogin.php", {northlat : user.northlat,
                                     southlat : user.southlat,
                                     eastlng : user.eastlng,
                                     westlng : user.westlng}).then(function(response) {
          items = response.data;
          //console.log(response.data,"colto", items)
          
          var hj = new Date();
          var hjl = new Date();
          var currentdate = new Date(); 
          var curr_date = (currentdate.getDate()<10?'0':'') + currentdate.getDate();
          var curr_month = (currentdate.getMonth()<10?'0':'') + (currentdate.getMonth() + 1); //Months are zero based
          var curr_year = currentdate.getFullYear();
          var h2 = (currentdate.getHours()<10?'0':'') + currentdate.getHours();
          var m2 = (currentdate.getMinutes()<10?'0':'') + currentdate.getMinutes();

          var zone = [];
          var faltatempo = [];
          var ft = 0;
          //console.log(items)
          if(items!='E'){
            nextUrl = response.data[items.length-1].diainicio;
            NewInsta = response.data[0].diainicio;
            for(var i = 0 ; i<items.length ; i++){
              hj = items[i].diainicio.valueOf();
              var ano = (hj[0]+hj[1]+hj[2]+hj[3]).valueOf()-curr_year;
              var mes = (hj[5]+hj[6]).valueOf()-curr_month;
              var dia = (hj[8]+hj[9]).valueOf()-curr_date;
              var h = (hj[11]+hj[12]).valueOf()-h2;
              var m = (hj[14]+hj[15]).valueOf()-m2;
              

              var hjf =items[i].diafim.valueOf();
              items[i].dia =  (hj[8]+hj[9]).valueOf()+'/'+(hj[5]+hj[6]).valueOf()+'       ';
              items[i].hora = (hj[11]+hj[12]).valueOf()+':'+(hj[14]+hj[15]).valueOf() +'-'+(hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf() ;


              hjl = items[i].dialimiteconfirmacao.valueOf();
              var ano5 = (hjl[0]+hjl[1]+hjl[2]+hjl[3]).valueOf()-curr_year;
              var mes5 = (hjl[5]+hjl[6]).valueOf()-curr_month;
              var dia5 = (hjl[8]+hjl[9]).valueOf()-curr_date;
              var h5 = (hjl[11]+hjl[12]).valueOf()-h2;
              var m5 = (hjl[14]+hjl[15]).valueOf()-m2;


              zone[i] = 'green';
              if(ano5 == 0 && mes5 == 0 && dia5 == 0 && ((h5 == 1 && m5<30 && m5>0)||(h5==0 && m5 > 30)|| (h5==1 && m5>-30))){
                zone[i] = 'yellow';
              }
              if(ano5 == 0 && mes5 == 0 && (dia5 < 0 || (dia5==0 && h5 <= 0 && m5<=0))){
                zone[i] = 'red';
              }

              var radlat1 = Math.PI * user.lat/180
              var radlat2 = Math.PI * items[i].lat.valueOf()/180
              var theta = user.long-items[i].lng.valueOf()
              var radtheta = Math.PI * theta/180
              dist[i] = Math.sin(radlat1) * Math.sin(radlat2) + Math.cos(radlat1) * Math.cos(radlat2) * Math.cos(radtheta);
              if (dist[i] > 1) {
                dist[i] = 1;
              }
              dist[i] = Math.acos(dist[i])
              dist[i] = dist[i] * 180/Math.PI
              dist[i] = dist[i] * 60 * 1.1515
              dist[i] = dist[i] * 1.609344;

            items[i].dist = dist[i].toFixed(1);
            items[i].faltatempo = faltatempo[i];
            items[i].zone = zone[i];
            //console.log(ano, mes, dia , h, m, zone[i]);
            }
          }
          return items;

        });
      },


      Getranking: function() {
        return $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/ranking.php').then(function(response) {
          items = response.data[0];
          return items;

        });
      },


      Getfiltradotag: function(tag) {
        return $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/filtratag.php', {tag: tag.tag}).then(function(response) {
            items = response.data[0];
          return items;
        });
      },

      Getfiltradotag2: function(evento) {
        return $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/geteventofiltrado.php', {idevento: evento.idevento, iduser : evento.iduser}).then(function(response) {
          items = response.data[0];
          return items;
        });
      },

      Gettags: function(idevento) {
        //console.log(tag);
        return $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/gettags.php', {idevento: idevento}).then(function(response) {
          items = response.data[0];
          //console.log(items.nrow);
          return items;

        });
      },

      Getalltags: function() {
        //console.log(tag);
        return $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/getalltags.php').then(function(response) {
          items = response.data[0];
          //console.log(items.nrow);
          return items;

        });
      },

      Geteventoporid: function(evento) {
        // console.log(evento.idevento);
        // console.log(evento.iduser);
        return $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/getevento.php', {idevento: evento.idevento, iduser : evento.iduser}).then(function(response) {
          items = response.data[0];
          //console.log(response.data);
          return items;

        });
      },

      Geteventofiltrado: function(evento) {
        console.log(evento.preco, evento.genero, evento.northlat, evento.dificuldade);
        return $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/filtraevento.php', {preco: evento.preco,
                                                                            genero: evento.genero,
                                                                            northlat : evento.northlat,
                                                                            southlat : evento.southlat,
                                                                            dificuldade : evento.dificuldade,
                                                                            eastlng : evento.eastlng,
                                                                            westlng : evento.westlng}).then(function(response) {
          items = response.data;
          if(response.data == 'Error'){
            items=[];
          }
          console.log(items.length);
          return items;

        });
      },

      Getusers: function() {
        //console.log(nextUrl);
        return $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/getusers.php').then(function(response) {
          items = response.data[0];
          return items;

        });
      },


      Getcidades: function() {
        //console.log(nextUrl);
        return $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/getcidade.php').then(function(response) {
          items = response.data[0];
          return items;

        });
      },

      Getfiltradocidade: function(cidade) {
        //console.log(tag);
        return $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/filtracidade.php', {cidade: cidade}).then(function(response) {
          items = response.data;
          //console.log(items.nrow);
          return items;

        });
      },

      atualizarperfil2: function(user) {
      return $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarperfil.php' , user).then(function(result) {
        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/mudarprofilepicpessoaevento.php' , {iduser :user.iduser, 
                                                                  profilepic :  user.profilepic});
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/mudarapelidoevento.php' , {iduser :user.iduser, 
                                                                  apelido :  user.apelido});
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/mudarapelidopessoaevento.php' , {iduser :user.iduser, 
                                                                  apelido :  user.apelido});
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/mudarapelidoavaliacao.php' , {iduser :user.iduser, 
                                                                  apelido :  user.apelido});
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/mudarapelidochat.php' , {iduser :user.iduser, 
                                                                  apelido :  user.apelido});
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/mudarapelidonotificacao.php' , {iduser :user.iduser, 
                                                                  apelido :  user.apelido});
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/mudarapelidofollow.php' , {iduser :user.iduser, 
                                                                  apelido :  user.apelido});
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/mudarapelidofollow2.php' , {iduser :user.iduser, 
                                                                  apelido :  user.apelido});
          //console.log(result.data.msg);

          return(result.data.msg);  
          });
       },



      atualizarperfil: function(user) {
      return $q(function(resolve, reject) {
        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarperfil.php' , user).then(function(result) {
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/mudarapelidoevento.php' , {iduser :user.iduser, 
                                                                  apelido :  user.apelido,
                                                                  username :  user.username});
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/mudarprofilepicpessoaevento.php' , {iduser :user.iduser, 
                                                                  profilepic :  user.profilepic});
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/mudarapelidopessoaevento.php' , {iduser :user.iduser, 
                                                                  apelido :  user.apelido,
                                                                  username :  user.username});
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/mudarapelidoavaliacao.php' , {iduser :user.iduser, 
                                                                  apelido :  user.apelido,
                                                                  username :  user.username});
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/mudarapelidochat.php' , {iduser :user.iduser, 
                                                                  apelido :  user.apelido,
                                                                  username :  user.username});
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/mudarapelidonotificacao.php' , {iduser :user.iduser, 
                                                                  apelido :  user.apelido,
                                                                  username :  user.username});
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/mudarapelidofollow.php' , {iduser :user.iduser, 
                                                                  apelido :  user.apelido,
                                                                  username :  user.username});
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/mudarapelidofollow2.php' , {iduser :user.iduser, 
                                                                  apelido :  user.apelido,
                                                                  username :  user.username});
          //console.log(result.data.msg);
          if (result.data.success == true){
            resolve(result.data.msg);
            } else {
            reject(result.data.msg);
            }
          });
        });
       },

      atualizarpontos: function(user) {
      return $q(function(resolve, reject) {
        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpontos.php' , user).then(function(result) {
          //console.log(result.data.msg);
          if (result.data.success == true){
            resolve(result.data.msg);
            } else {
            reject(result.data.msg);
            }
          });
        });
       },

      atualizarevento: function(evento) {console.log(evento.diafim,"atualizarevento")
      return $q(function(resolve, reject) {
        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarevento.php' , {idevento : evento.idevento,
                                                                          nomeevento : evento.nomeevento,  
                                                                          duracao : evento.duracao,
                                                                          diainicio : evento.diainicio,
                                                                          semana : evento.semana,
                                                                          dialimiteconfirmacao : evento.dialimiteconfirmacao,
                                                                          diafim : evento.diafim,
                                                                          pmin : evento.pmin, 
                                                                          pmax : evento.pmax,
                                                                          patual : evento.patual,
                                                                          preco : evento.preco,
                                                                          precopor : evento.precopor, 
                                                                          nomelocal : evento.nomelocal,
                                                                          endereco : evento.endereco,
                                                                          estado : evento.estado,
                                                                          cidade : evento.cidade,
                                                                          lat : evento.lat,
                                                                          lng : evento.lng,
                                                                          dificuldade : evento.dificuldade,
                                                                          genero : evento.genero,
                                                                          eventopic : evento.eventopic,
                                                                          descricao : evento.descricao}).then(function(result) {
          console.log(result.data.msg);
          if (result.data.success == true){
             $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizardatapessoaevento.php' , {nomeevento : evento.nomeevento,
                                                                                    idevento : evento.idevento,
                                                                                    diainicio : evento.diainicio,
                                                                                    diafim :evento.diafim});
            resolve(result.data.msg);
            } else {
            reject(result.data.msg);
            }
          });
        });
       },

      GetParticipantes: function(aux) {
        //console.log(aux,"aux")
        return $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/participantes.php', {idevento : aux}).then(function(response) {
          items = response.data;
          //console.log(response.data.nrow);
         //console.log(response.data, "GetParticipantes");
         //console.log(items[0].nomeevento);
          return items;

        });
      },

      GetNotiOn: function(aux) {
        console.log(aux,"aux",aux.idevento,aux.iduser)
        return $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/minhanotion.php', {idevento : aux.idevento, iduser : aux.iduser}).then(function(response) {
          items = response.data.success;
          console.log(response.data.success, "GetNotiOn");
          return items;

        });
      },

      GetParticipantesNotifica: function(aux) {
        //console.log(aux,"aux")
        return $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/participantesnotifica.php', {idevento : aux}).then(function(response) {
          items = response.data;
          //console.log(response.data.nrow);
         //console.log(response.data, "GetParticipantes");
         //console.log(items[0].nomeevento);

          return items;

        });
      },
  
      GetParticipantes2: function(aux) {
      return $q(function(resolve, reject) {
        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/participantes.php' , {idevento : aux}).then(function(result) {
          //console.log(result.data.msg);
          if (!result.data.success){
            resolve(result.data);
            } else {
            reject(result.data.msg);
            }
          });
        });
       },


      GetParticipantesSemFav: function(aux) {
        return $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/participantessemfav.php', {idevento : aux}).then(function(response) {
          items = response.data;
          //console.log(response.data.nrow);
         //console.log(response.data);
         //console.log(items[0].nomeevento);

          return items;

        });
      },
      // GetParticipantesSemFav: function(aux) {
      // return $q(function(resolve, reject) {
      //   $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/participantessemfav.php' , {idevento : aux}).then(function(result) {
      //     //console.log(result.data.msg);
      //     if (result.data.success != false){
      //       resolve(result.data);
      //       } else {
      //       reject(result.data.msg);
      //       }
      //     });
      //   });
      //  },

      GetComentariosevento: function(aux) {
        return     $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/getcomentarioevento.php', {idevento : aux.idevento,
                                                                                        nomepessoaavaliada : aux.nomeevento}).then(function (response){
                                                            
          items = response.data;
          //console.log(response.data.length, "tamanho do array");
          if(items!='Error'){
            for(var i=0;i<items.length;i++){
              var h = items[i].datadecriacao[8]+items[i].datadecriacao[9] + "/" + items[i].datadecriacao[5]+items[i].datadecriacao[6] + "/" + items[i].datadecriacao[2]+items[i].datadecriacao[3];
              items[i].datacoment = h;
              //console.log(h)
            }
          }
          
         //console.log(response.data);
         //console.log(items[0].nomeevento);

          return items;

        });
      },

      GetComments2: function(aux) {
        return     $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/getcomentarios.php', {idpessoaavaliada : aux.iduser,
                                                                                  nomepessoaavaliada : aux.username}).then(function (response){
          comments = {};
          comments.chart =[];
          comments.mal =[];
          comments.ruins = {};
          comments.bons = {};
          comments.resto ={};
          comments.tudo ={};
          comments.tamanho;
          var Extrovertido = 0;
           var Introvertido = 0;
           var Realista = 0;
           var Curioso = 0;
           var Solidario = 0;
           var Racional = 0;
           var Organizado = 0;
           var Criativo = 0;
           var mal = 0;
           var bem = 0;
           
           //console.log(aux.iduser,  aux.username,response.data.success, 'GetComments2')
          if(response.data.success != false){                                                  
            ux1 = response.data.length;
            var recebidos = response.data;
          
            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/getcomentariosfeitos.php', {iduser : aux.iduser,
                                                                                nomeavaliador : aux.username}).then(function (feito){
              k = 0;                                                                   
              ux2 = feito.data.length;
              feitos = feito.data;
              if(feito.data=="error"){
                  
              }else{
                for(var e=0;e<ux1 ; e++){
                  if(recebidos[e].nota == '9'){
                    comments.ruins[mal] = recebidos[e];
                    comments.ruins[mal].achou = "Vacileiro";
                    var h = recebidos[e].datadecriacao[8]+recebidos[e].datadecriacao[9] + "/" + recebidos[e].datadecriacao[5]+recebidos[e].datadecriacao[6] + "/" + recebidos[e].datadecriacao[2]+recebidos[e].datadecriacao[3];
                    comments.ruins[mal].datacoment = h; 
                    mal ++;
                  }
                }
                var nota = 0;
                for(var i=0 ; i<ux2 ; i++){
                  for(var j=0;j<ux1 ; j++){
                    if (recebidos[j].nomepessoaavaliada == feitos[i].nomeavaliador && recebidos[j].nomeavaliador == feitos[i].nomepessoaavaliada && recebidos[j].idevento == feitos[i].idevento) {
                      //console.log(recebidos[j].nomepessoaavaliada , feitos[i].nomeavaliador , recebidos[j].nomeavaliador , feitos[i].nomepessoaavaliada , recebidos[j].idevento , feitos[i].idevento, i , j )  

                      comments.resto[k] = recebidos[j];
                        if(comments.resto[k].nota == '1'){
                          Extrovertido ++;
                          comments.resto[k].nota = Extrovertido;
                          comments.resto[k].achou = "extrovertido";
                          comments.bons[bem] = comments.resto[k];
                          comments.bons[bem].comentario = comments.resto[k].comentario;
                          comments.bons[bem].apelidoavaliador = comments.resto[k].apelidoavaliador;
                          comments.bons[bem].achou = "extrovertido"; 
                          var h = comments.resto[k].datadecriacao[8]+comments.resto[k].datadecriacao[9] + "/" + comments.resto[k].datadecriacao[5]+comments.resto[k].datadecriacao[6] + "/" + comments.resto[k].datadecriacao[2]+comments.resto[k].datadecriacao[3];
                          comments.bons[bem].datacoment = h; 
                          bem ++;
                        }
                        if(comments.resto[k].nota == '2'){
                          Introvertido ++;
                          comments.resto[k].nota = Introvertido;
                          comments.resto[k].achou = "introvertido";
                          comments.bons[bem] = comments.resto[k];
                          comments.bons[bem].comentario = comments.resto[k].comentario;
                          comments.bons[bem].apelidoavaliador = comments.resto[k].apelidoavaliador;
                          comments.bons[bem].achou = "introvertido"; 
                          var h = comments.resto[k].datadecriacao[8]+comments.resto[k].datadecriacao[9] + "/" + comments.resto[k].datadecriacao[5]+comments.resto[k].datadecriacao[6] + "/" + comments.resto[k].datadecriacao[2]+comments.resto[k].datadecriacao[3];
                          comments.bons[bem].datacoment = h; 
                          bem ++;
                        }
                        if(comments.resto[k].nota == '3'){
                          Realista ++;
                          comments.resto[k].nota = Realista;
                          comments.resto[k].achou = "realista";
                          comments.bons[bem] = comments.resto[k];
                          comments.bons[bem].comentario = comments.resto[k].comentario;
                          comments.bons[bem].apelidoavaliador = comments.resto[k].apelidoavaliador;
                          comments.bons[bem].achou = "realista"; 
                          var h = comments.resto[k].datadecriacao[8]+comments.resto[k].datadecriacao[9] + "/" + comments.resto[k].datadecriacao[5]+comments.resto[k].datadecriacao[6] + "/" + comments.resto[k].datadecriacao[2]+comments.resto[k].datadecriacao[3];
                          comments.bons[bem].datacoment = h; 
                          bem ++;
                        }
                        if(comments.resto[k].nota == '4'){
                          Curioso ++;
                          comments.resto[k].nota = Curioso;
                          comments.resto[k].achou = "curioso";
                          comments.bons[bem] = comments.resto[k];
                          comments.bons[bem].comentario = comments.resto[k].comentario;
                          comments.bons[bem].apelidoavaliador = comments.resto[k].apelidoavaliador;
                          comments.bons[bem].achou = "curioso"; 
                          var h = comments.resto[k].datadecriacao[8]+comments.resto[k].datadecriacao[9] + "/" + comments.resto[k].datadecriacao[5]+comments.resto[k].datadecriacao[6] + "/" + comments.resto[k].datadecriacao[2]+comments.resto[k].datadecriacao[3];
                          comments.bons[bem].datacoment = h; 
                          bem ++;
                        }
                        if(comments.resto[k].nota == '5'){
                          Solidario ++;
                          comments.resto[k].nota = Solidario;
                          comments.resto[k].achou = "solidário";
                          comments.bons[bem] = comments.resto[k];
                          comments.bons[bem].comentario = comments.resto[k].comentario;
                          comments.bons[bem].apelidoavaliador = comments.resto[k].apelidoavaliador;
                          comments.bons[bem].achou = "solidário"; 
                          var h = comments.resto[k].datadecriacao[8]+comments.resto[k].datadecriacao[9] + "/" + comments.resto[k].datadecriacao[5]+comments.resto[k].datadecriacao[6] + "/" + comments.resto[k].datadecriacao[2]+comments.resto[k].datadecriacao[3];
                          comments.bons[bem].datacoment = h; 
                          bem ++;
                        }
                        if(comments.resto[k].nota == '6'){
                          Racional ++;
                          comments.resto[k].nota = Racional;
                          comments.resto[k].achou = "racional";
                          comments.bons[bem] = comments.resto[k];
                          comments.bons[bem].comentario = comments.resto[k].comentario;
                          comments.bons[bem].apelidoavaliador = comments.resto[k].apelidoavaliador;
                          comments.bons[bem].achou = "racional"; 
                          var h = comments.resto[k].datadecriacao[8]+comments.resto[k].datadecriacao[9] + "/" + comments.resto[k].datadecriacao[5]+comments.resto[k].datadecriacao[6] + "/" + comments.resto[k].datadecriacao[2]+comments.resto[k].datadecriacao[3];
                          comments.bons[bem].datacoment = h; 
                          bem ++;
                        }
                        if(comments.resto[k].nota == '7'){
                          Organizado ++;
                          comments.resto[k].nota = Organizado;
                          comments.resto[k].achou = "organizado";
                          comments.bons[bem] = comments.resto[k];
                          comments.bons[bem].comentario = comments.resto[k].comentario;
                          comments.bons[bem].apelidoavaliador = comments.resto[k].apelidoavaliador;
                          comments.bons[bem].achou = "organizado"; 
                          var h = comments.resto[k].datadecriacao[8]+comments.resto[k].datadecriacao[9] + "/" + comments.resto[k].datadecriacao[5]+comments.resto[k].datadecriacao[6] + "/" + comments.resto[k].datadecriacao[2]+comments.resto[k].datadecriacao[3];
                          comments.bons[bem].datacoment = h; 
                          bem ++;
                        }
                        if(comments.resto[k].nota == '8'){
                          Criativo ++;
                          comments.resto[k].nota = Criativo; 
                          comments.resto[k].achou = "criativo";
                          comments.bons[bem] = comments.resto[k];
                          comments.bons[bem].comentario = comments.resto[k].comentario;
                          comments.bons[bem].apelidoavaliador = comments.resto[k].apelidoavaliador;
                          comments.bons[bem].achou = "criativo"; 
                          var h = comments.resto[k].datadecriacao[8]+comments.resto[k].datadecriacao[9] + "/" + comments.resto[k].datadecriacao[5]+comments.resto[k].datadecriacao[6] + "/" + comments.resto[k].datadecriacao[2]+comments.resto[k].datadecriacao[3];
                          comments.bons[bem].datacoment = h; 
                          bem ++;
                        }
                        var h = comments.resto[k].datadecriacao[8]+comments.resto[k].datadecriacao[9] + "/" + comments.resto[k].datadecriacao[5]+comments.resto[k].datadecriacao[6] + "/" + comments.resto[k].datadecriacao[2]+comments.resto[k].datadecriacao[3];
                        comments.resto[k].datacoment = h;
                      k++; 
                    }
                  }
                }
                // for(var te = 0;te<mal; te++){
                //   comments.resto[k] = comments.ruins[te];
                //   k++;
                // }
                var xdxd = 0;
                var ja = 0;
                var fe = mal;
                console.log(bem, "n bem", mal, "n mal", k)
                for(var by =0;by<k; by++){
                  if(mal==0){
                    comments.tudo[ja] = comments.resto[by];
                    ja++;
                  }
                  for(var ty = 0;ty<mal; ty++){
                    if(xdxd !=1){
                      //console.log(comments.resto[by].idavaliacao, "comments.resto[by].idavaliacao", comments.ruins[ty].idavaliacao, "comments.ruins[ty].idavaliacao")
                      if(comments.resto[by].idavaliacao.valueOf() > comments.ruins[ty].idavaliacao.valueOf()){
                        //console.log("conseguiu entrar aqui", comments.ruins[ty] , ty, comments.resto[by], by)
                         comments.tudo[ja] = comments.ruins[ty];
                         fe--;
                         xdxd = 1;
                         ja++;
                         comments.tudo[ja] = comments.resto[by];
                         ja++;
                      }else{
                        comments.tudo[ja] = comments.resto[by];
                        xdxd = 1;
                        ja++;
                      }
                    } 
                  }
                  xdxd = 0; 
                }
                for(var rt=0; rt<fe;rt++){
                  comments.tudo[ja] = comments.ruins[rt];
                  ja++;
                }


                comments.tamanho = k;
                comments.chart[0] = Extrovertido;
                comments.chart[1] = Introvertido;
                comments.chart[2] = Realista;
                comments.chart[3] = Curioso;
                comments.chart[4] = Solidario;
                comments.chart[5] = Racional;
                comments.chart[6] = Organizado;
                comments.chart[7] = Criativo;
                comments.mal[0] = mal + Extrovertido+Introvertido+Realista+Curioso+Solidario+Racional+Organizado+Criativo;
                comments.mal[1] = mal;
                comments.mal[2] = Extrovertido+Introvertido+Realista+Curioso+Solidario+Racional+Organizado+Criativo;

              }


                                // PARA MUDAR FRASE DEPOIS DE 3 AVALIÇÕES FEITAS
                if(aux.auxfrase>2){
                  var max = comments.chart[0];
                  var tipo = 1;
                  for (var i = 2; i < 8; i++) {
                    if (comments.chart[i] > max) {
                      tipo = i;
                      max = comments.chart[i];
                    }
                  }
                  //console.log("qtoooss",comments.chart[0], tipo
                  if(i == 8){
                    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/getfrase.php', {tipo : tipo}).then(function (fras){
                     //console.log("muda", max, tipo, fras.data[0].idfrase)
                      if(fras.data!="Error"){
                          comments.mal[3] = fras.data[0].frase;
                          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/zerarauxfrase.php', {frase : comments.mal[3], iduser : aux.iduser }).then(function (rrr){console.log("atulauza?",rrr.data.success)});
                          //console.log("muda", max, tipo, comments.mal[3])
                      }
                    });
                  }
                  //console.log("muda", max, tipo, comments.mal[3])
                }else{
                  comments.mal[3] = aux.frase;
                }
              //console.log( comments.tamanho , k, comments,'eqweqw', bem);
            });
          }

          return comments;

        });
      },

      GetComentarios: function(aux) {
        return     $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/getcomentarios.php', {idpessoaavaliada : aux.iduser,
                                                                                        nomepessoaavaliada : aux.username}).then(function (response){
                                                            
          items = response.data;
          //console.log(response.data.nrow);
         //console.log(response.data);
         //console.log(items[0].nomeevento);

          return items;

        });
      },

      GetComentariosfeitos: function(aux) {
        return     $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/getcomentariosfeitos.php', {iduser : aux.iduser,
                                                                                        nomeavaliador : aux.username}).then(function (response){
                                                            
          items = response.data;
          return items;

        });
      },

      GetComentariosDesseEventoPessoaAvaliou: function(aux) {
        //console.log( "iduser" , aux.stakeriduser, "nomepessoaavaliada :", aux.username, "idpessoaavaliada :" ,aux.iduser , "idevento :", aux.idevento)
        return     $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/getcomentariosdesseevento.php', {idpessoaavaliada : aux.iduser,
                                                                                                              idevento : aux.idevento,
                                                                                                              iduser : aux.stakeriduser,
                                                                                                              nomepessoaavaliada : aux.username}).then(function (response){
                                                            
          items = response.data;
          //console.log(response.data.success)
          //console.log(response.data.nrow);
         //console.log(response.data);
         //console.log(items[0].nomeevento);

          return items;

        });
      },

      AtualizaComentariosDesseEventoPessoaAvaliou: function(aux) {
        //console.log( "iduser" , aux.stakeriduser, "nomepessoaavaliada :", aux.username, "idpessoaavaliada :" ,aux.iduser , "idevento :", aux.idevento)
        return     $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizacomentariosdesseevento.php', {idpessoaavaliada : aux.iduser,
                                                                                                              idevento : aux.idevento,
                                                                                                              iduser : aux.stakeriduser,
                                                                                                              nomepessoaavaliada : aux.username}).then(function (response){
                                                            
          items = response.data;

          return items;

        });
      },

       GetComments3: function(aux) {
        return     $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/getavaliacoes.php', {idpessoaavaliada : aux.iduser,
                                                                                    nomepessoaavaliada : aux.username}).then(function (response){
          comments = {};
          comments.chart =[];
          comments.mal =[];
          comments.ruins = {};
          comments.bons = {};
          comments.resto ={};
          comments.tudo ={};
          comments.tamanho;
          var Extrovertido = 0;
          var Introvertido = 0;
          var Realista = 0;
          var Curioso = 0;
          var Solidario = 0;
          var Racional = 0;
          var Organizado = 0;
          var Criativo = 0;
          var mal = 0;
          var bem = 0;
           
           //console.log(aux.iduser,  aux.username,response.data.success, 'GetComments2')
          if(response.data.success != false){                                                  
            ux1 = response.data.length;
            var recebidos = response.data;
            k = 0;
            var nota = 0;
            comments.resto = recebidos;
            console.log(response.data.length)
            for(var k=0;k<ux1 ; k++){
              if(comments.resto[k].nota == '1'){
                Extrovertido ++;
                comments.resto[k].achou = "extrovertido";
                comments.bons[bem] = comments.resto[k];
                comments.bons[bem].comentario = comments.resto[k].comentario;
                comments.bons[bem].apelidoavaliador = comments.resto[k].apelidoavaliador;
                comments.bons[bem].achou = "extrovertido"; 
                var h = comments.resto[k].datadecriacao[8]+comments.resto[k].datadecriacao[9] + "/" + comments.resto[k].datadecriacao[5]+comments.resto[k].datadecriacao[6] + "/" + comments.resto[k].datadecriacao[2]+comments.resto[k].datadecriacao[3];
                comments.bons[bem].datacoment = h; 
                bem ++;
              }
              if(comments.resto[k].nota == '2'){
                Introvertido ++;
                comments.resto[k].achou = "introvertido";
                comments.bons[bem] = comments.resto[k];
                comments.bons[bem].comentario = comments.resto[k].comentario;
                comments.bons[bem].apelidoavaliador = comments.resto[k].apelidoavaliador;
                comments.bons[bem].achou = "introvertido"; 
                var h = comments.resto[k].datadecriacao[8]+comments.resto[k].datadecriacao[9] + "/" + comments.resto[k].datadecriacao[5]+comments.resto[k].datadecriacao[6] + "/" + comments.resto[k].datadecriacao[2]+comments.resto[k].datadecriacao[3];
                comments.bons[bem].datacoment = h; 
                bem ++;
              }
              if(comments.resto[k].nota == '3'){
                Realista ++;
                comments.resto[k].achou = "realista";
                comments.bons[bem] = comments.resto[k];
                comments.bons[bem].comentario = comments.resto[k].comentario;
                comments.bons[bem].apelidoavaliador = comments.resto[k].apelidoavaliador;
                comments.bons[bem].achou = "realista"; 
                var h = comments.resto[k].datadecriacao[8]+comments.resto[k].datadecriacao[9] + "/" + comments.resto[k].datadecriacao[5]+comments.resto[k].datadecriacao[6] + "/" + comments.resto[k].datadecriacao[2]+comments.resto[k].datadecriacao[3];
                comments.bons[bem].datacoment = h; 
                bem ++;
              }
              if(comments.resto[k].nota == '4'){
                Curioso ++;
                comments.resto[k].achou = "curioso";
                comments.bons[bem] = comments.resto[k];
                comments.bons[bem].comentario = comments.resto[k].comentario;
                comments.bons[bem].apelidoavaliador = comments.resto[k].apelidoavaliador;
                comments.bons[bem].achou = "curioso"; 
                var h = comments.resto[k].datadecriacao[8]+comments.resto[k].datadecriacao[9] + "/" + comments.resto[k].datadecriacao[5]+comments.resto[k].datadecriacao[6] + "/" + comments.resto[k].datadecriacao[2]+comments.resto[k].datadecriacao[3];
                comments.bons[bem].datacoment = h; 
                bem ++;
              }
              if(comments.resto[k].nota == '5'){
                Solidario ++;
                comments.resto[k].achou = "solidário";
                comments.bons[bem] = comments.resto[k];
                comments.bons[bem].comentario = comments.resto[k].comentario;
                comments.bons[bem].apelidoavaliador = comments.resto[k].apelidoavaliador;
                comments.bons[bem].achou = "solidário"; 
                var h = comments.resto[k].datadecriacao[8]+comments.resto[k].datadecriacao[9] + "/" + comments.resto[k].datadecriacao[5]+comments.resto[k].datadecriacao[6] + "/" + comments.resto[k].datadecriacao[2]+comments.resto[k].datadecriacao[3];
                comments.bons[bem].datacoment = h; 
                bem ++;
              }
              if(comments.resto[k].nota == '6'){
                Racional ++;
                comments.resto[k].achou = "racional";
                comments.bons[bem] = comments.resto[k];
                comments.bons[bem].comentario = comments.resto[k].comentario;
                comments.bons[bem].apelidoavaliador = comments.resto[k].apelidoavaliador;
                comments.bons[bem].achou = "racional"; 
                var h = comments.resto[k].datadecriacao[8]+comments.resto[k].datadecriacao[9] + "/" + comments.resto[k].datadecriacao[5]+comments.resto[k].datadecriacao[6] + "/" + comments.resto[k].datadecriacao[2]+comments.resto[k].datadecriacao[3];
                comments.bons[bem].datacoment = h; 
                bem ++;
              }
              if(comments.resto[k].nota == '7'){
                Organizado ++;
                comments.resto[k].achou = "organizado";
                comments.bons[bem] = comments.resto[k];
                comments.bons[bem].comentario = comments.resto[k].comentario;
                comments.bons[bem].apelidoavaliador = comments.resto[k].apelidoavaliador;
                comments.bons[bem].achou = "organizado"; 
                var h = comments.resto[k].datadecriacao[8]+comments.resto[k].datadecriacao[9] + "/" + comments.resto[k].datadecriacao[5]+comments.resto[k].datadecriacao[6] + "/" + comments.resto[k].datadecriacao[2]+comments.resto[k].datadecriacao[3];
                comments.bons[bem].datacoment = h; 
                bem ++;
              }
              if(comments.resto[k].nota == '8'){
                Criativo ++;
                comments.resto[k].achou = "criativo";
                comments.bons[bem] = comments.resto[k];
                comments.bons[bem].comentario = comments.resto[k].comentario;
                comments.bons[bem].apelidoavaliador = comments.resto[k].apelidoavaliador;
                comments.bons[bem].achou = "criativo"; 
                var h = comments.resto[k].datadecriacao[8]+comments.resto[k].datadecriacao[9] + "/" + comments.resto[k].datadecriacao[5]+comments.resto[k].datadecriacao[6] + "/" + comments.resto[k].datadecriacao[2]+comments.resto[k].datadecriacao[3];
                comments.bons[bem].datacoment = h; 
                bem ++;
              }
              if(comments.resto[k].nota == '9'){
                comments.resto[k].achou = "Vacileiro";
                comments.ruins[mal] = comments.resto[k];
                comments.ruins[mal].achou = "Vacileiro";
                var h = comments.resto[k].datadecriacao[8]+comments.resto[k].datadecriacao[9] + "/" + comments.resto[k].datadecriacao[5]+comments.resto[k].datadecriacao[6] + "/" + comments.resto[k].datadecriacao[2]+comments.resto[k].datadecriacao[3];
                comments.ruins[mal].datacoment = h; 
                mal ++;
              }
              var h = comments.resto[k].datadecriacao[8]+comments.resto[k].datadecriacao[9] + "/" + comments.resto[k].datadecriacao[5]+comments.resto[k].datadecriacao[6] + "/" + comments.resto[k].datadecriacao[2]+comments.resto[k].datadecriacao[3];
              comments.resto[k].datacoment = h;
            }
          }
                comments.tamanho = k;
                comments.chart[0] = Extrovertido;
                comments.chart[1] = Introvertido;
                comments.chart[2] = Realista;
                comments.chart[3] = Curioso;
                comments.chart[4] = Solidario;
                comments.chart[5] = Racional;
                comments.chart[6] = Organizado;
                comments.chart[7] = Criativo;
                comments.mal[0] = mal + Extrovertido+Introvertido+Realista+Curioso+Solidario+Racional+Organizado+Criativo;
                comments.mal[1] = mal;
                comments.mal[2] = Extrovertido+Introvertido+Realista+Curioso+Solidario+Racional+Organizado+Criativo;

              


                                // PARA MUDAR FRASE DEPOIS DE 3 AVALIÇÕES FEITAS
                if(aux.auxfrase>2){
                  var max = comments.chart[0];
                  var tipo = 1;
                  for (var i = 2; i < 8; i++) {
                    if (comments.chart[i] > max) {
                      tipo = i;
                      max = comments.chart[i];
                    }
                  }
                  //console.log("qtoooss",comments.chart[0], tipo
                  if(i == 8){
                    $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/getfrase.php', {tipo : tipo}).then(function (fras){
                     //console.log("muda", max, tipo, fras.data[0].idfrase)
                      if(fras.data!="Error"){
                          comments.mal[3] = fras.data[0].frase;
                          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/zerarauxfrase.php', {frase : comments.mal[3], iduser : aux.iduser }).then(function (rrr){console.log("atulauza?",rrr.data.success)});
                          //console.log("muda", max, tipo, comments.mal[3])
                      }
                    });
                  }
                  //console.log("muda", max, tipo, comments.mal[3])
                }else{
                  comments.mal[3] = aux.frase;
                }
              //console.log( comments.tamanho , k, comments,'eqweqw', bem);
            
          

          return comments;

        });
      },



      Getinteresse: function(aux) {

        return $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/interesse.php', {idevento : aux}).then(function(response) {
          items = response.data;

          return items;

        });
      },

      Getpinza: function(aux) {
        return $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/pinza.php', {iduser : aux.iduser, idevento: aux.idevento}).then(function(response) {
          items = response.data;
          console.log(response.data, "das")
          return items;

        });
      },

      GetStalkear: function(aux) {
        //console.log('GetStalkear',aux)
        return $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/stalkear.php', {iduser : aux}).then(function(response) {
          items = response.data[0];
          return items;

        });
      },

      Getmsg: function(idevento) {
        return  $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/getmsg.php' , {idevento : idevento}).then(function(result) {
          items = result.data;
          return items;
        });
      },

      GetNoti: function(aux) {
        return $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/getnewnotificacao.php', {iduser : aux.iduser, datadaultima : aux.datadaultima}).then(function(response) {
          items = response.data;
          return items;

        });
      },

      GetNotificacoes: function(aux) {

        return $q(function(resolve, reject) {
        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificacao.php' , {iduser : aux.iduser}).then(function(result) {
          if (result.data.success == true){
            resolve(result.data);
            } else {
              //console.log(result.data)
            //reject("Error");
            }
          });
        });
      },
      
      GetNotificacoes1: function(aux) {

        return $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificacao.php' , {iduser : aux.iduser}).then(function(result) {
          if (result.data.success == true){
            return result.data;
          } else {
              return "error"
            //reject("Error");
            }
          });
      },

  

      atualizarpessoaevento: function(user) {
        return $q(function(resolve, reject) {
        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpessoaevento.php' , {iduser : user.id_user_envia,
                                                                                idevento : user.idevento,
                                                                                confirmacao : user.confirmacao,
                                                                                estado :user.aceito,
                                                                                pontos :user.pontos}).then(function(result) {

          if (result.data.success == true){

            resolve(result.data.msg);
            } else {
            reject(result.data.msg);
            }
          });
        });
      },

      atualizarpessoaeventosconfirma: function(user) {
        return $q(function(resolve, reject) {
        //console.log(user[0].idconfirmacao, user[0].idadm)
        for(var i = 0; i<user.length;i++){
          var aaauxuser = user;
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpessoaeventosconfirma.php' , {idconfirmacao : user[i].idconfirmacao,
                                                                                          confirmacao : 'Sai pra nao bater horario',
                                                                                          estado :6}).then(function(result) {
          
          if (result.data.success == true){
            for(var j = 0; j<aaauxuser.length;j++){
              //.log(aaauxuser[j].idadm, aaauxuser[j].iduser , aaauxuser[j].nomeevento)
              $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacaoporids.php", {id_user_recebe : aaauxuser[j].idadm,
                                                                                      id_user_envia: aaauxuser[j].iduser,
                                                                                      nomeevento: aaauxuser[j].nomeevento,
                                                                                      tipo : '1'});
            }
            resolve(result.data.msg);
            } else {
            reject(result.data.msg);
            }
          });
        }
        
        });
      },

      pontospessoaevento: function(user) {
        return $q(function(resolve, reject) {
        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/pontospessoaevento.php' , {iduser : user.id_user_envia,
                                                                                idevento : user.idevento,
                                                                                pontos : user.pontos,
                                                                                auxpontos : user.auxpontos}).then(function(result) {

          if (result.data.success == true){
            resolve(result.data.msg);
            } else {
            reject(result.data.msg);
            }
          });
        });
       },

       ncriadoscriador: function(user) {
        return $q(function(resolve, reject) {
        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizancriadoscriador.php' , {iduser : user}).then(function(result) {

          if (result.data.success == true){
            resolve(result.data.msg);
            } else {
            reject(result.data.msg);
            }
          });
        });
       },

      GetNewEventos: function(user) {
        return $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/atual.php",{vezes : NewInsta,
                                                                     iduser :user.iduser,
                                                                     northlat : user.northlat,
                                                                     southlat : user.southlat,
                                                                     eastlng : user.eastlng,
                                                                     westlng : user.westlng}).then(function(response) {
          items = [];
          items = response.data[0];
          //console.log(response.data, "aquekrmlwemrlw", NewInsta)
          if(response.data !='Error'){
            //console.log("GetNewEventos")
            for (var g = 0; g<items.length;g++){
              var radlat1 = Math.PI * user.lat/180
              var radlat2 = Math.PI * items[g].lat.valueOf()/180
              var theta = user.long-items[g].lng.valueOf()
              var radtheta = Math.PI * theta/180
              dist[g] = Math.sin(radlat1) * Math.sin(radlat2) + Math.cos(radlat1) * Math.cos(radlat2) * Math.cos(radtheta);
              if (dist[g] > 1) {
                dist[g] = 1;
              }
              dist[g] = Math.acos(dist[g])
              dist[g] = dist[g] * 180/Math.PI
              dist[g] = dist[g] * 60 * 1.1515
              dist[g] = dist[g] * 1.609344;
              items[g].dist = dist[g].toFixed(1);
            
              var hj = items[g].diainicio.valueOf();
              var hjf =items[g].diafim.valueOf();
              items[g].dia =  (hj[8]+hj[9]).valueOf()+'/'+(hj[5]+hj[6]).valueOf()+'       ';
              items[g].hora = (hj[11]+hj[12]).valueOf()+':'+(hj[14]+hj[15]).valueOf() +'-'+(hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf() ;
            }

            if(response.data[0][0].diainicio < NewInsta){
              NewInsta = response.data[0][0].diainicio;
            }
            if(g == items.length){
              return items;
            }
          }else{
            return items;
          }
          
          
        });
      },

      GetOldEventos: function(user) {
          return $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/old.php", {vezes : nextUrl, 
                                                                     iduser :user.iduser,
                                                                     northlat : user.northlat,
                                                                     southlat : user.southlat,
                                                                     eastlng : user.eastlng,
                                                                     westlng : user.westlng}).then(function(response) {
            items = [];
            items = response.data[0];
             var hj = new Date();
             var currentdate = new Date(); 
             var curr_date = (currentdate.getDate()<10?'0':'') + currentdate.getDate();
             var curr_month = (currentdate.getMonth()<10?'0':'') + (currentdate.getMonth() + 1); //Months are zero based
             var curr_year = currentdate.getFullYear();
             var h2 = (currentdate.getHours()<10?'0':'') + currentdate.getHours();
             var m2 = (currentdate.getMinutes()<10?'0':'') + currentdate.getMinutes();
             var faltatempo = [];
             var ft = 0;
             var deletou = 0;
             // console.log(items.length);
             // console.log(items[0]);
           //console.log(nextUrl);
           //console.log(items[items.length-1].diainicio);
           if (items[0]!='E') {
            for(var i = 0 ; i<items.length ; i++){
            hj = items[i].diainicio.valueOf();

            var ano = (hj[0]+hj[1]+hj[2]+hj[3]).valueOf()-curr_year;
            var mes = (hj[5]+hj[6]).valueOf()-curr_month;
            var dia = (hj[8]+hj[9]).valueOf()-curr_date;
            var h = (hj[11]+hj[12]).valueOf()-h2;
            var m = (hj[14]+hj[15]).valueOf()-m2;
            

            var hjf =items[i].diafim.valueOf();
            items[i].dia =  (hj[8]+hj[9]).valueOf()+'/'+(hj[5]+hj[6]).valueOf()+'       ';
            items[i].hora = (hj[11]+hj[12]).valueOf()+':'+(hj[14]+hj[15]).valueOf() +'-'+(hjf[11]+hjf[12]).valueOf()+':'+(hjf[14]+hjf[15]).valueOf() ;


          
            var radlat1 = Math.PI * user.lat/180
            var radlat2 = Math.PI * items[i].lat.valueOf()/180
            var theta = user.long-items[i].lng.valueOf()
            var radtheta = Math.PI * theta/180
            dist[i] = Math.sin(radlat1) * Math.sin(radlat2) + Math.cos(radlat1) * Math.cos(radlat2) * Math.cos(radtheta);
            if (dist[i] > 1) {
              dist[i] = 1;
            }
            dist[i] = Math.acos(dist[i])
            dist[i] = dist[i] * 180/Math.PI
            dist[i] = dist[i] * 60 * 1.1515
            dist[i] = dist[i] * 1.609344;

          items[i].dist = dist[i].toFixed(1);   
          items[i].faltatempo = faltatempo[i];
          }
          }
           
          if(items[items.length-1].diainicio > nextUrl){
            nextUrl = items[items.length-1].diainicio;
            //console.log(nextUrl);
          }
          if (items == "E") {
            items = [];
          }
            return items;
  
          });
      },

      GetAbertos: function(user) {
        //console.log(user);
        return $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/abertos.php", {iduser : user,
                                                                      estado : '3'}).then(function(response) {
          items = response.data[0];
          //console.log(items);
          nextUrlCriados = response.data[0][items.length-1].idevento;
          NewInstaCriados = response.data[0][0].idevento;
          return items;
        });
      },



      GetAbertosQvou: function(user) {
        console.log(user, "GetAbertosQvou");
        return $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/abertosqvou.php", {iduser : user}).then(function(response) {
          items = response.data[0];
          
          return items;
        });
      },


      GetAbertosCriados: function(user) {
        //console.log(user);
        return $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/abertoscriados.php", {iduser : user}).then(function(response) {
          items = response.data[0];
          
          return items;
        });
      },

      GetAbertosInteresse: function(user) {
        //console.log(user);
        return $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/abertosinteresse.php", {iduser : user}).then(function(response) {
          items = response.data[0];
          
          return items;
        });
      },

      GetCriados: function(user) {
        return $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/criados.php", {adm : user.iduser}).then(function(response) {
          items = response.data[0];
          nextUrlCriados = response.data[0][items.length-1].idevento;
          //console.log(nextUrlCriados);
          NewInstaCriados = response.data[0][0].idevento;
          return items;
        });
      },
      GetCriadosacabados: function(user) {
        return $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/criadosacabados.php", {adm : user.iduser}).then(function(response) {
          items = response.data[0];
          nextUrlCriados = response.data[0][items.length-1].idevento;
          //console.log(nextUrlCriados);
          NewInstaCriados = response.data[0][0].idevento;
          return items;
        });
      },
      GetCriadosPerfil: function(user) {
        //console.log(nextUrl);
        return $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/criadosperfil.php", {adm : user.iduser}).then(function(response) {
          items = response.data[0];
          nextUrlCriados = response.data[0][items.length-1].idevento;
          //console.log(nextUrlCriados);
          NewInstaCriados = response.data[0][0].idevento;
          return items;
        });
      },
      GetCriadosnovos: function(user) {
        //console.log(nextUrl);
        return $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/criadosnovos.php", {adm : user.iduser}).then(function(response) {
          items = response.data[0];
          nextUrlCriados = response.data[0][items.length-1].idevento;
          //console.log(nextUrlCriados);
          NewInstaCriados = response.data[0][0].idevento;
          return items;
        });
      },
      verificahorariopessoaevento: function(user) {
        //console.log(nextUrl);
        return $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/verificahorariopessoaevento.php", {iduser : user.iduser}).then(function(response) {
          items = response.data[0];
          return items;
        });
      },
      verificahorariopessoaeventoconfirmados: function(user) {
        //console.log(nextUrl);
        return $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/verificahorariopessoaeventoconfirmados.php", {iduser : user.iduser}).then(function(response) {
          items = response.data[0];
          return items;
        });
      },
      verificahorariopessoaeventoaguardando: function(user) {
        //console.log(user.diainicio ,user.diafim, user.iduser);
        return $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/verificahorariopessoaeventoaguardando.php", {iduser : user.iduser,
                                                                                                      diainicio: user.diainicio,
                                                                                                      diafim: user.diafim}).then(function(response) {
          items = response.data[0];
          return items;
        });
      },

      GetFinalizadosPerfil: function(user) {
        //console.log(user);
        return $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/finalizadosperfil.php", {iduser : user,
                                                                                  estado : 3}).then(function(response) {
          
          finalizadocomnota = response.data[0];
          //console.log(finalizadocomnota.length, "tamano do finalizados")
          var t = 0 ;
          for(var i = 0; i < response.data[0].length;i++){
            //console.log( finalizadocomnota[i].idevento, 'dentro do loop')
            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/getcomentarioevento.php', {idevento : response.data[0][i].idevento,
                                                                               nomepessoaavaliada : response.data[0][i].nomeevento}).then(function (res){       
              //console.log(res.data)
              
            
              if(res.data == 'Error'){
                nota[t] = -1;
                nomeevento[t] = '';
                t++;
              }else{
                //console.log(response.data.length, 'tamanho do response.data')
                for (var j = 0; j < res.data.length; j++) {
                    //console.log(res.data[j].nomepessoaavaliada, 'nota', t)
                    if(j == 0){
                      nota[t] = parseFloat(res.data[j].nota)
                      //console.log('aquiii')
                    }else{
                      nota[t]  = parseFloat(res.data[j].nota) + parseFloat(nota[t]) ;
                      //console.log( nota[t].nota, 'aquiii')
                    }
                    nomeevento[t] = res.data[j].nomepessoaavaliada;
                    //console.log(nomeevento[t])
                  }
                nota[t]  = (nota[t] /res.data.length).toFixed(1);
                
                //console.log(nota[t].nota, t ,nota[t].nomeevento)
                t++; 
              }            
            });
            //console.log(finalizadocomnota.nota[t], t)
            if (nota.length==finalizadocomnota.length){
              //console.log(t, i)
              for(var i = 0; i < finalizadocomnota.length;i++){
                for (var o = 0; o<nota.length; o++){
                  //console.log(finalizadocomnota[i].nomeevento , i , nomeevento[o] , o )
                  if(nomeevento[o] == finalizadocomnota[i].nomeevento){
                    finalizadocomnota[i].nota = nota[o];
                    //console.log(nota[o], o ,nota[o].nomeevento)
                  }
                }
              }
            }
          }
          nextUrlCriados = finalizadocomnota[finalizadocomnota.length-1].idevento;
          NewInstaCriados = response.data[0][0].idevento;
         
          return finalizadocomnota;
        });
      },


      GetOldEventosCriados: function(user) {
         //console.log(nextUrl);
         //console.log(nextUrlCriados, user.iduser);
          return $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/oldcriados.php", {vezes : nextUrlCriados,
                                                                             adm : user.iduser}).then(function(response) {
            items = [];
            items = response.data[0];
            //console.log(items);
          if(items[items.length-1].idevento < nextUrlCriados){
            nextUrlCriados = items[items.length-1].idevento;
          }
          if (items == "E") {
            items = [];
          }
            return items;
  
          });
      },

      finalizarevts: function(j) {
        console.log("finalizarsemppl1", j)
        return $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/eventosparafinalizar.php', {hj:j}).then(function(result) {
          items = result.data;
          console.log(  "finalizarsems", items.length)
          if (result.data[0] != "E"){
            return result.data;
          } else {
            return "Error"
          }
        });
      },

      finalizarevts2: function(evento) {
          evento.estado = '1'; //evento finalizado
          return $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/participantes.php', {idevento : evento.idevento}).then(function(response) {
            items = response.data;
            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarevento.php' ,evento);
            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacaoporevento.php' , {idevento : evento.idevento,
                                                                                        nomeevento : evento.nomeevento});
            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/finalizapessoaevento.php' , {idevento : evento.idevento,
                                                                                      confirmacao : 'finalizado',
                                                                                      estado :'3'});
            var msg = 'Avalie o evento ' + evento.nomeevento
            for (var j = 0; j < items.length; j++) {
                $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : msg, 
                                idevento : evento.idevento,
                                nomeevento : evento.nomeevento,
                                id_user_envia : evento.adm,
                                username_envia : evento.admusername,
                                apelido_envia : evento.admapelido,
                                tipo : '6',    //update no evento
                                id_user_recebe : items[j].iduser});
                
            }
                    //   DELETAR NOTIFICAÇÕES PASSADAS DO EVENTO, DE ACEITAR OU NAO PARTICIPANTE

          return items;

        });
      }, 

      // FinalizarEventos: function() {         
      //     return $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/finalizar.php").then(function(response) {
      //       $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/finalizarpessoaeventopelofeed.php");
      //       $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/finalizarpessoaeventopelofeedquenaoforam.php");
      //       console.log('Finalizando part 1', response.data.success, response.data.length);
      //       if (response.data.success == true){
      //         //console.log(response.data.msg);
      //         $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/participantesparafinalizar.php').then(function(response) {
      //           fes = response.data;          
      //           //console.log('Finalizando part 2');                                                            
      //             for (var j = 0; j < fes.length; j++) {
      //               var mgs = 'Avalie o evento ' + fes[j].nomeevento;
      //                  $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : mgs, 
      //                                     idevento : fes[j].idevento,
      //                                     nomeevento : fes[j].nomeevento,
      //                                     id_user_envia : fes[j].idadm,
      //                                     username_envia :  fes[j].admusername,
      //                                     tipo : '6',       // avaliação de evento
      //                                     id_user_recebe : fes[j].iduser}).then(function (res){
      //                                    //console.log(res.data.msg)
      //                                  });
      //             }
                  
      //             //console.log('Finalizando part 3');
      //         });
      //       } else {
      //       //console.log(response.data.msg);
      //       }
          
      //       return response.data.msg;
  
      //     });
      // },

      paraenviarnoti: function(hj) {
        //console.log("finalizarsemppl1")
        return $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/eventosparaenviarnoti.php', {hj:hj}).then(function(result) {
          items = result.data;
          //console.log(  "finalizarsemppl1", items.length, items,)
          if (result.data[0] != "E"){
            return result.data;
          } else {
            return "Error"
          }
        });
      }, // NAO EXISTE PHP

       paraenviarnoti2: function(evento) {
         //console.log(nextUrl);
         //console.log(evento);
          evento.notifica = '1'; //evento finalizado
              //$scope.msgnoti = ('Avalie o evento: '+ items[i].nomeevento);
        
          return $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/participantes.php', {idevento : evento.idevento}).then(function(response) {
            items = response.data;
            //console.log(items[0].iduser , "drqwerqreq")
            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarevento.php' ,evento);
            var msg = 'Você tem um evento preste a ocorrer, clique em mim para saber'
            for (var j = 0; j < items.length; j++) {
                   var postParams = { 
                          "notification": {
                            "title": "Se prepare",
                            "body": msg,
                            //"click_action":"FCM_PLUGIN_ACTIVITY",
                            //"icon":"fcm_push_icon"
                            },
                          "to": items[j].devicetoken
                          }
                          var js = JSON.stringify(postParams);
                          var req = {
                           method: 'POST',
                           url: 'https://fcm.googleapis.com/fcm/send',
                           headers: {
                             'Authorization': 'key=AAAATsLpVfo:APA91bEph8ut7xPtKVJXPfK89IwDIRidGVkVKECccLpLPzNsd_YMuVkE7BXDNsvqvCUVyIbaMQ47ZFFAi2r7MeoKT2sjTfcIs_J9DAFYljwZeWsJaV_icyq07Jgf9uY6l0exIt9CmHNJ',
                             'Content-Type': 'application/json'
                           },
                           data: js
                          }
                  $http.defaults.headers.common.Authorization = 'key=AAAATsLpVfo:APA91bEph8ut7xPtKVJXPfK89IwDIRidGVkVKECccLpLPzNsd_YMuVkE7BXDNsvqvCUVyIbaMQ47ZFFAi2r7MeoKT2sjTfcIs_J9DAFYljwZeWsJaV_icyq07Jgf9uY6l0exIt9CmHNJ';
                  $http.post("https://fcm.googleapis.com/fcm/send", JSON.stringify(postParams)); 
            }
                    //   DELETAR NOTIFICAÇÕES PASSADAS DO EVENTO, DE ACEITAR OU NAO PARTICIPANTE

          return items;

        });
      },


      finalizarsemppl1: function(hj) {
        //console.log("finalizarsemppl1")
        return $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/eventosparafinalizarsemgente.php', {hj:hj}).then(function(result) {
          items = result.data;
          //console.log(  "finalizarsemppl1", items.length, items,)
          if (result.data[0] != "E"){
            return result.data;
          } else {
            return "Error"
          }
        });
      }, // NAO EXISTE PHP

       finalizarsemppl2: function(evento) {
         //console.log(nextUrl);
         //console.log(evento);
          evento.estado = '4'; //evento finalizado
              //$scope.msgnoti = ('Avalie o evento: '+ items[i].nomeevento);
        
          return $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/participantes.php', {idevento : evento.idevento}).then(function(response) {
            items = response.data;
            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarevento.php' ,evento);
            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacaoporevento.php' , {idevento : evento.idevento,
                                                                                        nomeevento : evento.nomeevento});
            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/finalizapessoaevento.php' , {idevento : evento.idevento,
                                                                                      confirmacao : 'cancelado',
                                                                                      estado :'4'});
            var msg = evento.nomeevento+' foi cancelado por falta de gente'
            for (var j = 0; j < items.length; j++) {
                $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : msg, 
                                idevento : evento.idevento,
                                nomeevento : evento.nomeevento,
                                id_user_envia : evento.adm,
                                username_envia : evento.admusername,
                                apelido_envia : evento.admapelido,
                                tipo : '10',    //update no evento
                                id_user_recebe : items[j].iduser});
                ///
                   var postParams = { 
                          "notification": {
                            "title": "Evento cancelado",
                            "body": msg,
                            //"click_action":"FCM_PLUGIN_ACTIVITY",
                            //"icon":"fcm_push_icon"
                            },
                          "to": items[j].devicetoken
                          }
                          var js = JSON.stringify(postParams);
                          var req = {
                           method: 'POST',
                           url: 'https://fcm.googleapis.com/fcm/send',
                           headers: {
                             'Authorization': 'key=AAAATsLpVfo:APA91bEph8ut7xPtKVJXPfK89IwDIRidGVkVKECccLpLPzNsd_YMuVkE7BXDNsvqvCUVyIbaMQ47ZFFAi2r7MeoKT2sjTfcIs_J9DAFYljwZeWsJaV_icyq07Jgf9uY6l0exIt9CmHNJ',
                             'Content-Type': 'application/json'
                           },
                           data: js
                          }
                  $http.defaults.headers.common.Authorization = 'key=AAAATsLpVfo:APA91bEph8ut7xPtKVJXPfK89IwDIRidGVkVKECccLpLPzNsd_YMuVkE7BXDNsvqvCUVyIbaMQ47ZFFAi2r7MeoKT2sjTfcIs_J9DAFYljwZeWsJaV_icyq07Jgf9uY6l0exIt9CmHNJ';
                  $http.post("https://fcm.googleapis.com/fcm/send", JSON.stringify(postParams)); 
            }
                    //   DELETAR NOTIFICAÇÕES PASSADAS DO EVENTO, DE ACEITAR OU NAO PARTICIPANTE

          return items;

        });
      },


      Cancelarevento: function(evento) {
         //console.log(nextUrl);
         //console.log(evento);
          evento.estado = '4'; //evento finalizado
              //$scope.msgnoti = ('Avalie o evento: '+ items[i].nomeevento);
        
          return $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/participantes.php', {idevento : evento.idevento}).then(function(response) {
            items = response.data;
            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarevento.php' ,evento);
            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/deletanotificacaoporevento.php' , {idevento : evento.idevento,
                                                                                        nomeevento : evento.nomeevento});
            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/finalizapessoaevento.php' , {idevento : evento.idevento,
                                                                                      confirmacao : 'cancelado',
                                                                                      estado :'4'});
            var msg = evento.nomeevento+' foi cancelado por falta de gente'
            for (var j = 0; j < items.length; j++) {
                $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/notificapessoa.php', {notificacao : msg, 
                                idevento : evento.idevento,
                                nomeevento : evento.nomeevento,
                                id_user_envia : evento.adm,
                                username_envia : evento.admusername,
                                apelido_envia : evento.admapelido,
                                tipo : '10',    //update no evento
                                id_user_recebe : items[j].iduser});


                var postParams = { 
                          "notification": {
                            "title": "Evento cancelado",
                            "body": msg,
                            // "click_action":"FCM_PLUGIN_ACTIVITY",
                            //"icon":"fcm_push_icon"
                            },
                          "to": items[j].devicetoken
                          }
                          var js = JSON.stringify(postParams);
                          var req = {
                           method: 'POST',
                           url: 'https://fcm.googleapis.com/fcm/send',
                           headers: {
                             'Authorization': 'key=AAAATsLpVfo:APA91bEph8ut7xPtKVJXPfK89IwDIRidGVkVKECccLpLPzNsd_YMuVkE7BXDNsvqvCUVyIbaMQ47ZFFAi2r7MeoKT2sjTfcIs_J9DAFYljwZeWsJaV_icyq07Jgf9uY6l0exIt9CmHNJ',
                             'Content-Type': 'application/json'
                           },
                           data: js
                          }
                  $http.defaults.headers.common.Authorization = 'key=AAAATsLpVfo:APA91bEph8ut7xPtKVJXPfK89IwDIRidGVkVKECccLpLPzNsd_YMuVkE7BXDNsvqvCUVyIbaMQ47ZFFAi2r7MeoKT2sjTfcIs_J9DAFYljwZeWsJaV_icyq07Jgf9uY6l0exIt9CmHNJ';
                  $http.post("https://fcm.googleapis.com/fcm/send", JSON.stringify(postParams)); 

                  
            }
                    //   DELETAR NOTIFICAÇÕES PASSADAS DO EVENTO, DE ACEITAR OU NAO PARTICIPANTE

          return items;

        });
      },


      faz48h: function(ic) {      
        return $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/finalizados48h.php").then(function(response) {
                items = response.data[0];
  
                //console.log(response.data, items, 'faz 48h')
                if (items != "E") {
                  for(var u = 0;u<items.length;u++){
                  //console.log(items[u].idevento);
                  items[u].estado =5;
                  //console.log(items[u].nomeevento, items[u].duracao, items[u].diainicio, items[u].diafim, items[u].descricao, items[u].estado, items[u].endereco, items[u].lat )
                  $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/finalizarevento.php' , {idevento: items[u].idevento});
                   $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/participantes.php', {idevento : items[u].idevento}).then(function(response) {
                    items2 = response.data;
                      //console.log(response.data.nrow);
                     //console.log(response.data);
                     //console.log(items2.length, 'pegando participantes');
                         for(var v = 0;v<items2.length;v++){
                          auxp = parseFloat(items2[v].pontos)+3;
                          if (items2[v].confirmacao == 'Criador não lembra dele no evento, avalie-o se vc se lembra dele') {
                            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/penalidade.php' , {iduser : items2[v].iduser,
                                                                                              idevento : items2[v].idevento,
                                                                                              username : items2[v].username,
                                                                                              tipopenalidade : '3'});// Falou que foi mas não foi
                            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/48hpessoaevento.php' , {iduser : items2[v].iduser,
                                                                                              idevento : items2[v].idevento,
                                                                                              confirmacao : 'Não foi aparentemente',
                                                                                              estado : '5', // pessoa nao foi confirmada por ninguem após 48h
                                                                                              pontos : auxp});
                            //console.log(items2[v].iduser, items2[v].username , 'nao foi no evento', items2[v].idevento );
                          }else{
                              if (ic.iduser == items2[v].iduser) {
                                if(ic.yellow>=3){
                                    if(ic.antiyellow == 2){
                                      console.log('Aqui termina a penalidade amarela');
                                      $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpenalidades.php", {idpenalidade : ic.idyellow[0]});
                                      $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpenalidades.php", {idpenalidade : ic.idyellow[1]});
                                      $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpenalidades.php", {idpenalidade : ic.idantiyellow[0]});
                                      $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpenalidades.php", {idpenalidade : ic.idantiyellow[1]});
                                    }else{
                                      $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/penalidade.php' , {iduser : items2[v].iduser,
                                                                                                idevento : items2[v].idevento,
                                                                                                username : items2[v].username,
                                                                                                tipopenalidade : '4'});
                                    }
                                  }
                                  //console.log(ic.black)
                                
                                  if(ic.black>=3){
                                    if (ic.antiblack == 2 && ic.antired == 1) {
                                      //console.log('Aqui termina a penalidade preta');
                                      $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpenalidades.php", {idpenalidade : ic.idblack[0]});
                                      $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpenalidades.php", {idpenalidade : ic.idblack[1]});
                                      $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpenalidades.php", {idpenalidade : ic.idantired[0]});
                                      $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpenalidades.php", {idpenalidade : ic.idantiblack[0]});
                                      $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpenalidades.php", {idpenalidade : ic.idantiblack[1]});
                                    }else{
                                      $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/penalidade.php' , {iduser : items2[v].iduser,
                                                                                                idevento : items2[v].idevento,
                                                                                                username : items2[v].username,
                                                                                                tipopenalidade : '6'});
                                    }
                                  }
                                  if(ic.iduser == items2[v].idadm){
                                    if(ic.red >=3){
                                      $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpenalidades.php", {idpenalidade : ic.idred[0]});
                                      $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpenalidades.php", {idpenalidade : ic.idred[1]});
                                      $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpenalidades.php", {idpenalidade : ic.idred[2]});
                                      //console.log('Matei a penalidade RED');
                                    }
                                        /// FAÇO O UPDATE DAS PENALIDADES QUE ME FODEM E CRIO ANTI RED DE CRIAÇÃO (TIPOPENALIDADE = 5)

                                    if(ic.black >=3){
                                        /// FAÇO O UPDATE DAS PENALIDADES QUE ME FODEM MATANDO A PENALIDADE BLACK    
                                      if(ic.antiblack >= 3){
                                        $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpenalidades.php", {idpenalidade : ic.idblack[0]});
                                        $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpenalidades.php", {idpenalidade : ic.idblack[1]});
                                        $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpenalidades.php", {idpenalidade : ic.idblack[2]});
                                        $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpenalidades.php", {idpenalidade : ic.idantiblack[0]});
                                        $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpenalidades.php", {idpenalidade : ic.idantiblack[1]});
                                        $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarpenalidades.php", {idpenalidade : ic.idantiblack[2]});
                                        //console.log('Matei a penalidade BLACK');
                                      }else{
                                        /// CRIO O ANTIRED (TIPOPENALIDADE = 5)
                                        $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/penalidade.php' , {iduser :items2[v].idadm,
                                                                                                    idevento : items2[v].idevento,
                                                                                                    username : items2[v].admusername,
                                                                                                    tipopenalidade : '5'});
                                        //console.log('Criou antiRED do BLACK');
                                      }

                                    }
                                  }

                              }
                    
                             $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/48hpessoaevento.php' , {iduser : items2[v].iduser,
                                                                                              idevento : items2[v].idevento,
                                                                                              confirmacao : items2[v].confirmacao,
                                                                                              estado : '3', // finalizado
                                                                                              pontos : auxp});
                          }

                         }

                          });
                        }
                  }
                //console.log(response.data, items.length);
                
              
         
          if (items == "E") {
            items = [];
          }
            return items;
  
          });
      },

      getIC: function(user) {
          //console.log('getIC', user.iduser)
          return $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/getpessoaevento.php", {iduser : user.iduser,
                                                                                 estado : '3'}).then(function(response) {
            items = [];

            //console.log(response.data)
            if(response.data == 'Error'){
              ic.naofuieventos = 0;
              ic.neventos = 0;
              ic.total = 100;
              ic.black = 0;
              ic.red = 0;
              ic.yellow = 0;
              ic.antiblack = 0;
              ic.antired = 0;
              ic.antiyellow = 0;
              ic.lenghtblack = 0;
              ic.lenghtred = 0;
              ic.lenghtyellow = 0;
              ic.idblack = [];
              ic.idred = [];
              ic.idyellow = [];

              ic.lenghtantiblack = 0;
              ic.lenghtantired = 0;
              ic.lenghtantiyellow = 0;
              ic.idantiblack = [];
              ic.idantired = [];
              ic.idantiyellow = [];
              $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/getpenalidade.php", {iduser : user.iduser}).then(function(tes) {                                                                    
                  items = tes.data[0];
                    // console.log(items , tes.data[0])
                  if(tes.data.success != false){
                    for(var h = 0;h<tes.data[0].length;h++){
                      if(tes.data[0][h].tipopenalidade == 3){ic.black += 1; ic.blackdate = tes.data[0][h].date; ic.idblack[ic.lenghtblack] =tes.data[0][h].idpenalidade;  ic.lenghtblack++;}
                      if(tes.data[0][h].tipopenalidade == 2){ic.red += 1;  ic.reddate = tes.data[0][h].date; ic.idred[ic.lenghtred] =tes.data[0][h].idpenalidade; ic.lenghtred++;}
                      if(tes.data[0][h].tipopenalidade == 1){ic.yellow += 1;  ic.yellowdate = tes.data[0][h].date; ic.idyellow[ic.lenghtyellow] =tes.data[0][h].idpenalidade; ic.lenghtyellow++;}
                      if(tes.data[0][h].tipopenalidade == 6){ic.antiblack += 1; ic.antiblackdate = tes.data[0][h].date; ic.idantiblack[ic.lenghtantiblack] =tes.data[0][h].idpenalidade; ic.lenghtantiblack++;}
                      if(tes.data[0][h].tipopenalidade == 5){ic.antired += 1;  ic.antireddate = tes.data[0][h].date; ic.idantired[ic.lenghtantired] =tes.data[0][h].idpenalidade; ic.lenghtantired++;}
                      if(tes.data[0][h].tipopenalidade == 4){ic.antiyellow += 1;  ic.antiyellowdate = tes.data[0][h].date; ic.idantiyellow[ic.lenghtantiyellow] =tes.data[0][h].idpenalidade; ic.lenghtantiyellow++;}
                    }
                    /// Penalidades diretamente no IC do individuo
                    /// Analise de eventos que a pessoa fez ou nao para anular as penalidades
                    if(ic.yellow>=3){
                      for(var u = 0; u<parseInt(ic.yellow/3);u++){
                        ic.total = (ic.total*0.95).toFixed(1);
                        ic.totalcalc = ic.total;
                      }
                    }
                    if(ic.red>=3){
                       for(var u = 0; u<parseInt(ic.red/3);u++){
                        ic.total = (ic.total*0.90).toFixed(1);
                        ic.totalcalc = ic.total;
                      }
                    }
                    if(ic.black>=3){
                       for(var u = 0; u<parseInt(ic.black/3);u++){
                        ic.total = (ic.total*0.80).toFixed(1);
                        ic.totalcalc = ic.total;
                      }
                    }
                  }    
                });
            }else{
              var neventosnao
              var neventos

              ic.black = 0;
              ic.red = 0;
              ic.yellow = 0;
              ic.antiblack = 0;
              ic.antired = 0;
              ic.antiyellow = 0;
              ic.lenghtblack = 0;
              ic.lenghtred = 0;
              ic.lenghtyellow = 0;
              ic.idblack = [];
              ic.idred = [];
              ic.idyellow = [];

              ic.lenghtantiblack = 0;
              ic.lenghtantired = 0;
              ic.lenghtantiyellow = 0;
              ic.idantiblack = [];
              ic.idantired = [];
              ic.idantiyellow = [];

              items = response.data[0];
            
              if (items=='E') {
                  ic.neventos = parseFloat(0);
              }else{
                  ic.neventos =parseFloat(items.length);
              }

              $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/getpessoaevento.php", {iduser : user.iduser,
                                                                                estado : '5'}).then(function(res) { 
                if (res.data[0] =='E') {
                  ic.naofuieventos = parseFloat(0);
                  ic.total = ((ic.neventos/(ic.neventos+ic.naofuieventos))*100).toFixed(1);
                  //console.log(ic.total , "dentro do if")
                }else{
                  ic.naofuieventos = parseFloat(res.data[0].length);
                  ic.total = ((ic.neventos/(ic.neventos+ic.naofuieventos))*100).toFixed(1);
                  //console.log(ic.total , "dentro do else", ic.neventos, ic.naofuieventos)
                }

               

                $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/getpenalidade.php", {iduser : user.iduser}).then(function(tes) {                                                                    
                  items = tes.data[0];
                    // console.log(items , tes.data[0])
                  if(tes.data.success != false){
                    for(var h = 0;h<tes.data[0].length;h++){
                      if(tes.data[0][h].tipopenalidade == 3){ic.black += 1; ic.blackdate = tes.data[0][h].date; ic.idblack[ic.lenghtblack] =tes.data[0][h].idpenalidade;  ic.lenghtblack++;}
                      if(tes.data[0][h].tipopenalidade == 2){ic.red += 1;  ic.reddate = tes.data[0][h].date; ic.idred[ic.lenghtred] =tes.data[0][h].idpenalidade; ic.lenghtred++;}
                      if(tes.data[0][h].tipopenalidade == 1){ic.yellow += 1;  ic.yellowdate = tes.data[0][h].date; ic.idyellow[ic.lenghtyellow] =tes.data[0][h].idpenalidade; ic.lenghtyellow++;}
                      if(tes.data[0][h].tipopenalidade == 6){ic.antiblack += 1; ic.antiblackdate = tes.data[0][h].date; ic.idantiblack[ic.lenghtantiblack] =tes.data[0][h].idpenalidade; ic.lenghtantiblack++;}
                      if(tes.data[0][h].tipopenalidade == 5){ic.antired += 1;  ic.antireddate = tes.data[0][h].date; ic.idantired[ic.lenghtantired] =tes.data[0][h].idpenalidade; ic.lenghtantired++;}
                      if(tes.data[0][h].tipopenalidade == 4){ic.antiyellow += 1;  ic.antiyellowdate = tes.data[0][h].date; ic.idantiyellow[ic.lenghtantiyellow] =tes.data[0][h].idpenalidade; ic.lenghtantiyellow++;}
                    }
                    /// Penalidades diretamente no IC do individuo
                    /// Analise de eventos que a pessoa fez ou nao para anular as penalidades
                    if(ic.yellow>=3){
                      for(var u = 0; u<parseInt(ic.yellow/3);u++){
                        ic.total = (ic.total*0.95).toFixed(1);
                        ic.totalcalc = ic.total;
                      }
                    }
                    if(ic.red>=3){
                       for(var u = 0; u<parseInt(ic.red/3);u++){
                        ic.total = (ic.total*0.90).toFixed(1);
                        ic.totalcalc = ic.total;
                      }
                    }
                    if(ic.black>=3){
                       for(var u = 0; u<parseInt(ic.black/3);u++){
                        ic.total = (ic.total*0.80).toFixed(1);
                        ic.totalcalc = ic.total;
                      }
                    }
                  }    
                });
              });
             //console.log( ic.neventos , ic , ic.naofuieventos, ic.total)
            }
            return ic;
           
          });
      },

      possoseguir: function(user) {
        //console.log(user.outro, user.eu, 'no service');
        return $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/getpessoaevento.php", {iduser : user.outro,
                                                                                estado : '3'}).then(function(response) {
          items = response.data[0];
          if (items !='E') {
            // followbutton = false;
              for(var i=0;i<items.length;i++){
                return $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/geteventopessoaevento.php", {idevento : items[i].idevento,
                                                                    estado : '3'}).then(function(response) { 
                  var novo = response.data[0];
                  console.log(novo , "novo")
                  for(var j=0 ;j<response.data[0].length;j++){
                    console.log(novo[j].iduser , user.outro, "possoseguir");
                    if (novo[j].iduser == user.eu) {
                      followbutton = true;
                      console.log('fui no evento com este cara e nao sigo', user.eu , novo[j].idevento);
                    }
                  }
                return followbutton;
                });
              }
            }else{
              followbutton = false;
            }
          return followbutton;
        });
      },

      GetPontos: function(user) {
        //console.log('GetPontos',user);
        return $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/getpessoaeventopontos.php", {iduser : user,
                                                                                      estado : '3'}).then(function(response) {
          if(response.data == 'Error'){
            p=0;
          }else{
            items = response.data[0];
            p=0;
              for(var i=0;i<items.length;i++){
                p += parseFloat(items[i].pontos);
              }
          }
          return p;
        });
      },

      VerificaNotificacao: function(noti) {
        //console.log(nextUrl);
        return $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/notiverifica.php", {id_user_recebe : noti.recebe,
                                                                              id_user_envia: noti.envia,
                                                                              nomeevento: noti.nomeevento,
                                                                              tipo : noti.tipo}).then(function(response) {
           if(response.data.success == true){
              //console.log('Ja existe essa notificação');
           }else{
              //console.log('Pode mandar notificação');
           }
         
          return !response.data.success;
        });
      },

      filtro: function(user){
        return $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/filtro.php", {iduser :user.iduser,
                                 genero : user.genero,
                                 northlat : user.northlat,
                                 southlat : user.southlat,
                                 eastlng : user.eastlng,
                                 westlng : user.westlng}).then(function(response) {
        return  response.data[0];
        });
      },


      Filtradinamicamente21: function(tuto) {
        //console.log("Filtradinamicamente21", tuto.tamanho,  tuto.filtro.dificuldade, tuto.filtro.precof, tuto.filtro.genero , tuto.filtro.northlat)
        var filtred = {};
        var aux3 = 0;
        return $q(function(resolve, reject) {
          for(var i = 0; i<tuto.tamanho; i++){
          var R = 6371; // Radius of the earth in km
          var dLat = (tuto[i].lat-tuto.filtro.lat) * (Math.PI/180);  // deg2rad below toRad
          var dLon = (tuto[i].lng-tuto.filtro.long) * (Math.PI/180); 
          var a = 
            Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.cos((tuto.filtro.lat) * (Math.PI/180)) * Math.cos((tuto[i].lat) * (Math.PI/180)) * 
            Math.sin(dLon/2) * Math.sin(dLon/2)
            ; 
          var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
          var d = R * c; // Distance in km

              //console.log(d, tuto.filtro.raio , tuto.filtro.long, tuto[i].lat, tuto[i].idevento )
            if(d<tuto.filtro.raio){
              //console.log(tuto.filtro.genero)
              if(tuto.filtro.genero == "todos"){
                if(tuto.filtro.precof == "ambos"){
                  if(tuto.filtro.dificuldade == "Não importa" || tuto.filtro.dificuldade == "Qual a dificuldade do evento?"){
                    filtred[aux3] = tuto[i];
                    aux3++;
                    //console.log( "aquiiiiiiii ",  tuto[i].idevento)
                  }else{
                    if(tuto[i].dificuldade == tuto.filtro.dificuldade){
                      filtred[aux3] = tuto[i];
                      aux3++;
                    }
                  }
                }else{
                  if (tuto.filtro.precof == "gratis") {
                    if(tuto[i].preco ==  0 ){
                      if(tuto.filtro.dificuldade == "Não importa" || tuto.filtro.dificuldade == "Qual a dificuldade do evento?"){
                        filtred[aux3] = tuto[i];
                        aux3++;
                      }else{
                        if(tuto[i].dificuldade == tuto.filtro.dificuldade){
                          filtred[aux3] = tuto[i];
                          aux3++;
                        }
                      }
                    }
                  }
                  if (tuto.filtro.precof == "pago") {
                    if (tuto.filtro.precof == "pago") {
                      if(tuto[i].precopor == '2' ){
                        tuto[i].preco = (tuto[i].preco.valueOf()/tuto[i].pmin.valueOf());
                        if(tuto[i].preco <=  tuto.filtro.precovalor){
                          if(tuto.filtro.dificuldade == "Não importa" || tuto.filtro.dificuldade == "Qual a dificuldade do evento?"){
                            filtred[aux3] = tuto[i];
                            aux3++;
                          }else{
                            if(tuto[i].dificuldade == tuto.filtro.dificuldade){
                              filtred[aux3] = tuto[i];
                              aux3++;
                            }
                          }
                        }
                      }else{
                        if(tuto[i].preco <=  tuto.filtro.precovalor){
                          if(tuto.filtro.dificuldade == "Não importa" || tuto.filtro.dificuldade == "Qual a dificuldade do evento?"){
                            filtred[aux3] = tuto[i];
                            aux3++;
                          }else{
                            if(tuto[i].dificuldade == tuto.filtro.dificuldade){
                              filtred[aux3] = tuto[i];
                              aux3++;
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }else{
                if(tuto[i].genero == tuto.filtro.genero){
                  if(tuto.filtro.precof == "ambos"){
                    if(tuto.filtro.dificuldade == "Não importa" || tuto.filtro.dificuldade == "Qual a dificuldade do evento?"){
                      filtred[aux3] = tuto[i];
                      aux3++;
                    }else{
                      if(tuto[i].dificuldade == tuto.filtro.dificuldade){
                        filtred[aux3] = tuto[i];
                        aux3++;
                      }
                    }
                  }else{
                    if (tuto.filtro.precof == "gratis") {
                      if(tuto[i].preco ==  0 ){
                        if(tuto.filtro.dificuldade == "Não importa" || tuto.filtro.dificuldade == "Qual a dificuldade do evento?"){
                          filtred[aux3] = tuto[i];
                          aux3++;
                        }else{
                          if(tuto[i].dificuldade == tuto.filtro.dificuldade){
                            filtred[aux3] = tuto[i];
                            aux3++;
                          }
                        }
                      }
                    }
                    if (tuto.filtro.precof == "pago") {
                      if(tuto[i].precopor == '2' ){
                        tuto[i].preco = (tuto[i].preco.valueOf()/tuto[i].pmin.valueOf());
                        if(tuto[i].preco <=  tuto.filtro.precovalor){
                          if(tuto.filtro.dificuldade == "Não importa" || tuto.filtro.dificuldade == "Qual a dificuldade do evento?"){
                            filtred[aux3] = tuto[i];
                            aux3++;
                          }else{
                            if(tuto[i].dificuldade == tuto.filtro.dificuldade){
                              filtred[aux3] = tuto[i];
                              aux3++;
                            }
                          }
                        }
                      }else{
                        if(tuto[i].preco <=  tuto.filtro.precovalor){
                          if(tuto.filtro.dificuldade == "Não importa" || tuto.filtro.dificuldade == "Qual a dificuldade do evento?"){
                            filtred[aux3] = tuto[i];
                            aux3++;
                          }else{
                            if(tuto[i].dificuldade == tuto.filtro.dificuldade){
                              filtred[aux3] = tuto[i];
                              aux3++;
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
          if (filtred){
            //console.log("Tamanho do filtrado", filtred.length, aux3);
            resolve(filtred);
          }else {
            //console.log("nao volto nada");
            reject(filtred);
          }
        })
      },

      AtualizaEstrela: function() {
        //console.log("AtualizaEstrela")
        return $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarestrelaperfil.php').then(function(response) {
          items = response.data.success;
          //console.log(items, "AtualizaEstrela")
          return items;

        });
      },

      verificausername: function(user) {
        //console.log("AtualizaEstrela")
        return $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/api.php', {username : user.username}).then(function(response) {
          items = response.data;
          return items;

        });
      },

      CriaConta: function(user) {
        //console.log("AtualizaEstrela")
        return $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/api3.php', {username : user.username, email: user.email, password: user.password, apelido:user.apelido, idade:user.idade, genero: user.genero, profilepic:user.profilepic, devicetoken:user.devicetoken
        }).then(function(response) {
          items = response.data;
          return items;

        });
      },

      DesatulizaEstrela: function() {
        //console.log("DesatulizaEstrela")
        return $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/desatualizarestrelaperfil.php').then(function(response) {
          items = response.data.success;
          console.log(items, "DesatulizaEstrela")
          return items;

        });
      },

      AtualizaEstrelaPessoaevento: function() {
        //console.log("AtualizaEstrelaPessoaevento")
          $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarestrelapessoaevento.php').then(function(resp) {
            //console.log(resp.data.success);
          });
        
      },
      verificanome: function(user) {
        console.log(user);
      return $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/verificanome.php' , {username:user}).then(function(result) {
          console.log(result.data.success, "sucesso");
            return result.data.success;
          });
       }, //NAO EXISTE PHP

      atualizarsenha: function(user) {
      return $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/atualizarsenha.php' , {password:user.password, email:user.email}).then(function(result) {
          console.log(result.data.success, "sucesso");
            return result.data.success;
          });
       }, // NAO EXISTE PHP

      // signup: function(user) {
      // return $q(function(resolve, reject) {
      //   $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/api.php" , {email : user.email,
      //                     password : user.password,
      //                     username : user.username,
      //                     apelido : user.apelido,
      //                     idade : user.idade,
      //                     genero : user.genero,
      //                     profilepic : user.profilepic,
      //                     devicetoken : user.devicetoken}).then(function(result) {
      //     if (result.data.success == true){
      //       resolve(result.data.msg);
      //       } else {
      //       reject(result.data.msg);
      //       }
      //     });
      //   });
      //  },
      // entrar: function(useraux) {
      // return $q(function(resolve, reject) {
      //   $http.post(link , useraux).then(function(result) {
      //     if (result.data.success == true){
      //       resolve(result.data);
      //       } else {
      //       reject(result.data);
      //       }
      //     });
      //   });
      //  },

        Entrando: function(user) {
        //console.log("AtualizaEstrela")
        return $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/api2.php', {email: user.email, password: user.password}).then(function(response) {
          items = response.data;
          return items;

        });
      },

      Mudadevice: function(user) {
        //console.log("AtualizaEstrela")
        return $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/mudadevicetokenuser.php', {devicetoken: user.devicetoken, iduser: user.iduser}).then(function(response) {
            $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/mudadevicetokenpessoaevento.php', {devicetoken: user.devicetoken, iduser: user.iduser})
          items = response.data;
          return items;

        });
      },

      lastlogin: function(user) {
        //console.log("AtualizaEstrela")
        return $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/lastloginuser.php', {hj: user.hj, iduser: user.iduser}).then(function(response) {
          items = response.data;
          return items;

        });
      },

      getusuario: function(useraux) {
      return $q(function(resolve, reject) {
        $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/getusuario.php" , {username : useraux.username}).then(function(result) {
          //console.log(result.data[0].iduser);
          
          //console.log(result.data[0].msg);
            if (result.data != false){
            resolve(result.data[0]);
            } else {
            reject(result.data);
            }
          });
        });
       },

      getusuario2: function(useraux) {
      return $q(function(resolve, reject) {
        $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/getusuario.php" , {username : useraux}).then(function(result) {
          //console.log(result.data[0].iduser);
          
          //console.log(result.data[0].msg);
            if (result.data != false){
            resolve(result.data[0]);
            } else {
            reject(result.data);
            }
          });
        });
       },

      // confereconvite: function(codigo) {
      // return $q(function(resolve, reject) {
      //   $http.post("http://ec2-3-84-65-68.compute-1.amazonaws.com/confereconvite.php" , {codigo : codigo}).then(function(result) {
      //     //console.log(result.data[0].iduser);
          
      //     console.log(result.data.success, "result.data");
      //       if (result.data.success != false){
      //       resolve(result.data[0]);
      //       } else {
      //         console.log("fd")
      //       reject(result.data);
      //       }
      //     });
      //   });
      //  },

      confereconvite: function(codigo) {
        //console.log("confereconvite",codigo )
        return $http.post('http://ec2-3-84-65-68.compute-1.amazonaws.com/confereconvite.php', {codigo: codigo}).then(function(response) {
          items = response.data;
          if(items.success){
            console.log(items,"dasds")
          }
          console.log(items,"items")
          return items;

        });
      },

       MandaPushNoti: function(pushnoti) {
      // var header = {"Authorization": "key=AAAATsLpVfo:APA91bEph8ut7xPtKVJXPfK89IwDIRidGVkVKECccLpLPzNsd_YMuVkE7BXDNsvqvCUVyIbaMQ47ZFFAi2r7MeoKT2sjTfcIs_J9DAFYljwZeWsJaV_icyq07Jgf9uY6l0exIt9CmHNJ",
      //                                 "Content-Type": "application/json"}; //'Content-type': 'application/json'
        console.log(pushnoti.titulo, pushnoti.msg, pushnoti.token)
        var postParams = { 
                          "notification": {
                            "title": pushnoti.titulo,
                            "body": pushnoti.msg,
                            //"click_action":"FCM_PLUGIN_ACTIVITY",
                            //"icon":"fcm_push_icon"
                            },
                          "to": pushnoti.token
                          }
                          var js = JSON.stringify(postParams);
                          var req = {
                           method: 'POST',
                           url: 'https://fcm.googleapis.com/fcm/send',
                           headers: {
                             'Authorization': 'key=AAAATsLpVfo:APA91bEph8ut7xPtKVJXPfK89IwDIRidGVkVKECccLpLPzNsd_YMuVkE7BXDNsvqvCUVyIbaMQ47ZFFAi2r7MeoKT2sjTfcIs_J9DAFYljwZeWsJaV_icyq07Jgf9uY6l0exIt9CmHNJ',
                             'Content-Type': 'application/json'
                           },
                           data: js
                          }

                          //$http(req)
                          //console.log(JSON.stringify(postParams) , header)
        $http.defaults.headers.common.Authorization = 'key=AAAATsLpVfo:APA91bEph8ut7xPtKVJXPfK89IwDIRidGVkVKECccLpLPzNsd_YMuVkE7BXDNsvqvCUVyIbaMQ47ZFFAi2r7MeoKT2sjTfcIs_J9DAFYljwZeWsJaV_icyq07Jgf9uY6l0exIt9CmHNJ';
        return $http.post("https://fcm.googleapis.com/fcm/send", JSON.stringify(postParams)).then(function(result) {
//         curl -X POST -H "Authorization: key=<your_server_key>" -H "Content-Type: application/json" -d '{
//   "notification": {
//     "title": "New Article",
//     "body": "Firebase Cloud Messaging for Web using JavaScript",
//     "icon": "alarm.png",
//     "click_action": "http://rakibul.net/fcm-web-js"
//   },
//   "to": "<your_client_token>"
// }' "https://fcm.googleapis.com/fcm/send"

       // return $http.post('https://fcm.googleapis.com/fcm/send' , ).then(function(result) {
           console.log(result, "sucesso");
            return result;
          });
       },

      sendnotification: function() {
      // var header = {"Authorization": "key=AAAATsLpVfo:APA91bEph8ut7xPtKVJXPfK89IwDIRidGVkVKECccLpLPzNsd_YMuVkE7BXDNsvqvCUVyIbaMQ47ZFFAi2r7MeoKT2sjTfcIs_J9DAFYljwZeWsJaV_icyq07Jgf9uY6l0exIt9CmHNJ",
      //                                 "Content-Type": "application/json"}; //'Content-type': 'application/json'
        var postParams = { 
                          "notification": {
                            "title": "Borai",
                            "body": "Ultimo",
                            //"click_action":"FCM_PLUGIN_ACTIVITY",
                            //"icon":"fcm_push_icon"
                            },
                          "to": "dLog4Miyaus:APA91bGvWCPYoQHrp_VRWYziBa_PTM4cCzwhsKZqDd603hGpETg-iA8QShuJB4pp39KJ3CkI2gtCzFm02tCJcu1gba9cn9ojR4bE3xO_r_Y1SB87ydVBVFg5MwDtAgXU040Iif2dYagz"
                          }
                          var js = JSON.stringify(postParams);
                          var req = {
                           method: 'POST',
                           url: 'https://fcm.googleapis.com/fcm/send',
                           headers: {
                             'Authorization': 'key=AAAATsLpVfo:APA91bEph8ut7xPtKVJXPfK89IwDIRidGVkVKECccLpLPzNsd_YMuVkE7BXDNsvqvCUVyIbaMQ47ZFFAi2r7MeoKT2sjTfcIs_J9DAFYljwZeWsJaV_icyq07Jgf9uY6l0exIt9CmHNJ',
                             'Content-Type': 'application/json'
                           },
                           data: js
                          }

                          //$http(req)
                          //console.log(JSON.stringify(postParams) , header)
        $http.defaults.headers.common.Authorization = 'key=AAAATsLpVfo:APA91bEph8ut7xPtKVJXPfK89IwDIRidGVkVKECccLpLPzNsd_YMuVkE7BXDNsvqvCUVyIbaMQ47ZFFAi2r7MeoKT2sjTfcIs_J9DAFYljwZeWsJaV_icyq07Jgf9uY6l0exIt9CmHNJ';
        return $http.post("https://fcm.googleapis.com/fcm/send", JSON.stringify(postParams)).then(function(result) {
//         curl -X POST -H "Authorization: key=<your_server_key>" -H "Content-Type: application/json" -d '{
//   "notification": {
//     "title": "New Article",
//     "body": "Firebase Cloud Messaging for Web using JavaScript",
//     "icon": "alarm.png",
//     "click_action": "http://rakibul.net/fcm-web-js"
//   },
//   "to": "<your_client_token>"
// }' "https://fcm.googleapis.com/fcm/send"

       // return $http.post('https://fcm.googleapis.com/fcm/send' , ).then(function(result) {
           console.log(result, "sucesso");
            return result;
          });
       }
      
    }
 })



.factory('BlankFactory', [function(){

}])

.service('BlankService', [function(){

}]);
