# Change Log

## v1.0.2

- Support commonjs

## v1.0.2

- Move dependencies into devDependencies

## v1.0.1

### Bug fixes
* fix(toArrayFilter): handle non-objects 9bc79dd1
* fix(toArrayFilter): ignore 'undefined' and `null` for better binding support  *Brian Gray*    **8bfd99c8**

## v1.0.0

First release